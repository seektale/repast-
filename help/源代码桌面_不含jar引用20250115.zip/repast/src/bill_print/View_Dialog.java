package bill_print;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import root.Front;
public class View_Dialog extends JDialog{
	private static final long serialVersionUID = -7513552125839358803L;
	//账单预览对话框，如果对话框采用dispose()的方法，第次预览将占用两兆内存
	public View_Dialog(){
		super(Front.front,"帐单视图  Bill View",true);
		addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent k){
				//响应回车键
				if(k.getKeyCode()==KeyEvent.VK_ENTER){
					setVisible(false);
				}
				//按ESC键退出
				else if(k.getKeyCode()==KeyEvent.VK_ESCAPE){
					setVisible(false);
				}
			}
		});
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	public void to(JPanel p){
		//获取用户屏幕大小
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		//因为操作系统有任务栏，高度要减一些;最高限制为900；		A4纸的边595 mn 842
		int n=screenSize.height-30;
		if(n>900)	n=900;
		//保持比例美观
		double m=n/1.44;
		setSize((int)m,n);
		
		setContentPane(p);
		setLocationRelativeTo(null);//初始位置在屏幕正中间
		setVisible(true);
	}
}