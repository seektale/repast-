package desk_ago;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import pub.DateUI;
import pub.ModifiedFlowlayout;
import pub.Var;
import root.Front;
import root.Sql;
public class Query_group extends JDialog implements ActionListener{
	private static final long serialVersionUID = -7911151577088045362L;
	private JTable t;
	
	private String sql_style="";	//结账方式
	private String deskdiv="";		//餐区
	private String sql_part="";		//餐段
	private String sql_time="";		//时间
	
	private JTextField times1=gette();
	private JTextField times2=gette();
	private JTextField timee1=gette();
	private JTextField timee2=gette();
	
	private JTextArea sqltext=new JTextArea(6,6);
	private JButton view_sql=new JButton("View Sql");
	private JButton sel=new JButton("查询");
	private JButton clo=new JButton("返回");
	
	private desk_div ddiv=new desk_div();
	private meal_part mp=new meal_part();
	private bills bo=new bills();
	Query_group(JTable t){
		super(new JFrame(),true);
		this.t=t;
		setTitle("组合查询");
		setSize(620,400);					
		setLocationRelativeTo(null);	//初始位置在屏幕正中间
		setResizable(false);
		JPanel con=new JPanel(new BorderLayout());
		setContentPane(con);

		//传入参数：中文名与英文名
		JPanel cen=new JPanel(new BorderLayout());
		cen.add(getPan(),BorderLayout.NORTH);
		con.add(cen,BorderLayout.CENTER);
		
		JPanel cen1=new JPanel(new BorderLayout());
		cen1.add(getbillstyle(),BorderLayout.NORTH);
		cen.add(cen1,BorderLayout.CENTER);
		
		JPanel cen2=new JPanel(new BorderLayout());
		cen2.add(getdiv(),BorderLayout.NORTH);
		cen1.add(cen2,BorderLayout.CENTER);
		
		JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT,3,0));
		nor.setBorder(Sql.getBorder(2, "日期"));
		nor.add(new JLabel("开台日期:"));
		nor.add(times1);
		nor.add(new JLabel("<-->"));
		nor.add(times2);
		nor.add(new JLabel(" 结账日期:"));
		nor.add(timee1);
		nor.add(new JLabel("<-->"));
		nor.add(timee2);
		JPanel cen3=new JPanel(new BorderLayout());
		cen3.add(nor,BorderLayout.NORTH);
		cen2.add(cen3,BorderLayout.CENTER);
		
		sqltext.setLineWrap(true);
		sqltext.setWrapStyleWord(true);
		JPanel cen4=new JPanel(new BorderLayout());
		cen4.add(new JScrollPane(sqltext),BorderLayout.NORTH);
		cen3.add(cen4,BorderLayout.CENTER);
		
		//南面
		JPanel sou=new JPanel(new FlowLayout(FlowLayout.RIGHT));
		sou.add(view_sql);
		sou.add(sel);
		sou.add(clo);
		view_sql.addActionListener(this);
		sel.addActionListener(this);
		clo.addActionListener(this);
		con.add(sou,BorderLayout.SOUTH);
		setVisible(true);
	}
	private JTextField gette(){
		final JTextField te=new JTextField(8);
		te.setEditable(false);
		te.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DateUI du = new DateUI();
				te.setText(du.toString());
			}
		});
		te.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				DateUI du = new DateUI();
				te.setText(du.toString());
			}
		});
		return te;
	}
	
	//餐区过滤
	private JPanel getPan(){
		JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT,3,0));
		nor.setBorder(Sql.getBorder(2, "区域过虑"));
		for(String temp : Var.area()){
			JCheckBox b=new JCheckBox(temp);
			b.addActionListener(ddiv);
			nor.add(b);
		}
		nor.setToolTipText("对区域未做任何选择时，查询的结果将包含所有区域。");
		return nor;
	}
	
	//结算方式过滤
	private JPanel getbillstyle(){
		//JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT,3,0));
		JPanel nor=new JPanel(new ModifiedFlowlayout(FlowLayout.LEFT,3,5));
		nor.setBorder(Sql.getBorder(2, "结算方式"));
		String style[]=Sql.getString("select DISTINCT 结算方式 from billstyle", this);
		for(String temp : style){
			JCheckBox b=new JCheckBox(temp);
			b.addActionListener(bo);
			nor.add(b);
		}
		return nor;
	}
	
	//时段
	private JPanel getdiv(){
		JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT,3,0));
		nor.setBorder(Sql.getBorder(2, "时段"));
		String div[]=Sql.getString("select DISTINCT 选择时段 from hqdeskgo", this);
		for(String temp : div){
			JCheckBox b=new JCheckBox(temp);
			b.addActionListener(mp);
			nor.add(b);
		}
		return nor;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==view_sql){
			if((times1.getText().isEmpty())&&(times2.getText().length()>0)){
				JOptionPane.showMessageDialog(Front.front,"当对开台时间的终止时间作了定义时，其起始时间不能为空！");
				return ;
			}
			if((timee1.getText().isEmpty())&&(timee2.getText().length()>0)){
				JOptionPane.showMessageDialog(Front.front,"当对结账时间的终止时间作了定义时，其起始时间不能为空！");
				return ;
			}

			String val="select 台次,开台时间,开台工号,结账时间,结账工号,区域,台号,别名,选择时段 from hqdeskgo \n";
			
			//结账方式
			if(sql_style.length()>3){
				val=val+"where 台次 in (select 台次 from billstyle where ("+sql_style.substring(3)+")) \n";
			}
			
			//餐区选择
			if(deskdiv.length()>3){
				if(val.indexOf("where")==-1){
					val=val+"where ("+deskdiv.substring(3)+") \n";
				}
				else{
					val=val+"and ("+deskdiv.substring(3)+") \n";
				}
			}
			
			//餐段条件
			if(sql_part.length()>3){
				if(val.indexOf("where")==-1){
					val=val+"where ("+sql_part.substring(3)+") \n";
				}
				else{
					val=val+"and ("+sql_part.substring(3)+") \n";
				}
			}
			
			//时间条件
			ortime();	//初始化sql_time值
			if(!sql_time.isEmpty()){
				if(val.indexOf("where")==-1){
					val=val+"where ("+sql_time+") ";
				}
				else{
					val=val+"and ("+sql_time+") ";
				}
			}
			
			//先要清空内容
			sqltext.setText("");
			sqltext.setText(val+" limit 0,300; \n#最多返回前300行数据,因为特别情况下不建议将hqbill表的全部数据返回");
		}
		else if(e.getSource()==sel){
			view_sql.doClick();
			Sql.getArrayToTable(sqltext.getText(), this, t);
			Sql.TableAtt(t, true, false);
		}
		else if(e.getSource()==clo){
			dispose();
		}
	}
	private void ortime(){
		String m="",n="";
		//开台时间都作了选择
		if((times1.getText().length()>0)&&(times2.getText().length()>0)){
			m="date(开台时间)>'"+times1.getText()+"' and date(开台时间)<'"+times2.getText()+"'";
		}
		//仅开台时间的起始时间作了选择
		else if(times1.getText().length()>0){
			m="date(开台时间)='"+times1.getText()+"'";
		}

		//结账时间都作了选择
		if((timee1.getText().length()>0)&&(timee2.getText().length()>0)){
			n="date(结账时间)>'"+timee1.getText()+"' and date(结账时间)<'"+timee2.getText()+"'";
		}
		//仅结账时间的起始时间作了选择
		else if(timee1.getText().length()>0){
			n="date(结账时间)='"+timee1.getText()+"'";
		}
		
		if((!m.isEmpty())&&(!n.isEmpty())){
			sql_time=m+" and "+n;
		}
		else{
			sql_time=m+n;
		}
	}
	
	//结账方式对应的sql语句
	class bills implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JCheckBox temp=(JCheckBox)e.getSource();
			if(temp.isSelected()){
				sql_style=sql_style+"or 结算方式='"+temp.getText()+"' ";
			}
			else{
				sql_style=sql_style.replace("or 结算方式='"+temp.getText()+"' ", "");
			}
		}
	}
	
	//餐段
	class meal_part implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JCheckBox temp=(JCheckBox)e.getSource();
			if(temp.isSelected()){
				sql_part=sql_part+"or 选择时段='"+temp.getText()+"' ";
				return ;
			}
			sql_part=sql_part.replace("or 选择时段='"+temp.getText()+"' ", "");
		}
	}
	
	//餐区选择
	class desk_div implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JCheckBox temp=(JCheckBox)e.getSource();
			if(temp.isSelected()){
				deskdiv = deskdiv+"or 区域='"+temp.getText()+"' ";
				return ;
			}
			deskdiv=deskdiv.replace("or 区域='"+temp.getText()+"' ", "");
		}
	}
}
