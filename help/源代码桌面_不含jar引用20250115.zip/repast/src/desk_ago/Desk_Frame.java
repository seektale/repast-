package desk_ago;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import bill_print.Print_pan;
import root.Front;
import root.Sql;
public class Desk_Frame extends JInternalFrame implements ActionListener{
	private static final long serialVersionUID = -3266159011449849443L;
	//Meal_Count变量的值为0时表示“未开台”，否则表示其它三种情况(“已开台”、“未班结”、“已班结”)
	public String area, index, alias ; 
	public String Meal_num; 	// 餐次，即bill表中的主键
	
	private Dish  myDish;
	private JTable his,pri;
	private JPanel Pan=new JPanel(new BorderLayout(12,12));
	private JPanel southPan=new JPanel(new FlowLayout());
	
	private JButton start		= init_Button("开台信息",KeyEvent.VK_G);
	private JButton food		= init_Button("商品查看",KeyEvent.VK_U);
	private JButton history		= init_Button("操作记录",KeyEvent.VK_H);
	private JButton printjob	= init_Button("出单记录",KeyEvent.VK_P);
	private JButton billprint	= init_Button("打印账单",KeyEvent.VK_P);
	private JButton billover	= init_Button("结账记录",KeyEvent.VK_P);
	private JButton exit		= init_Button("退出管理",KeyEvent.VK_Q);
	
	public Desk_Frame(String MCount){
		super("",true,true,true,true);
		String sql="select 区域,台号,别名 from hqdeskgo where 台次="+MCount;
		String temp[]=Sql.getString(sql, this);
		if(temp.length>0){
			area=temp[0];
			index=temp[1];
			alias=temp[2];
			Meal_num=MCount;
			init();
		}
		else{
			JOptionPane.showMessageDialog(Front.front,"台次："+MCount+" 在班结表hqbill中不存在!");
			dispose();
		}
	}
	public void init(){
		setTitle("历史台号：" + area + index +"号台  "+ alias);
		setLayer(1);	//默认层数为0,数字大，在上面,这里是进入餐台，所以要在上面
		setContentPane(Pan);
		setOpaque(false);
		setSize(Front.inFrame.getSize());
		setVisible(true);
		
		Pan.add(new JLabel(),BorderLayout.NORTH);
		Pan.add(new JLabel(),BorderLayout.EAST);
		Pan.add(new JLabel(),BorderLayout.WEST);
		Pan.add(southPan,BorderLayout.SOUTH);
		Pan.add(new JLabel(),BorderLayout.CENTER);
		southPan.setBackground(Color.lightGray);
		
    	food.doClick();
	}
	
	private JButton init_Button(String s,int c){
		JButton b=new JButton(s+"("+(char)c+")");
		b.addActionListener(this);
		b.setMnemonic(c);
		southPan.add(b);
		return b;
	}
	public void actionPerformed(ActionEvent e){
		//开台
		if(e.getSource()==start){
			final Desk_oldstart temp=new Desk_oldstart(Meal_num,area,index,alias);
			temp.setPreferredSize(new Dimension(450,420));
			JOptionPane.showMessageDialog(Front.front, temp, "开台信息", 1, new ImageIcon());
		}
		if(e.getSource()==billprint){
			//直接使用desk_portal中的打印类
			final Print_pan temp = new Print_pan(Integer.valueOf(Meal_num));
			JOptionPane.showMessageDialog(Front.front, temp, "打印账单", 1, new ImageIcon());
		}
		if(e.getSource()==billover){
			JPanel bill=new JPanel(new BorderLayout(0,10));
			bill.setPreferredSize(new Dimension(450,160));
			
			String des[] = Sql.getString("select bill_discribea("+Meal_num+")", this);
			JLabel la=new JLabel();
			la.setBorder(Sql.getBorder(2, ""));
			la.setFont(new Font("",Font.BOLD,18));
		    la.setForeground(Color.BLUE);
			if(des.length>0) la.setText(des[0]);
			bill.add(la,BorderLayout.NORTH);

			JTable t = Sql.getTable();
			Sql.getArrayToTable("select * from billstyle where 台次="+Meal_num, this, t);
			Sql.TableAtt(t, true, false);
			bill.add(new JScrollPane(t),BorderLayout.CENTER);
			
			JOptionPane.showMessageDialog(Front.front, bill, "结账信息", 1, new ImageIcon());
		}
		//查看已点菜品
		else if(e.getSource()==food){
			if(myDish==null) myDish=new Dish(Meal_num);
			cardshow(myDish,(JButton)e.getSource());
		}
		//查看操作历史
		else if(e.getSource()==history){
			if(his==null){
				his=Sql.getTable("select * from hqdishlog where 台次="+Meal_num, Sql.getTable(), this, true);
			}
			JScrollPane temp=new JScrollPane(his);
			Sql.TableAtt(his, true, false);
			cardshow(temp,(JButton)e.getSource());
		}
		//查看出单
		else if(e.getSource()==printjob){
			if(pri==null){
				pri=Sql.getTable("select * from print_job where meal_count="+Meal_num, Sql.getTable(), this, true);
			}
			JScrollPane temp=new JScrollPane(pri);
			Sql.TableAtt(pri, true, false);
			cardshow(temp,(JButton)e.getSource());
		}
		//关闭该桌台对话框
		else if(e.getSource()==exit){
			dispose();
		}
	}
	private void cardshow(JComponent com,JButton b){
		Pan.remove(4);
		Pan.add(com,BorderLayout.CENTER);
		Pan.setVisible(false);
		Pan.setVisible(true);
	}
}

