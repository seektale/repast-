package desk_ago;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import pub.Popup_tab;
import root.Front;
import root.Sql;
public class Dish extends JSplitPane implements ActionListener,MouseListener{
	private static final long serialVersionUID = -7436024886627445531L;
	private JRadioButton Standard 	= new JRadioButton("有效商品");		//单选
	private JRadioButton invalid 	= new JRadioButton("失效商品");
	private JRadioButton alldish 	= new JRadioButton("所有商品");
	private JCheckBox 	 cardmodel 	= new JCheckBox("卡片模式");
	
	private JPanel Card	= new JPanel(new CardLayout());
	public  JTable cookup=Sql.getTable();		//该桌台菜品表格
	public  JTable cookdown=Sql.getTable();		//菜品日志
	private DishCard dc=new DishCard(this);
	
	private String Mealnum;
	public Dish(String Mealnum){
		this.Mealnum=Mealnum;
		setOneTouchExpandable(true);
		setOrientation(JSplitPane.VERTICAL_SPLIT);
	    setDividerSize(6);
	    setOpaque(false);
	    
	    JPanel lei=new JPanel(new FlowLayout(FlowLayout.LEFT,10,2));
	    lei.setBorder(Sql.getBorder(2, ""));
	    lei.add(Standard);
	    lei.add(invalid);
	    lei.add(alldish);
	    lei.add(cardmodel);
	    
	    JPanel chomode=new JPanel(new FlowLayout(FlowLayout.LEFT,5,2));
	    chomode.add(lei);
	    Standard.addActionListener(this);
	    invalid.addActionListener(this);
	    alldish.addActionListener(this);

	    ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
	    radioGroup.add(Standard);
	    radioGroup.add(invalid);
	    radioGroup.add(alldish);
	    
	    cookup.setComponentPopupMenu(new Popup_tab(cookup));
	    cookup.addMouseListener(this);
	    Card.add(new JScrollPane(cookup),"表格模式");
	    JScrollPane js=new JScrollPane(dc);
		js.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
	    Card.add(js,"卡片模式");
	    JPanel lc=new JPanel(new BorderLayout());
	    lc.add("Center",Card);
	    lc.add("South",chomode);
	    
		setLeftComponent(lc);
		setRightComponent(new JScrollPane(cookdown));
		setSize(Front.inFrame.getSize());
		setDividerLocation(0.7d);
		
		alldish.setSelected(true);	//默认显示所有商品
		cardmodel.addActionListener(this);
		
		refresh();
	}
	public void refresh(){
		if(Standard.isSelected())		Standard.doClick();
		else if(invalid.isSelected())	invalid.doClick();
		else if(alldish.isSelected())	alldish.doClick();
	}
	public JRadioButton currentwho(){
		if(Standard.isSelected())		return Standard;
		else if(invalid.isSelected())	return invalid;
		else return alldish;
	}
	private void setfalse(){
		if(cardmodel.isSelected()){
			dc.refresh();
			((CardLayout)Card.getLayout()).show(Card, "卡片模式");
		}
		else{
			((CardLayout)Card.getLayout()).show(Card, "表格模式");
		}
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==cardmodel){
			refresh();
		}
		else if(e.getSource()==Standard){
			String sql="select * from hqdish where 台次="+Mealnum+" and 属性=''";
			Sql.getTable(sql, cookup, this, true);
			setfalse();
		}
		else if(e.getSource()==invalid){
			String sql="select * from hqdish where 台次="+Mealnum+" and 属性<>''";
			Sql.getTable(sql, cookup, this, true);
			setfalse();
		}
		else if(e.getSource()==alldish){
			Sql.getTable("select * from hqdish where 台次="+Mealnum, cookup, this, true);
			setfalse();
		}
	}
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		//处理单击事件,显示日志信息
		int m=cookup.getSelectedRow();
		if (m!=-1){
			String sql=Sql.getval(cookup, "索引", m);
			Sql.getArrayToTable("select * from hqdishlog where 商品索引="+sql, this, cookdown);
			Sql.TableAtt(cookdown, true, false);
        }
	}
	public void mouseReleased(MouseEvent e) {}
}
