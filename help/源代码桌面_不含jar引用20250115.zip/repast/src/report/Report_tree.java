package report;
import java.util.HashSet;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.*;

import root.Sql;
public class Report_tree extends JTree implements TreeSelectionListener {
	private static final long serialVersionUID = 596173890639226995L;
	private JTable t ;
	public Report_tree(JTable t) {
		super(new DefaultMutableTreeNode("报表分类"));
		this.t = t ;
		setEditable(true);
		setOpaque(false);
		addTreeSelectionListener(this);
		setEditable(false);		//这样节点不会出现编辑状态
		refresh();
	}
	
	//刷新节点
	public void refresh(){
		//由DefaultTreeModel的getRoot()方法取得根节点.
		DefaultTreeModel treeModel = (DefaultTreeModel) getModel();
		DefaultMutableTreeNode rootNode = (DefaultMutableTreeNode) treeModel.getRoot();
		
		rootNode.removeAllChildren();	//删除所有子节点
		
		//读取并更新数据
		JTable val=Sql.getTable("select item,value from general where name='report' order by item,value;", this);
		HashSet<String> hs=new HashSet<String>();
		DefaultMutableTreeNode su=null;
		for(int m=0;m<val.getRowCount();m++){
			String str=val.getValueAt(m, 0).toString();
			//HashSet的好处在于没有重复值，否则插入失败
			boolean b=hs.add(str);
			if(b){
				su = new DefaultMutableTreeNode(str);
				rootNode.add(su);
			}
			DefaultMutableTreeNode insu = new DefaultMutableTreeNode(val.getValueAt(m, 1));
			su.add(insu);
		}
		treeModel.reload();		//刷新节点
	}
	
	//节点焦点发生变化时
	public void valueChanged(TreeSelectionEvent e) {
		//是否为叶子节点
		if(leaf()) return ;
		
		//考虑当前选中对象是父节点的情况
		String dep=selected();
		String temp="select value from general where name='report' and item='"+dep+"';";
		Sql.getArrayToTable(temp, this, t);
	}
	
	//返回当前选中的部门名称
	public String selected(){
		TreePath treepath = getSelectionPath();
		if (treepath != null){
			DefaultMutableTreeNode selectedNode=(DefaultMutableTreeNode)treepath.getLastPathComponent();
			return selectedNode.toString();
		}
		return "";
	}
	//返回当前选中的部门是否是叶子节点
	public boolean leaf(){
		TreePath treepath = getSelectionPath();
		if (treepath != null){
			DefaultMutableTreeNode selectedNode=(DefaultMutableTreeNode)treepath.getLastPathComponent();
			return selectedNode.isLeaf();
		}
		return false;
	}
}

