package report;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import pub.*;
import root.Front;
import root.Sql;
public class Report_short extends JDialog implements ActionListener{
	private static final long serialVersionUID = -1193669964168673L;
	private JTable t = Sql.getTable();
	private ButtonGroup radioGroup = new ButtonGroup();
	private JPanel com = new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JSplitPane jp = new JSplitPane();
	public Report_short(){
		super(Front.front, "收银快捷报表 (未班结)", true);
		String sql = "select DISTINCT 结账工号 from deskgo where not isnull(结账时间)";
		String[] ss = Sql.getString(sql, this);
		
		JPanel left=new JPanel(new ModifiedFlowlayout(FlowLayout.LEFT));
		for(int k=0;k<ss.length;k++){
			JButton temp=new JButton(ss[k]);
			temp.addActionListener(this);
			temp.setPreferredSize(new Dimension(120,30));
			left.add(temp);
		}
		JScrollPane lefts=new JScrollPane(left);
		lefts.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
		jp.setRightComponent(lefts);
		
		sql = "select value,remark from general where name ='report' and value like '%#' ";
		ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
		for(String temp[] : arr){
			final JRadioButton R=new JRadioButton(temp[0]);
			R.setActionCommand(temp[1]);
			R.setSelected(true); //只有第一个会生效
			R.addActionListener(this);
			com.add(R);
			radioGroup.add(R);
		}
		
		// 恢复一次可以选择多行
		t.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		
		JPanel right = new JPanel(new BorderLayout());
		right.add(new JScrollPane(t),BorderLayout.CENTER);
		right.add(com,BorderLayout.SOUTH);
		jp.setLeftComponent(right);
		
		jp.setDividerSize(7);
		jp.setOneTouchExpandable(true);
		jp.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
		
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
		    	jp.setDividerLocation(0.83d);
		    }
		});
		
		JPanel conroot = new JPanel(new BorderLayout(10,10));
		conroot.add(jp, BorderLayout.CENTER);
		conroot.add(new JLabel(),BorderLayout.EAST);
		conroot.add(new JLabel(),BorderLayout.WEST);
		conroot.add(new JLabel(),BorderLayout.NORTH);
		conroot.add(new JLabel(),BorderLayout.SOUTH);
		
		setContentPane(conroot);
		setSize(820,520);
		setLocationRelativeTo(null); //初始位置在屏幕正中间
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Front.logo);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() instanceof JRadioButton){
			final JRadioButton temp = (JRadioButton)e.getSource();
			if(how(temp.getActionCommand())){
				jp.setDividerLocation(0.83d);
				while(t.getRowCount()>0) ((DefaultTableModel)t.getModel()).removeRow(0);
				((DefaultTableModel)t.getModel()).setColumnIdentifiers(new String[]{});
			}
			else{
				jp.setDividerLocation(1d);
				Sql.getArrayToTable(temp.getActionCommand(), this, t);
				Sql.TableAtt(t, true, false);
			}
			return ;
		}
		
		if(radioGroup.getSelection()==null){
			JOptionPane.showMessageDialog(Front.front, "未选择报表名称");
			return ;
		}
		
		String cmd = radioGroup.getSelection().getActionCommand();
		if(how(cmd)){
			cmd = cmd.replace("@String", e.getActionCommand());
			Sql.getArrayToTable(cmd, this, t);
			Sql.TableAtt(t, true, false);
		}
		else{
			radioGroup.clearSelection();
		}
	}
	
	private boolean how(String sql){
		int k=sql.indexOf("\n");	//读取第一行数据
		String val = "" ;
		if(k>0){
			val = sql.substring(0,k);
		}
		if(val.startsWith("#") && val.contains("@String")){
			return true;
		}
		return false;
	}
}
