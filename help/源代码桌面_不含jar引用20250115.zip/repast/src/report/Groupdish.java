package report;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import pub.DateUI;
import root.Front;
import root.Sql;
public class Groupdish extends JDialog implements ActionListener,MouseListener{
	private static final long serialVersionUID = 2323602568904711269L;
	private JPanel con = new JPanel(new BorderLayout(3,3));
	private JTextField from = new JTextField(8);
	private JTextField to   = new JTextField(8);
	private JRadioButton day = new JRadioButton("按天");
	private JRadioButton week = new JRadioButton("按周");
	private JRadioButton month = new JRadioButton("按月");
	private JRadioButton year = new JRadioButton("按年");
	private JTextArea sqltip = new JTextArea(4,6);
	private JButton ok = new JButton("查询");
	private JButton exit = new JButton("退出");
	private ArrayList<JLabel> sequence = new ArrayList<JLabel>();	//分组顺序提示标签
	private ArrayList<JLabel> parameter = new ArrayList<JLabel>();	//选择的参数
	private ArrayList<String> groupval = new ArrayList<String>();	//选择的组
	private JTable t;
	public Groupdish(JTable t){
		super(Front.front, true);
		this.t=t;
		JPanel nor = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JPanel left = new JPanel(new GridLayout(10, 1, 2, 2));
		JPanel cen = new JPanel(new GridLayout(10, 1, 2, 2));
		JPanel right = new JPanel(new GridLayout(10, 1, 2, 2));
		JPanel sou = new JPanel(new BorderLayout());
		sou.add(new JScrollPane(sqltip),BorderLayout.CENTER);
		JPanel radio = new JPanel(new FlowLayout(FlowLayout.LEFT));
		radio.add(new JLabel("时间段分组选择:"));
		radio.add(day);
		radio.add(week);
		radio.add(month);
		radio.add(year);
		sou.add(radio,BorderLayout.NORTH);
		JPanel soubut = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		soubut.add(ok);
		soubut.add(exit);
		sou.add(soubut,BorderLayout.SOUTH);
		ok.addActionListener(this);
		exit.addActionListener(this);
		sqltip.setBackground(Color.LIGHT_GRAY);
		sqltip.setEditable(false);
		sqltip.setWrapStyleWord(true);
		sqltip.setLineWrap(true);
		sqltip.setText("默认情况下只查询<属性>为空的商品，即只查询有效商品\n如需输入空字符串,可使用空格代替\n" +
					   "注意：这里的时间(按天,按周,按月,按年)是相对于<点单时间>,而非<结账时间>");
		sqltip.setCaretPosition(0);
		nor.add(new JLabel("开始日期:"));
		nor.add(from);
		nor.add(new JLabel("结束日期:"));
		nor.add(to);
		day.setSelected(true);
		from.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent arg0) {
				DateUI d = new DateUI();
				if(d.toString().isEmpty()) return ;
				from.setText(d.toString());
			}
		});
		to.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent arg0) {
				DateUI d = new DateUI();
				if(d.toString().isEmpty()) return ;
				to.setText(d.toString());
			}
		});
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		from.setText(df.format(new Date()));
		to.setText(df.format(new Date()));
		ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
	    radioGroup.add(day);
	    radioGroup.add(week);
	    radioGroup.add(month);
	    radioGroup.add(year);
		
		JLabel tip = new JLabel(" 分组顺序 ",JLabel.CENTER);
		tip.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));
		right.add(tip);
		
		tip = new JLabel("亦可指定某一个参数(AND关系)",JLabel.CENTER);
		tip.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));
		cen.add(tip);
		
		tip = new JLabel(" 选择分组顺序 ");
		tip.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));
		left.add(tip);
		String val[]=new String[]{"属性","科目","分类","小类","商品名","单位","实价","折扣","点单员"};
		for(String temp : val){
			JCheckBox ch = new JCheckBox(temp);
			ch.addActionListener(this);
			left.add(ch);
			
			JLabel lab = new JLabel("",JLabel.RIGHT);
			sequence.add(lab);
			right.add(lab);
			
			lab = new JLabel("",JLabel.CENTER);
			lab.setBackground(Color.PINK);
			lab.setOpaque(true);
			lab.setName(temp);
			lab.addMouseListener(this);
			parameter.add(lab);
			cen.add(lab);
		}
		
		con.add(nor,BorderLayout.NORTH);
		con.add(left,BorderLayout.WEST);
		con.add(cen,BorderLayout.CENTER);
		con.add(right,BorderLayout.EAST);
		con.add(sou,BorderLayout.SOUTH);
		con.setBorder(BorderFactory.createTitledBorder(""));
		
		setContentPane(con);
		setTitle("商品消费分组统计查询");
		setSize(380, 480);
		setLocationRelativeTo(Front.inFrame);	// 相对谁居中
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Front.logo);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == ok){
			if(timeCheck()) return ;
			String group = "";
			String select = "";
			String selectnull = "";
			//默认情况下只查询属性为空的商品，即只查询有效商品
			String where = " where 点单时间>='"+from.getText()+"' and 点单时间<='"+to.getText()+"' and 属性='' ";
			if(day.isSelected()){
				group = "group by 日期 ";
				select = "SELECT date(`点单时间`) AS 日期,sum(数量) as 商品数量 ";
			}
			if(week.isSelected()){
				group = "group by 星期 ";
				select = "SELECT date_format(点单时间,'%x年-第%v周') AS 星期,sum(数量) as 商品数量 ";
			}
			if(month.isSelected()){
				group = "group by 月份 ";
				select = "SELECT date_format(点单时间,'%Y-%m') as 月份,sum(数量) as 商品数量 ";
			}
			if(year.isSelected()){
				group = "group by 年份 ";
				select = "SELECT year(点单时间) as 年份,sum(数量) as 商品数量 ";
			}
			selectnull = "SELECT '统计：',sum(数量) ";
			
			//分组group
			for(String temp : groupval){
				group = group + "," + temp ;
			}
			//要查询的列select
			String getcol[] = getcol();
			for(String temp : getcol){
				select = select + "," + temp ;
				selectnull = selectnull + ",''" ;
			}
			if(select.contains("属性")){		//如查对属性有要求，则应取消对属性的限制
				where = where.replace("and 属性=''", "");
			}
			
			//查询条件where
			for(JLabel lab : parameter){
				if(lab.getText().isEmpty())	continue ;
				where = where + "and " + lab.getName() + "='"+lab.getText()+"' ";
			}
			
			
			String sql = ",sum(实价*数量*折扣) as 收入_不含账单折扣 from hqdish ";
			sql =select+sql+where+group +" union "+ selectnull+sql+where;
			
			sqltip.setText(sql);
			Sql.getArrayToTable(sql, this, t);
			Sql.TableAtt(t, true, true);
			return ;
		}
		if(e.getSource() == exit){
			dispose();
			return ;
		}
		if(e.getSource() instanceof JCheckBox){
			JCheckBox ch = (JCheckBox)e.getSource();
			if(ch.isSelected()){
				groupval.add(ch.getText());
				showsequence();
			}
			else{
				groupval.remove(ch.getText());
				showsequence();
			}
		}
	}
	
	private boolean timeCheck(){
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		try{
		    Date mm = df.parse(from.getText());
		    Date nn = df.parse(to.getText());
		    long k = mm.getTime() - nn.getTime();
		    if(k>0){
		    	JOptionPane.showMessageDialog(this, "开始时间不能大于结束时间", "时间段选择错误", 0);
		    	return true ;
		    }
		}
		catch (Exception e){
			JOptionPane.showMessageDialog(this, e.getMessage(), "时间段值<格式>不正确", 0);
			return true ;
		}
		return false ;
	}
	
	private void showsequence(){
		for(JLabel temp : sequence){
			temp.setText("");
		}
		for(int k=0; k<groupval.size(); k++){
			sequence.get(k).setText(groupval.get(k));
		}
	}
	
	private String[] getcol(){
		HashSet<String> hs = new HashSet<String>();
		for(String temp : groupval){
			hs.add(temp);
		}
		for(JLabel lab : parameter){
			if(lab.getText().isEmpty())	continue ;
			hs.add(lab.getName());
		}
		String val[] = new String[hs.size()];
		hs.toArray(val);
		return val;
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		JLabel lab = (JLabel)e.getSource();
		if(e.getButton() == MouseEvent.BUTTON3){
			lab.setText("");
			return ;
		}
		
		String sql = lab.getName();
		
		if(sql.equals("商品名")){
			String val=JOptionPane.showInputDialog(this, "请输入商品名：");
			if(val==null) return ;
			lab.setText(val);
			return ;
		}
		if(sql.equals("实价")){
			String val=JOptionPane.showInputDialog(this, "请输入商品价格：");
			if(val==null) return ;
			lab.setText(val);
			return ;
		}
		
		sql = " select DISTINCT "+sql+" from hqdish ";
		String res[] = Sql.getString(sql, this);
		JPanel pan = new JPanel(new GridLayout(res.length/10+1, 10));
		if(res.length<10) pan.setLayout(new FlowLayout());
		else if(res.length%10==0) pan.setLayout(new GridLayout(res.length/10, 10));
		
		ButtonGroup  rg	= new ButtonGroup();
		for(String temp : res){
			if(temp.isEmpty()) continue;
			JRadioButton rad = new JRadioButton(temp);
			rad.setActionCommand(temp);
			rg.add(rad);
			pan.add(rad);
		}
		int k = JOptionPane.showConfirmDialog(this, pan, "请选择一个对象", 2, 1, new ImageIcon());
		if(k==0 && rg.getSelection()!=null){
			String cmd = rg.getSelection().getActionCommand();
			lab.setText(cmd);
		}
	}
}


