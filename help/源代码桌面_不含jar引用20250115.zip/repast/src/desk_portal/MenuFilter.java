package desk_portal;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
public class MenuFilter extends JPanel implements DocumentListener{
	private static final long serialVersionUID = 12466804413034725L;
	public JTextField like=new JTextField(12);
	public MenuFilter(){
		setLayout(new FlowLayout(FlowLayout.LEFT));
		setOpaque(false);
		
		like.getDocument().addDocumentListener(this);
   	    like.setForeground(Color.BLUE);
   	    like.setToolTipText("限制最多返回100条数据,如需查询更多，可用时间段查询,空格与下划线代表匹配任意单个字符");
   	    
   	    add(like);
	}
	
	public void insertUpdate(DocumentEvent arg0) {
		if(like.getText().isEmpty()){
			return ;
		}
		
		String val = like.getText().replace(" ", "_");	//空格代表匹配任意单个字符
		val = val.replace("'", "");			//这个字符不能有，因为需要时行转义
		
		//为防止数据表过大，限制最多返回100条数据,如果需要查询更多，可用时间段查询
		val="select * from menu where 助记符 like '%"+val+"%' or 编号 like '%"+val+"%' or 商品名 like '%"+val+"%' limit 0,100";
		
		//回调结果
		if(GetDateCallback!=null){
        	GetDateCallback.onDismiss(val);
        }
	}
	public void removeUpdate(DocumentEvent arg0){
		insertUpdate(null);
	}
	public void changedUpdate(DocumentEvent e) {}
	
	
	   
    /**
     * 设置回调接口
     */
    private GetDate GetDateCallback;
    public void setGetDateCallback(GetDate val) {
        GetDateCallback = val;
    }
    
    /**
     * 回调接口
     */
    public interface GetDate {
        public void onDismiss(String mydate);
    }
}

