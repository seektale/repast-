package desk_portal;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import pub.ConfigFile;
import pub.Photo;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class Desk_print extends JPanel implements ActionListener{
	private static final long serialVersionUID = -45935457789735752L;
	private JButton refresh=new JButton("刷新 R");
	private JButton ok=new JButton("修复/重复 出单 P");
	private JButton com=new JButton("本地串口打印 C");
	private JLabel lab=new JLabel();
	private JTable t=Sql.getTable();
	private JTable dsc=Sql.getTable();
	private int mealnum;
	public Desk_print(int Meal_num){
		this.mealnum=Meal_num;
		setLayout(new BorderLayout());
		
		t.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				String s=Sql.getval(t, "who", t.getSelectedRow());
				s=s+"：[ "+Sql.getval(t, "dishclass", t.getSelectedRow());
				s=s+"●"+Sql.getval(t, "dishname", t.getSelectedRow());
				s=s+" ]   Remark："+Sql.getval(t, "remark", t.getSelectedRow());
				lab.setText(s);
				
				String str=Sql.getval(t, "dish_ind", t.getSelectedRow());
				str = "select * from print_job where dish_ind="+str ;
				Sql.getArrayToTable(str, this, dsc);
				Sql.TableAtt(dsc, true, false);
			}
		});
		
		JPanel down=new JPanel(new BorderLayout());
		JPanel sou=new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
		sou.add(refresh);
		sou.add(ok);
		sou.add(com);
		sou.add(lab);
		down.add(sou, BorderLayout.NORTH);
		down.add(new JScrollPane(dsc), BorderLayout.CENTER);
		
		JSplitPane js = new JSplitPane();
		js.setOrientation(JSplitPane.VERTICAL_SPLIT);
		js.setLeftComponent(new JScrollPane(t));
		js.setRightComponent(down);
		js.setSize(Front.inFrame.getSize());
		js.setDividerLocation(0.7);
		add(js, BorderLayout.CENTER);
		
		ok.addActionListener(this);
		com.addActionListener(this);
		refresh.addActionListener(this);
		ok.setMnemonic(KeyEvent.VK_P);
		com.setMnemonic(KeyEvent.VK_C);
		refresh.setMnemonic(KeyEvent.VK_R);
		refresh.doClick();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==ok){
			int k=t.getSelectedRow();
			if(k<0){
				JOptionPane.showMessageDialog(Front.front,"请先选择要 修复/重复 出单的数据行？","消息",2);
				return ;
			}
			//如果站点已变更或不存在，则Photo.printbin()方法会检查打印站点名是否有效
			int b=Integer.valueOf(Sql.getval(t, "dish_ind", k));
			String place=Sql.getval(t, "print_place", k);
			
			print(b,place);	//出单
		}
		else if(e.getSource()==com){
			int k=t.getSelectedRow();
			if(k<0){
				JOptionPane.showMessageDialog(Front.front,"请先选择要 修复/重复 出单的数据行？","消息",2);
				return ;
			}
			
			int b=Integer.valueOf(Sql.getval(t, "dish_ind", k));
			byte bb[] = Photo.getsamebin(b, "com");

			try {
				String temp=ConfigFile.getProperty("PrintCom");
				if(temp.toUpperCase().equals("COM1"))	Photo.Printcom(bb, "COM1");
				if(temp.toUpperCase().equals("COM2"))	Photo.Printcom(bb, "COM2");
				if(temp.trim().isEmpty())	JOptionPane.showMessageDialog(Front.front, "未启用COM打印开关,请在[设计]菜单列表中开启。","注意",0);
			}
			catch (Exception err) {
				JOptionPane.showMessageDialog(Front.front, err.getMessage(),"失败",0);
			}
		}
		else{
			Sql.getArrayToTable("select * from print_job where meal_count="+mealnum, this, t);
			Sql.TableAtt(t,true,true);
		}
	}
	
	//打印数据
	private void print(final int ind, final String site){
		//采用线程的方法，与主线程分开；这样修复大量出单日志时，可以连续操作而不用等待出单是否成功。
		Thread th=new Thread(new Runnable() {
			public void run() {
				lab.setText(" 正在从数据库中读取打印数据...");
				byte b[] = Photo.getsamebin(ind, site);
				if(b==null){
					lab.setText(" 从数据库中读取打印数据失败");
					return ;
				}
				
				lab.setText(" 正在将数据发送给热敏打印机...");
				boolean result = Photo.printbin(b, site, true);
				if(result){
					lab.setText(" 打印成功!!! 请刷新查看结果");
					//提交打印结果
					String sql = "select binary_result_repair("+ind+",'"+site+"','R')";
					String submit_result[] = Sql.getString(sql, Desk_print.this);
					if(submit_result.length==1){
						SouthPan.warn("提交站点["+site+"] 修复/重复 打印结果: "+submit_result[0], false);
					}
					//刷新提交后的结果
					refresh.doClick();
				}
				else{
					lab.setText(" 打印失败");
				}
			}
		});
		th.start();
	}
}
