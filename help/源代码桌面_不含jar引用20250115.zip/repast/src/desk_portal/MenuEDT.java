package desk_portal;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.Icon;
import javax.swing.SwingWorker;
import Menu.IconPre;
import pub.*;
import root.Sql;
public class MenuEDT extends SwingWorker<List<MenuCard>, MenuCard> {
	private String photonum[] ;
	private List<MenuCard> card;
	private HashMap<MenuCard, Icon> hm = new HashMap<MenuCard, Icon>();
	public MenuEDT(List<MenuCard> card){
		this.card = card ;
	}
	
	protected List<MenuCard> doInBackground() throws Exception {
		List<MenuCard> icon = new ArrayList<MenuCard>();
		photonum = Sql.getString("select num from photo", this);
		
		for (MenuCard mc : card){
			final int dishind = Integer.valueOf(mc.getval("编号"));
			if(!isphoto(photonum, mc.getval("编号"))) continue;
			
			Icon co=Photo.readIcon(dishind);
			if(co==null) continue;
			
			mc.pic.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					Icon con = Photo.readIcon(dishind,true) ;
					if(con!=null)	new IconPre(con);
				}
			});
			
			hm.put(mc, co);
			publish(mc);
			icon.add(mc);
		}
		
		return icon ;
	}
	
	protected void process(List<MenuCard> val){
		if(isCancelled()) return ;
		for(MenuCard temp : val){
			temp.pic.setIcon(hm.get(temp));
			temp.pic.setCursor(Cursor.getPredefinedCursor(12));  //鼠标指针为手型
			temp.setVisible(false);
			temp.setVisible(true);
		}
	}
	
	protected void done() {
		if(isCancelled()) return ;
		try {
			for(MenuCard temp : get()){
				temp.pic.setIcon(hm.get(temp));
				temp.setVisible(false);
				temp.setVisible(true);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//判断是否有图片
	private boolean isphoto(String photonum[],String dishnum ){
		for(String temp : photonum){
			if(temp.equals(dishnum)) return true;
		}
		return false;
	}
}
