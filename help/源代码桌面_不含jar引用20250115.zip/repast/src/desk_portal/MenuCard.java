package desk_portal;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceEvent;
import java.awt.dnd.DragSourceListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import pub.PanelRound;
import root.Sql;
public class MenuCard extends JPanel implements MouseListener, DragGestureListener, DragSourceListener {
	private static final long serialVersionUID = 1345543565434354L;
	private ArrayList<String> val;
	public JLabel pic=new JLabel();
	public static ArrayList<String> menucol = Sql.getArrayListToColumn("menu", "MenuCard");
	// 拖放功能
	private DragSource dragSource; 
	public static String drop_index,drop_price; 
	public MenuCard(ArrayList<String> val, int width, boolean flag) {
		this.val = val;
		int mywidth = width;   //下面要用到
		if(width==0) width=280;
		setLayout(null);
		setBorder(new PanelRound(true));	//稍微带点圆角
		setBackground(Color.pink);
		addMouseListener(this);
		
		//拖放功能
	    dragSource = new DragSource();
	    dragSource.createDefaultDragGestureRecognizer(this, DnDConstants.ACTION_COPY_OR_MOVE, this);
		
		//下面的功能是能自动适应宽度
		width = width-5-18;				//规定布局间隙为5，这里要先减去一个,还要减去滚动条约18
		int amount = width / (280+5);	//除以方块的 宽度加间隙，即280+5
		if(amount==0) amount=1;
		width = width / amount - 5 ;
		setPreferredSize(new Dimension(width,60));
		
		double temp=-1;
		try {temp=Double.valueOf(getval("库存"));} catch (Exception e) {}
		
		//锁定优先，其次是库存
		if(getval("锁定").equals("Y")){
			setBackground(Color.ORANGE);
		}
		else if(temp<=0 && temp!=-1){
			setBackground(Color.LIGHT_GRAY);
		}
		else{
			int a=getval("分类").indexOf("推荐");
			int b=getval("小类").indexOf("推荐");
			int c=getval("商品名").indexOf("推荐");
			if((a>=0)||(b>=0)||(c>=0))	setBackground(Color.CYAN);
		}
		
		//先加入的组件在最上层，这样初始化时如果有图片其pic.setCursor(Cursor.getPredefinedCursor(12)); 才有效果
		pic.setBounds(getPreferredSize().width-100, 2, 260, 55);
		add(pic);
		
		JLabel dname=new JLabel(getval("商品名"));
		dname.setBounds(10, 8, 300, 20);
		dname.setFont(new Font("楷体",Font.BOLD,18));
		dname.setForeground(Color.BLUE);
		add(dname);
		//如果文字太长，商品名无法显示全，则用tip显示全
		if(dname.getText().length()>10) dname.setToolTipText(dname.getText());
		
		String pri=getval("价格");
		if(pri.endsWith(".00")) pri=pri.replace(".00", "");
		JLabel price=new JLabel("￥ "+pri);
		price.setBounds(10, 34, 200, 20);
		price.setFont(new Font("楷体",Font.PLAIN,18));
		add(price);
		
		final JLabel unit=new JLabel("<html><body>"+"/"+getval("单位")+" <font color=gray>"+getval("频率")+"</font></body></html>");
		unit.setBounds(100, 34, 200, 20);
		unit.setFont(new Font("楷体",Font.PLAIN,18));
		add(unit);
		
		//套餐处理
		if(getval("分类").equals("套餐")) {
			String sql = "select 编号,商品名,价格,单位 from menu where " +
						 "(select 备注 from menu where 编号="+getval("编号")+") like concat('%',编号,'%')";
			ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
			String tip="<font color=blue>套菜明细：</font>";
			for(String list[] : arr){
				tip=tip+"<br>"+list[0];
				tip=tip+"  "+list[1];
				tip=tip+"  "+list[2];
				tip=tip+"/"+list[3];
			}
			if(arr.size()>0) {
				setToolTipText("<html><body>"+tip+"</body></html>");
			}
		}
		
		if(flag) return ;
		/****************************************************************************************/
		
		
		//小菜名处理
		remove(pic);
		remove(unit);

		//下面的功能是能自动适应宽度
		mywidth = mywidth-5-18;	
		amount = mywidth / (210);
		if(amount==0) amount=1;
		mywidth = mywidth / amount - 5 ;
		setPreferredSize(new Dimension(mywidth,35));
		
		dname.setBounds(6, 8, mywidth, 20);
		dname.setFont(new Font("楷体", Font.BOLD, 18));
		if(getToolTipText()==null) setToolTipText(getval("助记符"));
		price.setBounds(mywidth-90, 10, 80, 18);
		price.setFont(new Font("楷体", Font.BOLD, 18));
		price.setText(pri+"/"+getval("单位"));
		//price.setForeground(Color.BLUE);
		price.setHorizontalAlignment(SwingConstants.RIGHT);
		
		addMouseMotionListener(new MouseMotionListener() {
			public void mouseMoved(MouseEvent e) {
				if(e.getX()>MenuCard.this.getWidth()*0.8){
					setCursor(Cursor.getPredefinedCursor(12));
					return ;
				}
				setCursor(Cursor.getPredefinedCursor(0));
			}
			public void mouseDragged(MouseEvent e) {}
		});
	}
	
	//根据列名和第几组得到对应值
	public String getval(String colname){
		int k = menucol.indexOf(colname);
		if(k==-1) return "";
		if(k>=val.size()) return "";
		return val.get(k);
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {
		setBorder(Sql.getBorder(2, ""));
	}
	public void mouseExited(MouseEvent e) {
		setBorder(new PanelRound(true));	//稍微带点圆角
	}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	
	
	/*************************************************************************************/
	
	public void dragGestureRecognized(DragGestureEvent evt) {
		final Transferable t = new StringSelection("drop to menulist");
		dragSource.startDrag(evt, DragSource.DefaultCopyDrop, t, this);
	}

	public void dragEnter(DragSourceDragEvent evt) {
		drop_index = getval("编号");
		drop_price = getval("价格");
	}

	public void dragOver(DragSourceDragEvent evt) {
		System.out.println("over");
	}

	public void dragExit(DragSourceEvent evt) {
		System.out.println("leaves");
	}

	public void dropActionChanged(DragSourceDragEvent evt) {
		System.out.println("changes the drag action between copy or move");
	}

	public void dragDropEnd(DragSourceDropEvent evt) {
		System.out.println("finishes or cancels the drag operation");
		drop_index = null;
		drop_price = null;
	}
}

