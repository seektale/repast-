package desk_portal;
//开台界面
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import pub.Var;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class Desk_start extends JDialog implements ActionListener{
	private static final long serialVersionUID = 84114463252656566L;
	private JTextField m[]=new JTextField[4];

	private JComboBox<String> meal_time	=new JComboBox<String>(new String[]{"早餐","中餐","晚餐","夜宵",""});
	private JComboBox<String> market	=new JComboBox<String>(Var.getMarket());
	private JTextField whomeal 	= new JTextField();
	private JComboBox<String> sale;
	private JComboBox<String> vip = new JComboBox<String>(new String[]{"是","否"});
	
	private JTextArea re=new JTextArea("备注",3,30);  	//开台备注
	private JLabel kai=new JLabel();					//提示信息
	private JLabel who=new JLabel("",JLabel.LEFT);		//提示信息
	private JButton submit=new JButton("提交 Submit");
	
	private String mealnum,area,deskind;
	public Desk_start(String mealnum, String area, String deskind){
		super(Front.front,"开台信息",true);
		this.mealnum=mealnum;
		this.area=area;
		this.deskind=deskind;
		
		JPanel con = new JPanel();
		BoxLayout layout=new BoxLayout(con, BoxLayout.Y_AXIS); //垂直布局
		con.setLayout(layout);
		
	    JPanel p=new JPanel(new GridLayout(6,1,2,8));
	    
	    JLabel des = new JLabel("",JLabel.CENTER);
	    des.setFont(new Font("",Font.BOLD,16));
	    des.setForeground(Color.BLUE);
	    String stat[]=Sql.getString("select 别名,容客量,简述,状态 from desk where 区域='"+area+"' and 台号="+deskind, this);
		if(stat.length>0){
			if(stat[3].equals("联台")){
				JOptionPane.showMessageDialog(Front.front, "请先切换卡台状态为空台", "错误", 0);
				dispose();
				return ;
			}
			if(stat[0].isEmpty()) stat[0]="No Name";
			des.setText(stat[0]+" (容客量:"+stat[1]+")   "+stat[2]);
		}
	    p.add(des);
	    
	    JPanel temp=new JPanel(new BorderLayout());
		temp.add("West",new JLabel("顾客单位："));
		whomeal.getDocument().addDocumentListener(new DocumentListener() {
			private Guest_Popup up;
			public void removeUpdate(DocumentEvent e) {}
			public void insertUpdate(DocumentEvent e) {
				String s=whomeal.getText();
				if(s.isEmpty()) return ;
				String sql="select 宾客单位 from booking where 宾客单位 like '%"+s+"%' limit 0,50";
				String arr[]=Sql.getString(sql, this);
				if(arr.length>0){
					Guest_Popup popup = new Guest_Popup(arr);
					//如果whomeal组件不显示，下面一句会出现异常
					if(whomeal.isShowing())	popup.show(whomeal, 1,whomeal.getHeight());
					up=popup;
				}
				else{
					if(up!=null) up.setVisible(false);
				}
			}
			public void changedUpdate(DocumentEvent e) {}
		});
		temp.add("Center",whomeal);
	    p.add(temp);
	    
	    p.add(getpan("主宾姓氏：",m[0]=new JTextField(),"发票编码：",m[1]=new JTextField("")));
	    
	    String mess="<html><body><font color=red>时段定义：</font><br>①早上05点到上午10点--早餐<br>②上午10点到下午02点--中餐" +
	    			"<br>③下午05点到晚上08点--晚餐<br>④晚上08点到夜里24点--夜宵</body></html>";
	    meal_time.setToolTipText(mess);
	    p.add(getpan("宾客人数：",m[2]=new JTextField("1"),"选择时段：",meal_time));
	    
	    String salesql = "select name_chinese from account where department='销售部' and strlength(name_chinese)>0;";
	    sale=new JComboBox<String>(Sql.getString(salesql, this));
	    sale.addItem("");
	    sale.setSelectedItem("");	//默认不选择销售员
	    sale.setEditable(true);
	    sale.setToolTipText("单击下拉列表 可 选择销售员！");
	    vip.setSelectedItem("否");	//默认为否
	    p.add(getpan("销售人员：",sale,"VIP 客户 ：",vip));
	    
	    market.actionPerformed(null);	//默认不选择任何值
	    p.add(getpan("市场来源：",market,"联系电话：",m[3]=new JTextField("")));
		con.add(p);
		
		m[2].addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(m[2].isEditable() && m[2].isEnabled() && m[2].isFocusOwner()){
					int val = 0;
					try{
						val = Integer.valueOf(m[2].getText());
					}catch (Exception err) {
						return ;
					}
					if(e.getX() < m[2].getWidth()/2){
						val--;
						if(val<0) val = 0;
					}
					else{
						val++;
					}
					m[2].setText(val+"");
				}
			}
		});
		
		con.add(Box.createVerticalStrut((18)));
		re.setLineWrap(true);         //自动换行
		con.add(new JScrollPane(re));
	    
		//根层面板中心与南面部局
		submit.addActionListener(this);
		submit.setMnemonic(KeyEvent.VK_S);
		
		/*//创建水平Box组件  
        Box box=Box.createHorizontalBox();  
        box.add(lockdesk);  
        box.add(Box.createHorizontalGlue());  //使的组件一左一右分隔开
        box.add(submit);
		con.add(box);
		*/
		JPanel exitpan = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		exitpan.add(submit);
		con.add(exitpan);
		
		con.add(Box.createVerticalStrut((18)));
		con.add(new JSeparator());
		
		JPanel deskmsg=new JPanel(new FlowLayout(FlowLayout.LEFT));
		who.setForeground(Color.blue);
		who.setFont(new Font("粗体", Font.PLAIN, 18));
		deskmsg.add(who);
		con.add(deskmsg);

		deskmsg=new JPanel(new FlowLayout(FlowLayout.LEFT));
		kai.setForeground(Color.blue);
		kai.setFont(new Font("粗体", Font.PLAIN, 18));
		deskmsg.add(kai);
		con.add(deskmsg);
		
		refresh();
		
		JPanel conroot = new JPanel(new BorderLayout(30,30));
		conroot.add(con,BorderLayout.CENTER);
		conroot.add(new JLabel(),BorderLayout.EAST);
		conroot.add(new JLabel(),BorderLayout.WEST);
		//conroot.add(new JLabel(),BorderLayout.NORTH);
		conroot.add(new JLabel(),BorderLayout.SOUTH);
		setContentPane(conroot);
		setSize(500,550);
		setLocationRelativeTo(null); //初始位置在屏幕正中间
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Front.logo);
		setVisible(true);
	}
	private JPanel getpan(String a,Component A,String b,Component B){
		JPanel master=new JPanel(new GridLayout(1,2,5,2));
	    JPanel temp=new JPanel(new BorderLayout());
	    temp.add("West",new JLabel(a));
	    temp.add("Center",A);
	    master.add(temp);
	    temp=new JPanel(new BorderLayout());
	    temp.add("West",new JLabel(b));
	    temp.add("Center",B);
	    master.add(temp);
	    return master;
	}
	
	//提交数据
	public void actionPerformed(ActionEvent e) {
		
		//正则表达式数字验证,以下值须为数字，存储过程要求传入数字
		java.util.regex.Pattern pattern=java.util.regex.Pattern.compile("[0-9]*");
        java.util.regex.Matcher match=pattern.matcher(m[2].getText());
        if(match.matches()==false||m[2].getText().equals("")){
        	JOptionPane.showMessageDialog(Front.front, "宾客人数 必须输入正确的数字且不可为空！");
        	return ;
        } 
        ArrayList<String> v=new ArrayList<String>();
		v.add(mealnum);								//餐次，未开台则是0
		v.add(whomeal.getText());					//用餐单位
		v.add(m[0].getText());						//主宾姓氏
		v.add(m[1].getText());						//发票编号
		v.add(m[2].getText());						//用餐人数
		v.add((String)meal_time.getSelectedItem());	//选择餐段
		v.add((String)sale.getSelectedItem());		//销售人员
		v.add((String)vip.getSelectedItem());		//VIP客户
		v.add(m[3].getText());						//联系电话
		v.add((String)market.getSelectedItem());	//市场来源
		v.add(re.getText());						//开台备注
		v.add(area);								//餐区
		v.add(deskind);								//台号
		
		boolean res = Sql.mysqlprocedure("desk_start",v);
		
		//新开台，刷新界面
		if(res && mealnum.equals("0")){
			dispose();
			Front.selected.doClick();
			return ;
		} 
		refresh();
		dispose();
	}
	
	public void refresh(){
		
		//如果没开台
		if(mealnum.equals("0")){
	    	//状态说明
	    	String s[]=Sql.getString("select 状态,状态说明 from desk where 区域='"+area+"' and 台号="+deskind+";", this);
	    	if(s.length>0){
	    		if(!s[1].isEmpty()) s[1]="原因为："+s[1];
	    		kai.setText("<html><body>"+"当前状态："+s[0]+"<br>"+s[1]+"</body></html>");
	    	}
	    	meal_time.setSelectedItem("");	//由开台存储过程自动选择时间段
	    	return ;
		}
		
		/****************************************************/
		
		//初始化数据
		String sql="宾客单位,主宾姓氏,发票编码,宾客人数,选择时段,销售人员,VIP客户,市场来源,联系电话,备注,锁台,开台工号,开台时间,结账工号,结账时间";
		sql="select "+sql+" from deskgo where 台次="+mealnum;
		String s[]=Sql.getString(sql, this);
		
    	if(s.length==0){
    		SouthPan.warn("查询 deskgo 表中台次:"+mealnum+" 的开台信息失败",true);
    		return ;
    	}
    	
    	if(s[10].equals("N")){
			
		} 
		
		kai.setText("<html><p>开："+s[11]+" "+s[12]+"</p><span>结："+s[13]+" "+s[14]+"</span></html>");
		who.setText("编号 ==> "+mealnum+"   ( 已结账 )");
		if(s[14].isEmpty()) who.setText("编号 ==> "+mealnum+"   ( 未结账 )");
		
		whomeal.setText(s[0]);
		m[0].setText(s[1]);
		m[1].setText(s[2]);
		m[2].setText(s[3]);
		meal_time.setSelectedItem(s[4]);
		sale.setSelectedItem(s[5]);
		vip.setSelectedItem(s[6]);
		market.setSelectedItem(s[7]);
		m[3].setText(s[8]);
		re.setText(s[9]);
	}
	
	/*
	 * 内部类,右键菜单
	 * */
	class Guest_Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -1825919536906L;
		Guest_Popup(String arr[]){
			for(int k=0;k<arr.length;k++){
				JMenuItem a = new JMenuItem(arr[k]);
				a.addActionListener(this);
				add(a);
			}
			//不要自动获得焦点，这一句非常重要
			setFocusable(false);
		}
		public void actionPerformed(ActionEvent e) {
			whomeal.setText(e.getActionCommand());
		}
	}
}

