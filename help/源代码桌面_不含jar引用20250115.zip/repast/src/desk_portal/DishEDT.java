package desk_portal;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.SwingWorker;
import pub.Var;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
//已点菜品的卡片模型
public class DishEDT extends SwingWorker<List<dishCard>, dishCard> implements MouseListener{
	private static ArrayList<String> dishcolname ;
	private ArrayList<String[]> arr ;
	private DishPan dish;
	private String sql;
	public DishEDT(DishPan dish, String sql){
		this.dish=dish;
		this.sql=sql;
	}
	
	//下面的功能是能自动适应宽度
	private int reSize(){
		JScrollPane js=(JScrollPane)dish.dc.getParent().getParent();
		
		//布局时Var.dishhgap()，这里要先减去一个,还要减去滚动条约18
		int width=js.getWidth()-Var.dishhgap()-18;	
		if(width<=0) return 0;
		
		//除以方块的 宽度加间隙，即Var.dishw()+Var.dishhgap()
		int num=width / (Var.dishw()+Var.dishhgap());
		if(num==0) num=1;
		return width /num - Var.dishhgap() ;
	}
	
	protected List<dishCard> doInBackground() throws Exception {
		if(dishcolname==null){
			dishcolname = Sql.getArrayListToColumn("dish", this);
		}
		
		arr = Sql.getArrayToArrary(sql, this);
		List<dishCard> dcard = new ArrayList<dishCard>();
		
		int width=reSize();	//写在开头，以勉反复运算
		for(int k=0;k<arr.size();k++){
			final dishCard p = new dishCard(Integer.valueOf(getval("索引",k)),width);
			
			String cla=getval("属性",k);
			String te=getval("商品名",k);
			if(cla.isEmpty()){
				te=" "+te;
			}
			else{
				te="<html><body><font color=red>["+cla+"]</font>"+te+"</body></html>";
			}
			if(cla.startsWith("退单")){
				p.setBackground(Var.getColor("退单商品背景色彩"));
			}
			final JLabel dndn = getLabel(te);
			dndn.setForeground(Var.getColor("商品名称文字色彩"));
			dndn.setFont(new Font("楷体", Font.BOLD, 18));
			p.add(dndn);
			
			String pr=getval("实价",k);
			if(pr.endsWith(".00"))	pr=pr.replace(".00", "");
			String num=getval("数量",k);
			if(num.endsWith(".00"))	num=num.replace(".00", "");
			te=pr+" ￥"+"  ×"+num+getval("单位",k);
			
			try{
				final double per=Double.valueOf(getval("折扣",k));
				if(per<1){
					//获取格式化对象
					NumberFormat nt = NumberFormat.getPercentInstance();
					//设置百分数精确度2即保留两位小数
					//nt.setMinimumFractionDigits(2);
					//最后格式化并输出,适合两位小数转百分比,未设置百分比精度时会自动四舍五入
					te=te+"  ×"+nt.format(per);
				}
			}
			catch (Exception e) {
				// TODO: handle exception
				SouthPan.warn("商品："+getval("商品名",k)+" 的折扣计算出现了异常，请检查？", true);
			}
			p.add(getLabel(te));

			te=getval("点单员",k);
			if(getval("点单时间",k).length()>11){
				te=te+" "+getval("点单时间",k).substring(11,16);
				te=te+" ["+howlong(getval("点单时间",k))+"]";
			}	
			p.add(getLabel(" "+te));
			
			final JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
			final JLabel print = getLabel("出单");
			temp.add(print);
			if(getval("出单",k).equals("0")){
				print.setText("待出单");
				print.setForeground(Color.GRAY);
			}
			else if(getval("出单",k).equals("-1")){
				print.setText("失效");
				print.setForeground(Color.GRAY);
			}
			else {
				print.setText("已出单");
			}
			
			final JLabel rere = getLabel(getval("备注",k));
			rere.setForeground(Var.getColor("商品名称文字色彩"));
			temp.add(rere);
			temp.setOpaque(false);
			p.add(temp);
			p.addMouseListener(this);
			
			publish(p);
			dcard.add(p);
		}
		return dcard ;
	}
	
	protected void process(List<dishCard> val){
		if(isCancelled()) return ;
		for(dishCard temp : val){
			dish.dc.add(temp);
		}
		dish.dc.setVisible(false);
		dish.dc.setVisible(true);
	}

	protected void done() {
		if(isCancelled()) return ;
		try {
			for(dishCard temp : get()){
				dish.dc.add(temp);
			}
			dish.dc.setVisible(false);
			dish.dc.setVisible(true);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//计算时间差
	private String howlong(String old) {
		String val = ">1day" ;
		try {
			SimpleDateFormat dfs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date begin = dfs.parse(old);
			Date now   = new Date();
			long time = (now.getTime() - begin.getTime()) / 1000;	// 除以1000是为了转换成秒

			long day = time / (24 * 3600);
			long hour = time % (24 * 3600) / 3600;
			long minute = time % 3600 / 60;
			//long second = time % 60 ;
			
			if(day==0){
				String m = hour<10 ? "0"+hour : ""+hour ;
				String n = minute<10 ? "0"+minute : ""+minute ;
				val = m +":"+ n ;
			} 
			//System.out.println("" + day + "天" + hour + "小时" + minute + "分"+ second + "秒");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return val ;
	}
	private String getval(String col,int row){
		int k = dishcolname.indexOf(col);
		return arr.get(row)[k];
	}
	private JLabel getLabel(String str){
		JLabel name=new JLabel(str);
		name.setFont(new Font(Var.dishfont(), Font.PLAIN, Var.dishtextsize()));
		name.setForeground(Var.getColor("商品显示前景"));
		return name;
	}
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent e) {
		dishCard temp=(dishCard)e.getSource();
		temp.setBorder(Sql.getBorder(1, ""));
	}
	public void mouseExited(MouseEvent e) {
		dishCard temp=(dishCard)e.getSource();
		temp.setBorder(Sql.getBorder(2, ""));
	}
	public void mousePressed(MouseEvent e) {
		
		final dishCard temp=(dishCard)e.getSource();
		if(e.getButton()==3 || e.getX()>temp.getWidth()*0.9){
			final dishpopup dp = new dishpopup(temp.ind);
			dp.show(temp, temp.getWidth()-dp.getPreferredSize().width, temp.getHeight());
			return;
		}
		
		if (e.getClickCount() == 1){
			//显示选中状态
			if(temp.boo){
				temp.setBackground(Var.getColor("正常商品背景色彩"));
				temp.boo=false;
			}
			else{
				temp.setBackground(Var.getColor("商品选中背景"));
				temp.boo=true;
			}
        }
		
		//双击
		if (e.getClickCount() == 2){
	        new DishDialog(temp.ind);
	        dish.refresh();	//无条件刷新
        }
	}
	public void mouseReleased(MouseEvent e) {}
	

	
	/*
	 * 内部类 [菜单]
	 * */
	class dishpopup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -18366350034196L;
		private JMenuItem a = new JMenuItem("删除 Delete");
		private JMenuItem b = new JMenuItem("退单 Back_dish");
		private JMenuItem d = new JMenuItem("重复点单 Repeat_Order");
		private JMenuItem e = new JMenuItem("分单 Split_Dish");
		private JMenuItem g = new JMenuItem("日志 log");
		private int dishind ;
		public dishpopup(int dishind){
			this.dishind=dishind;
			a.addActionListener(this);
			b.addActionListener(this);
			d.addActionListener(this);
			e.addActionListener(this);
			g.addActionListener(this);
			add(a);
			addSeparator();
			addSeparator();
			add(b);
			addSeparator();
			addSeparator();
			add(d);
			addSeparator();
			addSeparator();
			add(e);
			addSeparator();
			addSeparator();
			add(g);
		}
		
		public void actionPerformed(ActionEvent es) {
			if(es.getSource()==a){
				Sql.mysqlprocedure("dish_del",dishind+"");
				dish.refresh();	//刷新
				return ;
			}
			if(es.getSource()==b){
				dish.backdish(dishind);
				return ;
			}
			if(es.getSource()==d){
				dish.repeat(dishind);
				return ;
			}
			if(es.getSource()==e){
				dish.splitdish(dishind);
				return ;
			}
			// 某些换台的商品其日志不会显示在换台后的卡台里，通过下面的方式来显示其日志。
			if(es.getSource()==g) {
				final JScrollPane js = new JScrollPane(Sql.getTable("select * from dishlog where 商品索引="+dishind, DishEDT.this));
				js.setPreferredSize(new Dimension(1000, 200));
				JOptionPane.showMessageDialog(Front.front, js, "日志", 1, new ImageIcon());
				return ;
			}
		}
	}
}

//自定义商品描述面板
class dishCard extends JPanel{
	private static final long serialVersionUID = -158130390052855788L;
	public int ind;
	public boolean boo=false;
	public dishCard(int ind, int width){
		this.ind=ind;
		
		setPreferredSize(new Dimension(Var.dishw(),Var.dishh()));
		if(width>0){
			setPreferredSize(new Dimension(width,Var.dishh()));
		}
		setLayout(new GridLayout(2, 2, 2, 0));
		
		setBackground(Var.getColor("商品显示背景"));
		setBorder(Sql.getBorder(2, ""));
	}
}
