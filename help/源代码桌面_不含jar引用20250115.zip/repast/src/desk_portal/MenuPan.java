package desk_portal;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableColumn;
import pub.*;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class MenuPan extends JSplitPane implements ActionListener{
	private static final long serialVersionUID = -1190923669964168673L;
	private JButton	  linkdish		= new JButton("套餐商品");
	private JButton	  gooddish		= new JButton("推荐商品");
	public  JButton   actiontimes	= new JButton("常用商品");
	private JButton   aux			= new JButton("辅助商品");
	private JCheckBox CardModel		= new JCheckBox("卡片模式");
	private JLabel	  rowtip		= new JLabel("");
	private JPanel    right  		= new JPanel(new BorderLayout());	//右边的卡片布局面板
	private JPanel    rightCenter 	= new JPanel(new CardLayout());		//右边中心
	private JPanel    card			= new JPanel(new ModifiedFlowlayout(FlowLayout.LEFT,5,3)); //向左对齐
	private JPanel    rightSouth  	= new JPanel(new FlowLayout(FlowLayout.LEFT,5,5));	//右边下边
	
	private MenuFilter ms = new MenuFilter();
	private JTable t = Sql.getTable();
	private int Meal_num ;
	private ArrayList<String> whoval;
	private MenuEDT MEDT ;
	public MenuPan(int Meal_num){
		this.Meal_num=Meal_num;
		
		//左边的菜品分类栏
		String[] ss=Var.getMenu_class();
		
		JPanel left=new JPanel(new ModifiedFlowlayout(FlowLayout.CENTER,0,0));		//左边的菜单面板
		for(int k=0;k<ss.length;k++){
			JButton temp=new JButton(ss[k]);
			temp.addActionListener(this);
			temp.setPreferredSize(new Dimension(110,35));
			temp.setToolTipText(ss[k]);
			left.add(temp);
		}
		rightCenter.add(new JScrollPane(t),"表格模式");
		JScrollPane js=new JScrollPane(card);
		js.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
        rightCenter.add(js,"卡片模式");
        
		right.add("Center",rightCenter);
		right.add("South",rightSouth);
		rightSouth.add(myPanel());

		final JScrollPane lefts=new JScrollPane(left);
		lefts.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
		setLeftComponent(lefts);
		setRightComponent(right);
		setOrientation(JSplitPane.HORIZONTAL_SPLIT);
		setSize(Front.inFrame.getSize());
		setDividerSize(7);
		setDividerLocation(0.12d);
		setOneTouchExpandable(true);
		
		//是否显示为卡片模式
		String temp=ConfigFile.getProperty("MenuShowModel2");
		if(temp.equals("Y")){
			CardModel.setSelected(true);
			((CardLayout)rightCenter.getLayout()).show(rightCenter, "卡片模式");
		}
	}
	
	private JPanel myPanel(){
		JPanel two = new JPanel(new FlowLayout(FlowLayout.LEFT));
		
		t.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e){
				if (e.getClickCount() == 2){	//处理双击事件
					//将行数据转成字符串数组
					ArrayList<String> val=new ArrayList<String>();
					for(int col=0;col<t.getColumnCount();col++){
						val.add(t.getValueAt(t.getSelectedRow(), col).toString());
					}
					whoval=val;
					sub();
		        }
			}
		});
		
		//实现自定义的接口
		ms.setGetDateCallback(new MenuFilter.GetDate(){
			public void onDismiss(String val){
				showMenu(val);
			}
		});
		
		CardModel.addActionListener(this);
		linkdish.addActionListener(this);
		gooddish.addActionListener(this);
		actiontimes.addActionListener(this);
		aux.addActionListener(this);
		two.add(ms.like);
		two.add(linkdish);
		two.add(aux);
		two.add(gooddish);
		two.add(actiontimes);
		two.add(CardModel);
		two.add(rowtip);
		
		rowtip.setForeground(Color.BLUE);
		actiontimes.setToolTipText("只显示排名前50的商品！");
		gooddish.setToolTipText("大类，小类，商品名 含有'推荐'二字的均显示");
		
		return two ;
	}
	
	/*本算法于2014-01-20 09:00:00 放弃 Place:Home
	//将cho.like对象注册监听的顺序交换一下，因为java机制为后注册先执行
	private void listener(){
		cho.like.getDocument().removeDocumentListener(cho);	//移除
		cho.like.getDocument().addDocumentListener(this);	//注册第一个
		cho.like.getDocument().addDocumentListener(cho);	//恢复注册第二个
	}
	*/
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==CardModel){
			//记录配置
			ConfigFile.setProperty("MenuShowModel2", CardModel.isSelected());
			
			if(CardModel.isSelected()){
				((CardLayout)rightCenter.getLayout()).show(rightCenter, "卡片模式");
				showMenu("");
				return ;
			}
			((CardLayout)rightCenter.getLayout()).show(rightCenter, "表格模式");
			return ;
		}
		
		if(e.getSource()==actiontimes){
			showMenu("select * from menu order by 频率 desc,编号 asc limit 0,50;");
		}
		else if(e.getSource()==aux){
			showMenu("select * from menu where 分类='辅助';");
		}
		else if(e.getSource()==linkdish){
			showMenu("select * from menu where 分类 like '%套餐%'");
		}
		else if(e.getSource()==gooddish){
			showMenu("select * from menu where 分类 like '%推荐%' or 小类 like '%推荐%' or 商品名 like '%推荐%'");
		}
		
		//单击商品某一分类时显示相应分类
		else{
			//商品小类弹出
			String com=e.getActionCommand();
			String sql="select distinct 小类 from menu where 小类!='' and 分类='"+com+"';";
			String s[]=Sql.getString(sql, this);
			
			if(s.length>0){
				JButton bu=(JButton)e.getSource();
				Popup po=new Popup(com,s);
				po.show(bu, bu.getWidth(), 1);
			}
			
			//对MenuTable表格进行更新
			showMenu("select * from menu where 分类='"+com+"'");
		}
	}
	
	public void showMenu(String sql){
		//刷新表格
		if(sql!=null && !sql.isEmpty()){
			Sql.getArrayToTable(sql, this, t);
			Sql.TableAtt(t, true, false);	//平均列宽
			hideCol(15);hideCol(14);hideCol(13);hideCol(12);
		}
		if(!CardModel.isSelected())	return ;
		
		//处理卡片模式显示
		if(MEDT!=null){
			MEDT.cancel(true);
			rowtip.setText("     新查询发起。");
		}
		
		card.removeAll();	//先清空
		
		final JScrollPane js=(JScrollPane)card.getParent().getParent();
		List<MenuCard> cmlist = new ArrayList<MenuCard>();
		for(int row=0;row<t.getRowCount();row++){
			//将行数据转成字符串数组
			final ArrayList<String> val = new ArrayList<String>();
			for(int col=0;col<t.getColumnCount();col++){
				Object ob=t.getValueAt(row, col);
				val.add(ob.toString());
			}
			final MenuCard cm=new MenuCard(val, js.getWidth(), true);
			cm.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e){
					//左单击
					if(e.getButton()==1){
						whoval=val;
			        	sub();
					}
					//右单击,弹出二维码
					if(e.getButton()==3){
						new Menu.Weipre(val.get(0)+"#"+val.get(4));
					}
				}
			});
			
			card.add(cm);
			cmlist.add(cm);
			if(card.getComponentCount()>=80){
				//为节约内存资源,只显示前80个商品
				break;
			}
			if(!card.isShowing()) break;
		}
		
		card.setVisible(false);	//刷新
		card.setVisible(true);
		
		rowtip.setText("   卡片加载完成，开始处理图片");
		MEDT = new MenuEDT(cmlist);
		MEDT.execute();
	}
	
	private void hideCol(int column){
		TableColumn tc = t.getTableHeader().getColumnModel().getColumn(column);
        tc.setPreferredWidth(0);
        tc.setMinWidth(0);
        tc.setMaxWidth(0);
	}
	
	//点单对话框
	private void sub(){
		final JPanel con=new JPanel(new BorderLayout(0,6));
		final JTextField num=new JTextField("1"); //充许输入小数
		JTextField price=new JTextField();
		price.setText(getval("价格"));
		num.setPreferredSize(new Dimension(100,30));
		price.setPreferredSize(new Dimension(100,30));
		price.setEditable(false);
		price.setBackground(Color.LIGHT_GRAY);
		num.setToolTipText("可以输入带小数点的数字");
		
		//编号，大类，小类，菜名，价格，单位，库存，锁定，助记符，频率，最近一次，图片，备注
		JLabel tf=new JLabel();
		String  tip="<font color=blue>编号：</font>"+getval("编号")+"  ("+getval("分类")+" --- "+getval("小类")+")\n";
		tip=tip+"<br><font color=blue>名称：</font>"+getval("商品名")+"   "+getval("价格")+"元 /"+getval("单位")+"\n";
		tip=tip+"<br><font color=blue>库存：</font>"+getval("库存")+" (值为-1代表未启用沽清)\n";
		tip=tip+"<br><font color=blue>成本：</font>"+getval("成本")+"\n";
		tip=tip+"<br><font color=blue>频率：</font>"+getval("频率")+"  Last："+getval("最近一次")+"\n";
		//套餐的备注记录了子商品编号，这里不作显示
		if(!getval("备注").isEmpty() && !getval("分类").equals("套餐")){
			tip=tip+"<br><font color=blue>备注："+getval("备注")+"</font>";
		}
		
		tf.setText("<html><body>"+tip+"</body></html>");
		tf.setFont(new Font(null,Font.BOLD,15));
		con.add(tf,BorderLayout.NORTH);
		
		JPanel fp=new JPanel(new BorderLayout());
		JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT));
		JPanel sub=new JPanel(new BorderLayout());
		JLabel msg=new JLabel("点单数量：",JLabel.RIGHT);
		msg.setFont(new Font(null,Font.BOLD,16));
		sub.add(msg,BorderLayout.WEST);
		sub.add(num,BorderLayout.CENTER);
		p.add(sub);
		
		JButton aa = new JButton("⇑");
		JButton bb = new JButton("⇓");
		p.add(aa);
		p.add(bb);
		fp.add(p,BorderLayout.NORTH);
		
		JLabel la=new JLabel();
		la.setForeground(Color.RED);
		fp.add(la,BorderLayout.SOUTH);
		
		aa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int val = 0;
				try{
					val = Integer.valueOf(num.getText())+1;
				}catch (Exception err) {
					return ;
				}
				num.setText(val+"");
			}
		});
		bb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int val = 0;
				try{
					val = Integer.valueOf(num.getText())-1;
					if(val<0) val=0;
				}catch (Exception err) {
					return ;
				}
				num.setText(val+"");
			}
		});
		
		/****************************************************/
		
		double m=-1;
		try {
			m=Double.valueOf(getval("库存"));
		} catch (Exception e) {
			// TODO: handle exception
			SouthPan.warn("商品："+getval("商品名")+" 的库存数据有误，无法转成Double数据类型。", false);
		}
		//库存判断，-1代表不启用库存功能
		if(m==0){
			la.setText("<html><body><br> 注意：商品库存不足，继续出售该商品，请先确认。</body></html>");
		}
		//务必放在库存判断之后，便于锁定的判定为主要
		if(getval("锁定").equals("Y")){
			la.setText("<html><body><br> 注意：该商品已被锁定，商品不可使用。</body></html>");
		}
		// 即有库存，又没有禁用，则显示特价信息
		if(la.getText().isEmpty()){
			la.setText("<html><body>"+getTimePrice(price,getval("商品名"))+"</body></html>");
		}
		
		/****************************************************/
		
		con.add(new JSeparator(),BorderLayout.CENTER);	//分割线
		con.add(fp,BorderLayout.SOUTH);
		
		//Front.inFrame
		int action=JOptionPane.showConfirmDialog(Front.front, con, "点单："+getval("商品名"), 2, 1, new ImageIcon());
		if(action==0){
			ArrayList<String> v=new ArrayList<String>();
			v.add(String.valueOf(Meal_num));		//餐次
			v.add(getval("编号"));					//菜品编号
			v.add(num.getText());					//数量
			v.add(price.getText());					//价格
			//提交菜品
			Sql.mysqlprocedure("dish_order_init",v);
			ms.like.selectAll();
		}
	}
	//专供sub()点单对话框方法调用，用于简化代码
	private String getval(String col){
		return whoval.get(MenuCard.menucol.indexOf(col));
	}
	
	//时价方案处理
	private String getTimePrice(JTextField price, String dishname){
		String sql = "select timeused('"+getval("时价定义")+"','"+dishname+"',"+price.getText()+","+Meal_num+")" ;
		String data[] = Sql.getString(sql, this);
		return data[0];
	}
	
	
	/*
	 * 内部类,右键菜单
	 * */
	class Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -18259196L;
		private Popup(String maxclass,String s[]){
			//商品小类
			for(String temp : s){
				JMenuItem me = new JMenuItem(maxclass+"   "+temp);
				me.addActionListener(this);
				add(me);
			}
		}
		public void actionPerformed(ActionEvent e) {
			String s=e.getActionCommand();
			String a=s.substring(0, s.indexOf(" "));
			String b=s.substring(s.lastIndexOf(" ")+1);
			//对MenuTable表格进行更新
			showMenu("select * from menu where 分类='"+a+"' and 小类='"+b+"'");
		}
	}
}


