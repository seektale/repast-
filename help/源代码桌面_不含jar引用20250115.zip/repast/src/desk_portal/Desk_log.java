package desk_portal;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

import root.Front;
import root.Sql;
public class Desk_log extends JSplitPane{
	private static final long serialVersionUID = -4593851044789735752L;
	private JTable t=Sql.getTable();
	private JTable dsc=Sql.getTable();
	public Desk_log(int Meal_num){
		
		String sql="select * from dishlog where 台次="+Meal_num+" order by 序号";
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
		
		t.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);	//恢复多选功能
		t.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				String str=Sql.getval(t, "商品索引", t.getSelectedRow());
				if(str.equals("0")) return ;
				str = "select * from dishlog where 商品索引="+str ;
				Sql.getArrayToTable(str, this, dsc);
				Sql.TableAtt(dsc, true, false);
			}
		});
		
		setOrientation(JSplitPane.VERTICAL_SPLIT);
		setLeftComponent(new JScrollPane(t));
		setRightComponent(new JScrollPane(dsc));
		setSize(Front.inFrame.getSize());
		setDividerLocation(0.7);
	}
}
