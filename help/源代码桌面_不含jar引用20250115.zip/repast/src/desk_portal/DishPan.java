package desk_portal;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableColumnModel;
import print.PrintDB;
import pub.ConfigFile;
import pub.ModifiedFlowlayout;
import pub.Popup_tab;
import pub.TableCellb;
import pub.Var;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class DishPan extends JPanel implements ActionListener,TableModelListener,DropTargetListener {
	private static final long serialVersionUID = -743602336627445531L;
	public JButton refresh = new JButton("刷新") ;
	public JButton qumenu = new JButton("打开菜谱") ;
	private JCheckBox cardmodel	= new JCheckBox("卡片模式") ;
	
	private JButton delete=new JButton("删除");
	private JButton back=new JButton("退单");
	private JButton combine=new JButton("并单");
	private JButton split=new JButton("分单");
	private JButton chdesk=new JButton("换台");
	private JButton percent=new JButton("批量操作");
	private JButton printall=new JButton("全部下单");
	private JButton printhold=new JButton("全部叫起");
	
	private MenuPanSub menusub ;
	private JPanel Card	= new JPanel(new CardLayout());
	public  JTable cookup = new JTable();		//该桌台菜品表格
	public  JPanel dc = new JPanel();
	private JSplitPane centerjs = new JSplitPane();
	public int Meal_num;
	public DishPan(int Meal_num){
		this.Meal_num=Meal_num;
	    
		//新的解决方案
		dc.setLayout(new ModifiedFlowlayout(FlowLayout.LEFT, Var.dishhgap(), Var.dishvgap()));
		
	    //在注册监听之前初始化这两个参数
		String temp=ConfigFile.getProperty("MenuShowModel");
		if(temp.equals("Y"))	cardmodel.setSelected(true);
	    
	    JPanel chomode=new JPanel(new FlowLayout(FlowLayout.LEFT,5,2));
	    chomode.add(refresh);
	    chomode.add(cardmodel);
	    
	    qumenu.addActionListener(this);
	    refresh.addActionListener(this);
	    back.addActionListener(this);
	    chdesk.addActionListener(this);
	    delete.addActionListener(this);
	    combine.addActionListener(this);
	    split.addActionListener(this);
	    percent.addActionListener(this);
	    printall.addActionListener(this);
	    printhold.addActionListener(this);
	    cardmodel.addActionListener(this);
	    
	    delete.setToolTipText("一次选择一个 待出单的商品 删除");
	    back.setToolTipText("一次选择一个 已出单商品 退单，分单后的商品无法退单，需要合并后才能退单");
	    printall.setToolTipText("将待出单 全部 打印出单");
	    printhold.setToolTipText("与下单一样，但会标识叫起属性");
	    
	    chomode.add(new JLabel(" ※ ※ "));
	    chomode.add(delete);
	    chomode.add(back);
	    chomode.add(combine);
	    chomode.add(split);
	    chomode.add(chdesk);
	    chomode.add(new JLabel(" ※ ※ "));
	    chomode.add(percent);
	    chomode.add(printall);
	    chomode.add(printhold);
	    
	    cookup.setComponentPopupMenu(new Popup_tab(cookup));
	    cookup.getModel().addTableModelListener(this);
	    
	    //拖拽功能
		new DropTarget(Card, DnDConstants.ACTION_COPY_OR_MOVE, this, true, null);
		
	    Card.add(new JScrollPane(cookup),"表格模式");
	    JScrollPane js=new JScrollPane(dc);
		js.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
	    Card.add(js,"卡片模式");

	    final JPanel north=new JPanel(new BorderLayout());
	    north.add(chomode, BorderLayout.CENTER);
	    north.add(qumenu, BorderLayout.EAST);
	    
	    setLayout(new BorderLayout());
	    add(north, BorderLayout.NORTH);
	    add(cards(Card), BorderLayout.CENTER);
	}
	
	private JSplitPane cards(JPanel Card){
		centerjs.setLeftComponent(Card);
		menusub = new MenuPanSub(Meal_num);
		centerjs.setRightComponent(menusub);
		
		//响应回接口的结果
		menusub.setGetCallback(new MenuPanSub.GetDate() {
			public void onRefresh() {
				refresh();
			}
		});
		
		//centerjs.setDividerLocation(1.0);
		//centerjs.setOneTouchExpandable(true);
		centerjs.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
		centerjs.setDividerSize(0);
		return centerjs;
	}
	
	// 不要轻易改掉，刷新可能没那么简单
	public void refresh(){
		
		String sql = "select * from dish where 台次="+Meal_num ;
		
		if(cardmodel.isSelected()){
			((CardLayout)Card.getLayout()).show(Card, "卡片模式");
			dc.removeAll();
			dc.setVisible(false);
			dc.setVisible(true);
			final DishEDT edt = new DishEDT(this, sql);
			edt.execute();
			return ;
		}

		((CardLayout)Card.getLayout()).show(Card, "表格模式");
		// 找出当前选中行的索引
		int sel=cookup.getSelectedRow();
		String ind1 = sel<0 ? "" : Sql.getval(cookup, "索引", sel);
		
		// 取消对行选中状态，以免cookup的监听事件响应，//全部取消，不会出错
		if(cookup.getRowCount()>0){
			cookup.removeRowSelectionInterval(0, cookup.getRowCount()-1);
		}
		
		Sql.getArrayToTable(sql, this, cookup);
		// 隐藏指定列
		if(qumenu.getText().contains("关闭")){
			uphidemin();
			cookup.setRowHeight(26);
			cookup.setFont(new Font("楷体",Font.BOLD,18));
		}
		else{
			uphide();
			cookup.setRowHeight(Var.getTableHeight());
			cookup.setFont(null);
		}
		
		// 正确启用UI线程的方法,到EDT线程中执行
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
				Sql.autoWidthC(cookup);  //强行最大列宽
		    }
		});
		
		// 恢复选中此行
		if(!ind1.isEmpty())
		for(int k=0;k<cookup.getRowCount();k++){
			String ind2=Sql.getval(cookup, "索引", k);
			if(ind1.equals(ind2)){
				cookup.setRowSelectionInterval(k,k);
				break;
			}
		}
		
		cookup.setDefaultRenderer(Object.class, new TableCellb(cookup));
		// 右对齐
		//cookup.getColumn("实价").setCellRenderer(new MyTableCellRenderer());
		
		
		// 统计
		final ArrayList<String[]> val1 = Sql.getArrayToArrary("select bill_discribea("+Meal_num+")", this);
		final ArrayList<String[]> val2 = Sql.getArrayToArrary("select bill_discribec("+Meal_num+")", this);
		final String tip="<html><body><font color=blue size=5>"+val1.get(0)[0]+"</font><p>" +
				"<font color=red size=5>"+val2.get(0)[0]+"</font><p></body></html>";
		
		cookup.setToolTipText(tip);
		dc.setToolTipText(tip);
	}
	class MyTableCellRenderer extends DefaultTableCellRenderer {
		private static final long serialVersionUID = -4127477074143665006L;
		public MyTableCellRenderer() {
			super();
			setHorizontalAlignment(JLabel.RIGHT);
		}
		public void setValue(Object value) {
			super.setValue(value);
		}
	}
	
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==cardmodel){
			//记录配置
			ConfigFile.setProperty("MenuShowModel", cardmodel.isSelected());
			refresh();
		}
		else if(e.getSource()==refresh){
			refresh();
		}
		else if(e.getSource()==printall){
			new PrintDB(Meal_num, refresh);
			//refresh();	//刷新,PrintRun会执行刷新
		}
		else if(e.getSource()==printhold){
			new PrintDB(Meal_num, refresh, true);
			//refresh();	//刷新,PrintRun会执行刷新
		}
		else if(e.getSource()==back){
			int se = cookup.getSelectedRow();
			
			int k=sub();
			if(k==0) return ;
			backdish(k);
			
			//恢复选中行，这样做是为了快速退单，以免频繁需要先选中表中某一行数据
			if(cookup.getRowCount()==0) return ;
			if(cookup.getRowCount()==se) se=cookup.getRowCount()-1;
			cookup.setRowSelectionInterval(se,se);
		}
		else if(e.getSource()==chdesk){
			if(Meal_num==0)	JOptionPane.showMessageDialog(Front.front,"提示：未开台！");
			else new ChangeDesk(Meal_num);
		}
		else if(e.getSource()==delete){
			int se = cookup.getSelectedRow();
			int k=sub();
			if(k>0){
				Sql.mysqlprocedure("dish_del",k+"");
				refresh();	//刷新 
			}
			//恢复选中行，这样做是为了快速删除商品，以免频繁需要先选中表中某一行数据
			if(cookup.getRowCount()==0) return ;
			if(cookup.getRowCount()==se) se=cookup.getRowCount()-1;
			cookup.setRowSelectionInterval(se,se);
		}
		else if(e.getSource()==combine){
			if(cardmodel.isSelected()){
				final ArrayList<String> v=new ArrayList<String>();
				for(Component dcc : dc.getComponents()){
					dishCard temp = (dishCard)dcc;
					if(temp.boo) v.add(temp.ind+"");
				}
				if(v.size()==2){
					Sql.mysqlprocedure("dish_combine",v);
					refresh();	//刷新
					return ;
				}
				SouthPan.warn("请在卡片商品中选择 两个商品 进行并单操作！", true);
				return ;
			}
			
			int m[]=cookup.getSelectedRows();
			if(m.length==2){
				ArrayList<String> v=new ArrayList<String>();
				v.add(Sql.getval(cookup, "索引", m[0]));
				v.add(Sql.getval(cookup, "索引", m[1]));
				Sql.mysqlprocedure("dish_combine",v);
				refresh();	//刷新
				return ;
			}
			SouthPan.warn("请一次在表格中选择 两个商品 进行并单操作！", true);
		}
		else if(e.getSource()==split){
			int k=sub();
			if(k==0) return ;
			splitdish(k);
		}
		else if(e.getSource()==percent){
			batch ba=new batch();
			ba.show(percent, 1, percent.getHeight());
		}
		else if(e.getSource()==qumenu){
			if(qumenu.getText().contains("打开")){
				qumenu.setText("关闭菜谱");
				centerjs.setDividerLocation(0.5);
			}
			else{
				qumenu.setText("打开菜谱");
				centerjs.setDividerLocation(1.0);
			}
			refresh();
		}
	}
	
	//仅在第一次生成新对象时调用一下
	public void first(){
		qumenu.setText("关闭菜谱");
		centerjs.setDividerLocation(0.5);
		//确定第一次的位置
		menusub.setDividerLocation(0.25);
		refresh();
	}
	
	//退单
	public void backdish(int ind){
		String Tnum[]=Sql.getString("select 数量 from dish where 索引="+ind, this);
		final JSpinner num=new JSpinner(new SpinnerNumberModel(1d,-100d,Integer.MAX_VALUE,1));
		if(Tnum.length>0) num.setValue(Double.valueOf(Tnum[0]));
		num.setPreferredSize(new Dimension(160, 30));
		((JSpinner.NumberEditor)num.getEditor()).getTextField().addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e){
				if(e.getX()>num.getWidth()/2){
					num.setValue(num.getNextValue());
					return ;
				}
				num.setValue(num.getPreviousValue());
				//如果值小于等于0，则应恢复原值
				String temp = String.valueOf(num.getValue());
				double dou = Double.valueOf(temp);
				if(dou<=0) num.setValue(num.getNextValue());
			}
		});
		
		final JComboBox<String> reson = new JComboBox<String>(Var.getbackdish_reson());
		reson.setPreferredSize(new Dimension(160, 30));
		reson.setEditable(true);
		reson.setSelectedItem(ConfigFile.getProperty("BackDishReson"));
		reson.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ConfigFile.setProperty("BackDishReson", reson.getSelectedItem().toString());
			}
		});
		
		JPanel Pan=new JPanel();
		Pan.setPreferredSize(new Dimension(260,80));
		Pan.setLayout(new BoxLayout(Pan, BoxLayout.PAGE_AXIS));	  // 一行一行的布局
		JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("退单数量："));
		temp.add(num);
		Pan.add(temp);
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("退单原因："));
		temp.add(reson);
		Pan.add(temp);
		Pan.add(new JSeparator());	//分割线
		
		int action=JOptionPane.showConfirmDialog(Front.front, Pan, "退单（价格自动归零）", 2, 1, new ImageIcon());
		if(action==0){
			final ArrayList<String> v=new ArrayList<String>();
			v.add(ind+"");		//商品索引 
			v.add(num.getValue().toString());
			v.add(reson.getSelectedItem().toString());	//退单原因
			boolean b=Sql.mysqlprocedure("dish_back_init",v);
			if(b){
				//int re=JOptionPane.showConfirmDialog(Front.front, "退单成功，是否打印 退单 ？","打印退单",0);
				//if(re==0){
					new PrintDB(Meal_num, refresh);
				//}
			}
			refresh();
		}
	}
	//分单
	public void splitdish(int ind){
		String Tnum[]=Sql.getString("select 数量 from dish where 索引="+ind, this);
		final double num=Double.valueOf(Tnum[0]);
		final JSpinner pin1 = new JSpinner(new SpinnerNumberModel(0.0,0.0,1000.0,1.0));
		final JSpinner pin2 = new JSpinner(new SpinnerNumberModel(0.0,0.0,1000.0,1.0));
		pin1.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				double one=Double.valueOf(pin1.getValue().toString());
				pin2.setValue(num-one);
			}
		});
		JPanel p=new JPanel(new FlowLayout());
		p.add(new JLabel("分出数量:"));
		p.add(pin1);
		p.add(new JLabel("      剩余数量:"));
		p.add(pin2);
		
		int action=JOptionPane.showConfirmDialog(Front.front,p,"商品拆分 总数量："+num,2,1,new ImageIcon());
		if(action==0){
			ArrayList<String> v=new ArrayList<String>();
			v.add(ind+"");	//商品索引 
			v.add(pin1.getValue().toString());		//第一份数量
			v.add(pin2.getValue().toString());		//第二份数量
			
			Sql.mysqlprocedure("dish_split",v);
			refresh();	//刷新
		}
	}
	
	// 重复点单
	public void repeat(int ind){
		final JSpinner num=new JSpinner(new SpinnerNumberModel(1d,-100d,Integer.MAX_VALUE,1));
		num.setPreferredSize(new Dimension(160, 30));
		num.setValue(1);
		((JSpinner.NumberEditor)num.getEditor()).getTextField().addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(e.getX()>num.getWidth()/2){
					num.setValue(num.getNextValue());
				}
				else{
					num.setValue(num.getPreviousValue());
				}
			}
		});
		
		int action=JOptionPane.showConfirmDialog(Front.front,num,"重复点单 请输入数量：",2,1,new ImageIcon());
		if(action==0){
			String val[]=Sql.getString("select 商品编号,实价 from dish where 索引="+ind, this);
			if(val.length==0) return ;
			
			ArrayList<String> v=new ArrayList<String>();
			v.add(Meal_num+"");					//餐次
			v.add(val[0]);						//菜品编号
			v.add(num.getValue().toString());	//数量
			v.add(val[1]);						//价格
			//提交菜品
			Sql.mysqlprocedure("dish_order_init",v);
			
			refresh();
		}
	}
	
	//得到当前选中的商品索引
	private int sub(){
		if(cardmodel.isSelected()){
			ArrayList<Integer> dishind = new ArrayList<Integer>();
			for(Component dcc : dc.getComponents()){
				dishCard temp = (dishCard)dcc;
				if(temp.boo) dishind.add(temp.ind);
			}
			if(dishind.size()==0){
				SouthPan.warn("未选择目标商品，请单击选择！", true);
				return 0;
			}
			if(dishind.size()>1){
				SouthPan.warn("一次只能选择一个商品进行操作！", true);
				return 0 ;
			}
			return dishind.get(0);
		}
		
		//表格模式
		int k=cookup.getSelectedRow();
		if(k==-1){
			SouthPan.warn("请先选中要操作的数据行！", true);
			return 0;
		}
		return Integer.valueOf(Sql.getval(cookup, "索引", k));
	}
	
	String oldval = "" ;
	public void tableChanged(TableModelEvent arg0) {
		if(!cookup.isEditing())	return ;
		int m=cookup.getSelectedRow();
		int n=cookup.getSelectedColumn();
		if(m<0 || n<0) return ;
		
		String colname=cookup.getColumnName(n);		// 列名
		String ind=Sql.getval(cookup, "索引", m);	// 索引
		String val=Sql.getval(cookup, colname, m);	// 新值
		
		ArrayList<String> v=new ArrayList<String>();
		v.add(ind);
		v.add(val);
		if(colname.equals("商品名"))		Sql.mysqlprocedure("dish_name",v);
		else if(colname.equals("实价"))	Sql.mysqlprocedure("dish_price",v);
		else if(colname.equals("单位"))	Sql.mysqlprocedure("dish_unit",v);
		else if(colname.equals("数量"))	Sql.mysqlprocedure("dish_amount",v);
		else if(colname.equals("折扣"))	Sql.mysqlprocedure("dish_percent",v);
		else if(colname.equals("备注"))	Sql.mysqlprocedure("dish_remark",v);
		else {
			SouthPan.warn("不支持对列：<"+colname+"> 的编辑", true);
			return ;
		}
		
		refresh();	//不管修改成功与否，均刷新数据
	}
	
	/**
	 * 隐藏JTable中不需要显示的列
	 * @param table		需要隐藏列的JTable
	 * @param colIndex  需要隐藏的列的下标（JTable列下标从0开始）
	 */
	private void uphide(){
		String str[]=Var.getDishCol().split(",");	//以逗号分割的数字转字符串数组
		int[] colIndex=new int[str.length];
		for(int k=0;k<str.length;k++){
			colIndex[k]=Integer.valueOf(str[k]);
		}
		DefaultTableColumnModel dcm = (DefaultTableColumnModel)cookup.getColumnModel(); // 获取列模型
		for(int m=0;m<cookup.getColumnCount();m++){
			for (int n = 0; n < colIndex.length; n++) {
				if(m==n){
					dcm.getColumn(colIndex[m]).setPreferredWidth(0);
					dcm.getColumn(colIndex[m]).setMinWidth(0);
					dcm.getColumn(colIndex[m]).setMaxWidth(0);
					break;
				}
			}
		}
	}
	
	/**
	 * 隐藏JTable中不需要显示的列
	 * @param table		需要隐藏列的JTable
	 * @param colIndex  需要隐藏的列的下标（JTable列下标从0开始）
	 */
	private void uphidemin(){
		//String str[]=new String[]{"分类","商品名","实价","单位","数量"};
		String str[]=new String[]{"2","3","4","5","6","13","14","15"};
		int[] colIndex=new int[str.length];
		for(int k=0;k<str.length;k++){
			colIndex[k]=Integer.valueOf(str[k]);
		}
		DefaultTableColumnModel dcm = (DefaultTableColumnModel)cookup.getColumnModel(); // 获取列模型
		for(int m=0;m<cookup.getColumnCount();m++){
			for (int n = 0; n < colIndex.length; n++) {
				if(m==n){
					dcm.getColumn(colIndex[m]).setPreferredWidth(0);
					dcm.getColumn(colIndex[m]).setMinWidth(0);
					dcm.getColumn(colIndex[m]).setMaxWidth(0);
					break;
				}
			}
		}
	}
	
	/*
	 * 内部类
	 * */
	class batch extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -1825927878196L;
		private JMenuItem a = new JMenuItem("批量改折扣 (待出单,已出单,且该商品允许打折)");
		private JMenuItem b = new JMenuItem("批量改价格 (待出单,已出单)");
		private JMenuItem c = new JMenuItem("批量改数量 (待出单)");
		private JMenuItem d = new JMenuItem("批量改备注 (待出单,已出单)");
		public batch(){
			a.addActionListener(this);
			b.addActionListener(this);
			c.addActionListener(this);
			d.addActionListener(this);
			add(a);
			addSeparator();
			add(b);
			addSeparator();
			add(c);
			addSeparator();
			add(d);
		}
		
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==a){
				String per = JOptionPane.showInputDialog(Front.front,"请输入一个大于0小于1的值(修改折扣)：","0.9");
				if(per==null || per.isEmpty()) return ;
				
				ArrayList<String> v=new ArrayList<String>();
				v.add(Meal_num+"");
				v.add(per);
				Sql.mysqlprocedure("dish_percent_all",v);
				
				refresh();	//刷新
			}
			if(e.getSource()==b){
				String per = JOptionPane.showInputDialog(Front.front,"请输入一个数字(修改价格)：","0");
				if(per==null || per.isEmpty()) return ;
				
				ArrayList<String> v=new ArrayList<String>();
				v.add(Meal_num+"");
				v.add(per);
				Sql.mysqlprocedure("dish_price_all",v);
				
				refresh();	//刷新
			}
			if(e.getSource()==c){
				String per = JOptionPane.showInputDialog(Front.front,"请输入一个数字(修改数量)：","1");
				if(per==null || per.isEmpty()) return ;
				
				ArrayList<String> v=new ArrayList<String>();
				v.add(Meal_num+"");
				v.add(per);
				Sql.mysqlprocedure("dish_amount_all",v);
				
				refresh();	//刷新
			}
			if(e.getSource()==d){
				String per = JOptionPane.showInputDialog(Front.front,"请输入备注：","2桌备1桌");
				if(per==null || per.isEmpty()) return ;
				
				ArrayList<String> v=new ArrayList<String>();
				v.add(Meal_num+"");
				v.add(per);
				Sql.mysqlprocedure("dish_remark_all",v);
				
				refresh();	//刷新
			}
		}
	}
	
	
	
	/*************************************************************************************/

	@Override
	public void dragEnter(DropTargetDragEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dragExit(DropTargetEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dragOver(DropTargetDragEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void drop(DropTargetDropEvent arg0) {
		// TODO Auto-generated method stub
		if(MenuCard.drop_index==null || MenuCard.drop_price==null) return ;
		
		ArrayList<String> v=new ArrayList<String>();
		v.add(String.valueOf(Meal_num));	//餐次
		v.add(MenuCard.drop_index);			//菜品编号
		v.add("1");					        //数量
		v.add(MenuCard.drop_price);			//价格
		//提交菜品
		boolean boo = Sql.mysqlprocedure("dish_order_init",v);
		if(boo){
			refresh();
		}
	}

	@Override
	public void dropActionChanged(DropTargetDragEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
}

