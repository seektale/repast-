package vip;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import log.AdvSelect;
import pub.Photo;
import pub.PinYin;
import pub.Var;
import root.Front;
import root.Sql;
public class ARdes extends JPanel implements ActionListener,DocumentListener{
	private static final long serialVersionUID = 628339174455004718L;
	private JPanel nora=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JButton add=getButton("新建AR账");
	private JButton refresh=getButton("刷新");
	private JButton del=getButton("删除");
	private JButton charge=getButton("充值/扣款");
	private JButton credit=getButton("修改信用额度");
	private JButton lock=getButton("锁定/解锁");
	private JButton adv=new JButton("高级查询");
	
	private JTextField text=new JTextField(20);
	private JTable t=Sql.getTable();
	private String sql="select * from vip limit 0,200";
	public ARdes(){
	    setOpaque(false);
	    setLayout(new BorderLayout());
	    
	    nora.add(new JLabel(" ○ ○ "));
	    for(int k=0;k<Var.getAR_class().length;k++){
	    	getButton(Var.getAR_class()[k]);
	    }
	    
	    JPanel norb=new JPanel(new FlowLayout(FlowLayout.LEFT));
	    text.getDocument().addDocumentListener(this);
	    String web="<html><body>输入";
		web=web+"<font color=blue>&nbsp&nbsp客户AR账号&nbsp&nbsp</font>或";
		web=web+"<font color=blue>&nbsp&nbsp账户名/助记符&nbsp&nbsp</font>或";
		web=web+"<font color=blue>&nbsp&nbsp单位名称</font>&nbsp&nbsp查询：</body></html>";
	    norb.add(new JLabel(web));
		norb.add(text);
		norb.add(adv);
		
		JPanel nor=new JPanel();
		nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
		nor.add(nora);
		nor.add(new JSeparator());	//分割线
		nor.add(norb);
		add(nor,BorderLayout.NORTH);
		
		t.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount()==2){
					dia(false);
				}
			}
		});
		adv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AdvSelect("vip", t);
			}
		});
		
		add("Center",new JScrollPane(t));
		updateTable(); //显示默认记录
	}
	private JButton getButton(String s){
		JButton b=new JButton(s);
		b.addActionListener(this);
		nora.add(b);
		if(nora.getComponentCount()==2) nora.add(new JLabel(" ○ ○ "));
		return b;
	}
	
	public void changedUpdate(DocumentEvent e) {}
	public void insertUpdate(DocumentEvent e) {
		String val=text.getText();
		if(val==null) return ;
		sql="select * from vip where " +
			"AR账号 like '"+val+"%' or 账户名 like '%"+val+"%' or " +
			"助记符 like '"+val+"%' or 单位 like '%"+val+"%' limit 0,200;";
		updateTable();
	}
	public void removeUpdate(DocumentEvent e) {
		insertUpdate(e);
	}
	private void updateTable(){
		int k=t.getSelectedRow();
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
		if((k!=-1)&&(t.getRowCount()>k)){
			t.setRowSelectionInterval(k, k);
		}
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==add){
			dia(true);
		}
		else if(e.getSource()==refresh){
			updateTable();
		}
		else if(e.getSource()==del){
			if(check()) return ;
			
			final String ar = Sql.getval(t, "AR账号", t.getSelectedRow());
			final String img1 = Sql.getval(t, "图片一", t.getSelectedRow());
			final String img2 = Sql.getval(t, "图片二", t.getSelectedRow());
			if(img1.equals("0")==false || img2.equals("0")==false) {
				JOptionPane.showMessageDialog(null, "AR账户删除前请先删除相关的签名图片："+img1+" "+img2, "错误 Error", 0);
				return;
			}
			
			String val = JOptionPane.showInputDialog("AR账户删除原因？");
			if(val==null) return;
			
			final ArrayList<String> v=new ArrayList<String>();
			v.add("delete");
			v.add(ar);
			v.add("0");
			v.add(val);
			Sql.mysqlprocedure("AR_value", v);
			updateTable();
		}
		else if(e.getSource()==charge){
			if(check()) return ;
			
			JPanel pan = new JPanel(new GridLayout(4, 1));
			JTextField money = new JTextField("0");
			JTextField rem = new JTextField();
			pan.add(new JLabel(" 充值/扣款 金额：",JLabel.LEFT));
			pan.add(money);
			pan.add(new JLabel(" 备注：",JLabel.LEFT));
			pan.add(rem);
			int k=JOptionPane.showConfirmDialog(null, pan, "正数代表充值,负数代表扣款", 2, 1, new ImageIcon());
			if(k!=0) return ;
			
			try{
				Integer.valueOf(money.getText());
				ArrayList<String> v=new ArrayList<String>();
				v.add("charge");
				v.add(Sql.getval(t, "AR账号", t.getSelectedRow()));
				v.add(money.getText());
				v.add(rem.getText());
				Sql.mysqlprocedure("AR_value", v);
				updateTable();
			}catch (Exception exc) {
				JOptionPane.showMessageDialog(null,"只能输入数字","注意",0);
			}
		}
		else if(e.getSource()==credit){
			if(check()) return ;
			
			JPanel pan = new JPanel(new GridLayout(4, 1));
			JTextField money = new JTextField();
			JTextField rem = new JTextField();
			pan.add(new JLabel(" 用户透支额度：",JLabel.LEFT));
			pan.add(money);
			pan.add(new JLabel(" 本次修改原因：",JLabel.LEFT));
			pan.add(rem);
			int k=JOptionPane.showConfirmDialog(null, pan, "修改信用额度", 2, 1, new ImageIcon());
			if(k!=0) return ;
			
			try{
				Integer.valueOf(money.getText());
				ArrayList<String> v=new ArrayList<String>();
				v.add("credit");
				v.add(Sql.getval(t, "AR账号", t.getSelectedRow()));
				v.add(money.getText());
				v.add(rem.getText());
				Sql.mysqlprocedure("AR_value", v);
				updateTable();
			}catch (Exception exc) {
				JOptionPane.showMessageDialog(null,"只能输入数字","注意",0);
			}
		}
		else if(e.getSource()==lock){
			if(check()) return ;
			
			String s=JOptionPane.showInputDialog("锁定/解锁 备注");
			if(s==null) return ;
			
			ArrayList<String> v=new ArrayList<String>();
			v.add("lock");
			v.add(Sql.getval(t, "AR账号", t.getSelectedRow()));
			v.add("0");
			v.add(s);
			Sql.mysqlprocedure("AR_value", v);
			updateTable();
		}
		else{
			sql="select * from vip where 类别='"+e.getActionCommand()+"' limit 0,200;";
			updateTable();
		}
	}
	private boolean check(){
		if(t.getSelectedRow()>=0) return false;
		JOptionPane.showMessageDialog(Front.front,"未选择数据行","注意",0);
		return true;
	}
	private void dia(boolean b){
		JTextField ar=new JTextField(12);
		JComboBox<String> cla=new JComboBox<String>(Var.getAR_class());
		JCheckBox ch=new JCheckBox("锁定");
		JTextField company=new JTextField(25);
		JTextField address=new JTextField(25);
		final JTextField user=new JTextField(10);
		final JTextField helpChar=new JTextField(9);
		JTextField phone=new JTextField(10);
		JTextField createDate=new JTextField(9);
		JTextField money=new JTextField(10);
		JTextField exceed=new JTextField(9);
		JTextField sign1=new JTextField(10);
		JTextField sign2=new JTextField(10);
		JTextField remark=new JTextField(25);
		JLabel icon1=new JLabel(Var.getIcon("米饭"));
		JLabel icon2=new JLabel(Var.getIcon("米饭"));
		
		JPanel pan=new JPanel();
		pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));	//一行一行的布局
		
		JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		JLabel la=new JLabel("AR账号：");
		la.setPreferredSize(new Dimension(60, 20));
		temp.add(la);
		temp.add(ar);
		temp.add(cla);
		ch.setEnabled(false);
		temp.add(ch);
		pan.add(temp);
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("单位：");
		la.setPreferredSize(new Dimension(60, 20));
		temp.add(la);
		temp.add(company);
		pan.add(temp);
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("地址：");
		la.setPreferredSize(new Dimension(60, 20));
		temp.add(la);
		temp.add(address);
		pan.add(temp);
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("账户名：");
		la.setPreferredSize(new Dimension(60, 20));
		temp.add(la);
		temp.add(user);
		la=new JLabel(" 助记符");
		la.setPreferredSize(new Dimension(45, 20));
		temp.add(la);
		temp.add(helpChar);
		pan.add(temp);
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("账户余额：");
		la.setPreferredSize(new Dimension(60, 20));
		temp.add(la);
		money.setEditable(false);money.setBackground(Color.LIGHT_GRAY);
		temp.add(money);
		la=new JLabel(" 信用额");
		la.setPreferredSize(new Dimension(45, 20));
		temp.add(la);
		exceed.setEditable(false);exceed.setBackground(Color.LIGHT_GRAY);
		temp.add(exceed);
		pan.add(temp);
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("联系电话：");
		la.setPreferredSize(new Dimension(60, 20));
		temp.add(la);
		temp.add(phone);
		la=new JLabel(" 建账期");
		la.setPreferredSize(new Dimension(45, 20));
		temp.add(la);
		createDate.setEditable(false);createDate.setBackground(Color.lightGray);
		temp.add(createDate);
		pan.add(temp);
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("有效签名：");
		la.setPreferredSize(new Dimension(60, 20));
		temp.add(la);
		temp.add(sign1);
		temp.add(sign2);
		pan.add(temp);
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("备注：");
		la.setPreferredSize(new Dimension(60, 20));
		temp.add(la);
		temp.add(remark);
		pan.add(temp);

		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("签名照参考：");
		la.setPreferredSize(new Dimension(100, 20));
		temp.add(la);
		pan.add(temp);
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(icon1);
		pan.add(temp);
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(icon2);
		pan.add(temp);
		
		pan.add(new JSeparator());	//分割线
		
		final PinYin py = new PinYin();
		user.getDocument().addDocumentListener(new DocumentListener() {
			public void removeUpdate(DocumentEvent arg0) {
				helpChar.setText(py.String2Alpha(user.getText()));
			}
			public void insertUpdate(DocumentEvent arg0) {
				helpChar.setText(py.String2Alpha(user.getText()));
			}
			public void changedUpdate(DocumentEvent arg0) {}
		});
		
		
		//初始化参数
		if(b){
			ar.setText("输入卡号 或 自定义编码");
		}
		else{
			int row=t.getSelectedRow();
			ar.setEditable(false);
			ar.setBackground(Color.LIGHT_GRAY);
			ar.setText(Sql.getval(t, "AR账号", row));
			cla.setSelectedItem(Sql.getval(t, "类别", row));
			if(Sql.getval(t, "锁定", row).equals("Y"))	ch.setSelected(true);
			company.setText(Sql.getval(t, "单位", row));
			address.setText(Sql.getval(t, "地址", row));
			user.setText(Sql.getval(t, "账户名", row));
			helpChar.setText(Sql.getval(t, "助记符", row));
			phone.setText(Sql.getval(t, "电话", row));
			createDate.setText(Sql.getval(t, "建账日期", row));
			money.setText(Sql.getval(t, "余额", row));
			exceed.setText(Sql.getval(t, "信用额度", row));
			sign1.setText(Sql.getval(t, "签名一", row));
			sign2.setText(Sql.getval(t, "签名二", row));
			remark.setText(Sql.getval(t, "备注", row));
			
			String pic1=Sql.getval(t, "图片一", row);
			String pic2=Sql.getval(t, "图片二", row);
			if(!pic1.equals("0")) icon1.setIcon(Photo.readIcon(Integer.valueOf(pic1),true));
			if(!pic2.equals("0")) icon2.setIcon(Photo.readIcon(Integer.valueOf(pic2),true));
		}
		
		boolean result=true;
		do{
			int k=JOptionPane.showConfirmDialog(null, pan,"AR账户管理",2,1,new ImageIcon());
			if(k!=0) return ;
			
			ArrayList<String> v=new ArrayList<String>();
			if(b) v.add("Y"); else v.add("N");
			v.add(ar.getText());
			v.add(cla.getSelectedItem().toString());
			v.add(company.getText());
			v.add(address.getText());
			v.add(user.getText());
			v.add(helpChar.getText());
			v.add(phone.getText());
			v.add(sign1.getText());
			v.add(sign2.getText());
			v.add(remark.getText());
			result = Sql.mysqlprocedure("AR_edit", v);
		}while(!result);
		
		updateTable();
	}
}

