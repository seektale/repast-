package vip;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import root.Sql;
public class ARconsume extends JPanel implements ActionListener,DocumentListener{
	private static final long serialVersionUID = -3434694733889928203L;
	private JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JTextField text=new JTextField(20);
	private JButton sel=new JButton("返回AR账号列表");
	private JTable t=Sql.getTable();
	private String sql="select * from vip limit 0,100";
	public ARconsume(){
		setLayout(new BorderLayout());
		sel.addActionListener(this);
		text.getDocument().addDocumentListener(this);
		t.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(t.getColumnName(0).equals("AR账号")){
					String val=Sql.getval(t, "AR账号", t.getSelectedRow());
					
					String a = "select '未班结',deskgo.台次,结账工号,结账时间,区域,台号,别名,结算方式,参数,金额 from " +
					   		   "(deskgo right join billstyle on deskgo.台次=billstyle.台次) " +
					   		   "where 结算方式 like '挂AR%' AND NOT ISNULL(结账时间) and 参数='"+val+"' ";
			
					String b = "select '已班结',hqdeskgo.台次,结账工号,结账时间,区域,台号,别名,结算方式,参数,金额 from " +
					   		   "(hqdeskgo right join billstyle on hqdeskgo.台次=billstyle.台次) " +
					   		   "WHERE 结算方式 like '挂AR%' AND NOT ISNULL(`结账时间`) and 参数='"+val+"' ";
			
					ArrayList<String[]> arr = Sql.getArrayToArrary(a+" union "+b, ARconsume.this);
					if(arr.size()==0){
						JOptionPane.showMessageDialog(null,"当前AR账号没有消费记录存在","消息",0);
						return ;
					}
					Sql.getArrayToTable(a+" union "+b , this, t);
					Sql.TableAtt(t, true, false);
				}
			}
		});
		String web="<html><body>输入";
		web=web+"<font color=blue>&nbsp&nbsp客户AR账号&nbsp&nbsp</font>或";
		web=web+"<font color=blue>&nbsp&nbsp账户名/助记符&nbsp&nbsp</font>或";
		web=web+"<font color=blue>&nbsp&nbsp单位名称</font>&nbsp&nbsp查询：</body></html>";
		nor.add(new JLabel(web));
		nor.add(text);
		nor.add(sel);
		
		add(nor,BorderLayout.NORTH);
		add(new JScrollPane(t),BorderLayout.CENTER);
		
		String a = "select '未班结',deskgo.台次,结账工号,结账时间,区域,台号,别名,结算方式,参数,金额 from " +
				   "(deskgo right join billstyle on deskgo.台次=billstyle.台次) " +
				   "where 结算方式 like '挂AR%' AND NOT ISNULL(结账时间) ";
		
		String b = "select '已班结',hqdeskgo.台次,结账工号,结账时间,区域,台号,别名,结算方式,参数,金额 from " +
				   "(hqdeskgo right join billstyle on hqdeskgo.台次=billstyle.台次) " +
				   "WHERE 结算方式 like '挂AR%' AND NOT ISNULL(`结账时间`) ";

		Sql.getArrayToTable(a+" union "+b+" order by 结账时间 desc limit 0,200", this, t); //默认显示一个汇总
		Sql.TableAtt(t, true, false);
	}
	
	public void changedUpdate(DocumentEvent e) {}
	public void insertUpdate(DocumentEvent e) {
		String val=text.getText();
		if(val==null) return ;
		sql = "select * from vip where " +
					 "AR账号 like '"+val+"%' or 账户名 like '%"+val+"%' or " +
					 "助记符 like '"+val+"%' or 单位 like '%"+val+"%' limit 0,100;";
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
	}
	public void removeUpdate(DocumentEvent e) {
		insertUpdate(e);
	}
	public void actionPerformed(ActionEvent e) {
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
	}
}
