package vip;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import root.Front;
import root.Sql;
import sidePanel.WestPan;
public class ICinit extends JPanel implements ActionListener{
	private static final long serialVersionUID = -3434694733889928203L;
	private JPanel cen=new JPanel(new GridLayout(8, 2));
	private JButton init = new JButton("新卡初始化密码");
	private JButton restore = new JButton("恢复出厂密码设置");
	private JButton check = new JButton("检查 check");
	
	private JTextField a = new JTextField("ffffffffffff",10); 
	private JTextField b = new JTextField("",10);
	private JNativeSub jn = new JNativeSub();
	public ICinit(){
		setLayout(new BorderLayout());
		
		subpan sub[] = new subpan[16];
		int k = 0 ;
		for(JPanel p : sub){
			p = new subpan(k);
			p.setBorder(Sql.getBorder(2, "第"+ k++ +"扇区"));
			cen.add(p);
		}
		
		String html="<html><body>说明：默认密码是IC卡片初始化时系统设定的口令，如果初始口令不正确，可尝试自己输入一个正确的口令。" +
		 			"这里只对A密码进行校验。IC卡出厂密码：FFFFFFFFFFFF<p> " +
		 			"<font color=blue>初始化密码：</font>将第 2 扇区的密码修改为系统设定的密码,并写入卡的编号,不对其它任何数据修改或变更。" +
		 			"<font color=blue>恢复出厂密码：</font>将第 2 扇区的密码恢为出厂密码 FFFFFFFFFFFF,不修改任何数据。</font></body></html>";
		JLabel tip = new JLabel(html);
		
		JPanel fuc = new JPanel(new FlowLayout(FlowLayout.LEFT));
		fuc.setBackground(Color.LIGHT_GRAY);
		fuc.add(init);
		fuc.add(restore);
		fuc.add(check);
		fuc.add(new JLabel("  输入12位16进制原始密码：",JLabel.RIGHT));
		fuc.add(a);
		fuc.add(new JLabel("  IC卡表面上的编号：",JLabel.RIGHT));
		fuc.add(b);
		
		tip.setBackground(Color.LIGHT_GRAY);
		tip.setOpaque(true);
		tip.setPreferredSize(new Dimension(1,40));
		init.addActionListener(this);
		restore.addActionListener(this);
		check.addActionListener(this);
		
		a.setBackground(Color.PINK);
		a.setFont(new Font(null, Font.BOLD, 15));
		b.setFont(new Font(null, Font.BOLD, 15));
		a.getDocument().addDocumentListener(new DocumentListener() {
			public void removeUpdate(DocumentEvent e) {
				insertUpdate(e);
			}
			public void insertUpdate(DocumentEvent e) {
				if(a.getText().length()==12){
					a.setBackground(Color.PINK);
					return ;
				}
				a.setBackground(Color.RED);
			}
			public void changedUpdate(DocumentEvent e) {}
		});
		
		add(fuc, BorderLayout.NORTH);
		add(cen, BorderLayout.CENTER);
		add(tip, BorderLayout.SOUTH);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==check){
			//从 ARdes 复制过来的代码
			ArrayList<String> arr = jn.getMyInfo();
			if(arr==null || arr.size()!=3) return ;
			
			JPanel pan = new JPanel(new BorderLayout());
			pan.setPreferredSize(new Dimension(220, 80));
			JPanel west = new JPanel(new GridLayout(3, 1));
			
			west.add(new JLabel("卡面编号:"));
			west.add(new JLabel("卡密码MD5:  "));
			west.add(new JLabel("总资产:"));
			
			JPanel cen = new JPanel(new GridLayout(3, 1));
			for(String s : arr){
				JTextField temp = new JTextField(s);
				temp.setBackground(Color.LIGHT_GRAY);
				temp.setEditable(false);
				cen.add(temp);
			}
			
			pan.add(west, BorderLayout.WEST);
			pan.add(cen, BorderLayout.CENTER);
			JOptionPane.showMessageDialog(Front.front, pan, "IC卡片查询  "+jn.snr, 1, new ImageIcon());
			
			return ;
		}
		
		/*********************************************************************************************/
		
		String user = WestPan.curuser.getText();
		if(!user.startsWith("root")){
			JOptionPane.showMessageDialog(null, "操作属风险行为，仅限管理员ROOT操作。", "注意", 2);
			return ;
		}
		
		if(e.getSource()==restore){
			jn.restore();
			return ;
		}
		if(a.getText().length()!=12){
			JOptionPane.showMessageDialog(null, "原始密码长度不正确", "注意", 0);
			return ;
		}
		if(a.getText().getBytes().length>16){
			JOptionPane.showMessageDialog(null, "输入的卡片编号太长,限16字节。", "注意", 0);
			return ;
		}
		boolean res = jn.initCard(hexStringToBytes(a.getText()), b.getText());
		if(res){
			try{
				int k = Integer.valueOf(b.getText().trim());
				b.setText((k+1)+"");
			}catch (Exception err) {}
		}
	}
	
	// 把字节用  16 进制表示字节
	private String Hex16(byte[] b) {
	   String val = "" ;
	    for (byte k : b) {
	        String temp = Integer.toHexString(k & 0xFF);
	        
	        if(temp.length()==1) temp = "0"+temp ;
	        val = val + temp ;
	        
	        System.out.print(temp+" ");
	    }
	    
	    System.out.println();
	    return val ;
	}
	// 将16进制字符串转为字节数组
	public byte[] hexStringToBytes(String hexString) {
		if (hexString == null || hexString.equals("")) {
			return null;
		}
		hexString = hexString.toUpperCase();
		int length = hexString.length() / 2;
		char[] hexChars = hexString.toCharArray();
		byte[] d = new byte[length];
		for (int i = 0; i < length; i++) {
			int pos = i * 2;
			d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
		}
		return d;
	}
	private byte charToByte(char c) {
		return (byte) "0123456789ABCDEF".indexOf(c);
	}
	
	class subpan extends JPanel implements ActionListener{
		private static final long serialVersionUID = 2542276532156724792L;
		private JLabel a = new JLabel("", JLabel.CENTER);
		private JLabel b = new JLabel("", JLabel.CENTER);
		private JLabel c = new JLabel("", JLabel.CENTER);
		private JLabel d = new JLabel("", JLabel.CENTER);
		private JButton m = new JButton("默认密码");
		private JButton n = new JButton("指定密码");
		private int k ;
		public subpan(int k){
			this.k = k ;
			setLayout(new BorderLayout());
			m.addActionListener(this);
			n.addActionListener(this);
			
			if(k==1 || k==2 || k==3){
				m.setForeground(Color.BLUE);
				n.setForeground(Color.BLUE);
			}
			
			JPanel left = new JPanel(new GridLayout(2,2));
			left.add(a);
			left.add(b);
			left.add(c);
			left.add(d);
			add(left, BorderLayout.CENTER);
			
			JPanel east = new JPanel(new GridLayout(2,1));
			east.add(m);
			east.add(n);
			add(east, BorderLayout.EAST);
		}
		
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==n){
				String val = JOptionPane.showInputDialog("请输入12位密码(16进制0-9,A-F)：");
				if(val==null || val.isEmpty()) return ;
				if(val.length()!=12){
					JOptionPane.showMessageDialog(Front.front, "密码长度不正确");
					return ;
				}
				
				getData(hexStringToBytes(val));
				return ;
			}
			getData(jn.psd);
		}
		
		private void getData(byte[] psd){
			// 先清空数据
			a.setText("");
			b.setText("");
			c.setText("");
			d.setText("");
			a.setToolTipText(null);
			b.setToolTipText(null);
			c.setToolTipText(null);
			d.setToolTipText(null);
			
			try{
				ArrayList<byte[]> arr = jn.getInfoArea(psd, k);
				if(arr==null) return ;
				
				a.setText(Hex16(arr.get(0)));
				b.setText(Hex16(arr.get(1)));
				c.setText(Hex16(arr.get(2)));
				d.setText(Hex16(arr.get(3)));
				
				a.setToolTipText("<html><body>"+new String(arr.get(0))+"<p>"+jn.toHex(arr.get(0))+"</body></html>");
				b.setToolTipText("<html><body>"+new String(arr.get(1))+"<p>"+jn.toHex(arr.get(1))+"</body></html>");
				c.setToolTipText("<html><body>"+new String(arr.get(2))+"<p>"+jn.toHex(arr.get(2))+"</body></html>");
				d.setToolTipText("<html><body>"+new String(arr.get(3))+"<p>"+jn.toHex(arr.get(3))+"</body></html>");
			}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
			}
		}
	}
}
