package vip;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;
import org.xvolks.jnative.JNative;
import org.xvolks.jnative.exceptions.NativeException;
import org.xvolks.jnative.Type;
import org.xvolks.jnative.pointers.Pointer;
import root.Front;
public class JNativeSub {
	private int icdev = 0 ;
	public String snr = "" ;	// 卡片序列号
	
	//byte p[] = new byte[]{0,0,0,0,0,0};
	public byte psd[] = new byte[]{(byte)0x78, (byte)0x97, (byte)0x89, (byte)0x78, (byte)0x97, (byte)0x89};
	/*
	private void JustStudy() throws NativeException, IllegalAccessException {
		// 硬件版本信息
		Pointer ptr = Pointer.createPointerFromString("                  "); 
		JNative jn = new JNative("mwrf32", "rf_get_status");
		jn.setParameter(0, icdev);
		jn.setParameter(1, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		int result = jn.getRetValAsInt();
		System.out.println("rf_get_status: "+ptr.getAsString()+" "+result);
		
		// 蜂鸣
		jn = new JNative("mwrf32", "rf_beep");
		jn.setParameter(0, Type.INT, ""+icdev);
		jn.setParameter(1, Type.INT, "30");
		jn.setRetVal(Type.INT);
		jn.invoke();
		result = jn.getRetValAsInt();
		System.out.println("valc: "+result);
		
		//取得读写器产品序列号，没有，读取不到
		ptr = Pointer.createPointer(17);
		jn = new JNative("mwrf32", "rf_srd_snr");
		jn.setParameter(0, Type.INT, ""+icdev);
		jn.setParameter(1, Type.INT, "16");
		jn.setParameter(2, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		result = jn.getRetValAsInt();
		System.out.println("vald: "+ptr.getAsString()+" "+result);
		
		//读取软件版本号
		ptr = Pointer.createPointerFromString("                         "); 
		jn = new JNative("mwrf32", "lib_ver");
		jn.setParameter(0, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		result = jn.getRetValAsInt();
		System.out.println("vale: "+ptr.getAsString()+" "+result);
		
		//射频读写模块复位, 断电几毫秒
		jn = new JNative("mwrf32", "rf_reset");
		jn.setParameter(0, icdev);
		jn.setParameter(1, 300);
		jn.setRetVal(Type.INT);
		jn.invoke();
		result = jn.getRetValAsInt();
		System.out.println("rf_reset: "+result);
	}
	
	
	// 在进行值操作时，必须先执行初始化值函数，然后才可以读、减、加的操作, (可能初始化是将该块的存储格式按官方的格式存储，好比硬盘格式化)
	private boolean initvalsub(int k, long initval) throws NativeException, IllegalAccessException {
		//LONG versionLong = new LONG(32);  
        //versionLong.setValue(initval);  
        
		JNative jn = new JNative("mwrf32", "rf_initval");
		jn.setParameter(0, icdev);
		jn.setParameter(1, k);    	// 块地址（1～63）
		jn.setParameter(2, Type.LONG, String.valueOf(initval)); 	//初始值
		jn.setRetVal(Type.INT);
		jn.invoke();
		int result = jn.getRetValAsInt();
		System.out.println("rf_inival: "+result);
		
		return false ;
	}
	// 加减值
	private void valplus(int who, long desval) throws NativeException, IllegalAccessException {
		if(desval>0){
			JNative jn = new JNative("mwrf32", "rf_increment");
			jn.setParameter(0, icdev);
			jn.setParameter(1, 4);    	// 块地址（1～63）
			jn.setParameter(2, Type.LONG, String.valueOf(desval)); 	// 要增加的值
			jn.setRetVal(Type.INT);
			jn.invoke();
			int result = jn.getRetValAsInt();
			System.out.println("rf_increment: "+result);
		}
		else{
			desval = desval * -1 ;
			JNative jn = new JNative("mwrf32", "rf_decrement");
			jn.setParameter(0, icdev);
			jn.setParameter(1, 4);    	// 块地址（1～63）
			jn.setParameter(2, Type.LONG, String.valueOf(desval)); 	// 要减的值
			jn.setRetVal(Type.INT);
			jn.invoke();
			int result = jn.getRetValAsInt();
			System.out.println("rf_decrement: "+result);
		}
	}
	// 读取值
	private long readval(int k) throws NativeException, IllegalAccessException {
		if(k<0 || k>63){
			JOptionPane.showMessageDialog(null, "指定的块地址 "+k+" 不正确，志地埴范围:0-63");
			return -1 ;
		}
		if((k+1) % 4 == 0){
			JOptionPane.showMessageDialog(null, "指定的块地址 "+k+" 不正确，志地埴范围:0-63, 控制块除外。");
			return -1 ;
		}
		Pointer ptr = Pointer.createPointer(16);
		
		JNative jn = new JNative("mwrf32", "rf_readval");
		jn.setParameter(0, icdev);
		jn.setParameter(1, k);    	// 块地址（1～63）
		jn.setParameter(2, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		//int result = jn.getRetValAsInt();
		//System.out.println("rf_readval: "+result);
		
		return ptr.getAsLong(0);
	}
	
	*/
	
	// 符合我自己的餐饮系统查询卡数据
	public ArrayList<String> getMyInfo() {
		ArrayList<byte[]> arr = null ;
		ArrayList<String> result = new ArrayList<String>();
		
		try{
			arr = getInfo(psd, 123);
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
		}
		
		// 翻译字节数据
		if(arr==null) return null;
		for(byte[] temp : arr){
			result.add(new String(temp).trim());
		}

		return result ;
	}
	
	/**********************************************************************************/
	// 符合我自己的餐饮系统 , 发行IC卡
	public boolean giveCard(){

		//检查是否在使用中
		try{
			ArrayList<byte[]> temp = getInfo(psd, 10);
			if(temp==null) return false ;
			
			if(!Arrays.equals(temp.get(0), new byte[16])){
				String check = new String(temp.get(0)) ;
				JOptionPane.showMessageDialog(Front.front, "当前IC卡片正在使用中。请换一张卡片！\nval:"+check, "错误", 0);
				return false ;
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace() ;
			JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
			return false ;
		}
		
		// 写入数据,   注意：卡的编号用null代替，以免被抺掉
		return giveCardData(null, "", "0");
	}
	
	/**********************************************************************************/
	
	// 符合我自己的餐饮系统 , 充值
	public boolean CardCharge(double money){
		double srcMoney = 0.0 ;
		//检查是否在使用中
		try{
			ArrayList<byte[]> temp = getInfo(psd, 10);
			if(temp==null) return false ;
			
			if(Arrays.equals(temp.get(0), new byte[16])){
				JOptionPane.showMessageDialog(Front.front, "当前IC卡片未发行/启用！", "错误", 0);
				return false ;
			}
			
			String srcm = new String(temp.get(0)) ;
			srcMoney = Double.valueOf(srcm.trim()) ;
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace() ;
			try{CloseDev();}catch (Exception err) {};
			JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
			return false ;
		}
		
		boolean b = giveCardData(null, null, String.valueOf(srcMoney+money));
		if(b==false) return false ;
		
		return true ;
	}
	
	/**********************************************************************************/
	
	// 符合我自己的餐饮系统 , 空白卡初始化新卡片(按我的卡片信息存储规则制作)
	public boolean initCard(byte[] initpsd, String cardno){
		try{
			if(OpenDev()){
				CloseDev();
				return false;
			}
			
			// 第二个认证
			if(auth(initpsd, 2)){
				CloseDev();
				return false;
			}
			// 修改第2个扇区控制块里面的A密码
			boolean b = writeb3(initpsd, psd, 2);
			if(b==false){
				CloseDev();
				JOptionPane.showMessageDialog(Front.front, "修改第 二 扇区密码失败", "出现错误", 0);
				return false;
			}

			// 写入卡片外面编号信息, 需要先认证
			if(auth(psd, 2)){
				return false;
			}
			writeDate(8, cardno.getBytes());

			beep();
			CloseDev();
			
			JOptionPane.showMessageDialog(Front.front, "IC卡片初始化完成！", "消息", 1);
		}
		catch (Exception e) {
			e.printStackTrace();
			try{CloseDev();}catch (Exception err) {};
			JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
			return false;
		}
		return true;
	}
	// 恢复出厂设置
	public boolean restore(){
		byte def[] = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF};
		try{
			if(OpenDev()){
				CloseDev();
				return false;
			}
			
			// 修改第2个扇区控制块里面的A密码
			boolean b = writeb3(psd, def, 2);
			if(b==false){
				CloseDev();
				JOptionPane.showMessageDialog(Front.front, "恢复第 二 扇区密码失败", "出现错误", 0);
				return false;
			}

			beep();
			CloseDev();
			
			JOptionPane.showMessageDialog(Front.front, "IC卡片恢复出厂设置完成！", "消息", 1);
		}
		catch (Exception e) {
			e.printStackTrace();
			try{CloseDev();}catch (Exception err) {};
			JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
			return false;
		}
		return true;
	}
	// 专供上面的修改密码调用
	private boolean writeb3(byte[] initpsd, byte[] despsd, int area) throws NativeException, IllegalAccessException{
		byte def[] = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF};
		// 必须先认证了之后，才能再进行读写操作。
		if(auth(initpsd, area)){
			return false;
		}
		
		// 读取卡中数据
		Pointer ptr = Pointer.createPointer(16);
		JNative jn = new JNative("mwrf32", "rf_read");
		jn.setParameter(0, icdev);
		jn.setParameter(1, area*4+3);    // 读取哪个控制块
		jn.setParameter(2, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		
		int result = jn.getRetValAsInt();
		//System.out.println("rf_changeb3: 改密码结果1:"+result);
		if(result==1 || result==12) return false ;
		
		byte temp[] = ptr.getMemory() ;
		System.arraycopy(despsd, 0, temp, 0,  6);		// A密码修改
		if(Arrays.equals(despsd, def)){
			System.arraycopy(despsd, 0, temp, 10, 6);	// B密码未启用时，B密码区可用作存储数据，这里存储A密码作备忘
		}
		else{
			System.arraycopy(new byte[16], 0, temp, 10, 6);
		}
		
		// 写入数据
		ptr = Pointer.createPointer(16);
		ptr.setMemory(temp);
		
		jn = new JNative("mwrf32", "rf_write");
		jn.setParameter(0, icdev);
		jn.setParameter(1, area*4+3);    // 写入哪个块,一次必须写一个块，为16个字节；M1卡块地址（1～63）；
		jn.setParameter(2, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		
		result = jn.getRetValAsInt();
		//System.out.println("rf_changeb3: 改密码结果2:"+result);
		if(result==1) return false ;
		
		
		/* 官方提供的修改密码的方法
		Pointer pA = Pointer.createPointer(6);
		pA.setMemory(psd_new);
		Pointer pB = Pointer.createPointer(6);
		pB.setMemory(psd_new);
		
		
		jn = new JNative("mwrf32", "rf_changeb3");
		jn.setParameter(0, icdev);
		jn.setParameter(1, area);
		
		jn.setParameter(2, pA);   //
		jn.setParameter(3, 0);
		jn.setParameter(4, 0);
		jn.setParameter(5, 0);
		jn.setParameter(6, 1);
		jn.setParameter(7, 0);
		jn.setParameter(8, pB);   //
		
		jn.setRetVal(Type.INT);
		jn.invoke();
		result = jn.getRetValAsInt();
		System.out.println("rf_changeb3: 改密码结果:"+result);
		*/
		
		
		return true ;
	}
	
	//发新卡写入数据
	public boolean giveCardData(String a, String b, String c){
		try{
			if(OpenDev()){
				CloseDev();
				return false ;
			}
			
			if(a!=null || b!=null || c!=null){
				if(auth(psd, 2)){
					CloseDev();
					return false ;
				}
				if(a!=null) writeDate(2*4,   GetByte16(a));
				if(b!=null) writeDate(2*4+1, GetByte16(b));
				if(c!=null) writeDate(2*4+2, GetByte16(c));
			}
			
			beep();
			CloseDev();
		}
		catch (Exception e) {
			e.printStackTrace();
			try{CloseDev();}catch (Exception err) {};
			JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
			return false ;
		}
		
		return true ;
	}
	private byte[] GetByte16(String s){
		if(s.getBytes().length>16){
			byte b[] = new byte[16] ;
			System.arraycopy(s.getBytes(), 0, b, 0, 16);
			return b ;
		}
		return s.getBytes() ;
	}
	/**********************************************************************************/
	
	// 向卡片中写入密码
	public boolean CardSetPsd(String src, String des){
		try{
			if(OpenDev()){
				CloseDev();
				return false ;
			}
			
			if(auth(psd, 2)){
				CloseDev();
				return false ;
			}
			
			ArrayList<byte[]> temp = getData(2, false);
			if(temp==null || temp.size()!=3){
				CloseDev();
				return false ;
			}
			
			// 如果设置过密码，则检查原密码是否正确
			if(Arrays.equals(temp.get(1), new byte[16])){
				if(!src.trim().isEmpty()){
					CloseDev();
					JOptionPane.showMessageDialog(Front.front, "当前IC卡片原密码为空，请勿填写原密码！", "消息", 0);
					return false ;
				}
			}
			else{
				if(!Arrays.equals(temp.get(1), head16(src))){
					CloseDev();
					JOptionPane.showMessageDialog(Front.front, "原密码不正确！", "消息", 0);
					return false ;
				}
			}
			
			if(des!=null){	// 是否要修改密码
				if(des.trim().isEmpty()){
					writeDate(9, new byte[16]);
				}
				else{
					writeDate(9, head16(des));
				}
			}
			
			beep();
			CloseDev();
		}
		catch (Exception e) {
			e.printStackTrace();
			try{CloseDev();}catch (Exception err) {};
			JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
			return false ;
		}
		
		return true ;
	}
	// 得到前16个字节，多的不要
	private byte[] head16(String s) throws NoSuchAlgorithmException{
		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] md5byte = md.digest(s.trim().getBytes());
		byte[] res = new byte[16] ;
		System.arraycopy(md5byte, 0, res, 0, 16);
		return res ;
	}
	
	/**********************************************************************************/
	
	// 设备与卡是否准备就绪, 是否有读取写入权限
	public String cardno = "" ;
	public boolean isReady(boolean flag) {
		try{
			// 检查是否在使用中
			ArrayList<byte[]> temp = getInfo(psd, 123);
			if(temp==null) return false ;

			cardno = new String(temp.get(0));
			
			if(flag){
				// 要求是一张空白卡，即发行新卡。
				if(!Arrays.equals(temp.get(2), new byte[16])){
					CloseDev();
					JOptionPane.showMessageDialog(Front.front, "当前IC卡片正在使用中。请换一张空白卡！", "就绪检查", 0);
					return false ;
				}
			}
			else{
				// 要求是一张正在使用的卡片。
				if(Arrays.equals(temp.get(2), new byte[16])){
					CloseDev();
					JOptionPane.showMessageDialog(Front.front, "这是一张未 启用/发行 的空白卡！", "就绪检查", 0);
					return false ;
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace() ;
			try{CloseDev();}catch (Exception err) {};
			JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
			return false ;
		}
		
		return true ;
	}
	
	/**********************************************************************************/
	// 读取指定扇区数据, 专用于卡片技术分析
	public ArrayList<byte[]> getInfoArea(byte[] psd, int area) throws NativeException, IllegalAccessException {
		if(area<0 || area>15){
			JOptionPane.showMessageDialog(Front.front, "指定的参数不正确："+area, "错误", 0);
			return null;
		}
		
		if(OpenDev()){
			CloseDev();
			return null;
		}
		
		// 先认证这个块
		if(auth(psd, area)){
			CloseDev();
			return null;
		}
		
		// 得到指定扇区的数据
		ArrayList<byte[]> arr = getData(area, true) ;
		beep();
		CloseDev();
		
		return arr ;
	}
	
	// 读取卡片块的信息, 123, X
	private ArrayList<byte[]> getInfo(byte[] psd, int area) throws NativeException, IllegalAccessException {
		if(OpenDev()){
			CloseDev();
			return null;
		}
		
		ArrayList<byte[]> arr = new ArrayList<byte[]>();
		
		if(area==123){
			// 先认证这个块
			if(auth(psd, 2)){
				CloseDev();
				return null;
			}
			// 得到指定扇区的数据
			ArrayList<byte[]> temp = getData(2, false) ;
			if(temp==null){
				CloseDev();
				return null;
			}
			else{
				for(byte[] b : temp) arr.add(b);
			}
		}
		else if(area>=0 && area<64){
			// 先认证这个块
			if(auth(psd, area/4)){
				CloseDev();
				return null;
			}
			
			// 读取卡中指定的块数据
			Pointer ptr = Pointer.createPointer(16);
			JNative jn = new JNative("mwrf32", "rf_read");
			jn.setParameter(0, icdev);
			jn.setParameter(1, area);    // 读取哪个块
			jn.setParameter(2, ptr);
			jn.setRetVal(Type.INT);
			jn.invoke();
			int result = jn.getRetValAsInt();
			if(result==1 || result==12){
				CloseDev();
				return null ;
			}
			arr.add(ptr.getMemory());
		}
		else{
			CloseDev();
			JOptionPane.showMessageDialog(Front.front, "指定的参数不正确："+area, "错误", 0);
			return null;
		}
		
		CloseDev();
		return arr ;
	}
	
	// 读取一个扇区的3个块的数据，给上面的方法专用
	private ArrayList<byte[]> getData(int area, boolean flag) throws NativeException,IllegalAccessException {
		ArrayList<byte[]> arr = new ArrayList<byte[]>();
		// 读取卡中数据
		Pointer ptr = Pointer.createPointer(16);
		JNative jn = new JNative("mwrf32", "rf_read");
		jn.setParameter(0, icdev);
		jn.setParameter(1, area*4);    // 读取哪个块
		jn.setParameter(2, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		int result = jn.getRetValAsInt();
		if(result==1 || result==12){
			return null ;
		}
		arr.add(ptr.getMemory());
		//System.out.println("rf_read: 读取结果:"+result+" "+ toHex(ptr.getMemory()));
		
		jn.setParameter(1, area*4+1);    // 读取哪个块
		jn.invoke();
		result = jn.getRetValAsInt();
		if(result==1 || result==12){
			return null ;
		}
		arr.add(ptr.getMemory());
		
		jn.setParameter(1, area*4+2);    // 读取哪个块
		jn.invoke();
		result = jn.getRetValAsInt();
		if(result==1 || result==12){
			return null ;
		}
		arr.add(ptr.getMemory());
		
		if(flag){
			jn.setParameter(1, area*4+3);    // 是否读取控制块信息
			jn.invoke();
			result = jn.getRetValAsInt();
			if(result==1 || result==12){
				return null ;
			}
			arr.add(ptr.getMemory());
		}
		
		return arr ;
	}
	
	/**********************************************************************************/
	
	// 设备复位, 未能达到实际效果
	public void devReset(){
		try{
			CloseDev();
			
			JNative jn = new JNative("mwrf32", "rf_reset");
			jn.setParameter(0, icdev);
			jn.setParameter(1, 100);
			jn.setRetVal(Type.INT);
			jn.invoke();
			
			OpenDev();
			beep();
			CloseDev();
		}
		catch (Exception e) {
			try{CloseDev();}catch (Exception err) {};
			e.printStackTrace() ;
			JOptionPane.showMessageDialog(Front.front, e.getMessage()+"\n注意：JNative只能在32位的JDK或JRE环境中运行，不支持64位环境。", "出现错误", 0);
		}
	}
	
	// 写入数据, 每次16字节
	private void writeDate(int k, byte[] val) throws NativeException, IllegalAccessException {
		if(k<0 || k>63){
			JOptionPane.showMessageDialog(Front.front, "指定的块地址 "+k+" 不正确，志地埴范围:0-63", "错误", 0);
			return ;
		}
		if((k+1) % 4 == 0){
			JOptionPane.showMessageDialog(Front.front, "指定的块地址 "+k+" 不正确，志地埴范围:0-63, 控制块除外。", "错误", 0);
			return ;
		}
		
		Pointer ptr = Pointer.createPointer(16);
		ptr.setMemory(val);
		
		JNative jn = new JNative("mwrf32", "rf_write");
		jn.setParameter(0, icdev);
		jn.setParameter(1, k);    // 写入哪个块,一次必须写一个块，为16个字节；M1卡块地址（1～63）；
		jn.setParameter(2, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		
		int result = jn.getRetValAsInt(); //12
		System.out.println("rf_write: 写入结果:"+result);
	}
	
	// 认证扇区密码
	private boolean auth(byte psd[], int area) throws NativeException, IllegalAccessException {
		//装入密码
		Pointer ptr = Pointer.createPointer(6);
		ptr.setMemory(psd);
		JNative jn = new JNative("mwrf32", "rf_load_key");
		jn.setParameter(0, icdev);
		jn.setParameter(1, 0);		//装入密码模式，同密码验证模式mode_auth
		jn.setParameter(2, area);	//扇区号（M1卡：0～15；  ML卡：0）
		jn.setParameter(3, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		//int result = jn.getRetValAsInt();
		//System.out.println("rf_load_key: "+result); 
		
		
		//寻卡，能返回在工作区域内某张卡的序列号
		/*0——表示IDLE模式，一次只对一张卡操作；
		  1——表示ALL模式，一次可对多张卡操作；
		  2——表示指定卡模式，只对序列号等于snr的卡操作（高级函数才有）*/
		ptr = Pointer.createPointer(30);
		jn = new JNative("mwrf32", "rf_card");
		jn.setParameter(0, icdev);
		jn.setParameter(1, 1); 		//寻卡模式
		jn.setParameter(2, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		int result = jn.getRetValAsInt();
		if(result==1){
			JOptionPane.showMessageDialog(Front.front, "设备找不到卡片，请将卡片正确放置。", "提示", 0);
			return true;
		}
		snr = toHex(ptr.getMemory()) ;
		System.out.println("rf_card: <"+snr+"> "+result);
		
		// 验证某个扇区密码, rf_authentication_key可直接传入密码，但实测表明有时会出现密码不正确时通过了验证，后续读数据又被阻止。
		ptr = Pointer.createPointer(6);
		ptr.setMemory(psd);
		jn = new JNative("mwrf32", "rf_authentication");
		jn.setParameter(0, icdev);
		jn.setParameter(1, 0);    	  // 密码验证模式
		jn.setParameter(2, area);	  // 要验证密码的扇区号（0～15）
		//jn.setParameter(3, ptr);
		jn.setRetVal(Type.INT);
		jn.invoke();
		result = jn.getRetValAsInt(); //65488
		System.out.println("rf_authentication: 认证结果:"+result);
		if(result==1 || result==4) {
			JOptionPane.showMessageDialog(Front.front, "卡片第 "+area+" 扇区密码验证失败，卡片可能非法。 val:"+result, "认证失败", 0);
			return true;
		}
		
		return false;
	}
	// 蜂鸣
	private void beep() throws NativeException, IllegalAccessException {
		JNative jn = new JNative("mwrf32", "rf_beep");
		jn.setParameter(0, icdev);
		jn.setParameter(1, 30);
		jn.setRetVal(Type.INT);
		jn.invoke();
	}
	// 打开设备
	private boolean OpenDev() throws NativeException, IllegalAccessException {
		// 打开设备连接
		JNative jn = new JNative("mwrf32", "rf_init");
		jn.setParameter(0, 0);			//串口号，取值为0～3
		jn.setParameter(1, 115200);		//USB接口固定为此波特率
		jn.setRetVal(Type.INT);
		jn.invoke();
		icdev = jn.getRetValAsInt(); 	//icdev为设备句柄，成功则返回串口标识符>0，失败返回负值，如：440
		if(icdev<=0){
			JOptionPane.showMessageDialog(Front.front, "明华设备打开失败，请检查设备是否连接，是否有多个程序访问设备。", "错误", 0);
			return true;
		}
		return false;
	}
	// 关闭设备
	private void CloseDev() throws NativeException, IllegalAccessException {
		// 关闭设备
		JNative jn = new JNative("mwrf32", "rf_halt");
		jn.setParameter(0, icdev);
		jn.setRetVal(Type.INT);
		jn.invoke();
		//System.out.println("rf_halt: 关闭:"+jn.getRetVal());
		
		jn = new JNative("mwrf32", "rf_exit");
		jn.setParameter(0, icdev);
		jn.setRetVal(Type.INT);
		jn.invoke();
		//System.out.println("rf_exit: 断开连接:"+jn.getRetVal());
	}
	
	
	public String toHex(byte[] bRefArr){
		return Integer.toHexString(toInt(bRefArr));
	}
	private int toInt(byte[] bRefArr) {
	    int iOutcome = 0;
	    byte bLoop;
	    
	    for (int i = 0; i < bRefArr.length; i++) {
	        bLoop = bRefArr[i];
	        iOutcome += (bLoop & 0xFF) << (8 * i);
	    }
	    return iOutcome;
	}
	
	/* 16 进制表示字节
	private String Hex16(byte[] b) {
	   String val = "" ;
	    for (byte k : b) {
	        String temp = Integer.toHexString(k & 0xFF);
	        
	        if(temp.length()==1) temp = "0"+temp ;
	        val = val + temp ;
	        
	        System.out.print(temp+" ");
	    }
	    
	    System.out.println();
	    return val ;
	}
	*/
}
