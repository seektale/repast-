package vip;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import log.AdvSelect;
import root.Front;
import root.Sql;
public class IClog extends JPanel implements ActionListener{
	private static final long serialVersionUID = -3434232323889928203L;
	private JButton check = new JButton("最近日志");
	private JButton adv = new JButton("高级查询");
	private JButton print = new JButton("打印小票");
	private JTextField text = new JTextField("",15);
	private JTable east = Sql.getTable();
	public IClog(final ICissue ici){
		setLayout(new BorderLayout());
		JPanel fuc = new JPanel(new FlowLayout(FlowLayout.LEFT));
		fuc.setBackground(Color.LIGHT_GRAY);
		fuc.add(check);
		fuc.add(adv);
		fuc.add(print);
		fuc.add(new JLabel("   模糊查询："));
		fuc.add(text);
		
		check.addActionListener(this);
		
		text.getDocument().addDocumentListener(new DocumentListener() {
			public void removeUpdate(DocumentEvent e) {
				insertUpdate(e);
			}
			public void insertUpdate(DocumentEvent e) {
				String s = text.getText().trim() ;
				s = s.replace("'", "");
				if(s.trim().isEmpty()) return ;
				
				s = "ind like '%"+s+"%' or issueid like '%"+s+"%' or cardid like '%"+s+"%' or action like '%"+s+"%' or val like '%"+s+"%'";
				Sql.getArrayToTable("select * from cardlog where "+s+" limit 0,300", IClog.this, east);
				Sql.TableAtt(east, true, false);
			}
			public void changedUpdate(DocumentEvent e) {}
		});
		
		adv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AdvSelect("cardlog", east);
			}
		});
		
		print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int k = east.getSelectedRow() ;
				if(k<0){
					JOptionPane.showMessageDialog(Front.front,"未选择表格数据行。","注意 Error",0);
					return ;
				}
				ici.print(east.getValueAt(k, 0).toString());
			}
		});
		
		add(fuc, BorderLayout.NORTH);
		add(new JScrollPane(east), BorderLayout.CENTER);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==check){
			Sql.getArrayToTable("select * from cardlog order by ind desc limit 0,300 ", this, east);
			Sql.TableAtt(east, true, false);
			return ;
		}
	}
}
