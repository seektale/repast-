package vip;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import pub.ConfigFile;
import pub.ModifiedFlowlayout;
import pub.PanelRound;
import pub.Photo;
import pub.Var;
import root.Front;
import root.Sql;
public class ARicon extends JPanel implements ActionListener,DocumentListener{
	private static final long serialVersionUID = 628339174455004718L;
	private JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JButton refresh=getButton("刷新");
	private JTextField text=new JTextField(20);
	private JPanel card=new JPanel();
	private String sql="select * from vip limit 0,200;";
	private ArrayList<String[]> arr = new ArrayList<String[]>(); //保存当前需要显示的所有数据
	public ARicon(){
	    setOpaque(false);
	    setLayout(new BorderLayout());
	    text.getDocument().addDocumentListener(this);
	    
	    String web="<html><body>输入";
		web=web+"<font color=blue>&nbsp&nbsp客户AR账号&nbsp&nbsp</font>或";
		web=web+"<font color=blue>&nbsp&nbsp账户名/助记符&nbsp&nbsp</font>或";
		web=web+"<font color=blue>&nbsp&nbsp单位名称</font>&nbsp&nbsp查询：</body></html>";
		
	    nor.add(new JLabel(web));
		nor.add(text);
	    nor.add(new JLabel(" ○ ○ "));
	    for(int k=0;k<Var.getAR_class().length;k++){
	    	getButton(Var.getAR_class()[k]);
	    }
		add(nor,BorderLayout.NORTH);
		
		card.setOpaque(false);
		card.setLayout(new ModifiedFlowlayout(FlowLayout.LEFT,5,5));//向左对齐
		JScrollPane js=new JScrollPane(card);
		js.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
   	    add(js,BorderLayout.CENTER);
	}
	private JButton getButton(String s){
		JButton b=new JButton(s);
		b.addActionListener(this);
		nor.add(b);
		return b;
	}
	public void actionPerformed(ActionEvent e) {
		if(e==null || e.getSource()==refresh){
			arr = Sql.getArrayToArrary(sql, this);
			final Thread th=new Thread(new Runnable() {
				public void run() {
					getSign();
				}
			});
			th.setDaemon(true);
			th.start();
			return ;
		}
		sql="select * from vip where 类别='"+e.getActionCommand()+"' limit 0,200;";
		actionPerformed(null);
	}
	private synchronized void getSign(){
		card.removeAll();
		card.setVisible(false);
		card.setVisible(true);
		for(int row=0; row<arr.size(); row++){
			String temp[] = arr.get(row);
			final JPanel p=new JPanel(new BorderLayout());
			p.setBackground(Color.LIGHT_GRAY);
			p.setBorder(new PanelRound(true));	//稍微带点圆角
			
			String web="<font color=blue>AR:</font>"+temp[0];
			web=web+"<font color=blue>&nbsp&nbsp&nbsp账户名:</font>"+temp[2];
			web=web+"<font color=blue>&nbsp&nbsp&nbsp单位:</font>"+temp[3];
			web=web+"<font color=blue>&nbsp&nbsp&nbsp图片:</font>"+(temp[13].equals("0") ? "○" : "●")+(temp[14].equals("0") ? "○" : "●");
			JLabel text = new JLabel("<html><body>"+web+"</body></html>");
			p.add(text,BorderLayout.NORTH);
			
			int m=Integer.valueOf(temp[13]);	//Sql.getval(t, "图片一", row)
			int n=Integer.valueOf(temp[14]);	//Sql.getval(t, "图片二", row)
			JPanel cen=new JPanel(new GridLayout(1, 2, 2, 0));
			cen.setOpaque(false);
			if(m>0) cen.add(new JLabel(Photo.readIcon(m,true)));
			if(n>0) cen.add(new JLabel(Photo.readIcon(n,true)));
			p.add(cen,BorderLayout.CENTER);
			
			JLabel soulab=new JLabel();
			soulab.setPreferredSize(new Dimension(0, 3));	//下面留空隙
			p.add(soulab,BorderLayout.SOUTH);
			p.setPreferredSize(new Dimension((getWidth()-50)/3, 120));
			
			p.setComponentPopupMenu(new pop(m,n,temp[0],temp[2]));
			new DropTarget(p, DnDConstants.ACTION_COPY_OR_MOVE, new drag(temp[0], temp[2]), true, null); //拖拽功能
			card.add(p);
			card.setVisible(false);
			card.setVisible(true);
		}
	}
	
	public void changedUpdate(DocumentEvent e) {}
	public void insertUpdate(DocumentEvent e) {
		String val=text.getText();
		if(val==null) return ;
		//防止数据量过大，只显示前100行
		sql="select * from vip where " +
			"AR账号 like '"+val+"%' or 账户名 like '%"+val+"%' or " +
			"助记符 like '"+val+"%' or 单位 like '%"+val+"%' limit 0,100;";
		actionPerformed(null);	
	}
	public void removeUpdate(DocumentEvent e) {
		insertUpdate(e);
	}
	
	/*
	 * 内部类,右键菜单
	 * */
	public class pop extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -185565400196L;
		private JMenuItem a = new JMenuItem("导入图片 Import Icon");
		private JMenuItem b = new JMenuItem("导出图一 Export Icon first");
		private JMenuItem c = new JMenuItem("导出图二 Export Icon second");
		private JMenuItem d = new JMenuItem("删除图一 delete Icon first");
		private JMenuItem e = new JMenuItem("删除图二 delete Icon second");
		private int numa,numb;
		private String ar,name;
		pop(int numa,int numb,String ar,String name){
			this.numa=numa;
			this.numb=numb;
			this.ar=ar;
			this.name=name;
			a.addActionListener(this);
			b.addActionListener(this);
			c.addActionListener(this);
			d.addActionListener(this);
			e.addActionListener(this);
			add(a);
			addSeparator();  //加分隔线
			add(b);
			add(c);
			addSeparator();
			add(d);
			add(e);
			addSeparator();
			add("可用拖放方式导入图片 drag image to import");
		}
		public void actionPerformed(ActionEvent eve) {
			if(eve.getSource()==a){
				userIcon();
			}
			else if(eve.getSource()==b){
				if(numa>0)	Photo.ExportIcon(numa, true);
				else JOptionPane.showMessageDialog(Front.front,"未导入过图片","错误 Error",0);
			}
			else if(eve.getSource()==c){
				if(numb>0)	Photo.ExportIcon(numb, true);
				else JOptionPane.showMessageDialog(Front.front,"未导入过图片","错误 Error",0);
			}
			else if(eve.getSource()==d){
				final ArrayList<String> v=new ArrayList<String>();
				v.add("delete_sign_first");
				v.add(ar);
				v.add("0"); //填充值 ，无意义
				v.add("第一签名"); //备注
				Sql.mysqlprocedure("AR_value", v);
				refresh.doClick();
			}
			else if(eve.getSource()==e){
				final ArrayList<String> v=new ArrayList<String>();
				v.add("delete_sign_second");
				v.add(ar);
				v.add("0"); //填充值 ，无意义
				v.add("第二签名"); //备注
				Sql.mysqlprocedure("AR_value", v);
				refresh.doClick();
			}
		}
		
		private void userIcon() {
			
			int which=checkimg(ar);
			if(which==0) return;
			
			//默认选择当前用户桌面
			String tem = ConfigFile.getProperty("JFileChooserDir");
	    	if(tem==null || tem.isEmpty()) {
	    		final Properties props=System.getProperties();
	    		tem=props.getProperty("user.home")+File.separator+"desktop"+File.separator;
	    		ConfigFile.setProperty("JFileChooserDir", tem);
	    	}
	    	//选择目录
	    	final JFileChooser fi=new JFileChooser(ConfigFile.getProperty("JFileChooserDir")); //打开当前目录
	    	int result=fi.showOpenDialog(Front.front);  //打开对话框
	    	if(result==JFileChooser.APPROVE_OPTION) {
	    		ConfigFile.setProperty("JFileChooserDir", fi.getSelectedFile().getParent()); //保存上一次打开的路经
	    		Photo.ImportSign(which,ar,name,fi.getSelectedFile());
	    		refresh.doClick();
	    	}
		}
	}
	
	//将图片拖拽到目标菜品卡片上，菜品的图片便会更新
	class drag implements DropTargetListener{
		private String ar,name;
		drag(String ar, String name){
			this.ar=ar;
			this.name=name;
		}
		public void drop(DropTargetDropEvent dtde) {
			if ((dtde.getDropAction() & DnDConstants.ACTION_COPY_OR_MOVE) != 0) {
				// Accept the drop and get the transfer data
				dtde.acceptDrop(dtde.getDropAction());
				Transferable transferable = dtde.getTransferable();
				try {
					final List<?> fileList = (List<?>) transferable.getTransferData(DataFlavor.javaFileListFlavor);
					final File transferFile = (File) fileList.get(0);
					
					int which=checkimg(ar);
					if(which==0) return;
					
					Photo.ImportSign(which, ar, name, transferFile);
					refresh.doClick();
				} catch (Exception e) {}
			}
		}
		public void dragEnter(DropTargetDragEvent arg0) {}
		public void dragExit(DropTargetEvent arg0) {}
		public void dragOver(DropTargetDragEvent arg0) {}
		public void dropActionChanged(DropTargetDragEvent arg0) {}
	}
	
	private int checkimg(String araccount) {
		final ArrayList<String[]> arr = Sql.getArrayToArrary("select 图片一,图片二 from vip where AR账号="+araccount, this);
		if(arr.size()==0) return 0;
		int which=0;
		if(arr.get(0)[1].equals("0")) which=2;
		if(arr.get(0)[0].equals("0")) which=1;
		if(which==0) JOptionPane.showMessageDialog(Front.front,"无法导入，请先删除旧的后才能导入。","提示",0);
		return which;
	}
}

