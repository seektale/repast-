package vip;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import root.Front;
public class ICPassword extends JDialog implements ActionListener,KeyListener{
	private static final long serialVersionUID = 4720246671093648959L;
	private JPasswordField a=new JPasswordField(""); 
	private JPasswordField b=new JPasswordField(""); 
	private JPasswordField c=new JPasswordField("");
	private JButton ok=new JButton("确定 Submit");
	private JButton cancel=new JButton("取消 Cancel");
	private JNativeSub jn = new JNativeSub();
	public ICPassword(){
		super(Front.front, true);
		setSize(250, 150);
		
		JPanel con=new JPanel(new BorderLayout());
		con.setBorder(BorderFactory.createTitledBorder(""));
		con.setBackground(Color.PINK);
		
		JPanel we=new JPanel(new GridLayout(3, 1));
		we.setOpaque(false);
		we.add(new JLabel("IC卡旧密码：",JLabel.RIGHT));
		we.add(new JLabel("IC卡新密码：",JLabel.RIGHT));
		we.add(new JLabel("确认新密码：",JLabel.RIGHT));
		con.add(we,BorderLayout.WEST);
		
		we=new JPanel(new GridLayout(3, 1));
		we.setOpaque(false);
		we.add(a);
		we.add(b);
		we.add(c);
		con.add(we,BorderLayout.CENTER);
		
		we=new JPanel(new FlowLayout(FlowLayout.CENTER));
		we.setOpaque(false);
		we.add(ok);
		we.add(cancel);
		con.add(we,BorderLayout.SOUTH);
		
		a.setBackground(Color.LIGHT_GRAY);
		ok.addActionListener(this);
		cancel.addActionListener(this);
		a.addKeyListener(this);
		b.addKeyListener(this);
		c.addKeyListener(this);
		ok.addKeyListener(this);
		cancel.addKeyListener(this);
		
		JPanel temp=new JPanel(new BorderLayout(6,6));
		temp.setBorder(BorderFactory.createRaisedBevelBorder());
		temp.add(con,BorderLayout.CENTER);
		setContentPane(temp);
		setLocationRelativeTo(null);
		setUndecorated(true);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==cancel){
			dispose();
			return ;
		}
		
		// 检查卡片合法性, 设备是否准备好, 可以将空白卡排除掉
		boolean res = jn.isReady(false) ;
		if(res==false) return ;
		
		String s=new String(a.getPassword());
		String m=new String(b.getPassword());
		String n=new String(c.getPassword());
		
		if(m.equals(n) && !s.equals(n)){
			// 因为存储的是MD5值，对密码长度没有要求
			boolean boo = jn.CardSetPsd(s, m) ;
			if(boo)	dispose();
			return ;
		}
		
		if(!m.equals(n)){
			JOptionPane.showMessageDialog(null,"确认 新密码 有误，新密码 不一致！","警告 Warning",2);
		}
		
		JOptionPane.showMessageDialog(null,"新旧密码相同，请重新输入！","警告 Warning",2);
	}
	@Override
	public void keyPressed(KeyEvent k) {
		//响应回车键
		if(k.getKeyCode()==KeyEvent.VK_ENTER){
			if(k.getSource()==a)		b.requestFocus();
			if(k.getSource()==b)		c.requestFocus();
			if(k.getSource()==c)		ok.requestFocus();
			if(k.getSource()==ok)		ok.doClick();
			if(k.getSource()==cancel)	dispose();
		}
		//按ESC键退出
		if(k.getKeyCode()==KeyEvent.VK_ESCAPE){
			dispose();
		}
	}
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
