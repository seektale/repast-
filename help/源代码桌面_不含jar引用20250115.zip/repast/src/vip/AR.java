package vip;
import javax.swing.JInternalFrame;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import root.Front;
public class AR extends JInternalFrame{
	private static final long serialVersionUID = 2664150451471140502L;
	private JTabbedPane tp=new JTabbedPane();
	private boolean boo1 = true;
	private boolean boo3 = true;
	private boolean boo4 = true;
	public AR(){
		
		super("AR 账号管理",true,true,true,true);
		setContentPane(tp);
	    setResizable(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
		tp.addTab("AR账户管理", new ARdes());
		tp.addTab("签名图片管理", new ARicon());
		tp.addTab("消费记录查询", new ARconsume());
		tp.addTab("充值/扣款记录查询", new ARcharge());
		tp.addTab("AR账户日志查询", new ARlog());
		
		tp.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				final int k = tp.getSelectedIndex();
				if(k==1 && boo1) {
					boo1 = false;
					((ARicon)(tp.getComponent(k))).actionPerformed(null); //显示默认记录
				}
				if(k==2) {
					//默认先显示消费记录
				}
				if(k==3 && boo3) {
					boo3 = false;
					((ARcharge)(tp.getComponent(k))).actionPerformed(null); //显示默认记录
				}
				if(k==4 && boo4) {
					boo4 = false;
					((ARlog)(tp.getComponent(k))).actionPerformed(null); //显示默认记录
				}
			}
		});
		
		setVisible(true);
	}
}
