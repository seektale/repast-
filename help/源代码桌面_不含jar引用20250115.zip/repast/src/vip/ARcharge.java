package vip;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import pub.DateUI;
import root.Sql;
public class ARcharge extends JPanel implements ActionListener,DocumentListener{
	private static final long serialVersionUID = -3434694733889928203L;
	private JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JTextField text=new JTextField(20);
	private JTextField date=new JTextField(8);
	private JButton sel=new JButton("最近100条记录");
	private JTable t=Sql.getTable();
	public ARcharge(){
		setLayout(new BorderLayout());
		text.getDocument().addDocumentListener(this);
		date.addActionListener(this);
		sel.addActionListener(this);
		date.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				DateUI du = new DateUI();
				date.setText(du.toString());
				if(date.getText().isEmpty()) return ;
				String sql="select * from viplog where date(time)='"+date.getText()+"' and action like '%充值%' " +
						   "order by ind desc ";
				Sql.getArrayToTable(sql, ARcharge.this, t);
				Sql.TableAtt(t, true, false);
			}
		});
		
		String web="<html><body>输入";
		web=web+"<font color=blue>&nbsp&nbsp客户AR账号&nbsp&nbsp</font>或";
		web=web+"<font color=blue>&nbsp&nbsp账户名/助记符&nbsp&nbsp</font>或";
		web=web+"<font color=blue>&nbsp&nbsp单位名称</font>&nbsp&nbsp查询：</body></html>";
		
		nor.add(new JLabel(web));
		nor.add(text);
		nor.add(new JLabel("  某一天的日志记录："));
		nor.add(date);
		nor.add(sel);
		
		add(nor,BorderLayout.NORTH);
		add(new JScrollPane(t),BorderLayout.CENTER);
	}
	
	public void changedUpdate(DocumentEvent e) {}
	public void insertUpdate(DocumentEvent e) {
		String val=text.getText();
		if(val.isEmpty()) return ;
		String sql = "select * from viplog where " +
					 "(arnum like '"+val+"%' or arname like '%"+val+"%' or arcom like '%"+val+"%') and " +
					 "action like '%充值%' order by ind desc limit 0,200;";
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
	}
	public void removeUpdate(DocumentEvent e) {
		insertUpdate(e);
	}
	
	public void actionPerformed(ActionEvent e) {
		String sql = "" ;
		if(e==null || e.getSource()==sel){
			sql="select * from viplog where action like '%充值%' order by ind desc limit 0,200";
		}
		else if(e.getSource()==date){
			DateUI du = new DateUI();
			date.setText(du.toString());
			if(date.getText().isEmpty()) return ;
			sql="select * from viplog where date(time)='"+date.getText()+"' and action like '%充值%' order by ind desc ";
		}
		
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
	}
}
