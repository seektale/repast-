package vip;
import javax.swing.JInternalFrame;
import javax.swing.JTabbedPane;
import root.Front;
public class ICCard extends JInternalFrame{
	private static final long serialVersionUID = 2664150451471140502L;
	private JTabbedPane tp=new JTabbedPane();
	public ICCard(){
		super("IC卡管理",true,true,true,true);
		setContentPane(tp);
	    setResizable(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
	    ICissue ici = new ICissue();
	    tp.addTab("IC卡发行", ici);
		tp.addTab("IC卡明细", new ICuser());
		tp.addTab("IC卡日志", new IClog(ici));
		tp.addTab("IC卡技术分析", new ICinit());
		
		setVisible(true);
	}
}
