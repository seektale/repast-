package Privilege;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;

import root.Front;
import root.Sql;
public class Pri_box extends JPanel implements ActionListener,MouseListener{
	private static final long serialVersionUID = -328724465546402451L;
	private final HashMap<String, ArrayList<String[]>> hm = new HashMap<String, ArrayList<String[]>>();
	private final ArrayList<String> charlist = new ArrayList<String>();
	public final ArrayList<JCheckBox> boxlist = new ArrayList<JCheckBox>();
	public final JTable priwho = Sql.getTable();	//权根管理
	private final JPanel cen = new JPanel();
    public Pri_box(){
    	setLayout(new BorderLayout());
    	cen.setLayout(new BoxLayout(cen, BoxLayout.PAGE_AXIS));	//一行一行的布局
    	cen.setOpaque(false);
		cen.setBorder(BorderFactory.createTitledBorder(""));
    	
    	//注意从哪个数据库中读取
		final String sql="select name,comment from mysql.proc where db='repast' order by comment";
    	final ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
    	
    	for(String temp[] : arr){
    		if(temp[1].isEmpty()){
    			System.out.println("存储过程："+temp[0]+" 没有备注信息，无法进行权限管理");
    			continue ;
    		}
    		final String first = temp[1].substring(0, 1);
    		final ArrayList<String[]> ob = hm.get(first);
    		if(ob==null){
    			ArrayList<String[]> arrob = new ArrayList<String[]>();
    			arrob.add(temp);
    			hm.put(first, arrob);
    			charlist.add(first);
    			continue ;
    		}
    		ob.add(temp);
    		hm.put(first, ob);
    	}
    	
    	for(final String temp : charlist){
    		final ArrayList<String[]> sub = hm.get(temp);
    		final JPanel boxsubpan = new JPanel(new GridLayout(sub.size()/4+1, 4));
    		if(sub.size()%4==0) boxsubpan.setLayout(new GridLayout(sub.size()/4, 4));
    		for(String two[] : sub){
    			String en = two[0];
        		String cn = two[1];
        		final JCheckBox cbox = new JCheckBox(cn.substring(1));
        		boxlist.add(cbox);
        		cbox.setName(en);
        		cbox.setToolTipText("<html>"+en+"<br>"+cn+"</html>");	//存储过程名称
        		cbox.addActionListener(this);
        		if(cn.startsWith("A")){
        			cbox.setForeground(Color.blue);
        		}
        		boxsubpan.add(cbox);
        		
        		//这两个权限存在给自己授权的可能，会导致执行不会成功，为防止误解，禁止操作；
        		//只有管理员有操作这两个存储过程的权限
        		if(en.equals("user_pri_call")||en.equals("user_pri_copy")){
        			cbox.setEnabled(false);
        		}
        		//后期改用了下面的方法，即以N开头的不可操作，但上面的不删除，这样中文名出错或不全是上面两个依然不可编辑
        		if(cn.startsWith("N")){
        			cbox.setEnabled(false);
        			cbox.setForeground(Color.red);
        		}
        		//恢复管理员可能操作，其它人操作没有权限
        		if(en.equals("user_pri")){
        			cbox.setEnabled(true);
        		}
    		}
    		if(sub.size()%4!=0){
    			for(int bu=0; bu<4-sub.size()%4; bu++){
        			boxsubpan.add(new JLabel());
        		}
    		}
    		
    		final JPanel describ = new JPanel(new FlowLayout(FlowLayout.LEFT));
    		final JLabel describlab = new JLabel(temp);
    		describlab.setForeground(Color.RED);
    		describ.add(describlab);
    		cen.add(describ);
    		cen.add(new JSeparator());	//分割线
    		cen.add(boxsubpan);
    	}
    	
		priwho.addMouseListener(this);
		final JPanel east = new JPanel(new BorderLayout());
		east.setPreferredSize(new Dimension(300,0));
    	JScrollPane js = new JScrollPane(priwho);
		east.add(js,BorderLayout.CENTER);
		final JLabel desc = new JLabel("<html><body>A：代表基本用户权限，请勿随意取消，它们是用户正常使用本软件的保证，" +
				"否则会导致用户在使用软件过程中部分功能异常甚至无法使用<br><br>N：代表开发人员调试 或 超级用户才能使用的选项，" +
				"这些选项不供用户选择<br><br>其它字母则是各模块具体权限的分类明细，相似权限选项则归类在一起<br><br>" +
				"如果数据库管理员修改编辑了存储过程或函数，则其它用户对该存储过程或函数的权限将失效，这时需要重新赋予用户权限" +
				"<br><br></body></html>");
		east.add(desc,BorderLayout.SOUTH);
		add(east,BorderLayout.EAST);
		js=new JScrollPane(cen);
		js.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
		add(js,BorderLayout.CENTER);
    }
    
	public void actionPerformed(ActionEvent e){
		final JCheckBox ch=(JCheckBox)e.getSource();
		int k = priwho.getSelectedRow();
		if(k==-1){
			JOptionPane.showMessageDialog(Front.front,"请先选择用户对象！","注意",0);
			if(ch.isSelected())	ch.setSelected(false);
			else ch.setSelected(true);
		}
		else{
			final String who = priwho.getValueAt(k, 0).toString();
			final ArrayList<String> v=new ArrayList<String>();
			v.add(who);							//当前选中的部门
			v.add(ch.getName());				//存储过程名
			if(ch.isSelected())	v.add("G");		//权限赋予和删除GRANT,REVOKE
			else				v.add("R");
			
			boolean boo=false;
			if(ch.getName().equals("user_pri")){
				boo=Sql.mysqlprocedure("user_pri_call",v);
			}
			else{
				boo=Sql.mysqlprocedure("user_pri",v);
			}
			//失败的情况下复位
			if(!boo){
				if(ch.isSelected())	ch.setSelected(false);
				else				ch.setSelected(true);
			}
		}
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		if(priwho.getSelectedRow()<0) return ;
		//先还原为未选中
		for(JCheckBox jbox : boxlist){
			jbox.setSelected(false);
		}
		String a=priwho.getValueAt(priwho.getSelectedRow(), 0).toString();

    	//找出其有哪些权限
		String sql="select Routine_name from mysql.procs_priv where db='repast' and User='"+a+"';";
		String str[]=Sql.getString(sql, this);
		
		//确定状态
		for(final String MM : str){
			for(final JCheckBox jbox : boxlist){
				if(MM.equals(jbox.getName())){
					jbox.setSelected(true);
					break;
				}
			}
		}
	}
}
