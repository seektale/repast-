package Privilege;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import pub.Popup_tab;
import pub.Var;
import root.Front;
import root.Sql;
public class PriFrame extends JInternalFrame implements ChangeListener{
	private static final long serialVersionUID = 4223236164786894393L;
	private JTable t=Sql.getTable();		//用户名单表
	private JTable valid=Sql.getTable();	//有效用户名单表
	private JTable analysis=Sql.getTable();
	private Pri_box box=new Pri_box();
	private JTabbedPane TabPan=new JTabbedPane();
	private Add_user ope=new Add_user(t);
	private Department detree=new Department(t,TabPan,ope);
	private JPanel Pan=new JPanel(new BorderLayout());
	public PriFrame(){
		super("用户 与 权限",true,true,true,true);
		setContentPane(Pan);
	    setResizable(true);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
		//右键菜单
		t.setComponentPopupMenu(new Menu_Popup());
		valid.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(e.getClickCount()!=2) return ;
				String username=Sql.getval(valid, "User", valid.getSelectedRow());
				int k=JOptionPane.showConfirmDialog(Front.front,"确定删除当前用户:"+username,"Dmumu",0,1,Var.getIcon("米饭"));
				if(k!=0) return ;
				Sql.mysqlprocedure("user_del",username);
				String sql="select Host,User,Select_priv,Insert_priv,Update_priv,Delete_priv from mysql.user;";
				Sql.getArrayToTable(sql, this, valid);
			}
		});
		
		Sql.getArrayToTable("select * from account;", this, t);
		Sql.TableAtt(t, true, false);
	    TabPan.add("账号列表",new JScrollPane(t));
	    TabPan.setToolTipTextAt(0, "在表格中单击右键弹出功能菜单");
	    TabPan.add("权限管理",box);
	    TabPan.add("生效账号(双击删除)",new JScrollPane(valid));
	    JTable protab = new JTable();
	    Sql.getArrayToTable("show procedure status;", this, protab);
	    TabPan.add("存储过程清单",new JScrollPane(protab));
	    protab = new JTable();
	    Sql.getArrayToTable("show function status;", this, protab);
	    TabPan.add("函数清单",new JScrollPane(protab));
	    
	    TabPan.add("权限分析",pri_select());
	    TabPan.addChangeListener(this);
	    
		JPanel p=new JPanel(new BorderLayout());
		p.add(detree,BorderLayout.NORTH);
		p.add(ope,BorderLayout.SOUTH);
		Pan.add("West",p);
		Pan.add("Center",TabPan);
		Pan.setOpaque(false);
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		// TODO Auto-generated method stub
		final int k=TabPan.getSelectedIndex();
		final String s=TabPan.getTitleAt(k);
		ope.text.setEnabled(false);
		if(s.contains("账号列表")){
			ope.text.setEnabled(true);
		}
		if(s.contains("生效账号")){
			final String sql="select Host,User,Select_priv,Insert_priv,Update_priv,Delete_priv from mysql.user;";
			Sql.getArrayToTable(sql, this, valid);
		}
		if(s.contains("权限分析")){
			final String sql="select DISTINCT name_english as '账号',name_chinese as '姓名',islock as '锁定' " + 
					"from mysql.user LEFT JOIN repast.account " + 
					"on repast.account.name_english=mysql.user.User " + 
					"order by department,name_english";
			//列名有问题,在更换驱动之后出现
			Sql.getArrayToTable(sql, this, analysis);
		}
		if(s.contains("权限管理")){
			//刷新用户表
			final String sql="select DISTINCT name_english as '账号',name_chinese as '姓名',department as '部门' " + 
					"from mysql.user LEFT JOIN repast.account " + 
					"on repast.account.name_english = mysql.user.User " + 
					"order by department,name_english";
			Sql.getArrayToTable(sql, this, box.priwho);
			//还原为未选中
			for(final JCheckBox jbox : box.boxlist){
				jbox.setSelected(false);
			}
		}
	}
	
	//权限分析面板
	private JPanel pri_select(){
		JPanel p=new JPanel(new BorderLayout());
		final JTable t=Sql.getTable();
		JLabel b=new JLabel(" 如无账号,请先尝试修复");
		
		JPanel we=new JPanel(new BorderLayout());
		we.add(b,BorderLayout.NORTH);
		we.add(new JScrollPane(analysis),BorderLayout.CENTER);
		p.add(we,BorderLayout.WEST);
		we.setPreferredSize(new Dimension(260,0));
		p.add(new JScrollPane(t),BorderLayout.CENTER);
		
		analysis.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e){
				if (e.getClickCount() != 1) return ;
				final String name=analysis.getValueAt(analysis.getSelectedRow(), 0).toString();
				Sql.getArrayToTable("show grants for "+name, this, t);
				
				//后期锁定已在java端初始化时控制，不在存储过程中进行限制登陆地点
				//Sql.getArrayToTable("show grants for "+name+"@127.0.0.1", getClass().getName(), t);
			}
		});
		return p;
	}
	
	/*
	 * 内部类,右键菜单
	 * */
	public class Menu_Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -18259645165400196L;
		private JMenuItem a,b,c,d,e;
		Menu_Popup(){
			a = new JMenuItem("新增用户");
			b = new JMenuItem("编辑用户");
			c = new JMenuItem("删除用户(建议停用)");
			d = new JMenuItem("复制权限(仅限root用户操作)");
			e = new JMenuItem("用户账号修复");
			
			a.addActionListener(this);
			b.addActionListener(this);
			c.addActionListener(this);
			d.addActionListener(this);
			e.addActionListener(this);
			
			add(a);
			add(b);
			add(c);
			addSeparator();  //加分隔线
			add(d);
			add(e);
			
			//原有的菜单项功能
			addSeparator();
			Popup_tab superpop=(Popup_tab)t.getComponentPopupMenu();
			add(superpop.getMenu());
		}
		@Override
		public void actionPerformed(ActionEvent err) {
			// TODO Auto-generated method stub
			if(err.getSource()==a){
				ope.adduser(null);
			}
			else if(err.getSource()==b){
				if(t.getSelectedRow()==-1){
					JOptionPane.showMessageDialog(Front.front,"没有选择要编辑的用户，请先选择数据行。","注意",0);
					return ;
				}
				ope.adduser("");
			}
			else if(err.getSource()==c){
				if(!t.isShowing()){
					JOptionPane.showMessageDialog(Front.front,"请先切换到账号列表视图！然后选择要删除的账号。","注意",0);
					return ;
				}
				int k=t.getSelectedRow();
				if(k==-1){
					JOptionPane.showMessageDialog(Front.front,"没有选择要删除的用户，请先选择数据行。","注意",0);
					return ;
				}
				String who=Sql.getval(t, "name_english", k);
				int flag=JOptionPane.showConfirmDialog(Front.front,"确定删除账号:"+who,"Smosu",0,1,Var.getIcon("米饭"));
				if(flag==0){
					boolean b=Sql.mysqlprocedure("user_del",who);
					if(b){
						DefaultTableModel dtm=(DefaultTableModel)t.getModel();
						dtm.removeRow(k);
					}
				}
			}
			else if(err.getSource()==d){
				int row=t.getSelectedRow();
				if(row==-1) {
					JOptionPane.showMessageDialog(Front.front,"请先选择相关用户数据行。","注意",0);
					return ;
				}
				String src=Sql.getval(t, "name_english", row)+"@"+Sql.getval(t, "name_chinese", row);
				
				JTable user = Sql.getTable();
				String usersql = "select name_english,name_chinese,department,duty,phone,sex from account";
				Sql.getArrayToTable(usersql, this, user);
				int flag=JOptionPane.showConfirmDialog(Front.front,new JScrollPane(user),"将 <"+src+"> 的权限复制给...",2,1,new ImageIcon());
				if(flag==0){
					int k=user.getSelectedRow();
					if(k==-1){
						JOptionPane.showMessageDialog(Front.front,"未选择目标账号。","注意",0);
						return ;
					}
					String who1=user.getValueAt(k, 0).toString();
					String who2=t.getValueAt(t.getSelectedRow(), 0).toString();
					ArrayList<String> v=new ArrayList<String>();
					v.add(who1);
					v.add(who2);
					Sql.mysqlprocedure("user_pri_copy",v);
				}
			}
			else if(err.getSource()==e){
				int row = t.getSelectedRow();
				if(row==-1) {
					JOptionPane.showMessageDialog(Front.front,"请先选择相关用户数据行。","注意",0);
					return ;
				}
				ArrayList<String> v=new ArrayList<String>();
				v.add(Sql.getval(t, "name_english", row));
				v.add(Sql.getval(t, "name_chinese", row));
				v.add(Sql.getval(t, "duty", row));
				v.add(Sql.getval(t, "phone", row));
				v.add(Sql.getval(t, "birthday", row));
				v.add(Sql.getval(t, "remark", row));
				v.add(Sql.getval(t, "department", row));
				v.add(Sql.getval(t, "sex", row));
				v.add(Sql.getval(t, "fullscreen", row));
				v.add(Sql.getval(t, "islock", row));
				Sql.mysqlprocedure("user_repair",v);
			}
		}
	}
}
