package Privilege;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashSet;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import pub.DateUI;
import pub.ModifiedFlowlayout;
import root.Front;
import root.Sql;
public class Add_user extends JPanel implements DocumentListener,ActionListener{
	private static final long serialVersionUID = 4223236164786894393L;
	public final JTextField text=new JTextField();
	private JTable t;
	public Add_user(JTable t){
		this.t=t;
		t.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e){
				if (e.getClickCount() == 2){	//响应鼠标对表格的双击事件
					adduser("");
		        }
			}
		});
		
	    setOpaque(false);
		setLayout(new GridLayout(6,1,0,3));
		
		JButton bu=new JButton("权限名称中英对照");
		bu.addActionListener(this);
		add(bu);
		
		bu=new JButton("辅助账号log修复");
		bu.addActionListener(this);
		add(bu);
		
		bu=new JButton("新增账号new");
		bu.addActionListener(this);
		add(bu);
		
		text.getDocument().addDocumentListener(this);
		text.setToolTipText("输入 字母账号 或 中文名，操作请在帐号列表视图下进行！");
		add(new JLabel(" 查询：",JLabel.LEFT));
		add(text);
 	    JSeparator sd=new JSeparator();	//分割线
 	    add(sd);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getActionCommand().contains("log")){
			Sql.mysqlprocedure("log_repair");
			return ;
		}
		if(arg0.getActionCommand().contains("new")){
			adduser(null);
			return ;
		}
		
		final String sql="select name,comment from mysql.proc where db='repast' order by name";
    	final ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
    	
    	final JPanel pan = new JPanel(new ModifiedFlowlayout(FlowLayout.LEFT, 0, 0));
    	for(String temp[] : arr){
    		final JLabel lab = new JLabel();
    		lab.setText("<html><body><B>."+temp[0]+"</B><br><font color=blue>."+temp[1]+"</font></body></html>");
    		lab.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));//立体感
    		lab.setPreferredSize(new Dimension(140,40));
    		lab.setOpaque(true);
    		lab.addMouseListener(new MouseAdapter() {
    			public void mouseExited(MouseEvent e) {
    				JLabel temp = (JLabel)e.getSource();
					temp.setBackground(null);
				}
				public void mouseEntered(MouseEvent e) {
					JLabel temp = (JLabel)e.getSource();
					temp.setBackground(Color.LIGHT_GRAY);
				}
			});
    		pan.add(lab);
    	}
    	final JScrollPane js = new JScrollPane(pan);
    	js.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
    	
    	final JDialog dia=new JDialog(Front.front);
		dia.setSize(1020, 600);
		dia.setResizable(false);	
		dia.setContentPane(js);
		dia.setTitle("权限名称中英对照   [ 数量:"+arr.size()+" ]");
		dia.setLocationRelativeTo(null);//初始位置在屏幕正中间
		dia.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		dia.setVisible(true);
	}
	@Override
	public void insertUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		final String str=text.getText();
		final String sql="select * from account where name_english like '%"+str+"%' or name_chinese like '%"+str+"%';";
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
		
	}
	@Override
	public void removeUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		insertUpdate(e);
	}
	@Override
	public void changedUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	//添加或编辑用户的对话框
	public void adduser(String ind){
		
		if(ind!=null){
			ind=Sql.getval(t, "name_english", t.getSelectedRow());
		}
		
		final JTextField te[]=new JTextField[6];
		final JRadioButton man = new JRadioButton("男");
		final JRadioButton women	= new JRadioButton("女");
		final JCheckBox lock=new JCheckBox("帐号锁定");
		final JCheckBox fullscreen=new JCheckBox("全屏登陆");
		
		final JPasswordField password=new JPasswordField("123456",16);   //密码框
		final JCheckBox editpass=new JCheckBox("修改密码");
		
		final String depstr = "select item from general where name='部门'" ;
		final JComboBox<String> dep=new JComboBox<String>(Sql.getString(depstr, this));
		dep.setPreferredSize(new Dimension(120,30));
		final ButtonGroup  radioGroup	= new ButtonGroup();//单选组
	    radioGroup.add(man);
	    radioGroup.add(women);
	    man.setSelected(true);	//默认选中
		
	    final JPanel nor=new JPanel();
		nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
		
		JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		JLabel la=new JLabel("账号 English_Name：");
		la.setPreferredSize(new Dimension(140,20));
 	    temp.add(la);
 	    temp.add(te[0]=new JTextField(12));
 	    nor.add(temp);
 	    
 	    temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
 	    la=new JLabel("姓名 Chinese_Name：");
		la.setPreferredSize(new Dimension(140,20));
 	    temp.add(la);
 	    temp.add(te[1]=new JTextField(12));
 	    nor.add(temp);
 	    nor.add(new JSeparator());	//分割线
 	    
 	    temp=new JPanel(new GridLayout(1,4,6,6));
 	    JPanel temp1=new JPanel(new FlowLayout(FlowLayout.LEFT));
	    temp1.add(new JLabel("部门："));
	    temp1.add(dep);
	    temp.add(temp1);
	    temp1=new JPanel(new FlowLayout(FlowLayout.LEFT));
	    temp1.add(new JLabel("职务："));
	    temp1.add(te[2]=new JTextField(10));
	    temp.add(temp1);
	    nor.add(temp);
	    
	    temp=new JPanel(new GridLayout(1,4,6,3));
 	    temp1=new JPanel(new FlowLayout(FlowLayout.LEFT));
	    temp1.add(new JLabel("电话："));
	    temp1.add(te[3]=new JTextField(10));
	    temp.add(temp1);
	    temp1=new JPanel(new FlowLayout(FlowLayout.LEFT));
	    temp1.add(new JLabel("生日："));
	    temp1.add(te[4]=new JTextField(10));
		te[4].addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				DateUI du = new DateUI();
				if(du.toString().isEmpty()) return ;
				te[4].setText(du.toString()); 
			}
		});
		te[4].setEditable(false);
	    temp.add(temp1);
	    nor.add(temp);
	    nor.add(new JSeparator());	//分割线
	    
 	    temp=new JPanel(new FlowLayout(FlowLayout.LEFT,10,2));
	    temp.add(man);
	    temp.add(women);
	    temp.add(fullscreen);
	    temp.add(lock);
	    nor.add(temp);

	    temp=new JPanel(new FlowLayout(FlowLayout.LEFT,10,2));
 	    temp.add(new JLabel("密码："));
 	    temp.add(password);
 	    password.setEnabled(false);
 	    password.setToolTipText("新账号如果未设置密码，则默认密码为：123456");
 	    temp.add(editpass);
 	    editpass.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(editpass.isSelected()){
					password.setEnabled(true);
				}
				else{
					password.setEnabled(false);
				}
				
			}
		});
 	    nor.add(temp);
 	    nor.add(new JSeparator());	//分割线
 	    
 	    temp=new JPanel(new FlowLayout(FlowLayout.LEFT,10,2));
	    temp.add(new JLabel("备注："));
	    temp.add(te[5]=new JTextField(24));
	    nor.add(temp);

 	    //初始化，ind为null代表新添加用户
		if(ind!=null){
			te[0].setBackground(Color.lightGray);
			te[0].setEditable(false);
			te[0].setText(ind);
			String val[]=Sql.getString("select * from account where name_english='"+ind+"';", this);
			if(val.length>0){
				te[0].setText(val[0]);
				te[1].setText(val[1]);
				te[2].setText(val[3]);
				te[3].setText(val[4]);
				te[4].setText(val[5]);
				te[5].setText(val[10]);
				
				dep.setSelectedItem(val[2]);
				if(val[6].equals("男")){
					man.setSelected(true);
					women.setSelected(false);
				}	
				else if(val[6].equals("女")){
					man.setSelected(false);
					women.setSelected(true);
				}
				if(val[7].equals("Y")){
					fullscreen.setSelected(true);
				}
				else{
					fullscreen.setSelected(false);
				}
				if(val[8].equals("Y")){
					lock.setSelected(true);
				}
				else{
					lock.setSelected(false);
				}
			}
		}
		if(editpass.isSelected()){
			editpass.doClick();
		}
		
		//开始弹出对话框
		String title="";
		if(ind==null)	title="添加新帐户";
		else			title="帐户编辑";
		int action=JOptionPane.showConfirmDialog(Front.front,nor,title,2,1,new ImageIcon());
		if(action==0){
			//修改帐户信息 或 新增帐户
			ArrayList<String> v=new ArrayList<String>();
			for(int k=0;k<te.length;k++){
				v.add(te[k].getText());
			}
			//部门
			v.add(dep.getSelectedItem().toString());
			//性别
			if(man.isSelected()){
				v.add("男");
			}
			else {
				v.add("女");
			}
			//全屏登陆
			if(fullscreen.isSelected()){
				v.add("Y");
			}
			else{
				v.add("N");
			}
			//是否锁定
			if(lock.isSelected()){
				v.add("Y");
			}
			else{
				v.add("N");
			}
			//密码
			v.add(String.valueOf(password.getPassword()));
			//是否对密码进行修改
			if(editpass.isSelected()){
				v.add("Y");
			}
			else{
				v.add("N");
			}
			
			boolean boo=false;
			if(ind==null)	boo=Sql.mysqlprocedure("user_add",v);
			else			boo=Sql.mysqlprocedure("user_edit",v);
			if(boo){
				//即时刷新表格
				String depart=dep.getSelectedItem().toString();
				HashSet<String> hs = new HashSet<String>();
				for(int k=0; k<t.getRowCount(); k++){
					hs.add(Sql.getval(t, "department", k));
				}
				if(hs.size()==1){
					//对某个部门的操作，则只刷新这个部门
					Sql.getArrayToTable("select * from account where department='"+depart+"' ", this, t);
				}
				else{
					//对所有用户在操作，则刷新所有用户
					Sql.getArrayToTable("select * from account ", this, t);
				}
				Sql.TableAtt(t, true, false);
			}
		}
	}
}

