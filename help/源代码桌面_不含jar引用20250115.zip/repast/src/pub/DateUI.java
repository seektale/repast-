package pub;
import java.awt.*;  
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;  
import java.awt.event.MouseEvent;  
import javax.swing.*;  
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;  
public class DateUI extends MouseAdapter{  
    private JDialog dia = new JDialog(new JFrame(),true);  
    
    private JSpinner yearsel=new JSpinner(new SpinnerNumberModel(2000,1900,2200,1));
    private JSpinner monthsel=new JSpinner(new SpinnerNumberModel(1,1,12,1));
    
    private JButton[][] buttons = new JButton[7][7];  
    private String[] weeks = { "日", "一", "二", "三", "四", "五", "六" };  
    //声明为静态变量，下次打开时显示上次设定的日期
    private static Calendar cd = Calendar.getInstance();
    private int curX = -1;
    private int curY = -1;
    private JLabel lun=new JLabel();
    private String result = "" ;
    public DateUI() {
        //相对位置
        //dia.setLocationRelativeTo(dateText);
        //默认关闭值
        dia.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JPanel con = new JPanel();  
        dia.setContentPane(con);
        
        //年份和月份只能上下选择，不能编辑
        DefaultEditor editor = (DefaultEditor)monthsel.getEditor();
		editor.getTextField().setEditable(false);
		editor = (DefaultEditor)yearsel.getEditor();
		editor.getTextField().setEditable(false);
		
		yearsel.setValue(cd.get(Calendar.YEAR));
		monthsel.setValue(cd.get(Calendar.MONTH)+1);
        
        con.setBorder(BorderFactory.createTitledBorder(""));
        con.setLayout(new BorderLayout());  
        JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));  
        JButton today=new JButton("今天");
        today.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				today();
			}
		});
        northPanel.add(today);
        northPanel.add(new JLabel(" 选择年份 :",JLabel.RIGHT));  
        northPanel.add(yearsel);
        yearsel.setPreferredSize(new Dimension(80,30));
        northPanel.add(new JLabel(" 选择月份 :",JLabel.RIGHT));  
        northPanel.add(monthsel);
        monthsel.setPreferredSize(new Dimension(60,30));
        northPanel.add(lun);
        
        JPanel centerPanel = new JPanel();  
        centerPanel.setLayout(new GridLayout(7, 7));  
        for (int i = 0; i < 7; i++) {  
            for (int j = 0; j < 7; j++) {  
                if (i == 0) {  
                    buttons[i][j] = new JButton(weeks[j]);  
                    buttons[i][j].setEnabled(false);  
                    buttons[i][j].setBackground(Color.green);  
                } else {  
                    buttons[i][j] = new JButton("");  
                    buttons[i][j].setBackground(Color.white);  
                    buttons[i][j].addMouseListener(this);  
                }  
                if (j == 0) {  
                    buttons[i][j].setForeground(Color.red);  
                }  
                centerPanel.add(buttons[i][j]);  
            }  
        }  
        
        setDate();	//初始日期位置
        
        yearsel.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				//保存旧值，并将日期设为1号
				int oldday = cd.get(Calendar.DAY_OF_MONTH);
				cd.set(Calendar.DAY_OF_MONTH, 1);
				
                String yy = yearsel.getValue().toString();  
                int yi = Integer.parseInt(yy);  
                cd.set(Calendar.YEAR, yi);
                
                //取得当月最后一天。
				int lastDate = cd.getActualMaximum(Calendar.DATE);
				if(oldday<=lastDate){
					cd.set(Calendar.DAY_OF_MONTH, oldday);	//还原
				}
				
				setDate(); 
			}
		});
        monthsel.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				//保存旧值，并将日期设为1号
				int oldday = cd.get(Calendar.DAY_OF_MONTH);
				cd.set(Calendar.DAY_OF_MONTH, 1);
				
                String yy = monthsel.getValue().toString();  
                int yi = Integer.parseInt(yy);  
                cd.set(Calendar.MONTH, yi-1);
                
                //注意，如果今天是1月30号，当改变月份为2月时，由于2月没有30号，所以日期会变为2号或者出错
				//取得当月最后一天。
				int lastDate = cd.getActualMaximum(Calendar.DATE);
				if(oldday<=lastDate){
					cd.set(Calendar.DAY_OF_MONTH, oldday);	//还原
				}
				
				setDate();
			}
		});
        
        con.add(northPanel, BorderLayout.NORTH);  
        con.add(centerPanel, BorderLayout.CENTER);
        dia.setTitle("日期选择");
        dia.setSize(500,300);
        dia.setLocationRelativeTo(null);//初始位置在屏幕正中间
        dia.setVisible(true);
    }
    
    public void mousePressed(MouseEvent e) {  
        for (int i = 1; i < 7; i++) {
            for (int j = 0; j < 7; j++) {  
                if (buttons[i][j].getText().isEmpty()) {  
                    continue;  
                }
                if (buttons[i][j].equals(e.getSource())) {
                	buttons[curX][curY].setBackground(Color.white);  
                    curX = i;  
                    curY = j;  
                    buttons[curX][curY].setBackground(Color.MAGENTA);  
                }  
            }  
        }
    }  
    public void mouseReleased(MouseEvent e) {
    	for (int i = 1; i < 7; i++) {
            for (int j = 0; j < 7; j++) {  
                if (buttons[i][j].equals(e.getSource())) {  
                	if (buttons[i][j].getText().isEmpty()) {  
                        return ;  
                    } 
                }  
            }  
        }
    	
    	String day=buttons[curX][curY].getText();
        String month=monthsel.getValue().toString();	//例'1月'
        String year=yearsel.getValue().toString();

        cd.set(Integer.valueOf(year), Integer.valueOf(month)-1, Integer.valueOf(day));
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

        result = df.format(cd.getTime()) ;
        dia.dispose();  
    }
    
    public String toString(){
    	return result ;
    }
    
    private void today(){
    	Calendar cal = Calendar.getInstance();
		yearsel.setValue(cal.get(Calendar.YEAR));
		monthsel.setValue(cal.get(Calendar.MONTH)+1);
		cd.set(Calendar.DATE, cal.get(Calendar.DATE));
		setDate();
    }
    
    private void setDate() {
        for (int i = 1; i < 7; i++) {  
            for (int j = 0; j < 7; j++) {  
                buttons[i][j].setText("");  
                buttons[i][j].setBackground(Color.white);  
                buttons[i][j].setEnabled(false);  
            }  
        }  

        int day = cd.get(Calendar.DAY_OF_MONTH);
        curX = cd.get(Calendar.WEEK_OF_MONTH);  
        curY = cd.get(Calendar.DAY_OF_WEEK) - 1;  
        buttons[curX][curY].setBackground(Color.MAGENTA);  

        cd.set(Calendar.DAY_OF_MONTH, 1);  
        int week = cd.get(Calendar.DAY_OF_WEEK);  
        int maxDay = cd.getActualMaximum(Calendar.DAY_OF_MONTH);  
        int k = 0;  
        int dm = 1;  
        for (int i = 1; i < 7; i++) {  
            for (int j = 0; j < 7; j++) {  
                k++;  
                if (k >= week && k < maxDay + week) {  
                    buttons[i][j].setText(dm++ + ""); //自加然后转字符串 
                    buttons[i][j].setEnabled(true);  
                }  
            }  
        }
        cd.set(Calendar.DAY_OF_MONTH, day);
        
        Lunar lunar=new Lunar(cd);
        lun.setText("  农历:"+lunar.toString());
    }
}  

