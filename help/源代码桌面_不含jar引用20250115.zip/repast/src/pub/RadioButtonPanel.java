package pub;
//一个笔较个性化的复选按扭，可以进行引用
//String s[]=new String[2];
//s[0]="afd";s[1]="fsa";
//RadioButtonPanel aa=new RadioButtonPanel(s);
import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.*;
import javax.swing.table.TableCellRenderer;
public class RadioButtonPanel extends JPanel {
	private static final long serialVersionUID = -7638169989922028949L;
	JRadioButton[] buttons;
	public RadioButtonPanel(String[] str) {
		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		buttons = new JRadioButton[str.length];
		for (int i = 0; i < buttons.length; i++) {
			buttons[i] = new JRadioButton(str[i]);
			buttons[i].setFocusPainted(false);
			add(buttons[i]);
		}
	}

	public void setSelectedIndex(int index) {
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setSelected(i == index);
		}
	}

	public int getSelectedIndex() {
		for (int i = 0; i < buttons.length; i++) {
			if (buttons[i].isSelected()) {
				return i;
			}
		}
		return -1;
	}

	public JRadioButton[] getButtons() {
		return buttons;
	}
}

class RadioButtonRenderer extends RadioButtonPanel implements TableCellRenderer {
	private static final long serialVersionUID = 4378378L;

	RadioButtonRenderer(String[] strs) {
		super(strs);
	}

	public Component getTableCellRendererComponent(JTable table, Object value,
			boolean isSelected, boolean hasFocus, int row, int column) {
		if (value instanceof Integer) {
			setSelectedIndex(((Integer) value).intValue());
		}
		return this;
	}
}

class RadioButtonEditor extends DefaultCellEditor implements ItemListener {
	private static final long serialVersionUID = -5782964532168428556L;
	RadioButtonPanel panel;
	public RadioButtonEditor(JCheckBox checkBox, RadioButtonPanel panel) {
		super(checkBox);
		this.panel = panel;
		ButtonGroup buttonGroup = new ButtonGroup();
		JRadioButton[] buttons = panel.getButtons();
		for (int i = 0; i < buttons.length; i++) {
			buttonGroup.add(buttons[i]);
			buttons[i].addItemListener(this);
		}
	}

	public Component getTableCellEditorComponent(JTable table, Object value,
			boolean isSelected, int row, int column) {
		if (value instanceof Integer) {
			panel.setSelectedIndex(((Integer) value).intValue());
		}
		return panel;
	}

	public Object getCellEditorValue() {
		return new Integer(panel.getSelectedIndex());
	}

	public void itemStateChanged(ItemEvent e) {
		super.fireEditingStopped();
	}
}
