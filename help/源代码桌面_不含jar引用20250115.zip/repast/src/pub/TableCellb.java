package pub;
import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import root.Sql;

//彩色表格,专用于台次点单以表格模式显示时的样式
public class TableCellb extends DefaultTableCellRenderer {
	private static final long serialVersionUID = -9148665517408962755L;
	private ArrayList<Integer> v=new ArrayList<Integer>();
	public TableCellb(JTable cookup){
		for(int k=0; k<cookup.getRowCount(); k++){
			if(Sql.getval(cookup, "出单", k).equals("0")) v.add(k);
		}
	}
	private final DefaultTableCellRenderer DEFAULT_RENDERER = new DefaultTableCellRenderer();
	public Component getTableCellRendererComponent(JTable table, Object value,boolean isSelected, boolean hasFocus, int row, int column){
		Component renderer = DEFAULT_RENDERER.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		Color foreground=null, background=null;
		if (isSelected) {
			//foreground = Color.red;
			background = Color.LIGHT_GRAY;
		}
		
		for (int k = 0; k < v.size(); k++) {
			if (row == v.get(k)) {
				foreground = Color.RED;
				// background = Color.LIGHT_GRAY;
				break; // 此句一定要加，否则只有最后一行生效
			}
		}
		
		renderer.setForeground(foreground);
		renderer.setBackground(background);

		
		// 其实renderer就是一个JLabel, 商品价格靠右对齐
		if(column==8){
			((JLabel)renderer).setHorizontalAlignment(SwingConstants.RIGHT);
		}
		else{
			((JLabel)renderer).setHorizontalAlignment(SwingConstants.LEFT);
		}
		
		
		return renderer;
	}
	
	/*private void goTable() {
		// 表格加工,将无意义菜品用蓝色文字显示
		ArrayList<Integer> v = new ArrayList<Integer>();
		for (int m = 0; m < cookup.getRowCount(); m++) {
			String mm = Sql.getval(cookup, "属性", m);
			if (!mm.isEmpty()) {
				v.add(m);
			}
		}
		cookup.setDefaultRenderer(Object.class, new TableCellb(v));
	}*/
}
		
	