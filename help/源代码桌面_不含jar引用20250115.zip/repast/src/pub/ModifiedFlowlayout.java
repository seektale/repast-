package pub;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Insets;
//当然楼主也提出了一个很好的建议，就是继承FLowLayout类，并重写minimumLayoutSize方法和preferredLayoutSize方法。
//这也是一个不错的办法。这个类用于解决Flowlayout布局自动换行的问题
public class ModifiedFlowlayout extends FlowLayout {  
	private static final long serialVersionUID = 146345545467643L;
	public ModifiedFlowlayout() {  
        super();  
    }  
    public ModifiedFlowlayout(int align) {  
        super(align);  
    }  
    public ModifiedFlowlayout(int align, int hgap, int vgap) {  
        super(align, hgap, vgap);  
    }  
    public Dimension minimumLayoutSize(Container target) {  
        return computeSize(target, false);  
    }  
    public Dimension preferredLayoutSize(Container target) {  
        return computeSize(target, true);  
    }
    private Dimension computeSize(Container target, boolean minimum) {
        synchronized (target.getTreeLock()) {  
            // 得到容器的间距离  
            Insets insets = target.getInsets();  
            int hgap = this.getHgap();  
            int vgap = this.getVgap();  
            // 得到容器的最大宽度  
            int maxwidth = target.getWidth() - (insets.left + insets.right + hgap * 2);  
            // 容器的组件个数  
            int nmembers = target.getComponentCount();  
            int x = 0, y = insets.top + vgap;
            int rowh = 0;  
            for (int i = 0; i < nmembers; i++) {
                Component m = target.getComponent(i);  
                // 如果组件是可见的  
                if (m.isVisible()) {  
                    Dimension d = minimum ? m.getPreferredSize() : m.getMinimumSize();  
                    m.setSize(d.width, d.height);  
                    if ((x == 0) || ((x + d.width) <= maxwidth)) {  
                        if (x > 0) {  
                            x += hgap;  
                        }  
                        x += d.width;  
                        rowh = Math.max(rowh, d.height);  
                    } else {  
                        x = d.width;  
                        y += vgap + rowh;
                        rowh = d.height;  
                    }
                    
                    //经过实测，布局里面的最后一行组件不会显示，自己加上这一句后解决了这个问题
                    if(i==nmembers-1) y += vgap + rowh;
                }
                
            }
            return new Dimension(x, y);  
        }
    }
}  