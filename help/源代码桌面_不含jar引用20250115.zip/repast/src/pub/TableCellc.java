package pub;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

//彩色表格,用于Lineup类
public class TableCellc implements TableCellRenderer {
	private int k ;
	public TableCellc (int k){
		this.k = k ;
	}
	
	private final DefaultTableCellRenderer DEFAULT_RENDERER = new DefaultTableCellRenderer();
	public Component getTableCellRendererComponent(JTable table, Object value,boolean isSelected, boolean hasFocus, int row, int column){
		Component renderer = DEFAULT_RENDERER.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		Color c=null;
		if (isSelected) c=Color.LIGHT_GRAY;
		if (row == k) c=Color.magenta;
		renderer.setForeground(null);
		renderer.setBackground(c);
		return renderer;
	}
}