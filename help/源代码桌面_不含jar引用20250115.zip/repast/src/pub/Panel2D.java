package pub;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.swing.JPanel;
//渐变色彩面板
public class Panel2D extends JPanel{
	private static final long serialVersionUID = 3692787239197944543L;
	private Color color1 = new Color(225,237,233);
	private Color color2 = new Color(76,124,206);
	public Panel2D(){}
	protected void paintComponent(Graphics g){
		//使用Graphics2D绘制渐变色彩
		Graphics2D g2d = (Graphics2D) g;
		g2d.setPaint(new GradientPaint(0, 0, color1, 0, this.getHeight(), color2));
		g2d.fill(new Rectangle(0, 0,this.getWidth(), this.getHeight()));
	} 
}