package pub;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import org.apache.commons.io.FileUtils;
import root.Front;
public class ConfigFile {
	
	public static String confdir; //Photo类要用到
	private static File config;
	//private static Properties props=System.getProperties();
    //private static File config = new File(props.getProperty("user.home")+"/Smosu/repast.properties"); 废弃
    
    public ConfigFile() {
		
    	String jarPath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		try {
			jarPath = java.net.URLDecoder.decode(jarPath, "UTF-8"); //解决路经中存在的空格问题，如：program%20files%20
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
    	
    	confdir = new File(jarPath).getParent() + File.separator + "conf";
    	config = new File(confdir+File.separator+"repast.properties");
    	
    	// 配置文件目录
    	final File tem = new File(confdir);
    	if(!tem.exists()) tem.mkdirs();
    	
    	// 初始化logo
    	Front.logo = new ImageIcon(getClass().getClassLoader().getResource("pic/rice.png")).getImage();
    	
    	// 配置图片文件目录
    	final File PhotoFile = new File(confdir+File.separator+"photo");
    	if(!PhotoFile.exists()) PhotoFile.mkdirs();
    	
    	// 当天日志文件目录
		SimpleDateFormat sd = new SimpleDateFormat("yyyyMMdd");
		final String sel = confdir + File.separator + sd.format(new Date());
		final File LogFile = new File(sel);
		if (!LogFile.exists())	LogFile.mkdirs();
		
		// 配置文件创建
		if (!config.exists()){
			try{
	        	FileOutputStream fos = new FileOutputStream(config);
	            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
	            //默认 服务器参数 及 账号密码
	            String defaultConfigInfo = "ServerName=127.0.0.1\n"
	                + "Port=3306\n"
	                + "DatabaseName=repast\n"
	                + "Maria=Y\n"				//启动数据库
	                + "UserName=root\n"
	                + "Password=123456\n";
	                //+ "Templet=系统模板\n"		//套打模板
	                //+ "MenuShowMode=Y\n"		//商品显示模式(Y代表卡片模式，N代表表格模式)
	                //+ "HotPrintStation=\n";	//热敏打印机站点
	            bw.write(defaultConfigInfo);
	            bw.close();
	        }
	        catch (Exception e){
	        	System.out.println("配置文件初始化异常\n"+e.toString());
	        }
		}
		
		// 日志文件创建
		sd = new SimpleDateFormat("yyyyMMddHHmmss");
		try {
			//发布之后JDK与程序在同一目录下,此时将日志输出到程序目录下
	    	final String[] findjdk = new File(jarPath).getParentFile().list(new FilenameFilter() {
				public boolean accept(File dir, String name) {
					if(name.toLowerCase().startsWith("jre")) return true;
					if(name.toLowerCase().startsWith("jdk")) return true;
					return false;
				}
			});
	    	if(findjdk.length>0) {
	    		//日志输出文件,所有System.out.println();语句的数据流均会写入这个文件
				final PrintStream out = new PrintStream(new File(sel + File.separator + sd.format(new Date()) + ".log"));
	    		System.setOut(out);
				System.setErr(out);		//系统的错误信息
	    	}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		//dll文件布署配置
		final String dlldir = new File(jarPath).getParent() + File.separator + "dll";
		final File dllfiles[] = new File(dlldir).listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				if(name.toLowerCase().endsWith(".dll")) return true;
				return false;
			}
		});
		if(dllfiles==null || dllfiles.length==0) {	//没有dll文件
			JOptionPane.showMessageDialog(null, "关于串口热敏打印，排队文本朗读叫号，M1会员卡的dll文件没有找到，除相应功能受限外不影响使用："+dlldir);
			return;
		}
		final File dest = new File(System.getProperty("java.home")+File.separator+"bin"); //放到jre的bin目录下
		for(final File dll : dllfiles) {
			try {
				FileUtils.copyFileToDirectory(dll, dest, true);
				System.out.println("dll文件复制布署成功："+dll.getPath() +" To "+ dest.getPath());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("dll文件复制布署失败："+dll.getPath() +" To "+ dest.getPath()+"\n"+e.getMessage()+"\n\n可能需要以管理员权限运行");
				JOptionPane.showMessageDialog(null, "dll文件复制布署失败："+dll.getPath()+"\n"+e.getMessage()+"\n\n可能需要以管理员权限运行");
			}
		}
		
		//串口打印配置文件，javax.comm.properties文件单独布署
		final File comm = new File(new File(jarPath).getParent() + File.separator + "jar" + File.separator + "javax.comm.properties");
		if(comm.exists()) {
			try {
				FileUtils.copyFileToDirectory(comm, new File(System.getProperty("java.home")+File.separator+"lib"), true);
				System.out.println("javax.comm.properties文件复制布署成功："+comm.getPath()+" To lib");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		//串口打印jar文件，comm.jar文件单独布署
		final File commjar = new File(new File(jarPath).getParent() + File.separator + "jar" + File.separator + "comm.jar");
		if (commjar.exists()) {
			try {
				FileUtils.copyFileToDirectory(commjar, new File(System.getProperty("java.home") + File.separator + "lib" + File.separator + "ext"),true);
				System.out.println("comm.jar文件复制布署成功：" + commjar.getPath() + " To lib/ext");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
    }
    
    
	/**
     * 获取配置文件信息
     */
    public static String getProperty(String who){
        try{
            // 定义一个properties对象
        	final Properties properties = new Properties();
            // 读取properties
        	final FileInputStream fis = new FileInputStream(config);
            // 加载properties文件
            properties.load(fis);
            // 读取properties中的某一项
            String temp=properties.getProperty(who);
            if(temp==null)	temp="";
            return temp;
        } catch (Exception e){
        	System.out.println("读取配置文件异常\n"+e.toString());
        	return "";
        }
    }
    
    
    /**
     * 修改配置文件信息，如果没有，会自动创建该对象
     */
    public static boolean setProperty(String who,boolean boo){
    	String val="N";
    	if(boo) val="Y";
    	return setProperty(who,val);
    }
    public static boolean setProperty(String who,String val){
        try{
            // 定义一个properties对象
            final Properties properties = new Properties();
            // 读取properties
            final FileInputStream fis = new FileInputStream(config);
            // 加载properties文件
            properties.load(fis);
            // 设置properties中的某一项
            properties.setProperty(who,val);	//properties.setProperty("Port","3306");
            
            final FileOutputStream fout = new FileOutputStream(config);
            properties.store(fout, "");//保存文件
            fout.close();
            return true;
        } catch (Exception e){
        	System.out.println("保存配置文件异常\n"+e.toString());
            return false;
        }
    }
}

