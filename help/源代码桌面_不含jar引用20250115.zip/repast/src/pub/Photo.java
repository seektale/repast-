package pub;
import java.awt.Image;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;

import javax.comm.CommPortIdentifier;
import javax.comm.SerialPort;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import org.apache.commons.io.FileUtils;

import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class Photo {
	
	/**************************************************************************************
	 * 　MySQL的四种BLOB类型 　　TinyBlob 最大 255 字节 　　Blob 最大 65K 　　MediumBlob 最大 16M   LongBlob 最大 4G
	*/
	// 图片缩放,假设图片宽 高 最大为max
	private static ByteArrayOutputStream getImage(File F, int max) throws Exception {
		BufferedImage Bi = ImageIO.read(F);
		
		// 图处本身很小，宽和高都小于等于max像素，则直接返回原图
		if ((Bi.getWidth() <= max) && (Bi.getHeight() <= max)) {
			ByteArrayOutputStream bs = new ByteArrayOutputStream();
			ImageOutputStream imOut = ImageIO.createImageOutputStream(bs);
			//切记使用jpg格式时图片压缩率很高，而png次之
			String type = Bi.getType()==6 ? "png" : "jpg";	//png格式为6，jpg格式为5
			ImageIO.write(Bi, type, imOut);
			return bs;
		}
		
		// 宽和高一个大于max,一个小于max，则改变max的值，否则直接处理会出异常
		if ((Bi.getWidth() < max) || (Bi.getHeight() < max)) {
			max = Math.min(Bi.getWidth(), Bi.getHeight());
		}
		
		// 开始进行缩放处理,下面一句作用不明，好像是压缩算法
		// Image img = Bi.getScaledInstance (max,max,Image.SCALE_SMOOTH);
		double Ratio = 0.0;
		if ((Bi.getHeight() > max) || (Bi.getWidth() > max)) {
			if (Bi.getHeight() > Bi.getWidth())
				Ratio = (double) max / Bi.getHeight();
			else
				Ratio = (double) max / Bi.getWidth();
		}
		AffineTransformOp op = new AffineTransformOp(AffineTransform.getScaleInstance(Ratio, Ratio), null);
		Image img = op.filter(Bi, null);

		ByteArrayOutputStream bs = new ByteArrayOutputStream();
		ImageOutputStream imOut = ImageIO.createImageOutputStream(bs);
		String type = Bi.getType()==6 ? "png" : "jpg";
		ImageIO.write((BufferedImage)img, type, imOut);
		return bs;
	}
	
	// 保存商品图片到数据库，拖放方式直接调用，参数：商品编号，商品名称，文件路经
	public static boolean savepic(int num, String name, final File f) {
		
		if (num <= 0) {
			JOptionPane.showMessageDialog(Front.front, "指定的图片索引不正确的,当前错误值：" + num, "错误 Error", 0);
			return false;
		}
		
		/* 判断图片格式是否正确，为了兼容性不做判断了
		try {
			BufferedImage Bi = ImageIO.read(f);
			Bi.getWidth();// 触发异常
		} catch (Exception e) {
			JOptionPane.showMessageDialog(Front.front, "文件错误，或无法识别图片格式。\n" + f.toPath(), "错误 Error", 0);
			return false;
		} */
		
		// 取消自动提交状态
		try {
			Sql.con.setAutoCommit(false);
		} catch (SQLException e) {}
		
		PreparedStatement stmt = null;
		
		/* 先将大图写入数据库 */
		try {
			// 更新数据时，如果主键出现了重复，则可以使用下面的方法变为更新
			final String sql = "INSERT INTO photo VALUES(" + num + ",'" + name + "',null,?,'',"+nextint()+",'商品图片') " +
						 "ON DUPLICATE KEY UPDATE img=?,version=version+1";
			
			//ByteArrayOutputStream bs = getImage(f, 1920); 放弃，直接100%保存原图
			final FileInputStream fis = new FileInputStream(f);
			final ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int len;
			byte[] buffer = new byte[1024];
			while ((len = fis.read(buffer)) != -1) {
				baos.write(buffer, 0, len);
			}
			final InputStream is1 = new ByteArrayInputStream(baos.toByteArray());
			final InputStream is2 = new ByteArrayInputStream(baos.toByteArray());
			stmt = Sql.con.prepareStatement(sql);
			stmt.setBinaryStream(1, is1, baos.size());
			stmt.setBinaryStream(2, is2, baos.size());
			stmt.executeUpdate();
			Sql.con.commit();
			is1.close();
			is2.close();
			baos.close();
			fis.close();
		} 
		catch (Exception ea) {
			SouthPan.warn("保存大图(原始图)出错：" + ea.getMessage(), true);
			ea.printStackTrace();
		} 
		finally {
			try {if(stmt!=null) stmt.close();} catch (Exception e) {}
		}
		
		/* 再将略缩图写入数据库 */
		try {
			// InputStream必须分开生成两个
			final ByteArrayOutputStream bs = getImage(f, 100);
			final InputStream is = new ByteArrayInputStream(bs.toByteArray());
			stmt = Sql.con.prepareStatement("update photo set icon=? where num=" + num + ";");
			stmt.setBinaryStream(1, is, bs.size());
			stmt.executeUpdate();
			Sql.con.commit();
			is.close();
			bs.close();
		} 
		catch (Exception ea) {
			// 如果用户在出错提示对话框中不点确定，stmt就不会关闭，会导致menu表被锁定，没有测试
			SouthPan.warn("保存小图(略缩图)出错：" + ea.getMessage(), true);
			ea.printStackTrace();
		} 
		finally {
			try {if(stmt!=null)stmt.close();} catch (Exception e) {}
		}

		// 确保恢复为自动提交状态
		try {
			Sql.con.setAutoCommit(true);
		} catch (SQLException e) {
		}
		return true;
	}

	// 保存签名图片到数据库，参数：第几个签名 ，AR账号，AR名称，文件路经
	public static void ImportSign(int which, String ar, String name, File f) {

		final String s[]=Sql.getString("select photo_num()", "Photo.ImportSigns");
		if(s.length==0){
			JOptionPane.showMessageDialog(Front.front,"select photo_num()没有返回结果","错误 Error",0);
			return ;
		}
		int num=Integer.valueOf(s[0]);
		if(num==0){
			String msg="数据表photo的编号在10000以内没有可用的编号(10000以上编号用于同步商品编号)";
			JOptionPane.showMessageDialog(Front.front,msg,"严重错误 Serious_Error",0);
			return ;
		}
		
		// 判断图片格式是否正确
		try {
			BufferedImage Bi = ImageIO.read(f);
			Bi.getWidth();// 触发异常
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "文件错误，或无法识别图片格式。\n" + f.toPath(), "错误 Error", 0);
			return ;
		}

		// 取消自动提交状态
		try {
			Sql.con.setAutoCommit(false);
		} catch (SQLException e) {}

		PreparedStatement stmt = null;
		try {
			// 更新数据如果主键出现了重复则可以使用下面的方法变为更新,这里取系统时间作为版本号
			String sql = "INSERT INTO photo VALUES(" + num + ",'" + name + "',null,?,'',"+nextint()+",'AR签名图片') " +
						 "ON DUPLICATE KEY UPDATE img=?,version=version+1";

			final ByteArrayOutputStream bs = getImage(f, 200);
			final InputStream is1 = new ByteArrayInputStream(bs.toByteArray());
			final InputStream is2 = new ByteArrayInputStream(bs.toByteArray());

			stmt = Sql.con.prepareStatement(sql);
			stmt.setBinaryStream(1, is1, bs.size());
			stmt.setBinaryStream(2, is2, bs.size());
			stmt.executeUpdate();
			Sql.con.commit();
			stmt.close();
			
			// 将AR标记为有签名照,关联对应索引
			if (which == 1)	sql = "update vip set 图片一=" + num + " where AR账号=" + ar;
			if (which == 2)	sql = "update vip set 图片二=" + num + " where AR账号=" + ar;
			stmt = Sql.con.prepareStatement(sql);
			stmt.executeUpdate();
			Sql.con.commit();
			stmt.close();
		} 
		catch (Exception ea) {
			// 如果用户在出错提示对话框中不点确定，stmt就不会关闭，会导致menu表被锁定，没有测试
			SouthPan.warn("保存签名图片出错：" + ea.getMessage(), true);
			ea.printStackTrace();
		} 
		finally {
			try {stmt.close();} catch (Exception e) {}
		}
		
		// 确保恢复为自动提交状态
		try {
			Sql.con.setAutoCommit(true);
		} catch (SQLException e) {}
	}

	// 保存广告和背景图片到数据库
	public static void ImportAD(int num, String web) {
		ByteArrayOutputStream bs = new ByteArrayOutputStream();
		try{
			final URL url = new URL(web);
			BufferedImage temp = ImageIO.read(url);
			
			// 判断图片格式是否正确
			try {
				temp.getType();	//触发异常
			} catch (Exception e) {
				//JOptionPane.showMessageDialog(null, "网络文件错误，或无法识别图片格式。\n", "错误 Error", 0);
				System.out.println("网络文件错误，或无法识别图片格式。\n"+e.toString());
				return ;
			}
			
			//初始化bs
			final ImageOutputStream imOut = ImageIO.createImageOutputStream(bs);
			String type = temp.getType()==6 ? "png" : "jpg";	//png格式为6，jpg格式为5
			ImageIO.write(temp, type, imOut);
			
			//对比图片,需要说明的是：相同图片，png格式每一个字节均一致，jpg格式则会有不到10字节的差别,但这10个字节在后面
			//为解决这个问题，这里只计算前1000个字节的MD5值 (不同图片可能前500字节相等，所以取大一点)
			byte sour[] = bs.toByteArray();
			byte head[] = new byte[1000];
			for(int k=0 ; k<1000 ; k++){
				if(sour.length<1000) break;
				head[k] = sour[k];
			}
			
			final MessageDigest messageDigest= MessageDigest.getInstance("MD5");
			messageDigest.update(head);
			
			//把数组每一字节换成16进制连成md5字符串
		    StringBuffer md5str = new StringBuffer();
			int digital;
			for (byte bb : messageDigest.digest()) {
				digital = bb;
				if(digital < 0) 	digital += 256;
				if(digital < 16)	md5str.append("0");
				md5str.append(Integer.toHexString(digital));
			}
			String oldmd5 = md5str.toString();
			
			//与数据库中保存的图片对比
		    String comp[] = Sql.getString("select photo_compare("+num+")", "Photo");
			if(oldmd5.equals(comp[0])){
				System.out.println("广告或背景图片:"+num+" 图片对比前1000字节MD5 相同，同步被忽略");
				return ;
			}
			System.out.println("广告或背景图片:"+num+" 图片对比前1000字节MD5 不相同，同步继续");
		}
		catch (Exception e) {
			//JOptionPane.showMessageDialog(null, "网络文件加工失败。\n", "错误 Error", 0);
			System.out.println( "网络文件加工失败。\n"+e.toString());
			return ;
		}
		
		
		// 取消自动提交状态
		try {
			Sql.con.setAutoCommit(false);
		} catch (SQLException e) {}
		
		PreparedStatement stmt = null;
		try {
			// 更新数据时，如果主键出现了重复，则可以使用下面的方法变为更新
			String sql = "INSERT INTO photo VALUES(" + num + ",'广告和背景图片',null,?,'',"+nextint()+",'管理员登陆时才更新') " +
						 "ON DUPLICATE KEY UPDATE img=?,version=version+1";
			
			InputStream is1 = new ByteArrayInputStream(bs.toByteArray());
			InputStream is2 = new ByteArrayInputStream(bs.toByteArray());
			
			stmt = Sql.con.prepareStatement(sql);
			stmt.setBinaryStream(1, is1, bs.size());
			stmt.setBinaryStream(2, is2, bs.size());
			stmt.executeUpdate();
			Sql.con.commit();
		} catch (Exception ea) {
			JOptionPane.showMessageDialog(Front.front,"保存广告或背景图出错：" + ea.getMessage(),"失败",0);
			ea.printStackTrace();
		} finally {
			try {stmt.close();} catch (Exception e) {}
		}

		// 确保恢复为自动提交状态
		try {
			Sql.con.setAutoCommit(true);
		} catch (SQLException e) {}
	}
	
	// 保存logo图片到数据库
	public static void ImportLogo(File f) {
		ByteArrayOutputStream bs ;
		// 判断图片格式是否正确
		try {
			BufferedImage Bi = ImageIO.read(f);
			Bi.getType();			// 触发异常			
			bs = getImage(f, 300);	// 处理文件
		} catch (Exception e) {
			JOptionPane.showMessageDialog(Front.front, "文件错误，或无法识别图片格式。\n" + f.getPath(), "错误 Error", 0);
			return ;
		}
		
		// 取消自动提交状态
		try {
			Sql.con.setAutoCommit(false);
		} catch (SQLException e) {}
		
		PreparedStatement stmt = null;
		try {
			// 更新数据时，如果主键出现了重复，则可以使用下面的方法变为更新
			String sql = "INSERT INTO photo VALUES(1,'logo',null,?,'',"+nextint()+",'单位LOGO') " +
						 "ON DUPLICATE KEY UPDATE img=?,version=version+1";
			
			InputStream is1 = new ByteArrayInputStream(bs.toByteArray());
			InputStream is2 = new ByteArrayInputStream(bs.toByteArray());

			stmt = Sql.con.prepareStatement(sql);
			stmt.setBinaryStream(1, is1, bs.size());
			stmt.setBinaryStream(2, is2, bs.size());
			stmt.executeUpdate();
			Sql.con.commit();
		} catch (Exception ea) {
			JOptionPane.showMessageDialog(Front.front,"保存Logo图出错：" + ea.getMessage(),"失败",0);
			ea.printStackTrace();
		} finally {
			try {stmt.close();} catch (Exception e) {}
		}

		// 确保恢复为自动提交状态
		try {
			Sql.con.setAutoCommit(true);
		} catch (SQLException e) {}
	}
	
	// 通过名称读取图片,图片存于表photo的img列；如果反复读取，请用Var.getIcon(name)缓存图片
	public static Icon readIcon(String name) {
		//编号大于10000专用于商品图片，小于10000用于系统自身使用
		String sql = "select img,num,name,version from photo where name='" + name + "' and num<10000;";
		return readIcon(sql, true);
	}
	
	// 通过索引读取图片,默认只读取小图片
	public static ImageIcon readIcon(int ind) {
		//先从本地缓存中读取
		final ImageIcon icon=LocalPhoto(ind,false);
		if(icon!=null){
			return icon;
		}
		//本地缓存中没有或版本不对则从数据库中更新,
		String sql = "select icon,num,name,version from photo where num=" + ind;
		return readIcon(sql, false);
	}
	
	// 通过索引读取图片,指定读取大图
	public static ImageIcon readIcon(int ind, boolean map) {
		//先从本地缓存中读取
		ImageIcon icon=LocalPhoto(ind,true);
		if(icon!=null){
			return icon;
		}
		//本地缓存中没有或版本不对则从数据库中更新
		String sql = "select img,num,name,version from photo where num=" + ind;
		return readIcon(sql, true);
	}
	// 通过索引读取图片,专用于刷新大图和小图
	public static ImageIcon Iconrefresh(int ind) {
		// 先缓存大图
		String sql = "select img,num,name,version from photo where num=" + ind;
		readIcon(sql, true);
		// 再缓存小图并返回
		sql = "select icon,num,name,version from photo where num=" + ind;
		return readIcon(sql, false);
	}
	
	// 所有从数据库中的图片读取均间接从这里得到
	private static ImageIcon readIcon(String sql, boolean map) {
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			SouthPan.writesql(sql);				// 终端窗口同步显示
			if(Sql.con == null) return null;	// 可能数据库不可用
			pstmt = Sql.con.prepareStatement(sql);
			if(pstmt == null) return null;		// 可能数据库不可用
			rs = pstmt.executeQuery();

			if (rs.first()) {
				byte b[] = null;
				if (map)	b = rs.getBytes("img");
				else		b = rs.getBytes("icon");
				if(b==null) return null;
				
				int num = rs.getInt("num");
				String version = rs.getString("version");
				String name = rs.getString("name");
				//防止这个错误 C:\Users\sa\Smosu\photo\17006@极品佛跳墙\位@1@false.jpg (系统找不到指定的路径。)
				name = name.replace("/", "@A");
				name = name.replace("\\", "@B");
				if(version==null) version="";
				
				//缓存图片到本地,注意is不可复用，所以要重新生成
				//缓存图片请以 (索引、商品名、版本、大小图标记) 命名 三个一个都不能少。
				//如:用户修改了某个商品索引,恰好版本又一致,这样会找到别的图片上去
				//BufferedInputStream XX = new BufferedInputStream(is);
				final InputStream temp = new ByteArrayInputStream(b); 
				final File f = new File(ConfigFile.confdir+File.separator+"photo"+File.separatorChar+num+"@"+name+"@"+version+"@"+map+".jpg");
				FileUtils.copyInputStreamToFile(temp, f);
				temp.close();
				
				//背景和广告登记图片名称 
				if(num==30 || num==31 || num==32) {
					ConfigFile.setProperty("icon"+num, num+"@"+name+"@"+version+"@"+map+".jpg");
				}
				return new ImageIcon(b);
			}
			else {
				SouthPan.warn("参数：" + sql + " 未能读取到数据！请检查图片是否存在于数据库", false);
			}
		}
		catch (Exception e) {
			SouthPan.warn("[photo.readIcon 读取图片异常 ]\n" + e.getMessage(), false);
			e.printStackTrace();
		} 
		finally {
			try {
				if(rs!=null) rs.close();
				if(rs!=null) pstmt.close();
			} catch (Exception e) {}
		}
		//规定没有图片返回null,不要返回new ImageIcon();
		return null;
	}

	//从本地缓存中读取图片，maxmin代表读取的是大图还是小图
	private static ImageIcon LocalPhoto(int ind, boolean maxmin) {
		
		String val[]=Sql.getString("select name,version from photo where num="+ind, "Photo.LocalPhoto"); //版本控制通过比较不同,而不是比较大小
		if(val.length==0) val=new String[]{"",""};
		val[0] = val[0].replace("/", "@A");
		val[0] = val[0].replace("\\", "@B");
		
		final String path=ConfigFile.confdir+File.separator+"photo"+File.separator+ind+"@"+val[0]+"@"+val[1]+"@"+maxmin+".jpg";
	    final File f = new File(path);
	    
		if(f.exists()) {
			SouthPan.warn("本地缓存有相同版本图片，返回本地缓存图片\n"+path, false);
			//背景和广告登记图片名称 ,虽然从数据库中读取时也进行登记，但如果配置文件被删除，这里就起到了修复登记的作用
			if(ind==30 || ind==31 || ind==32){
				ConfigFile.setProperty("icon"+ind, ind+"@"+val[0]+"@"+val[1]+"@"+maxmin+".jpg");
			}
			return new ImageIcon(path);
		}
		return null;
	}
	
	// 导出商品大图片到桌面
	public static void ExportIcon(int ind, boolean dia) {
		String sql = "select name,img from photo where num=" + ind;
		try {
			final PreparedStatement pstmt = Sql.con.prepareStatement(sql);
			final ResultSet rs = pstmt.executeQuery();
			if (rs.first()) {
				String thename = rs.getString(1);
				if((thename==null)||thename.isEmpty()){
					thename=ind+"";
				}
				final InputStream is = rs.getBinaryStream("img");
				if(is==null){
					JOptionPane.showMessageDialog(null,"记录存在，但图片在 Photo表img列中 不存在","错误 Error",0);
					return ;
				}
				
				String end = getContentType(rs.getBinaryStream("img"));
				if(end==null || end.isEmpty()) end="xxx";
				
				// 默认选择当前用户桌面
				final Properties props = System.getProperties();
				String sel = props.getProperty("user.home") +File.separator+ "desktop"+File.separator + thename + "." + end;
				File file = new File(sel);
				
				// 判断文件是否已经存在
				int k = 0;
				while (file.exists()) {
					k++;
					sel = props.getProperty("user.home") +File.separator+ "desktop" +File.separator+ thename + k + "." + end;
					file = new File(sel);
				}
				
				// 选择目录
				int result = JFileChooser.APPROVE_OPTION;
				if(dia){
					final JFileChooser chooser = new JFileChooser();
					// chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					// 只读取目录
					chooser.setSelectedFile(file);
					result = chooser.showSaveDialog(Front.front);
					String filePath = chooser.getSelectedFile().getPath();
					file = new File(filePath);
				}
				if(result==JFileChooser.APPROVE_OPTION) FileUtils.copyInputStreamToFile(is, file);
			}
			else {
				SouthPan.warn("没有相关记录，图片不存在，参数：" + sql, true);
			}
		} catch (Exception e) {
			SouthPan.warn("[photo.ExportIcon 导出图片异常 ]\n" + e.getMessage(), false);
			e.printStackTrace();
		}
	}
	
	
	/*******************************************************************************************/
	
	//读取字节,数据流  打印账单
	public static byte[] getbill(int mealnum){
		//是否显示退单和套餐明细
		String sua = ConfigFile.getProperty("Show_Back");
		String sub = ConfigFile.getProperty("Show_List");
		return getbin("select binary_bill("+mealnum+",'"+sua+"','"+sub+"')");
	}
	//读取字节,数据流  打印清单
	public static byte[] getlist(int mealnum, String site){
		return getbin("select binary_list("+mealnum+", '"+site+"')");
	}
	//读取字节,数据流  打印联单
	public static byte[] getunion(int mealnum, String site){
		//return getbin("select binary_union("+mealnum+", '"+site+"', 'N')");
		return getbin("select binary_union("+mealnum+", '"+site+"')");
	}
	
	//读取字节,专用于修复出单 和 重复出单, 直接调用数据库函数binary_repair()
	public static byte[] getsamebin(int dishind, String site){
		//return getbin("select convert(binary_repair("+dishind+", '"+site+"') using gbk)");
		return getbin("select binary_repair("+dishind+", '"+site+"')");
	}
	
	//读取字节,数据流  打印叫号
	public static byte[] getline(String ind){
		return getbin("select binary_line("+ind+")");
	}
	
	//读取字节,数据流  打印充值小票
	public static byte[] getcharge(String ind){
		return getbin("select binary_charge("+ind+")");
	}
	
	//读取字节,数据流
	private synchronized static byte[] getbin(String sql){
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			pstmt = Sql.con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.first();
			
			//下面的方法在程序打包后打印结果会乱码
			//byte b[] = rs.getBytes(1);
			//return new String(b).getBytes("gbk");
			
			/*
			//改用下面的方法一切正常
			String val=rs.getString(1);
			byte[] A = new byte[]{};
			try{A=val.getBytes("GBK");}catch (Exception e) {}
			return A ;
			*/
			return rs.getBytes(1);
		}
		catch (Exception e) {
			SouthPan.warn("[photo.getbin 读取打印字节流异常，请检查网络或权限 ]\n" + e.getMessage(), true);
			e.printStackTrace();
		} 
		finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
			} catch (Exception e) {}
		}
		return null;
	}
	
	//读取字节,后来加的，从存储过程中得到binary_go，返回值查看存储过程是4个
	public synchronized static HashMap<String[], byte[]> getBinDB(int mealnum, String hold){
		CallableStatement cs = null ;
		final HashMap<String[], byte[]> hm = new HashMap<String[], byte[]>();
        try{
        	cs = (CallableStatement)Sql.con.prepareCall("{call binary_go(?,?,?)}");
            cs.registerOutParameter(1, Types.VARCHAR);	//输出型参数
            cs.setString(2, mealnum+"");				//输入型参数
            cs.setString(3, hold);						//是否叫起
            cs.execute();
            
            //如果要得到结果集应使用rs = cs.executeQuery();
            //ResultSet rs = cs.executeQuery();
            if(cs.getWarnings()!=null){
            	JOptionPane.showMessageDialog(Front.front, cs.getWarnings().toString(), "Warnings", 0);
            }
            
            // 事务中输出的提示信息，即得到第一个输出型参数的值
            String sqlout = cs.getString(1);
            if(sqlout!=null && !sqlout.isEmpty()){
            	JOptionPane.showMessageDialog(Front.front, sqlout, "Warnings", 0);
            }
            
            // 没有错误的情况下处理结果集
            if(cs.getWarnings()==null && sqlout==null) {
            	boolean hadResults = false;
                int flag = 0;	//如果打印两份，则会出现重复，但HashMap不充许重复键值对，所以加一个序号标识。
                do{
                	final ResultSet rs = cs.getResultSet();
                	while(rs != null && rs.next()){
                		final String temp[] = new String[4];
                		temp[0] = rs.getString(1); //IP
                		temp[1] = rs.getString(2); //Port
                		temp[2] = rs.getString(3); //Site
                		temp[3] = "" + flag++;	   //放在最后面
                		hm.put(temp, rs.getBytes(4)); //binary
                     }
                     hadResults = cs.getMoreResults(); 	//检查是否存在更多结果集
                }while(hadResults);
            }
        }
        catch(Exception e){
			String s = e.getMessage();
			if (s == null) {
				// 比如，cat连接到了数据库，然后root删除了cat账号，当cat调用存储过程时e.getMessage就为空。
				s = "异常消息为空，可能帐号不存在，或其它不明原因。";
			}
			else if (s.startsWith("execute command denied to user")) {
				s = "没有权限，请向管理员申请。\n" + s;
			}
			JOptionPane.showMessageDialog(Front.front, "调用存储过程〖binary_go()〗异常: \n" + s, "Warnings", 0);
			e.printStackTrace();
        }
        finally{
        	//不再使用就关闭
        	try{cs.close();}catch (Exception e) {};
        }
        return hm ;
    }
	
	//不指定站点IP和端口时，自己根据站点名称找到IP和端口
	public static boolean printbin(byte temp[], String site, boolean boo){
		String sql = "select 站点,IP,端口 from print_config where 站点='"+site+"';" ;
		String config[]=Sql.getString(sql, "Photo.printbin()");
		if(config.length==0){
			SouthPan.warn("站点："+site+" 不存在，请正确配置打印机站点。", boo);
			return false;
		}
		String ip=config[1];				 //IP地址
		int port=Integer.valueOf(config[2]); //端口
		return printbin(temp, site, boo, ip, port);
	}
	
	//如果不加synchronized，程序时常有死机的现象
	public static synchronized boolean printbin(byte temp[], String site, boolean b, String ip, int port){
		boolean result = true;

		Socket socket = new Socket() ;
		ObjectOutputStream output = null ;
		SocketAddress add = new InetSocketAddress(ip, port); //服务器的ip和端口号
		try{
			socket.connect(add,3000);	//超时3秒
			output=new ObjectOutputStream(socket.getOutputStream());
			
			byte LF = 0x0A;	//打印并走纸的标记
			byte ESC = 0x1B;
			int flag=0;
			
			//复位两次,有些热敏打印机复位一次不够
			output.write(new byte[] {ESC, '@'});
			output.write(new byte[] {ESC, '@'});
			
			for(int k=0;k<temp.length;k++){
				output.write(temp[k]);
				flag++;
				
				//如果热敏打印机缓存为1024字节，应在快达到这个数之前将数据发送出去
				if((temp[k]==LF)&&(flag>900)){
					output.flush();
					flag=0;
					
					//复位两次
					output.write(new byte[] {ESC, '@'});
					output.write(new byte[] {ESC, '@'});
				}
			}
			output.flush();
		}
		catch (Exception e) {
			SouthPan.warn("打印机站点:"+site+" "+ip+":"+port+" 无法连接(超时3秒),打印失败\n\n"+e.getMessage(),b);
			//e.printStackTrace();
			result = false ;	//不要return false, 因为要下面的代码要关闭端口
		}
		finally{
			try {
				if(output!=null) output.close();
				if(socket!=null && !socket.isClosed()) socket.close();
			} catch (IOException e) {}
		}
		return result;
	}
	
	
	
	/*
	comm.jar拷贝到		      		c:\Program Files\Java\jdk1.6.0_23\jre\lib\ext;  
	javax.comm.properties拷贝到  		c:\Program Files\Java\jdk1.6.0_23\jre\lib; 
	win32comm.dll拷贝到           			c:\Program Files\Java\jdk1.6.0_23\bin。
	*/
	// com 值 ： COM1,COM2,COM3,COM4 等
	public static void Printcom(byte temp[], String com) throws Exception{
		Printcom(temp, com, true);
	}
	public static String Printcom(byte temp[], String com, boolean boo) throws Exception{
		
		final Enumeration<?> portList = CommPortIdentifier.getPortIdentifiers();
		boolean isok = true ;
		if(com==null || com.trim().isEmpty()) com="COM1";	//修复
		
		while (portList.hasMoreElements()){
			final CommPortIdentifier portId = (CommPortIdentifier) portList.nextElement();
			if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
				if (portId.getName().equalsIgnoreCase(com)) {
					
					SerialPort serialPort = (SerialPort)portId.open("Dmumu_Write_App", 2000);
					//serialPort.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
					//注意波特率要设为 19200 否则会乱码。
					serialPort.setSerialPortParams(19200, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
					
					final OutputStream output = serialPort.getOutputStream();
					
					byte LF = 0x0A;	//打印并走纸的标记
					byte ESC = 0x1B;
					int flag=0;
					
					//复位两次,有些热敏打印机复位一次不够
					output.write(new byte[] {ESC, '@'});
					output.write(new byte[] {ESC, '@'});
					
					for(int k=0;k<temp.length;k++){
						output.write(temp[k]);
						flag++;
						
						//如果热敏打印机缓存为1024字节，应在快达到这个数之前将数据发送出去
						if((temp[k]==LF)&&(flag>900)){
							output.flush();
							flag=0;
							
							//复位两次
							output.write(new byte[] {ESC, '@'});
							output.write(new byte[] {ESC, '@'});
						}
					}
					output.flush();

					output.close();
					serialPort.close();
					serialPort = null;
					
					isok = false ;
					break;
				}
			}
		}
		
		if(isok){
			SouthPan.warn("打印失败，找不到指定的串口 或 串口不存在："+com+"\n注意：COM只能在32位的JDK或JRE环境中运行，不支持64位环境。", 0, boo);
			return "N 找不到指定串口";
		}
		
		SouthPan.warn("打印完成，指定的串口："+com, false);
		return "Y 打印已完成";
    }
	
	private static int nextint() {
		final Random ran = new Random();
		int k = ran.nextInt(9999999);
		return k;
	}
	
	private static String getContentType(InputStream is) throws IOException {
		
		 byte[] buffer = new byte[8];
		 is.read(buffer, 0, 8);
		 String contentType = "";
		 
		 if (buffer[0] == (byte)0xFF && buffer[1] == (byte)0xD8 && buffer[2] == (byte)0xFF) {
			 contentType = "image/jpeg";
			 return "jpg";
		 } 
		 else if (buffer[0] == (byte)0x89 && buffer[1] == (byte)0x50 && buffer[2] == (byte)0x4E && buffer[3] == (byte)0x47) { 
			 contentType = "image/png";
			 return "png";
		 } 
		 else if (buffer[0] == (byte)0x47 && buffer[1] == (byte)0x49 && buffer[2] == (byte)0x46 && buffer[3] == (byte)0x38) {
			 contentType = "image/gif";
			 return "gif";
		 } 
		 
		 else if (buffer[0] == (byte)0x25 && buffer[1] == (byte)0x50 && buffer[2] == (byte)0x44 && buffer[3] == (byte)0x46 && buffer[4] == (byte)0x2D && buffer[5] == (byte)0x31 && buffer[6] == (byte)0x2E) {
			 return "pdf";
		 } 
		 
		 else if (buffer[0] == (byte)0x57 && buffer[1] == (byte)0x41 && buffer[2] == (byte)0x56 && buffer[3] == (byte)0x45) {
			 return "wav";
		 }
		 else if (buffer[0] == (byte)0x00 && buffer[1] == (byte)0x00 && buffer[2] == (byte)0x01 && buffer[3] == (byte)0xBA) {
			 return "mpg";
		 } 
		 else if (buffer[0] == (byte)0x00 && buffer[1] == (byte)0x00 && buffer[2] == (byte)0x01 && buffer[3] == (byte)0xB3) {
			 return "mpg";
		 } 
		 else if (buffer[0] == (byte)0x00 && buffer[1] == (byte)0x00 && buffer[2] == (byte)0x00 && buffer[3] == (byte)0x20 && buffer[4] == (byte)0x66 && buffer[5] == (byte)0x74 && buffer[6] == (byte)0x79 && buffer[7] == (byte)0x70) {
			 return "mp4"; //0x00, 0x00, 0x00, 0x20, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6F, 0x6D
		 }
		 
		 else {
			 contentType = URLConnection.guessContentTypeFromStream(is);
		 }
		 return contentType;
	}
	
}
