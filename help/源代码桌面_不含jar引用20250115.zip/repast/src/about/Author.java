package about;
//在JFrame上是不方便直接画背景的，一般是添加一个JPanel来实现,但要注意，要通过重载paintComponent()方法
import java.awt.*;
import javax.swing.*;

import root.Front;

import java.awt.event.*;
public class Author extends JDialog implements MouseListener{
	 private static final long serialVersionUID = 4794124565L;
     private final ScrollText s=new ScrollText();
 	 //图象标签和背景
	 private final Image backimg=new ImageIcon(this.getClass().getClassLoader().getResource("about/b.jpg")).getImage();
	 private final JLayeredPane lay=new JLayeredPane(){
    	 private static final long serialVersionUID = 49447584565L;
    	 protected void paintChildren(Graphics g){
             g.drawImage(backimg,2,2,this.getWidth()-5,this.getHeight()-5,this);
             super.paintChildren(g);
         }
     };
     /*
     public static void main(String args[]){
     	new Author(500,300);
     }
     */
     public Author(int m,int n){
    	 super(Front.front, true);	//这个最好加上
    	 
		 // 滚动文本
    	 s.addMouseListener(this);
		 s.setBounds(90, 60, 400, 195);
		 lay.add(s);
		 lay.setBorder(BorderFactory.createRaisedBevelBorder());
		 lay.addMouseListener(this);

		 setContentPane(lay);
    	 setSize(m, n);
		 setLocationRelativeTo(null);
		 setUndecorated(true);
		 setVisible(true);
     }
     public void mouseClicked (MouseEvent e){}
     public void mouseEntered (MouseEvent e){}
     public void mouseExited  (MouseEvent e){}
     public void mousePressed (MouseEvent e){
    	 s.flag=false;
		 dispose();
     }
     public void mouseReleased(MouseEvent e){}
}
