package log;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import pub.Popup_tab;
import pub.Var;
import root.Sql;
public class SelectUP extends JPanel implements ActionListener,DocumentListener{
	private static final long serialVersionUID = 1241605804413034725L;
	
	private JButton excel=new JButton("导出当前 Excel");
	private ArrayList<String> type;
	private JTextField like=new JTextField(20);
	public  JComboBox<String> cbox;
	public  JLabel sqltip=new JLabel("请输入查询时字段包含的字符！");
	
	private JTable t;
	private String subsql;
	public SelectUP(JTable t,String subsql,String tablename){
		this.t=t;
		this.subsql=subsql;
		setLayout(new FlowLayout(FlowLayout.LEFT));
		setOpaque(false);

		excel.addActionListener(this);
		JLabel msg=new JLabel("  ★输入查询条件前选择字段:");
		ArrayList<String> col = Sql.getcolname(tablename, getClass().getName());
		String cols[]=new String[col.size()];
		cbox=new JComboBox<String>(col.toArray(cols));
		type=Sql.getcoltype(tablename, getClass().getName());
		like.getDocument().addDocumentListener(this);
   	    like.setForeground(Color.BLUE);
   	    like.setToolTipText("限制最多返回300条数据,如需查询更多，可用时间段查询,空格与下划线代表匹配任意单个字符");
   	    
   	    add(new JLabel(Var.getIcon("参数过滤")));
   	    add(excel);
   	    add(msg);
   	    add(cbox);
   	    add(like);
		add(sqltip);
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==excel){
			Popup_tab.myxls(t,true);
		}
		else{
			sqltip.setText("共查询到 "+t.getRowCount()+" 条记录！"); 
		}
	}
	public void insertUpdate(DocumentEvent arg0) {
		if(like.getText().isEmpty()){
			sqltip.setText("没有输入查询条件");
		}
		else{
			String s1=cbox.getSelectedItem().toString();
			String s2=type.get(cbox.getSelectedIndex());
			String val=like.getText().replace(" ", "_");	//空格代表匹配任意单个字符
			val = val.replace("'", "");			//这个字符不能有，因为需要时行转义
			
			//s="select * from "+tablename+" where "+s+" like '%"+like.getText()+"%';";
			//为防止数据表过大，限制最多返回300条数据,如果需要查询更多，可用时间段查询
			
			//类型为数字直接用等号
			if(s2.startsWith("int")||s2.startsWith("tinyint")||s2.startsWith("double")){
				s1=subsql+" "+s1+" = '"+val+"' limit 0,300";
			}
			else{					//类型为字符串则进行匹配
				s1=subsql+" "+s1+" like '%"+val+"%' limit 0,300";
			}
			
			Sql.getArrayToTable(s1, this, t);
			sqltip.setText("共查询到 "+t.getRowCount()+" 条记录！");
		}
	}
	public void removeUpdate(DocumentEvent arg0){
		insertUpdate(null);
	}
	public void changedUpdate(DocumentEvent e) {}
}

