package log;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import pub.DateUI;
import root.Front;
import root.Sql;
public class AdvSelect extends JDialog implements ActionListener{
	private static final long serialVersionUID = -793322277088045362L;
	private JTextField val[] ;
	private JPanel wh[] ;
	private ArrayList<String> col ;
	private JTable t;
	private JTextArea sqltext = new JTextArea();
	private JButton ok = new JButton("查询");
	private JButton show = new JButton("展示前20行");
	private JButton back = new JButton("返回");
	public AdvSelect(String tablename,JTable t){
		super(Front.front, true);
		this.t=t;
		show.setName(tablename);

		col = Sql.getcolname(tablename, getClass().getName());
		ArrayList<String> type = Sql.getcoltype(tablename, getClass().getName());
		
		JPanel A = new JPanel(new GridLayout(col.size(), 1));
		JPanel B = new JPanel(new GridLayout(type.size(), 1));
		JPanel C = new JPanel(new GridLayout(type.size(), 1));
		JPanel D = new JPanel(new GridLayout(type.size(), 1));
		
		JPanel west = new JPanel(new GridLayout(1, 2));
		west.add(A);
		west.add(B);
		
		for(String temp : col)  A.add(getLab(temp));
		for(String temp : type) B.add(getLab(temp));
		
		val = new JTextField[col.size()];
		for(int k=0;k<col.size();k++){
			val[k]=new JTextField();
			val[k].setBorder(Sql.getBorder(2, ""));
			val[k].setEditable(false);
			C.add(val[k]);
		}

		wh = new JPanel[col.size()];
		for(int k=0;k<col.size();k++){
			if(type.get(k).contains("date")){
				wh[k] = new time(k);
				val[k].setBackground(Color.LIGHT_GRAY);
			}
			else if(type.get(k).contains("int")||type.get(k).contains("double")){
				wh[k] = new mynum(k);
				val[k].setBackground(Color.PINK);
			}
			else{
				wh[k] = new select(k);
			}
			D.add(wh[k]);
		}
		
		JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		south.add(ok);
		south.add(show);
		south.add(back);
		ok.addActionListener(this);
		show.addActionListener(this);
		back.addActionListener(this);
		
		sqltext.setWrapStyleWord(true);
		sqltext.setLineWrap(true);
		sqltext.setName(tablename);
		sqltext.setEditable(false);
		sqltext.setBackground(Color.LIGHT_GRAY);
		sqltext.setText("# 如需输入空字符串,可使用空格代替");
		
		JPanel con=new JPanel(new BorderLayout());
		con.setBorder(BorderFactory.createTitledBorder(""));
		JPanel nor = new JPanel(new BorderLayout());
		nor.add(west, BorderLayout.WEST);
		nor.add(C,BorderLayout.CENTER);
		nor.add(D,BorderLayout.EAST);
		con.add(new JScrollPane(nor),BorderLayout.NORTH);
		con.add(new JScrollPane(sqltext),BorderLayout.CENTER);
		con.add(south,BorderLayout.SOUTH);
		
		int height = nor.getPreferredSize().height ;
		setContentPane(con);
		setTitle("高级查询 ["+tablename+"] (限制最多返回1000条数据)");
		setSize(800, height+160);			//窗口大小
		setLocationRelativeTo(null);		//初始位置在屏幕正中间
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Front.logo);
		setVisible(true);
	}
	private JLabel getLab(String s){
		JLabel lab = new JLabel(s);
		lab.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));//立体感
		return lab ;
	}
	//具有浮雕边框
	private JLabel myLab(String s){
		JLabel text = new JLabel(s);
		text.setBorder(Sql.getBorder(2, ""));
		return text;
	}
	
	private boolean autosql(){
		String com = "" ;
		for(JTextField t : val){
			if(t.getText().isEmpty()) continue ;
			com = com + t.getText() + " ";
		}
		com=com.trim();
		if(com.startsWith("and")) com = com.replaceFirst("and",	"");
		if(com.startsWith("or"))  com = com.replaceFirst("or",	"");
		if(com.isEmpty()){
			sqltext.setText(sqltext.getText()+"\n# 没有选择 或 输入任何参数值");
			return true ;
		}
		sqltext.setText("select * from "+sqltext.getName()+" where "+com+" limit 0,1000 " );
		return false;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==ok){
			if(autosql()){
				return ;
			}
			
			Sql.getArrayToTable(sqltext.getText(), this, t);
			Sql.TableAtt(t, false, false);
			
			sqltext.setText(sqltext.getText()+"\n#查询到 "+t.getRowCount()+" 条数据 (为节约内存,每次最多能查询到1000条数据)");
		}
		if(e.getSource()==show){
			Sql.getArrayToTable("select * from "+show.getName()+" limit 0,20", this, t);
			Sql.TableAtt(t, true, true);
		}
		if(e.getSource()==back){
			dispose();
		}
	}
	
	//查询条件
	class select extends JPanel implements MouseListener {
		private static final long serialVersionUID = -2207304784316734834L;
		private JLabel and = myLab(" 并且 ");
		private JLabel or  = myLab(" 或者 ");
		private JLabel mofu = myLab(" 相似 ");
		private JLabel jing = myLab(" 相等 ");
		private int k;
		private select(final int k){
			this.k = k;
			setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
			add(and);
			add(or);
	 	    add(new JLabel());	//仅用于分隔开
			add(mofu);
			add(jing);

			or.setForeground(Color.BLUE);
			mofu.setForeground(Color.RED);
			
			val[k].setName("");
			and.addMouseListener(this);
			or.addMouseListener(this);
			mofu.addMouseListener(this);
			jing.addMouseListener(this);
			val[k].addMouseListener(new MouseAdapter() {
				public void mouseReleased(MouseEvent arg0) {
					String s = JOptionPane.showInputDialog(Front.front, "请输入参数：",val[k].getName());
					if(s==null) return ;
					val[k].setName(s);
					select.this.mousePressed(null);
				}
			});
		}
		
		public void mousePressed(MouseEvent e) {
			if(e!=null && e.getSource()==and){
				or.setForeground(null);
				and.setForeground(Color.BLUE);
			}
			if(e!=null && e.getSource()==or){
				and.setForeground(null);
				or.setForeground(Color.BLUE);
			}
			if(e!=null && e.getSource()==mofu){
				jing.setForeground(null);
				mofu.setForeground(Color.RED);
			}
			if(e!=null && e.getSource()==jing){
				mofu.setForeground(null);
				jing.setForeground(Color.RED);
			}
			
			val[k].setText(val[k].getName());
			if(val[k].getText().isEmpty()) return ;
			
			if(mofu.getForeground()==Color.RED){
				val[k].setText(col.get(k) +" like '%"+val[k].getText()+"%'");
			}
			else{
				val[k].setText(col.get(k) + "='" + val[k].getText() + "'");
			}
			
			if(and.getForeground()==Color.BLUE){
				val[k].setText(" and " + val[k].getText()); 
			}
			else{
				val[k].setText(" or " + val[k].getText()); 
			}
			autosql();
		}
		public void mouseClicked(MouseEvent e) {}
		public void mouseEntered(MouseEvent e) {}
		public void mouseExited(MouseEvent e) {}
		public void mouseReleased(MouseEvent e) {}
	}
	
	//日期选择
	class time extends JPanel implements MouseListener{
		private static final long serialVersionUID = -2207304784316734834L;
		private JLabel and = myLab(" 并且 ");
		private JLabel or  = myLab(" 或者 ");
		private JLabel day = myLab(" 日期 ");
		private JLabel month = myLab(" 月份 ");
		private JLabel div = myLab(" 时段 ");
		private JLabel clear = myLab(" 清除 ");
		private int k;
		private time(int k){
			this.k = k;
			setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
			add(and);
			add(or);
			add(new JLabel());	//仅用于分隔开
			add(day);
			add(month);
			add(div);
			add(clear);
			or.setForeground(Color.BLUE);
			and.addMouseListener(this);
			or.addMouseListener(this);
			day.addMouseListener(this);
			month.addMouseListener(this);
			div.addMouseListener(this);
			clear.addMouseListener(this);
		}
		
		//时间段查询
		private void timediv(String how){
			//初始化
			Calendar c = Calendar.getInstance();
			int Year = c.get(Calendar.YEAR);
			int Month = c.get(Calendar.MONTH) + 1;
			int day = c.get(Calendar.DAY_OF_MONTH);
			
			//日期
			JSpinner yeara=new JSpinner(new SpinnerNumberModel(Year,1900, 2200, 1));
			JSpinner montha = new JSpinner(new SpinnerNumberModel(Month, 1,12, 1));
			JSpinner daya = new JSpinner(new SpinnerNumberModel(day, 0, 31,1));
			JPanel datePanela=DatePanel(yeara,montha,daya);
			
			JSpinner yearb=new JSpinner(new SpinnerNumberModel(Year,1900, 2200, 1));
			JSpinner monthb = new JSpinner(new SpinnerNumberModel(Month, 1,12, 1));
			JSpinner dayb = new JSpinner(new SpinnerNumberModel(day, 0, 31,1));
			JPanel datePanelb=DatePanel(yearb,monthb,dayb);
			
			//时间
			JSpinner houa=new JSpinner(new SpinnerNumberModel(0,0,24,1));
			JSpinner mina = new JSpinner(new SpinnerNumberModel(0, 0,60, 1));
			JSpinner seca = new JSpinner(new SpinnerNumberModel(0, 0, 60,1));
			JPanel timePanela=TimePanel(houa,mina,seca);
			
			JSpinner houb=new JSpinner(new SpinnerNumberModel(23,0,24,1));
			JSpinner minb = new JSpinner(new SpinnerNumberModel(59, 0,60, 1));
			JSpinner secb = new JSpinner(new SpinnerNumberModel(59, 0, 60,1));
			JPanel timePanelb=TimePanel(houb,minb,secb);
			
			JPanel root=new JPanel();
			root.setLayout(new BoxLayout(root, BoxLayout.X_AXIS));
			root.add(getSlipt());
			JPanel p=new JPanel(new GridLayout(3, 1));
			p.add(new JLabel("  开始时间..."));
			p.add(datePanela);
			p.add(timePanela);
			root.add(p);
			
			root.add(getSlipt());
			p=new JPanel(new GridLayout(3, 1));
			p.add(new JLabel("  结束时间..."));
			p.add(datePanelb);
			p.add(timePanelb);
			root.add(p);
			
			int action=JOptionPane.showConfirmDialog(Front.front,root,"时间段查询",2,1,new ImageIcon());
			if(action==0){
				String s1="'"+yeara.getValue().toString()+"-"+montha.getValue().toString()+"-"+daya.getValue().toString()+" ";
				s1=s1+houa.getValue().toString()+":"+mina.getValue().toString()+":"+seca.getValue().toString()+"'";
				
				String s2="'"+yearb.getValue().toString()+"-"+monthb.getValue().toString()+"-"+dayb.getValue().toString()+" ";
				s2=s2+houb.getValue().toString()+":"+minb.getValue().toString()+":"+secb.getValue().toString()+"'";
				
				String sql = how + " ("+col.get(k)+">="+s1+" and "+col.get(k)+"<="+s2+")";
				val[k].setText(sql);
			}
		}
		private JSeparator getSlipt(){
			JSeparator separator = new JSeparator();   //创建竖直分隔线  
			separator.setOrientation(JSeparator.VERTICAL);  
			return separator;
		} 
		private JPanel DatePanel(JSpinner yearSpin,JSpinner monthSpin,JSpinner daySpin){
			JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			//年
			yearSpin.setEditor(new JSpinner.NumberEditor(yearSpin, "####"));
			datePanel.add(yearSpin);
			datePanel.add(new JLabel("年"));
			//月
			datePanel.add(monthSpin);
			datePanel.add(new JLabel("月"));
			//日
			datePanel.add(daySpin);
			datePanel.add(new JLabel("日"));
			return datePanel;
		}
		private JPanel TimePanel(JSpinner yearSpin,JSpinner monthSpin,JSpinner daySpin){
			JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			datePanel.add(yearSpin);
			datePanel.add(new JLabel("时"));
			datePanel.add(monthSpin);
			datePanel.add(new JLabel("分"));
			datePanel.add(daySpin);
			datePanel.add(new JLabel("秒"));
			return datePanel;
		}

		public void mousePressed(MouseEvent e) {
			if(e.getSource()==and || e.getSource()==or){
				if(e.getSource()==and){
					or.setForeground(null);
					and.setForeground(Color.BLUE);
				}
				if(e.getSource()==or){
					and.setForeground(null);
					or.setForeground(Color.BLUE);
				}
				if(val[k].getText().isEmpty()) return ;
				
				String temp = val[k].getText();
				temp = temp.trim();
				if(e.getSource()==and && temp.startsWith("or")){
					val[k].setText(val[k].getText().replaceFirst("or", "and"));
				}
				else{
					val[k].setText(val[k].getText().replaceFirst("and", "or"));
				}
				autosql();
				
				return ;
			}
			
			String how = "or";
			if(and.getForeground()==Color.BLUE)	how = "and";
			
			if(e.getSource()==day){
				DateUI du = new DateUI();
				if(du.toString().isEmpty()) return ;
				val[k].setText(how+" date("+col.get(k)+") = date('"+du.toString()+"')");
			}
			if(e.getSource()==month){
				Calendar c=Calendar.getInstance();
				int AA = c.get(Calendar.YEAR) ;
				int BB = c.get(Calendar.MONTH)+1 ;
				String result=JOptionPane.showInputDialog(Front.front,"请输入年份与月份，格式：xxxx-xx",AA+"-"+BB);
				if(result==null) return ;
				
				String temp[]=result.split("-");
				if(temp.length!=2){
					JOptionPane.showMessageDialog(Front.front,"格式不正确","Format Error",0);
					return ;
				}
				val[k].setText(how+" ( month("+col.get(k)+")="+temp[1]+" and year("+col.get(k)+")="+temp[0]+")" );
			}
			if(e.getSource()==clear){
				val[k].setText("");	
			}
			if(e.getSource()==div){
				timediv(how);
			}
			
			autosql();
		}
		public void mouseReleased(MouseEvent e) {}
		public void mouseClicked(MouseEvent e) {}
		public void mouseEntered(MouseEvent e) {}
		public void mouseExited(MouseEvent e) {}
	}
	
	//数字比较
	class mynum extends JPanel implements MouseListener{
		private static final long serialVersionUID = -2207304784316734834L;
		private JLabel and = myLab(" 并且 ");
		private JLabel or  = myLab(" 或者 ");
		private JLabel big = myLab(" 大于 ");
		private JLabel min = myLab(" 小于 ");
		private JLabel equ = myLab(" 等于 ");
		private JLabel clear = myLab(" 清除 ");
		private int k;
		private mynum(int k){
			this.k = k;
			setLayout(new FlowLayout(FlowLayout.LEFT,5,0));
			add(and);
			add(or);
			add(new JLabel());	//仅用于分隔开
			add(big);
			add(min);
			add(equ);
			add(clear);
			or.setForeground(Color.BLUE);
			and.addMouseListener(this);
			or.addMouseListener(this);
			big.addMouseListener(this);
			min.addMouseListener(this);
			equ.addMouseListener(this);
			clear.addMouseListener(this);
		}

		public void mousePressed(MouseEvent e) {
			if(e.getSource()==clear){
				val[k].setText("");	
				autosql();
				return ;
			}
			
			if(e.getSource()==and || e.getSource()==or){
				if(e.getSource()==and){
					or.setForeground(null);
					and.setForeground(Color.BLUE);
				}
				if(e.getSource()==or){
					and.setForeground(null);
					or.setForeground(Color.BLUE);
				}
				if(val[k].getText().isEmpty()) return ;
				
				String temp = val[k].getText();
				temp = temp.trim();
				if(e.getSource()==and && temp.startsWith("or")){
					val[k].setText(val[k].getText().replaceFirst("or", "and"));
				}
				else{
					val[k].setText(val[k].getText().replaceFirst("and", "or"));
				}
				autosql();
				
				return ;
			}
			
			String s = JOptionPane.showInputDialog(Front.front, "请输入参数：");
			if(s==null) return ;
			
			try{
				Double.valueOf(s);
			}catch (Exception err) {
				JOptionPane.showMessageDialog(Front.front, "参数不合法，必须为数字。");
				return ;
			}
			
			String how = "or";
			if(and.getForeground()==Color.BLUE)	how = "and";
			
			if(e.getSource()==big){
				if(val[k].getText().contains(">") || val[k].getText().isEmpty()){
					val[k].setText(how + " " + col.get(k)+">"+s);
				}
				if(val[k].getText().contains("<")){
					val[k].setText( val[k].getText()+" and "+col.get(k)+">"+s );
				}
			}
			if(e.getSource()==min){
				if(val[k].getText().contains("<") || val[k].getText().isEmpty()){
					val[k].setText(how + " " + col.get(k)+"<"+s);
				}
				if(val[k].getText().contains(">")){
					val[k].setText( val[k].getText()+" and "+col.get(k)+"<"+s );
				}
			}
			if(e.getSource()==equ){
				val[k].setText(how + " " + col.get(k)+"="+s);
			}
			
			autosql();
		}
		public void mouseReleased(MouseEvent e) {}
		public void mouseClicked(MouseEvent e) {}
		public void mouseEntered(MouseEvent e) {}
		public void mouseExited(MouseEvent e) {}
	}
}
