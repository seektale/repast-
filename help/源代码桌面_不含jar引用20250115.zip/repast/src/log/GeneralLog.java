package log;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import pub.DateUI;
import root.Front;
import root.Sql;
public class GeneralLog extends JPanel implements ActionListener {
	private static final long serialVersionUID = 3600076159573295391L;
	private JButton last=new JButton("最近200条数据");
	private JButton day=new JButton("指定日期");
	private JButton act = new JButton("动作action参考");
	private JTable t=Sql.getTable();	//同步显示的表格
	private JLabel msg = new JLabel();
	private SelectDown downpan;
	private ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
	private HashMap<String, String> filter=new HashMap<String, String>();
	public GeneralLog(){
		JPanel uppan = new JPanel(new FlowLayout(FlowLayout.LEFT));
		uppan.add(new JLabel("精确相关查询："));
		ArrayList<String[]> arr = new ArrayList<String[]>();
		arr.add(new String[]{"登陆",""});
		arr.add(new String[]{"账号",""});
		arr.add(new String[]{"下线","action like '%kill%'"});
		arr.add(new String[]{"台号","(action like '%台号%' or action like '%区域%')"});
		arr.add(new String[]{"配置","action like '%general%'"});
		arr.add(new String[]{"报表",""});
		arr.add(new String[]{"班结",""});
		arr.add(new String[]{"预定",""});
		arr.add(new String[]{"商品",""});
		arr.add(new String[]{"留言",""});
		for(String temp[] : arr){
			uppan.add(getbut(temp[0]));
			filter.put(temp[0], temp[1]);
		}
		
		act.addActionListener(this);
		uppan.add(act);
		last.addActionListener(this);
		uppan.add(last);
		day.addActionListener(this);
		uppan.add(day);
		
		downpan=new SelectDown(t,"select * from syslog where","syslog",msg);
		downpan.add(msg);
		
		JPanel nor = new JPanel();
		nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
		nor.add(uppan);
		nor.add(new JSeparator());	//分割线
		nor.add(downpan);
		
		setLayout(new BorderLayout());
		add(nor,BorderLayout.NORTH);
		add(new JScrollPane(t),BorderLayout.CENTER);
	}
	private JRadioButton getbut(String s){
		JRadioButton b = new JRadioButton(s);
		b.addActionListener(this);
		b.setActionCommand(s);
		radioGroup.add(b);
		return b;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==act){
			String arr[] = Sql.getString("select DISTINCT action from syslog", this);
			JPanel me =new JPanel(new GridLayout(10, 0));
			for(String temp : arr){
				JLabel lab = new JLabel(temp);
				lab.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));//立体感
				me.add(lab);
			}
			JOptionPane.showMessageDialog(Front.front, me, "系统日志 动作值 参考 (可用高级查询对动作过滤)", 1 ,new ImageIcon());
			return ;
		}
		
		if(e.getSource()==day || e.getSource()==last){
			if(radioGroup.getSelection()==null){
				JOptionPane.showMessageDialog(Front.front, "请先选择一个选项");
				return ;
			}
		}
		
		//当前对象
		String cmd = radioGroup.getSelection().getActionCommand();
		if(filter.get(cmd).isEmpty()){
			cmd = " action like '%"+cmd+"%' ";
		}
		else{
			cmd = filter.get(cmd);
		}
		
		String date = "";
		if(e.getSource()==day){
			DateUI du = new DateUI();
			date = " date(time)=date('"+du.toString()+"') and ";
		}
		
		//一定要倒序
		String sql = "select * from syslog where "+date+cmd+" order by ind desc limit 0,200" ;
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
		msg.setText("  共查询到: "+t.getRowCount()+ " 条数据");
	}
}
