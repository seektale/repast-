package log;
//自创公共组件,有局限性，对传入的sql语句不能太复杂
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;

import pub.Var;
import root.Sql;
public class Select extends JPanel{
	private static final long serialVersionUID = 1434443436111873614L;
	public SelectUP uppan;
	public SelectDown downpan;
	public JPanel down;
	public JTable t=Sql.getTable();	//同步显示的表格
	private String subsql;
	private boolean boo=true;
	public Select(String insql,boolean boo){
		this.boo=boo;	//为false则关闭downpan面板
		port(insql);
	}
	public Select(String insql){
		port(insql);
	}
	private void port(String insql){
		//insql为传入的sql语句标准如：select * from daydishlog where 餐次=40;
		//得到表名，并加功能insql语句
		if(insql.endsWith(";")) insql=insql.substring(0, insql.length()-1);	//先去掉逗号，统一格式
		int m=insql.indexOf("from");
		int n=insql.indexOf("where");
		String tablename="";
		if(n==-1){
			tablename=insql.substring(m+5);
			subsql=insql+" where";
		}
		else{
			tablename=insql.substring(m+5, n-1);
			subsql=insql+" and";
		}
		
		//初始化上下面板
		uppan=new SelectUP(t,subsql,tablename);
		if(boo)	downpan=new SelectDown(t,subsql,tablename,uppan.sqltip);
		else	{down=new JPanel();down.setLayout(new FlowLayout(FlowLayout.LEFT));}
		
		//组装组件
		JPanel pancen=new JPanel(new GridLayout(2, 1, 0, 0));
		pancen.add(uppan);
		if(boo)	pancen.add(downpan);
		else	pancen.add(down);
		setLayout(new BorderLayout());
		add("Center",pancen);
		add("East",new JLabel(Var.getIcon("leaves")));
		setOpaque(false);
	}
}
