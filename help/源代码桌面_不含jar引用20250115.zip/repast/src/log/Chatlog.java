package log;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import root.Sql;
public class Chatlog extends JPanel{
	private static final long serialVersionUID = 6223895947258211467L;
	public Chatlog(){
		JTable ct = Sql.getTable();
	    JLabel cmsg = new JLabel();
	    SelectDown cdown = new SelectDown(ct, "select * from chat where ", "chat", cmsg);
	    cdown.add(cmsg);
	    
	    setLayout(new BorderLayout());
	    add(cdown,BorderLayout.NORTH);
	    add(new JScrollPane(ct),BorderLayout.CENTER);
	}
}
