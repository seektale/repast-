package bill;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.TableModel;
import pub.ConfigFile;
import root.Front;
import root.Sql;
public class ToFront extends JInternalFrame implements MouseListener,ActionListener{
	private static final long serialVersionUID = 734348757668L;
	
	private JPanel nor = new JPanel(new FlowLayout(FlowLayout.LEFT));
	public  JPanel Pan = new JPanel(new BorderLayout());
	private JTable bill_list = Sql.getTable() ;
	private JSplitPane frontspp = new JSplitPane();
	
	private JTextField pcCode = new JTextField(5); 
	private JTextField pcText = new JTextField(10); 
	private String pcModu = "" ;
	private String pcArgcode = "" ;
	
	private JTextField amount = new JTextField(3); 
	private JTextField money  = new JTextField(10); 
	private JTextField remark = new JTextField(20); 
	private JButton ok = new JButton("入账");
	
	private Sybase syb ;
	private String accnt ;
	public ToFront(String pay){
		
		super("结账 转 前台",true,true,true,true);
		setContentPane(Pan);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());

	    /*
	    //去掉边框
    	setBorder(BorderFactory.createEmptyBorder());
    	//去掉标题栏
    	BasicInternalFrameUI ui = (BasicInternalFrameUI)getUI(); 
    	ui.setNorthPane(null);
	    */
	    
	    final String sql = "select item,value,remark from general where name='interface' and item like 'sql%' ";
		final ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
		final JTable dest[] = new JTable[arr.size()];
		
		final JTabbedPane tab = new JTabbedPane();
		for(int x=0; x<arr.size(); x++){
			dest[x] = Sql.getTable();
			dest[x].setName(arr.get(x)[1]);
			tab.addTab(arr.get(x)[2], new JScrollPane(dest[x]));
		}
		
		frontspp.setLeftComponent(tab);
		frontspp.setRightComponent(new JScrollPane(bill_list));
		frontspp.setOneTouchExpandable(true);
		frontspp.setOrientation(JSplitPane.VERTICAL_SPLIT);
		frontspp.setDividerSize(5);
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
				frontspp.setDividerLocation(0.7);
		    }
		});
		
		pcCode.addMouseListener(this);
		pcCode.setEditable(false);
		pcCode.setBackground(Color.LIGHT_GRAY);
		pcText.setEditable(false);
		pcText.setBackground(Color.LIGHT_GRAY);
		remark.setBackground(Color.PINK);
		ok.addActionListener(this);
		amount.setText("1");
		money.setText(pay);
		
		pcCode.setText(ConfigFile.getProperty("SybasePcCode"));
		pcText.setText(ConfigFile.getProperty("SybasePcText"));
		pcModu = ConfigFile.getProperty("SybasePcModu") ;
		pcArgcode = ConfigFile.getProperty("SybasePcArgcode") ;
		
		nor.add(new JLabel("选择营业项目代码："));
		nor.add(pcCode);
		nor.add(pcText);
		nor.add(new JLabel("  数量："));
		nor.add(amount);
		nor.add(new JLabel("  总消费："));
		nor.add(money);
		nor.add(new JLabel("  备注："));
		nor.add(remark);
		nor.add(ok);
		
		Pan.add(nor, BorderLayout.NORTH);
		Pan.add(frontspp, BorderLayout.CENTER);
		
		new Thread(new Runnable() {	//以免卡死
			public void run() {
				syb = new Sybase(dest);
				syb.setGetCallback(new Sybase.GetDate() {
					public void onGetTable(TableModel tm, String val) {
						accnt = val ;
						if(tm==null) return ;
						bill_list.setModel(tm);
						Sql.TableAtt(bill_list, true, true);
					}
				});
			}
		}).start();
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		if(syb==null) return ;
		final JTable t = syb.getPcCode();
		if(t==null) return ;
		t.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				int row = t.getSelectedRow();
				pcCode.setText(t.getValueAt(row, 0).toString());
				pcText.setText(t.getValueAt(row, 1).toString());
				//保存参数
				ConfigFile.setProperty("SybasePcCode", pcCode.getText());
				ConfigFile.setProperty("SybasePcText", pcText.getText());
				ConfigFile.setProperty("SybasePcMode",    t.getValueAt(row, 2).toString());
				ConfigFile.setProperty("SybasePcArgcode", t.getValueAt(row, 3).toString());
			}
		});
		JOptionPane.showMessageDialog(this, new JScrollPane(t),"选择项目",0,new ImageIcon());
	}
	public void mouseReleased(MouseEvent e) {}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(pcCode.getText().isEmpty()){
			JOptionPane.showMessageDialog(this, "营业项目不能为空 ？","注意",0);
			return ;
		}
		if(money.getText().isEmpty()){
			JOptionPane.showMessageDialog(this, "金额不能为空 ？","注意",0);
			return ;
		}
		if(accnt==null || accnt.isEmpty()){
			JOptionPane.showMessageDialog(this, "未在表格中选择指定账单 ？","注意",0);
			return ;
		}
		if(remark.getText().length()>50){
			JOptionPane.showMessageDialog(this, "备注太长，50字以内。","注意",0);
			return ;
		}
		
		double rmb = 0.0 ;
		try{
			rmb = Double.valueOf(money.getText());;
		}catch (Exception err) {
			JOptionPane.showMessageDialog(this, "金额输入不正确，必须为数字 ？","注意",0);
			return ;
		}
		
		double amo = 0.0 ;
		try{
			amo = Double.valueOf(amount.getText());
		}catch (Exception err) {
			JOptionPane.showMessageDialog(this, "数量输入不正确，必须为数字 ？","注意",0);
			return ;
		}
		
		String result = syb.inmoney(pcCode.getText().trim(), pcModu, pcArgcode, amo, rmb, accnt, remark.getText());
		if(result.contains(accnt)){
			JOptionPane.showMessageDialog(this, result+" 恭喜！入账成功。请刷新查看结果。", "入账成功 SUCCESS", 1);
			
			// 通过回调，写入餐饮数据库
			if(Callback!=null){
				Callback.onRefresh(accnt, rmb, remark.getText());
			}
		}
	}
	
	
	
	/**
     * 设置回调接口
     */
    private GetDate Callback;
    public void setGetCallback(GetDate val) {
        Callback = val;
    }
    
    /**
     * 回调接口
     */
    public interface GetDate {
        public void onRefresh(String accnt, Double money, String rem);
    }
}
