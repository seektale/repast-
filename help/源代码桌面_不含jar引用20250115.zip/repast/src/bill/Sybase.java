package bill;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class Sybase implements MouseListener{
	private final HashMap<String, String> hm = new HashMap<String, String>();
	private Connection con ;
	public Sybase(JTable dest[]){
		
		final String sql = "select item,value from general where name='interface' ";
		final ArrayList<String[]> parameter = Sql.getArrayToArrary(sql, this);
		for(String[] temp : parameter){
			hm.put(temp[0], temp[1]);
		}
		
		//英文效果，会乱码
		//String url = "jdbc:sybase:Tds:10.10.20.9:5000/foxhis?charset=cp850&jconnect_version=3";
		//中文效果，不会乱码		用FOX帐号不可行，只能用超级帐号
		final String url = "jdbc:sybase:Tds:"+hm.get("ip")+":"+hm.get("port")+"/"+hm.get("db_name")+"?" +
					 "charset=cp936&jconnect_version=3";
		//例：String url="jdbc:sybase:Tds:192.168.1.200:5000/foxhis?charset=cp936&jconnect_version=3";
		//这是专用于mysql数据库的     MysqlDataSource ds = new MysqlDataSource();
		
    	try {
    		//加载数据库驱动
			Class.forName("com.sybase.jdbc3.jdbc.SybDriver").newInstance();
			DriverManager.setLoginTimeout(5);
			con = DriverManager.getConnection(url, hm.get("account"), hm.get("password"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(Front.front, "连接到Sybase数据库异常");
			return ;
		}
		
		for(final JTable temp : dest){
			me(temp);
			temp.addMouseListener(this);
		}
		
		//关闭连接
		try {
			if(con!=null)	con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void me(JTable t){
		if(t==null) return ;
		if(t.getName().isEmpty()) return ;
		ResultSet rs = null;
		try {
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery(t.getName());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(Front.front, "连接到Sybase数据库后 执行sql查询语句异常");
			return ;
		}
		
		
		/******************************************************************/
		String[] col;		//表的例名
	   	try {
	   		ResultSetMetaData md=rs.getMetaData();
			col=new String[md.getColumnCount()];
			for(int m=0; m<md.getColumnCount(); m++){
				col[m]=md.getColumnName(m+1);
			}
		} catch (SQLException e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(Front.front, "连接到Sybase数据库后，处理表列名出错");
			return;
		}
		
		//向表中写入数据
		try{
			rs.last();
			String ss[][]=new String[rs.getRow()][col.length];
			
			rs.beforeFirst();
			while(rs.next()){
				for (int i=0; i<col.length; i++){
					String cat=rs.getString(i+1);
					
					if(cat!=null && cat.endsWith(".0000")) cat = cat.replace(".0000", "");
					if(cat!=null && cat.contains("  ")) cat = cat.replace("  ", "");
					
					ss[rs.getRow()-1][i]=cat;
				}
			}
			
			//关键一部，更新例名数据
			DefaultTableModel mod=(DefaultTableModel)t.getModel();
			mod.setDataVector(ss, col);
		}catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(Front.front, "连接到Sybase数据库后，数据处理失败");
            return ;
        }
		Sql.TableAtt(t, true, false);
		/********************************************************************/
		
		//关闭连接
		try {
			if(rs!=null) 	rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public void mouseClicked(MouseEvent arg0) {}
	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
	public void mousePressed(MouseEvent arg0) {
		if(Callback==null) return ;
		if(arg0.getButton()!=1) return ;
		Callback.onGetTable(new JTable().getModel(), "");	//先复位
		
		JTable t = (JTable)arg0.getSource();
		if(t.getRowCount()<=0 || t.getColumnCount()<=1) return ;
		
		int sel = t.getSelectedRow();
		String val  = t.getValueAt(sel, 0).toString();
		String val2 = t.getValueAt(sel, 1).toString();
		
		if(val.length()<2)		return ;
		if(val.startsWith("F") && !val2.trim().isEmpty())	val = val2;
		if(!val.startsWith("G") && !val.startsWith("C") && !val.startsWith("M") && !val.startsWith("F")) return ;

		
		//连接到数据库
		String url = "jdbc:sybase:Tds:"+hm.get("ip")+":"+hm.get("port")+"/"+hm.get("db_name")+"?" +
		 "charset=cp936&jconnect_version=3";
		try {
			con = DriverManager.getConnection(url, hm.get("account"), hm.get("password"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(Front.front, "连接到Sybase数据库异常");
			return ;
		}
		
		//得到结算明细数据, 按时间排序
		final JTable mytable = new JTable();
		String sql="select accnt,number,pccode,log_date,accntof,quantity,charge,balance,shift,empno,ref,ref1,ref2,roomno,billno from account where accnt='"+val+"' " +
				"and number not in (select number from gltemp where accnt = '"+val+"') and number not in (select number from outtemp where accnt = '"+val+"') " +
				
				"union " +
				
				"select accnt,number,pccode,log_date,accntof,quantity,charge,balance,shift,empno,ref,ref1,ref2,roomno,billno from gltemp where accnt='"+val+"' " +
				"and number not in (select number from outtemp where accnt = '"+val+"') " +
				
				"union " +
				
				"select accnt,number,pccode,log_date,accntof,quantity,charge,balance,shift,empno,ref,ref1,ref2,roomno,billno from outtemp where accnt='"+val+"' " +
				
				"order by log_date ";
		
		mytable.setName(sql);
		me(mytable);
		
		Callback.onGetTable(mytable.getModel(), val);
		
		//关闭连接
		try {
			if(con!=null)	con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void mouseReleased(MouseEvent arg0) {}
	
	//读取一张表的数据而已
	public JTable getPcCode(){
		//连接到数据库
		String url = "jdbc:sybase:Tds:"+hm.get("ip")+":"+hm.get("port")+"/"+hm.get("db_name")+"?" +
		 "charset=cp936&jconnect_version=3";
		try {
			con = DriverManager.getConnection(url, hm.get("account"), hm.get("password"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(Front.front, "连接到Sybase数据库异常");
			return null;
		}
		
		//得到结算明细数据, 按时间排序,modu为空字符串的项是资金流入代码，要排除。
		JTable mytable = Sql.getTable();
		String sql=" select pccode,descript,modu,argcode from pccode where modu<>'' ";
		mytable.setName(sql);
		me(mytable);
		
		
		//关闭连接
		try {
			if(con!=null)	con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return mytable ;
	}
	
	// 调用西软的存储过程
	public String inmoney(String pcCode, String pcModu, String Argcode, Double amount, Double rmb, String accnt, String remark){
		// 连接到数据库
		String url = "jdbc:sybase:Tds:"+hm.get("ip")+":"+hm.get("port")+"/"+hm.get("db_name")+"?" +
		 "charset=cp936&jconnect_version=3";
		try {
			con = DriverManager.getConnection(url, hm.get("account"), hm.get("password"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(Front.front, "连接到Sybase数据库异常");
			return null;
		}
		
		// 调用存储过程
		String sql = "{call p_gl_accnt_posting(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Calendar c = Calendar.getInstance();
		String result = "" ;
		try{
			CallableStatement cs = (CallableStatement)con.prepareCall(sql);
	        
	        cs.setString(1, "A");				//输入型参数
	        cs.setString(2, pcModu);			//输入型参数 modu_id 对比之后定为04 
	        cs.setString(3, "000");				//输入型参数 pc_id
	        cs.setInt(4, 123456);				// mdi_id 唯一的账务窗口ID
	        cs.setString(5, "3");				//班次
	        cs.setString(6, "cook");			//工号
	        cs.setString(7, accnt);				//宾客账号
	        cs.setInt(8, 1);					//subaccnt 
	        cs.setString(9, pcCode);			//费用码
	        cs.setString(10, Argcode);			//改编码argcode，打印在账单的代码,(arr.账单编码)
	        
	        cs.setDouble(11,amount);			//数量
	        cs.setDouble(12,rmb);				//金额
	        cs.setDouble(13,0.0);				//输入型参数
	        cs.setDouble(14,0.0);				//输入型参数
	        cs.setDouble(15,0.0);				//输入型参数
	        cs.setDouble(16,0.0);				//输入型参数
	        cs.setDouble(17,0.0);				//输入型参数
	        cs.setString(18, "");				//ref1 单号, 如：1503230032
	        cs.setString(19, remark);			//ref2 摘要 50个字符
	        cs.setDate(20, new Date(c.getTimeInMillis()));
	        
	        cs.setString(21, "");				//优惠理由 reason
	        cs.setString(22, "");				//输入型参数 mode
	        cs.setString(23, "IRNNX");			
	        cs.setInt(24, 123456);				//调整的账次
	        
	        cs.registerOutParameter(25, Types.VARCHAR);	//输出型参数 to_accnt
	        cs.registerOutParameter(26, Types.VARCHAR);	//输出型参数 msg
	        
	        cs.execute();	//总是返回boolean型的值false
	        
	        if(cs.getWarnings()!=null){
            	SouthPan.warn("存储过程返回的警告信息：\n"+cs.getWarnings(),true);
            }
	        
	        if(cs.getWarnings()==null){
	        	String to_accnt = cs.getString(25);
	 	        String msg = cs.getString(26);
	 	        if(to_accnt==null) to_accnt = "" ;
	 	        if(msg == null) msg = "" ;
	 	        result = msg ;
	 	        SouthPan.warn("存储过程返回结果：\nto_accnt:"+to_accnt+"\nmsg:"+msg,true);
	        }
		}
		catch (Exception e) {
			String s = e.getMessage();
			if (s == null) {
				s = "异常消息为空，可能帐号不存在，或其它不明原因。";
			}
			SouthPan.warn("调用存储过程异常: \n" + s, true);
			e.printStackTrace();
		}
		
		// 关闭连接
		try {
			if(con!=null)	con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}

	/**
	 * 设置回调接口
	 */
	private GetDate Callback;

	public void setGetCallback(GetDate val) {
		Callback = val;
	}

	/**
	 * 回调接口
	 */
	public interface GetDate {
		public void onGetTable(TableModel tm, String val);
	}
}
