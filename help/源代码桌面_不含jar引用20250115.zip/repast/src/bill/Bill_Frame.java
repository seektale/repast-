package bill;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import bill_print.Print_pan;
import pub.ConfigFile;
import root.Front;
import root.Sql;
//现金付款
public class Bill_Frame extends JDialog implements ActionListener{
	private static final long serialVersionUID = 323470394957143273L;
	public JButton submitbill = new JButton("确定结账 S");
	public JButton cancelbill = new JButton("取消结账 N");
	public JButton cana = new JButton("消单");
	public JButton canb = new JButton("免单");
	public JButton canc = new JButton("跑单");
	public JButton more = new JButton("其它方式");
    public Bill_calc bc ;
    public int mealnum ;
    private JTable t = Sql.getTable() ;
	public Bill_Frame(int mealnum){
		super(Front.front, "结账与打印",true);
		this.mealnum=mealnum;

		bc=new Bill_calc(mealnum);
		JPanel con = new JPanel(new BorderLayout(2,8));
		
	    t.addMouseListener(new MouseAdapter() {
	    	public void mousePressed(MouseEvent e) {
	    		if(e.getClickCount()==2){
	    			pop p = new pop();
		    		p.show(t, e.getX(), e.getY());
	    		}
			}
		});
	    
	    con.add(bc,BorderLayout.NORTH);
	    
        refresh();
	    con.add(new JScrollPane(t),BorderLayout.CENTER);
	    
	    JPanel sou=new JPanel();
		sou.setLayout(new BoxLayout(sou, BoxLayout.PAGE_AXIS));	//一行一行的布局
		
	    JPanel sousub = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    final String val[]=new String[]{"现付","刷卡","折扣","抺零","挂AR账","转前台","IC会员卡"};
	    for(String temp : val){
	    	JButton b = new JButton(temp);
	    	b.addActionListener(this);
	    	sousub.add(b);
	    }
	    
	    sousub.add(more);
	    sou.add(sousub);
	    sou.add(new JSeparator());	//分割线
	    sou.add(new JSeparator());	//分割线
	    sou.add(new JSeparator());	//分割线
	    sou.add(new JSeparator());	//分割线
	    sou.add(new JSeparator());	//分割线
	    sousub = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    sousub.add(submitbill);
	    sousub.add(cancelbill);
	    submitbill.setMnemonic(KeyEvent.VK_S);
	    cancelbill.setMnemonic(KeyEvent.VK_N);
	    submitbill.setForeground(Color.BLUE);
	    cancelbill.setForeground(Color.BLUE);
	    sousub.add(new JLabel(" ※ "));
	    sousub.add(cana);
	    sousub.add(canb);
	    sousub.add(canc);
	    sou.add(sousub);
	    sou.add(new JSeparator());	//分割线
	    sousub = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    sousub.add(new JLabel("提示：如果要收取服务费，请添加商品<服务费>，即定义一个名称为<服务费>的商品。"));
	    sou.add(sousub);
	    sousub = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    sousub.add(new JLabel("提示：双击结算条目可删除选定结算条目 或 修改备注"));
	    sou.add(sousub);
	    sou.add(Box.createVerticalStrut((10)));
	    sou.add(new JSeparator());	//分割线
	    sou.add(Box.createVerticalStrut((10)));
	    sou.add(new Print_pan(mealnum)); //打印面板
	    con.add(sou,BorderLayout.SOUTH);
	    
	    submitbill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean b = Sql.mysqlprocedure("billover", mealnum+"");
				if(b) dispose();
				else refresh();
			}
		});
	    cancelbill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean b = Sql.mysqlprocedure("bill_cancel", mealnum+"");
				if(b) dispose();
				else refresh();
			}
		});
	    cana.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				badbill(cana.getText());
			}
		});
	    canb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				badbill(canb.getText());
			}
		});
	    canc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				badbill(canc.getText());
			}
		});
	    more.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				billpop pp=new billpop();
				pp.show(more, 1, 30);
			}
		});
	    
	    //是否自动四舍五入
	    String isauto=ConfigFile.getProperty("auto45");
	    if(isauto.equals("Y")){
	    	bc.auto45.setSelected(true);
	    	subbill("四舍五入","Y","0","");
	    }
	    bc.auto45.addActionListener(this);
	    
	    JPanel conroot = new JPanel(new BorderLayout(20,20));
		conroot.add(con,BorderLayout.CENTER);
		conroot.add(new JLabel(),BorderLayout.EAST);
		conroot.add(new JLabel(),BorderLayout.WEST);
		conroot.add(new JLabel(),BorderLayout.NORTH);
		conroot.add(new JLabel(),BorderLayout.SOUTH);
		
		setContentPane(conroot);
	    setSize(new Dimension(600,620));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);//初始位置在屏幕正中间
		setIconImage(Front.logo);
		setVisible(true);
	}
	private void badbill(String s){
		String temp[]=Sql.getString("select value from general where name='结账' and item='"+s+"';", this);
		Object val=JOptionPane.showInputDialog(Front.front,"请选择撤消的原由：",s,3,null,temp,"");
		if(val==null) return ;

		ArrayList<String> arr = new ArrayList<String>();
		arr.add(mealnum+"");
		arr.add(s);
		arr.add((String)val);
		boolean b = Sql.mysqlprocedure("billnull",arr);
		
		if(b) dispose();
		else refresh();
	}
	public void actionPerformed(ActionEvent e) {
		String s = e.getActionCommand();
		if(s.startsWith("挂AR")){
			final Bill_ar ar = new Bill_ar();
			int k = JOptionPane.showConfirmDialog(Front.front, ar, "挂AR帐", 2, 1, new ImageIcon());
			if(k!=0) return ;
			if(ar.t.getSelectedRowCount()!=1){
				JOptionPane.showMessageDialog(Front.front, "未选择AR账号");
				return ;
			}
			String arnum = ar.t.getValueAt(ar.t.getSelectedRow(), 0).toString();
			money(s,arnum);
			return ;
		}
		
		if(s.equals("折扣")){
			String per = JOptionPane.showInputDialog("请输入一个大于0，小于1的数值","0.9");
			if(per==null || per.isEmpty()) return ;
			subbill(s,per,"0","");
			return ;
		}
		
		if(s.equals("抺零")){
			String val = bc.rmbtar.getText();
			String per = JOptionPane.showInputDialog(Front.front, "默认为小数点后面的值", "0"+val.substring(val.indexOf(".")));
			if(per==null || per.isEmpty()) return ;
			subbill(s,"",per,"");
			return ;
		}
		if(s.equals("转前台")){
			JDialog dia = new JDialog(Front.front,"转前台",true);
			
			Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
			int width  = (int)screensize.getWidth()-30;
			int height = (int)screensize.getHeight()-30;
			
			ToFront tfpan = new ToFront(bc.totalText.getText());
			tfpan.setGetCallback(new ToFront.GetDate() {
				public void onRefresh(String accnt, Double money, String rem) {
					subbill("转前台", accnt, money+"", rem);
				}
			});
			
			dia.setContentPane(tfpan.Pan);
			dia.setSize(width-8,height-36);
			dia.setLocationRelativeTo(null); //初始位置在屏幕正中间
			dia.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			dia.setResizable(false);
			dia.setVisible(true);
			return ;
		}
		if(s.equals("IC会员卡")){
			new Bill_IC(this);
			return ;
		}
		if(e.getSource()==bc.auto45){
			ConfigFile.setProperty("auto45", bc.auto45.isSelected()); //记录配置
			String flag = bc.auto45.isSelected() ? "Y" : "N" ;
			subbill("四舍五入",flag,"0","");
			return ;
		}
		money(s,"");
	}
	
	private void money(String style,String att){
		JSpinner num=new JSpinner(new SpinnerNumberModel(0d,-100d,Integer.MAX_VALUE,1));
		num.setValue(Sql.toDouble(bc.rmbtar.getText(),0)*-1);
		JTextField res = new JTextField(15);
		
		JPanel Pan=new JPanel();
		Pan.setPreferredSize(new Dimension(280,80));
		Pan.setLayout(new BoxLayout(Pan, BoxLayout.PAGE_AXIS));	//一行一行的布局
		JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("结算金额："));
		temp.add(num);
		Pan.add(temp);
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("扼要备注："));
		temp.add(res);
		Pan.add(temp);
		Pan.add(new JSeparator());	//分割线
		
		int action=JOptionPane.showConfirmDialog(Front.front,Pan,style,2,1,new ImageIcon());
		if(action==0){
			subbill(style,att,num.getValue().toString(),res.getText());
		}
	}
	/***********************************************************************/
	private void subbill(String style,String att,String money,String remark){
		String sql="select billsubmit("+mealnum+",'"+style+"','"+att+"',"+money+",'"+remark+"')";
		String re[] = Sql.getString(sql, this);
		if(re.length==0 || re[0].startsWith("N")) {
			//提示错误信息
			String err = "提交结算时没有返回最终结果";
			if(re.length>0) err=re[0];
			JOptionPane.showMessageDialog(Front.front, err);
		}
		refresh();
	}
	public void refresh(){
		Sql.getArrayToTable("select * from billstyle where 台次="+mealnum, this, t);
		Sql.TableAtt(t, true, false);
		String temp[]=Sql.getString("select 结账时间 from deskgo where 台次="+mealnum, this);
		if(temp.length>0 && temp[0].isEmpty()){
	        t.setEnabled(true);
		}
		else{
			t.setEnabled(false);
		}
		
		//结算金额
		double d = 0.0;
		for(int k=0 ; k<t.getRowCount(); k++){
			d=d+Double.valueOf(Sql.getval(t, "金额", k));
		}
		bc.rmb.setText(Sql.twodot(d));
		//消费金额
		double ds=Sql.toDouble(bc.totalText.getText(),0);
		//找零
		bc.rmbtar.setText(Sql.twodot(d-ds));
	}
	/***********************************************************************/
	/* 内部类
	 * 右键菜单
	 * */
	class pop extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -182455400196L;
		private JMenuItem a = new JMenuItem("修改备注 Edit_Remark");
		private JMenuItem b = new JMenuItem("删除 Delete");
		public pop(){
			a.addActionListener(this);
			b.addActionListener(this);
			add(a);
			addSeparator();
			add(b);
		}
		public void actionPerformed(ActionEvent es) {
			int row = t.getSelectedRow();
			if(row<0) return ;
			if(es.getSource()==a){
				String s = JOptionPane.showInputDialog(Front.front, "编辑备注", Sql.getval(t, "备注", row));
				if(s==null) return ;
				subbill(Sql.getval(t, "结算方式", row),"edit","0",s);
			}
			else if(es.getSource()==b){
    			subbill(Sql.getval(t, "结算方式", row),"delete","0","");
			}
		}
	}
	
	class billpop extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -18232423400196L;
		public billpop(){
			String sql = "select value from general where name='bill_style' order by item;" ;
			String paystyle[]=Sql.getString(sql, Bill_Frame.this);
			for(String temp : paystyle){
				JMenuItem m = new JMenuItem(temp);
				m.addActionListener(this);
				add(m);
				//addSeparator();
			}
		}
		public void actionPerformed(ActionEvent e) {
			money(e.getActionCommand(),"");
		}
	}
}
