package bill;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import root.Front;
import root.Sql;
import vip.JNativeSub;
public class Bill_IC extends JDialog implements ActionListener,KeyListener{
	private static final long serialVersionUID = 4720246671093648959L;
	private JTextField cardval[] = new JTextField[3];
	private JPasswordField a=new JPasswordField(""); 
	private JTextField b=new JTextField(""); 
	private JTextField c=new JTextField("");
	private JButton ok=new JButton("确定 Submit");
	private JButton cancel=new JButton("取消 Cancel");
	private JLabel cardid = new JLabel("IC卡内编码：", JLabel.CENTER);
	private JNativeSub jn = new JNativeSub();
	private Bill_Frame bf ;
	public Bill_IC(Bill_Frame bf){
		super(Front.front, true);
		setSize(250, 320);
		this.bf = bf ;
		
		JPanel con=new JPanel(new BorderLayout());
		JPanel we=new JPanel(new GridLayout(3, 1));
		we.setOpaque(false);
		we.add(new JLabel("IC卡密码：",JLabel.RIGHT));
		we.add(new JLabel("消费金额：",JLabel.RIGHT));
		we.add(new JLabel("备注：",JLabel.RIGHT));
		con.add(we,BorderLayout.WEST);
		b.setText(bf.bc.totalText.getText());
		b.setFont(new Font("楷体", Font.BOLD, 16));
		
		we=new JPanel(new GridLayout(3, 1));
		we.setOpaque(false);
		we.add(a);
		we.add(b);
		we.add(c);
		con.add(we,BorderLayout.CENTER);
		
		we=new JPanel(new FlowLayout(FlowLayout.CENTER));
		we.setOpaque(false);
		we.add(ok);
		we.add(cancel);
		con.add(we,BorderLayout.SOUTH);
		
		ok.addActionListener(this);
		cancel.addActionListener(this);
		a.addKeyListener(this);
		b.addKeyListener(this);
		c.addKeyListener(this);
		ok.addKeyListener(this);
		cancel.addKeyListener(this);
		
		// 需要先初始化sel();
		JPanel temp=new JPanel(new BorderLayout(6,6));
		temp.setBorder(BorderFactory.createTitledBorder(""));
		temp.add(sel(),BorderLayout.NORTH);
		
		// 写入数据
		ArrayList<String> arr = jn.getMyInfo();
		if(arr==null){
			dispose();
			return ;
		}
		for(int flag=0; flag<3; flag++){
			cardval[flag].setText(arr.get(flag));
		}
		
		cardid.setFont(new Font("楷体", Font.BOLD, 22));
		cardid.setText("使用中:"+jn.snr);
		cardid.setForeground(Color.BLUE);
		if(cardval[2].getText().trim().isEmpty()){
			cardid.setText("空白卡"+jn.snr);
			cardid.setForeground(Color.white);
			a.setEnabled(false);
			b.setEnabled(false);
			c.setEnabled(false);
		}
		
		if(cardval[1].getText().trim().isEmpty()){
			a.setEnabled(false);
		}
		
		temp.add(con, BorderLayout.SOUTH);
		temp.add(cardid, BorderLayout.CENTER);
		setContentPane(temp);
		setTitle("会员卡结算");
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	private JPanel sel(){
		JPanel pan = new JPanel(new BorderLayout());
		JPanel west = new JPanel(new GridLayout(3, 1));

		west.add(new JLabel("卡面编号："));
		west.add(new JLabel("卡密码MD5："));
		west.add(new JLabel("总资产："));
		
		JPanel cen = new JPanel(new GridLayout(3, 1));
		for(int flag=0; flag<3; flag++){
			cardval[flag] = new JTextField();
			cardval[flag].setEditable(false);
			cardval[flag].setBackground(Color.LIGHT_GRAY);
			if(flag == 2){
				cardval[flag].setFont(new Font(null, Font.BOLD, 15));
			}
			cen.add(cardval[flag]);
		}
		
		pan.add(west, BorderLayout.WEST);
		pan.add(cen, BorderLayout.CENTER);
		return pan;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==cancel){
			dispose();
			return ;
		}
		
		String s=new String(a.getPassword());
		if(a.isEnabled() && s.trim().isEmpty()){
			JOptionPane.showMessageDialog(this, "该会员卡设置有密码，请输入密码进行认证。", "需要验证", 2);
			return ;
		}
		
		// 检查卡片合法性, 设备是否准备好
		boolean res = jn.isReady(false) ;
		if(res==false){
			return ;
		}
		
		// 密码认证
		if(!cardval[1].getText().trim().isEmpty()){
			res = jn.CardSetPsd(s, null);
			if(res==false)	return ;
		}
		
		double bb = 0.0 ;
		try{
			bb  = Double.valueOf(b.getText().trim()) ;
		}catch (Exception err) {
			JOptionPane.showMessageDialog(this, "输入的消费 金额/余额 不正确，必须为数字。", "参数错误", 2);
			return ;
		}
		if(bb<=0){
			JOptionPane.showMessageDialog(this, "输入的消费金额必须大于0。", "消息", 2);
			return ;
		}
		
		// 写入数据库，同时对权限有检测功能
		ArrayList<String> v=new ArrayList<String>();
		v.add(jn.snr);
		v.add(b.getText().trim());
		v.add("餐次:"+bf.mealnum+" 卡号:"+cardval[0].getText()+" 金额:"+b.getText().trim());
		res = Sql.mysqlprocedure("card_consume", v);
		if(res==false) return ;
		
		// 同步IC卡金额
		jn.CardCharge(bb*-1);
		
		// 如果失败的话，钱可能会被扣掉
		String att = cardval[0].getText()+"#"+jn.snr ;
		String sql="select billsubmit("+bf.mealnum+",'会员IC卡','"+att+"',"+b.getText().trim()+",'"+c.getText()+"')" ;
		Sql.getString(sql, this);
		bf.refresh();

		dispose() ;
	}
	
	public void keyPressed(KeyEvent k) {
		//响应回车键
		if(k.getKeyCode()==KeyEvent.VK_ENTER){
			if(k.getSource()==a)		b.requestFocus();
			if(k.getSource()==b)		c.requestFocus();
			if(k.getSource()==c)		ok.requestFocus();
			if(k.getSource()==ok)		ok.doClick();
			if(k.getSource()==cancel)	dispose();
		}
		//按ESC键退出
		if(k.getKeyCode()==KeyEvent.VK_ESCAPE){
			dispose();
		}
	}
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
