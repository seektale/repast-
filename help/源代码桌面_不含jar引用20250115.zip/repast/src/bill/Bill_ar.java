package bill;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import root.Sql;
public class Bill_ar extends JPanel implements DocumentListener{
	private static final long serialVersionUID = 323454594957143273L;
	private JLabel nameicon1 = new JLabel();
	private JLabel nameicon2 = new JLabel();
	public JTable t = Sql.getTable();
	private JTextField sel = new JTextField(20);
	public Bill_ar(){
		setLayout(new BorderLayout());
	    
	    Sql.getArrayToTable("select AR账号,账户名,单位,余额,锁定,签名一,签名二 from vip limit 0,50", this, t);
	    Sql.TableAtt(t, true, false);
		t.getColumn("余额").setCellRenderer(new MyTableCellRenderer());
	    add(new JScrollPane(t),BorderLayout.CENTER);
	    
	    JPanel so=new JPanel(new FlowLayout(FlowLayout.LEFT));
	    so.add(new JLabel("查询："));
	    so.add(sel);
	    so.add(new JLabel("  输入 AR账号,账户名,单位 查询"));
	    add(so,BorderLayout.NORTH);
	    
	    JPanel don=new JPanel(new FlowLayout(FlowLayout.LEFT,1,2));
	    don.add(nameicon1);
	    don.add(nameicon2);
	    don.setSize(600, 100);
	    add(don,BorderLayout.SOUTH);
	    setPreferredSize(new Dimension(600, 500));
	    
	    sel.getDocument().addDocumentListener(this);
	    t.addMouseListener(new MouseAdapter() {
	    	public void mouseClicked(MouseEvent arg0) {
	    		nameicon1.setIcon(null); //清空
    			nameicon1.setIcon(null); //清空
	    		final String num = Sql.getval(t, "AR账号", t.getSelectedRow());
	    		final String s[]=Sql.getString("select 图片一,图片二 from vip where AR账号='"+num+"'", Bill_ar.this);
	    		if(s.length>0){
	    			int m=Integer.valueOf(s[0]);
	    			int n=Integer.valueOf(s[1]);
	    			if(m>0) nameicon1.setIcon(pub.Photo.readIcon(m,true));
	    			if(n>0) nameicon2.setIcon(pub.Photo.readIcon(n,true));
	    		}
			}
		});
	}

	public void changedUpdate(DocumentEvent e) {}
	public void insertUpdate(DocumentEvent e) {
		String s = sel.getText();
		String sql = "select AR账号,账户名,单位,余额,锁定,签名一,签名二 from vip " +
				     "where AR账号 like '%"+s+"%' or 账户名 like '%"+s+"%' or 单位 like '%"+s+"%' limit 0,20";
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
		//右对齐
		t.getColumn("余额").setCellRenderer(new MyTableCellRenderer());
	}
	public void removeUpdate(DocumentEvent e) {}
	
	
	class MyTableCellRenderer extends DefaultTableCellRenderer {
		private static final long serialVersionUID = -4127477074143665006L;
		public MyTableCellRenderer() {
			super();
			setHorizontalAlignment(JLabel.RIGHT);
		}
		public void setValue(Object value) {
			super.setValue(value);
		}
	}
}
