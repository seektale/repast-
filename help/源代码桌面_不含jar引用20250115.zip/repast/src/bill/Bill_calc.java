package bill;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import root.Sql;
public class Bill_calc extends JPanel{
	private static final long serialVersionUID = -58334195851877035L;
	//总消费额
	public JLabel totalText=getTe();							
    public JLabel  rmb =getTe();		//已收
    public JLabel  rmbtar =getTe();		//找零
    public JCheckBox auto45 = new JCheckBox("自动四舍五入");
	public Bill_calc(int meal_num){
		//这一句起到初始化total的作用,但不可声明变量时变这样初始化，否则值为0.0
		BoxLayout layout=new BoxLayout(this, BoxLayout.Y_AXIS); //垂直布局
		setLayout(layout);
		
	    JPanel p = new JPanel(new GridLayout(2, 3, 6, 8));
	    p.add(new JLabel("  总消费金额："));
	    totalText.setForeground(Color.red);
		p.add(totalText);
		p.add(auto45);
		
		p.add(new JLabel("  当前已结算金额："));
		rmb.setForeground(Color.blue);
		p.add(rmb);
		JPanel tar=new JPanel(new BorderLayout());
		tar.add(new JLabel("找零："),BorderLayout.WEST);
		rmbtar.setForeground(Color.blue);
		tar.add(rmbtar,BorderLayout.CENTER);
		p.add(tar);

		add(p);
		
		//计算总金额
		String sql = "select round(sum(实价*数量*折扣),2) from dish where 属性='' and 台次="+meal_num;
		String s[]=Sql.getString(sql, this);

		//注意：计算结果如果为0，即目标餐台没有任何菜品，则返回的数据为空字符串，而不是0.0或0
		if(s.length==0 || s[0].isEmpty())	s[0]="0";
		totalText.setText(s[0]);
	}
	
	//具有浮雕边框
	private JLabel getTe(){
		JLabel la=new JLabel();
		la.setBorder(Sql.getBorder(2, ""));
		return la;
	}
}

