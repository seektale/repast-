package Menu;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import log.Select;
import pub.PinYin;
import pub.Popup_tab;
import pub.Var;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class Menu extends JInternalFrame implements ActionListener,TableModelListener,Runnable{
	private static final long serialVersionUID = -6411629019479635720L;
	private JTabbedPane tab=new JTabbedPane();
	private JButton adddish=new JButton("新增商品");
	private JButton alldish=new JButton("所有商品");
	private JButton selclass=new JButton("选择分类");
	private boolean boo=true;	//存储过程调用结果
	
	private Select cho=new Select("select * from menu;",false);
	private JPanel Pan=new JPanel(new BorderLayout());
	
	private JButton autohelp= new JButton("自动助记符");
	private JButton reset	= new JButton("禁用库存");
	private JButton lock	= new JButton("锁定");
	private JButton unlock	= new JButton("解锁");
	private JButton del		= new JButton("删除");
	private JButton pery	= new JButton("允许打折");
	private JButton pern	= new JButton("禁止打折");
	private JButton tellmenu= new JButton("通知更新菜谱");
	
	//下面三个变量专用于线程
	private String curcol;
	private String curval;
	
	private JLabel per=new JLabel();	//进度显示
	public Menu(){
		super("商品管理",true,true,true,true);
		setContentPane(tab);
	    setResizable(true);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
		
		//大类选择按扭
   	    adddish. setForeground(Color.blue);
   	    adddish. addActionListener(this);
	    alldish. addActionListener(this);
	    selclass.addActionListener(this);
	    autohelp.addActionListener(this);
	    reset.	 addActionListener(this);
	    lock.	 addActionListener(this);
	    unlock.	 addActionListener(this);
	    pery.	 addActionListener(this);
	    pern.	 addActionListener(this);
	    del.	 addActionListener(this);
	    tellmenu.addActionListener(this);
	    
   	    cho.down.add(adddish);
   	    cho.down.add(selclass);
   	    cho.down.add(alldish);
   	    cho.down.add(autohelp);
   	    cho.down.add(reset);
   	    cho.down.add(lock);
   	    cho.down.add(unlock);
   	    cho.down.add(pery);
   	    cho.down.add(pern);
   	    cho.down.add(del);
   	    cho.down.add(tellmenu);
		
		Pan.add(cho,BorderLayout.NORTH);
   	    Pan.add(new JScrollPane(cho.t),BorderLayout.CENTER);
   	    
   	    tab.add("商品明细",Pan);
	    tab.add("商品二维码及图片",new Menu_pic());
	    tab.add("套餐管理",new Menu_good());
	    tab.add("◇商品时价绑定",new Menu_bind());
	    tab.add("◆商品时价定义",new Menu_time());
   	    
	    reset.setToolTipText("库存值为-1时代表禁用沽清功能");
   	    autohelp.setToolTipText("按Ctrl+A全选，可对所有菜品统一自动生成助记符");
		cho.uppan.cbox.setSelectedItem("助记符"); //默认位置在“助记符”

		//恢复表格为可编辑状态
		DefaultTableModel model=new DefaultTableModel(0,0){
    		private static final long serialVersionUID = 353230819L;
	        public boolean isCellEditable(int row, int column) {
	        	if((column==0)||(column==2)||(column==9)||(column==10)||(column==12)||(column==13)||(column==14)){
	        		return false;
	        	}
	        	return true;
	        }
		};
		model.addTableModelListener(this);
		cho.t.setModel(model);
		cho.t.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);	//恢复选择多行需求
		
		//在表cho.t初始化之后再加上右键菜单功能 
		Sql.getArrayToTable("select * from menu limit 0,80", this, cho.t);
		Sql.TableAtt(cho.t, false, true);
		cho.t.setComponentPopupMenu(new Menu_Popup());
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==adddish){
			new MenuDialog(false);
		}
		else if(e.getSource()==alldish){
			Sql.getTable("select * from menu", cho.t, this, true);
			cho.uppan.sqltip.setText("共"+cho.t.getRowCount()+"行记录！");
		}
		else if(e.getSource()==selclass){
			String sql = "select `分类`,COUNT(*) from menu GROUP BY `分类` ORDER BY `编号`";
			ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
			JPanel pan=new JPanel(new GridLayout(arr.size()/8+1, 8));
			ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
			for(final String temp[] : arr){
				JRadioButton bo=new JRadioButton(temp[0]+"   "+temp[1]);
				bo.setName(temp[0]);
				bo.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent ce) {
						JRadioButton rad=(JRadioButton)ce.getSource();
						Sql.getArrayToTable("select * from menu where 分类='"+rad.getName()+"'", this, cho.t);
						Sql.TableAtt(cho.t, true, true);
						cho.uppan.sqltip.setText("共"+cho.t.getRowCount()+"行记录！");
					}
				});
			    radioGroup.add(bo);
				pan.add(bo);
			}
			JOptionPane.showMessageDialog(Front.inFrame, pan,"选择商品分类   (数字代表商品数量)",0,new ImageIcon());
		}
		//自动助记符
		else if(e.getSource()==autohelp){
			//规定传入null时代表自动助记符事件
			tochange(null,"助记符");
		}
		else if(e.getSource()==reset){
			tochange("-1","库存");
		}
		else if(e.getSource()==lock){
			tochange("Y","锁定");
		}
		else if(e.getSource()==unlock){
			tochange("N","锁定");
		}
		else if(e.getSource()==pery){
			tochange("Y","允许打折");
		}
		else if(e.getSource()==pern){
			tochange("N","允许打折");
		}
		else if(e.getSource()==tellmenu){
			Sql.mysqlprocedure("menu_version");
		}
		else if(e.getSource()==del){
			int k[]=cho.t.getSelectedRows();
			if(k.length==0){
				JOptionPane.showMessageDialog(Front.front,"没有选择要删除的行 或 操作不支持卡片模式？ ");
				return ;
			}
			
			int res=JOptionPane.showConfirmDialog(Front.front,"确定要删除吗","Smosu",0,1,Var.getIcon("米饭"));
			if(res>0) return;
			
			//取消对行选中状态，以免cho.t的监听事件响应
			cho.t.removeRowSelectionInterval(0, cho.t.getRowCount()-1); 
			
			DefaultTableModel dtm=(DefaultTableModel)cho.t.getModel();
			//一但一行被删除，那么下一行的行数就减一，所以这里用k[0],而不是k[m]作为参数
			for(int m=0;m<k.length;m++){
				//删除菜品
				boolean boo=Sql.mysqlprocedure("menu_del",Sql.getval(cho.t, "编号", k[0]));
				if(boo){
					dtm.removeRow(k[0]);
					continue ;
				}
				break;
			}
		}
	}
	private void tochange(String val,String col){
		curval=val;	//值
		curcol=col;	//列

		int k[]=cho.t.getSelectedRows();
		if(k.length==0){
			JOptionPane.showMessageDialog(Front.front,"没有选择要操作的行，可一次选择多行。");
			return ;
		}
		
		//大于8行数量级的修改使用对话框提示进度，否则没有必要显示进度
		//因为小于8行数据的变更很快，况且如一两行的修改老是弹出进度对话框会很麻烦。
		if(k.length>8){
			//使用线程的方式，平均占用<40kb/s的网速。
			Thread th=new Thread(this);
			th.start();
			
			//对话框显示进度
			JOptionPane.showMessageDialog(Front.front,per,"处理进度",2,new ImageIcon());
		}
		else{
			run();
		}
	}
	
	public void run(){
		//cho.t.setRowSelectionInterval(k[m],k[m]); //选中此行
		int k[]=cho.t.getSelectedRows();
		PinYin py = new PinYin();
		for(int m=0;m<k.length;m++){
			//更新值,会自动触发cho.t的值更改事件,只有该事件响应结束后，代码才继续执行
			if(curval==null){
				//仅专用于自动助记符事件
				String s=py.String2Alpha(Sql.getval(cho.t, "商品名", k[m]));
				cho.t.setValueAt(s, k[m], colCount("助记符"));
			}
			else{
				//其它事件
				cho.t.setValueAt(curval, k[m], colCount(curcol));
			}
			
			//批量操作时(boo是全局变量)存储过程如果返回false,则中止循环
			if(!boo){
				SouthPan.warn("批量操作 调用存储过程更新数据时 在第 "+k[m]+" 行，"+curcol+" 列 出错 操作提前中止。", false);
				break;
			}
			
			//显示进度
			per.setText("当前处理第 "+(m+1)+" / "+k.length+" 行，勿必等待结束。");
			if((m+1)==k.length){
				per.setText("当前处理第 "+(m+1)+" / "+k.length+" 行，操作已完成。");
			}
		}
	}
	
	private ArrayList<String> colname = Sql.getcolname("menu", getClass().getName());
	public void tableChanged(TableModelEvent e) {
		//首先找出当前对象的row and col
		int m=e.getFirstRow();	//int m=cho.t.getSelectedRow();
		int n=e.getColumn();	//用户对列顺序作了变更时，n值不会变
		
		if(m<0 || n<0) return ;
		
		String des_colname=colname.get(n);	//当前对象的列名
		n=colCount(des_colname);			//这样就找出当前在第几列
		
		//收集数据并提交菜品变更,当用户对列顺序作了变更时，不会影响数据的混乱
		DefaultTableModel mod=(DefaultTableModel)cho.t.getModel();
		@SuppressWarnings("unchecked")
		Vector<String> v=(Vector<String>)mod.getDataVector().get(m);
		/*2014-01-23 give up Place:home
		Vector<String> v=new Vector<String>();
		for(int x=0;x<cho.t.getColumnCount();x++){
			v.add(Sql.getval(cho.t, colname[x], m));
		}*/
		boo=Sql.mysqlprocedure("menu_edit",new ArrayList<String>(v));
		if(boo) return ;
		
		//当更新失败时，重新读取数据库，刷新值
		String ind=Sql.getval(cho.t, "编号", m);
		String temp[]=Sql.getString("select "+des_colname+" from menu where 编号="+ind, this);
		if(temp.length>0){
			setval(temp[0], m, n);
		}
	}
	
	//根据列名返回列的序号
	private int colCount(String colname){
		for(int x=0;x<cho.t.getColumnCount();x++){
			if(cho.t.getColumnName(x).equals(colname)){
				return x;
			}
		}
		SouthPan.warn("列名："+colname+" 在表menu列中没有匹配列。", true);
		return -1;
	}
	
	private void setval(String val,int row,int col){
		//避免下一步赋值时响应事件，形成死循环
		cho.t.getModel().removeTableModelListener(this);
		cho.t.setValueAt(val, row, col);
		cho.t.getModel().addTableModelListener(this);
	}
	
	
	/*
	 * 内部类,右键菜单
	 * */
	class Menu_Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -18259645165400196L;
		private JMenuItem item[];
		private JMenuItem a,b,c,d,e,f;
		Menu_Popup(){
			String str[]=new String[]{"科目","小类","价格","单位","成本","库存","备注"};
			a = new JMenuItem("全选");
			b = new JMenuItem("取消选中行");
			//注意下面的三个功能在用户移动了表格列顺序时，值的刷新不能对应到列，只会对应到原来的列位置
			c = new JMenuItem("重置 编号 (编号将由系统自动生成)");
			d = new JMenuItem("修改 编号 (如果选择多行,后续编号自增,建议五位数)");
			e = new JMenuItem("修改 分类 (同时编号自动修正为与分类一致)");
			f = new JMenuItem("修改 分类 (但其编号不作任何改动)");
			a.addActionListener(this);
			b.addActionListener(this);
			c.addActionListener(this);
			d.addActionListener(this);
			e.addActionListener(this);
			f.addActionListener(this);
			add(a);
			add(b);
			addSeparator();  //加分隔线
			add(c);
			add(d);
			add(e);
			add(f);
			addSeparator();
			
			item=new JMenuItem[cho.t.getColumnCount()];
			for(int k=0;k<cho.t.getColumnCount();k++){
				//检查是否允许加入
				boolean flag=false;
				for(int n=0;n<str.length;n++){
					if(str[n].equals(cho.t.getColumnName(k))){
						flag=true;
						break;
					}	
				}
				//加入
				if(flag){
					item[k]=new JMenuItem("批量修改 "+cho.t.getColumnName(k));
					item[k].setName(cho.t.getColumnName(k));
					item[k].addActionListener(this);
					add(item[k]);
				}
			}
			
			//原有的菜单项功能
			addSeparator();
			Popup_tab superpop=(Popup_tab)cho.t.getComponentPopupMenu();
			add(superpop.getMenu());
		}
		@Override
		public void actionPerformed(ActionEvent ee) {
			// TODO Auto-generated method stub
			if(ee.getSource()==a){
				if((cho.t!=null)&&(cho.t.getRowCount()>0)){
					cho.t.setRowSelectionInterval(0,cho.t.getRowCount()-1); 
				}
			}
			else if(ee.getSource()==b){
				if((cho.t!=null)&&(cho.t.getRowCount()>0)){
					cho.t.removeRowSelectionInterval(0, cho.t.getRowCount()-1); 
				}
			}
			//实际上与修改分类一样，只是分类名称不变，编号自动生成
			else if(ee.getSource()==c){
				int k[]=cho.t.getSelectedRows();
				if(k.length==0){
					JOptionPane.showMessageDialog(null,"没有选择要操作的行？ 请选择，可一次选择多行。");
					return ;
				}
				
				for(int i=0;i<k.length;i++){
					ArrayList<String> v=new ArrayList<String>();
					v.add(Sql.getval(cho.t, "编号", k[i]));
					v.add(Sql.getval(cho.t, "分类", k[0]));
					boolean b=Sql.mysqlprocedure("menu_editclass",v);
					if(b){
						//更新编号值
						String sql="select 编号 from menu where 商品名='"+Sql.getval(cho.t, "商品名", k[i])+"';";
						String dishind[]=Sql.getString(sql, this);
						if(dishind.length>0){
							setval(dishind[0], k[i], 0);
						}
						continue ;
					}
					break;
				}
			}
			else if(ee.getSource()==d){
				int k[]=cho.t.getSelectedRows();
				if(k.length==0){
					JOptionPane.showMessageDialog(Front.front,"没有选择要操作的行？ 请选择，可一次选择多行。");
					return ;
				}

				String temp=Sql.getval(cho.t, "编号", k[0]);
				String val=JOptionPane.showInputDialog(Front.front,"将编号:"+temp+"  改为... (后续编号自增)");
				if(val!=null){
					int valnum=0;
					try{
						valnum=Integer.valueOf(val);
					}catch (Exception es) {
						JOptionPane.showMessageDialog(Front.front,"输入的新商品编号"+val+" 有误，不能转换成有效数字。");
					}
					if(valnum > 0){
						for(int i=0;i<k.length;i++){
							ArrayList<String> v=new ArrayList<String>();
							v.add(Sql.getval(cho.t, "编号", k[i]));
							v.add((valnum+i)+"");
							boolean b=Sql.mysqlprocedure("menu_editnum",v);
							if(b){
								setval((valnum+i)+"", k[i], 0);	//更新值
								continue ;
							}
							break;
						}
					}
				}
			}
			else if(ee.getSource()==e){
				int k[]=cho.t.getSelectedRows();
				if(k.length==0){
					JOptionPane.showMessageDialog(Front.front,"没有选择要操作的行？ 请选择，可一次选择多行。");
					return ;
				}
			
				String temp=Sql.getval(cho.t, "分类", k[0]);
				JComboBox<String> chclass=new JComboBox<String>(Var.getMenu_class(true));
				chclass.setEditable(true);
				chclass.setSelectedItem(temp);
				int ans=JOptionPane.showConfirmDialog(Front.front, chclass,"选择一个商品分类",0);
				if(ans==0){
					temp=chclass.getSelectedItem().toString();
					for(int i=0;i<k.length;i++){
						ArrayList<String> v=new ArrayList<String>();
						v.add(Sql.getval(cho.t, "编号", k[i]));
						v.add(temp);
						boolean b=Sql.mysqlprocedure("menu_editclass",v);
						if(b){
							//更新分类值
							setval(temp, k[i], 2);
							//更新编号值
							String sql="select 编号 from menu where 商品名='"+Sql.getval(cho.t, "商品名", k[i])+"';";
							String dishind[]=Sql.getString(sql, this);
							if(dishind.length>0){
								setval(dishind[0], k[i], 0);
							}
							continue ;
						}
						break;
					}
				}
			}
			else if(ee.getSource()==f){
				int k[]=cho.t.getSelectedRows();
				if(k.length==0){
					JOptionPane.showMessageDialog(Front.front,"没有选择要操作的行？ 请选择，可一次选择多行。");
					return ;
				}

				String temp=Sql.getval(cho.t, "分类", k[0]);
				JComboBox<String> chclass=new JComboBox<String>(Var.getMenu_class(true));
				chclass.setEditable(true);
				chclass.setSelectedItem(temp);
				int ans=JOptionPane.showConfirmDialog(Front.front, chclass,"选择一个商品分类",0);
				if(ans==0){
					temp=chclass.getSelectedItem().toString();
					for(int i=0;i<k.length;i++){
						//更新分类值,由表格监听来完成
						cho.t.setValueAt(temp, k[i], 2);
					}
				}
			}
			else{
				int k[]=cho.t.getSelectedRows();
				if(k.length==0){
					JOptionPane.showMessageDialog(Front.front,"没有选择要操作的行？ 请选择，可一次选择多行。");
					return ;
				}

				JMenuItem it=(JMenuItem)ee.getSource();
				String val=JOptionPane.showInputDialog(Front.front,it.getText(),"批量操作",3);
				if(val!=null)	tochange(val,it.getName());
			}
		}
	}
}
