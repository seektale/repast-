package Menu;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.*;
import pub.DateUI;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class Menu_time extends JPanel implements ActionListener{
	private static final long serialVersionUID = -6411629019479635720L;
	private JTable t;
	private JButton add	=new JButton("新增定义");
	private JButton del	=new JButton("删除定义");
	private JButton refresh	=new JButton("刷新");
	Menu_time(){
		setLayout(new BorderLayout());
	    JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
	    nor.add(add);
	    nor.add(del);
	    nor.add(refresh);
	    add.addActionListener(this);
	    del.addActionListener(this);
	    refresh.addActionListener(this);
   	    add(nor,BorderLayout.NORTH);
   	    
   	    t=Sql.getTable("select * from timeprice", Sql.getTable(), this, true);
   	    t.addMouseListener(new MouseAdapter() {
   	    	public void mousePressed(MouseEvent e) {
   	 		if (e.getClickCount() == 2){
   	 			int row=t.getSelectedRow();
   	 			String val=Sql.getval(t, "编号", row);
   	 			sub(val);
   	         }
   	 	}
		});
   	    add(new JScrollPane(t),BorderLayout.CENTER);
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==add){
			sub("0");
		}
		if(e.getSource()==refresh){
			Sql.getArrayToTable("select * from timeprice", this, t);
		}
		else if(e.getSource()==del){
			int k=t.getSelectedRow();
			if(k==-1){
				SouthPan.warn("没有选择要删除的数据行", true);
				return ;
			}
			Sql.mysqlprocedure("timeprice_del",Sql.getval(t, "编号", k));
			Sql.getArrayToTable("select * from timeprice", this, t);
		}
	}
	
	//对话框
	private void sub(String ind){
		//声明变量
		JRadioButton ch[]=new JRadioButton[5];
		ch[0]=new JRadioButton("按折扣");	ch[0].setSelected(true);
		ch[1]=new JRadioButton("按定价");
		ch[2]=new JRadioButton("按优惠");
		ch[0].setToolTipText("在价格的基础上打折，填写的值应大于 0，小于 1");
		ch[1].setToolTipText("指定一个新的价格");
		ch[2].setToolTipText("在原价格的基础按所填写的金额进行减免");
		JCheckBox used=new JCheckBox("启用");	used.setSelected(true);//默认启用
		JTextField name=new JTextField(16);
		JTextField money=new JTextField("0.0",6);
		JTextField time1=new JTextField("00:00:00",8);
		JTextField time2=new JTextField("23:59:59",8);
		
		final JTextField dayval=new JTextField(30);
		dayval.setEditable(false);
		JButton clear=new JButton("清除");

		JTextField remark=new JTextField(30);
		JCheckBox week[]=new JCheckBox[7];
		week[0]=new JCheckBox("星期一");
		week[1]=new JCheckBox("星期二");
		week[2]=new JCheckBox("星期三");
		week[3]=new JCheckBox("星期四");
		week[4]=new JCheckBox("星期五");
		week[5]=new JCheckBox("星期六");
		week[6]=new JCheckBox("星期天");
		dayval.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e){
				DateUI du = new DateUI();
				if(du.toString().isEmpty()) return ;
				
				if(dayval.getText().isEmpty()){
					dayval.setText(du.toString());
					return ;
				}
				dayval.setText(dayval.getText()+","+du.toString());
			}
		});
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dayval.setText("");
			}
		});
		
		ButtonGroup  radioGroup1 = new ButtonGroup(); //单选组
		radioGroup1.add(ch[0]);
		radioGroup1.add(ch[1]);
		radioGroup1.add(ch[2]);
		
		//开始布局
		JPanel p=new JPanel();
		p.setLayout(new BoxLayout(p, BoxLayout.PAGE_AXIS));	//一行一行的布局
		
		JPanel temp=new JPanel(new BorderLayout());
		temp.add(new JLabel("名称："),BorderLayout.WEST);
		temp.add(name,BorderLayout.CENTER);
		temp.add(used,BorderLayout.EAST);
		p.add(temp);
		p.add(new JSeparator());	//分割线
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(ch[0]);
		temp.add(ch[1]);
		temp.add(ch[2]);
		temp.add(new JLabel("   值"));
		temp.add(money);
		p.add(temp);
		p.add(new JSeparator());	//分割线
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		for(int m=0;m<week.length;m++){
			temp.add(week[m]);
		}
		p.add(temp);
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("指定日期"));
		temp.add(dayval);
		temp.add(clear);
		p.add(temp);
		p.add(new JSeparator());	//分割线
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("起止时间"));
		temp.add(time1);
		temp.add(new JLabel(" --- "));
		temp.add(time2);
		p.add(temp);
		p.add(new JSeparator());	//分割线
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("简要说明"));
		temp.add(remark);
		p.add(temp);
		
		//初始化参数
		if(!ind.equals("0")){
			String init[]=Sql.getString("select * from timeprice where 编号="+ind, this);
			if(init.length>0){
				name.setText(init[1]);
				if(!init[2].equals("0.0")) {ch[0].setSelected(true); money.setText(init[2]);}
				if(!init[3].equals("0.0")) {ch[1].setSelected(true); money.setText(init[3]);}
				if(!init[4].equals("0.0")) {ch[2].setSelected(true); money.setText(init[4]);}
				for(int m=0;m<init[5].length();m++){
					if(init[5].charAt(m)=='Y')	week[m].setSelected(true);
				}
				dayval.setText(init[6]);
				time1.setText(init[7]);
				time2.setText(init[8]);
				if(init[9].equals("Y"))	used.setSelected(true);
				else used.setSelected(false);
				remark.setText(init[10]);
			}
		}
		
		//开始弹出对话框
		String title="";
		if(ind.equals("0"))	title="新时间段价格定义";
		else				title="时间段价格编辑";
		int action=JOptionPane.showConfirmDialog(Front.front,p,title,2,1,new ImageIcon());
		if(action==0){
			ArrayList<String> v=new ArrayList<String>();
			v.add(ind);				//编号，为空字符串说明是新定义的
			v.add(name.getText());	//名称
			
			if(ch[0].isSelected()) v.add("折扣");
			else if(ch[1].isSelected()) v.add("定价");
			else if(ch[2].isSelected()) v.add("优惠");
			v.add(money.getText());
			
			String we="";
			for(int m=0;m<week.length;m++){
				if(week[m].isSelected()) we=we+"Y";
				else we=we+"N";
			}
			v.add(we);
			v.add(dayval.getText());
			
			v.add(time1.getText());
			v.add(time2.getText());
			if(used.isSelected())	v.add("Y");
			else v.add("N");
			v.add(remark.getText());

			//调用存储过程，刷新，并恢复选中的行
			Sql.mysqlprocedure("timeprice",v);
			int selectrow=t.getSelectedRow();
			
			Sql.getArrayToTable("select * from timeprice", this, t);
			//恢复选中的行
			if(selectrow>=0 && selectrow<t.getRowCount()){
				t.setRowSelectionInterval(selectrow,selectrow);
			}
		}
	}
}
