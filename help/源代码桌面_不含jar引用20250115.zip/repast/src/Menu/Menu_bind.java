package Menu;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

import log.Select;

import pub.Popup_tab;
import pub.Var;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class Menu_bind extends JPanel implements ActionListener,TableModelListener,Runnable{
	private static final long serialVersionUID = -6411629019471635720L;
	private String sql="select 编号,分类,小类,商品名,价格,单位,助记符,时价定义 from menu";
	private Select cho=new Select(sql,false);
	private JButton add	=new JButton("新增绑定");
	private JButton del	=new JButton("取消绑定");
	private JButton view=new JButton("查看所有绑定");
	private JButton selclass=new JButton("选择分类");
	private String curval;	//记录时间定义值
	public Menu_bind(){
		setLayout(new BorderLayout());
	    add.addActionListener(this);
	    del.addActionListener(this);
	    view.addActionListener(this);
   	    add(cho,BorderLayout.NORTH);
   	    
   	    //大类选择按扭
	    selclass.addActionListener(this);
	    cho.down.add(selclass);
   	    cho.down.add(add);
   	    cho.down.add(del);
   	    cho.down.add(view);
   	    cho.uppan.cbox.setSelectedItem("助记符"); //默认位置在“助记符”

   	    cho.t.getModel().addTableModelListener(this);
   	    cho.t.addMouseListener(new MouseAdapter() {
	    	public void mousePressed(MouseEvent e) {
	 		if (e.getClickCount() == 2){
	 			bind();
	         }
	 	}
		});
	    add(new JScrollPane(cho.t),BorderLayout.CENTER);
		cho.t.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);	//恢复选择多行需求
		
		view.doClick();	//默认显示所有绑定商品
		
		//在表cho.t初始化之后(即表有了列和数据)再加上右键菜单功能 
		cho.t.setComponentPopupMenu(new Menu_Popup());
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==del){
			can();
		}
		else if(e.getSource()==add){
			bind();
		}
		else if(e.getSource()==selclass){
			String subsql = "select `分类`,COUNT(*) from menu GROUP BY `分类` ORDER BY `编号`";
			ArrayList<String[]> arr = Sql.getArrayToArrary(subsql, this);
			JPanel pan=new JPanel(new GridLayout(arr.size()/8+1, 8));
			ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
			for(final String temp[] : arr){
				JRadioButton bo=new JRadioButton(temp[0]+"   "+temp[1]);
				bo.setName(temp[0]);
				bo.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent ce) {
						JRadioButton rad=(JRadioButton)ce.getSource();
						Sql.getArrayToTable(sql+" where 分类='"+rad.getName()+"'", this, cho.t);
						Sql.TableAtt(cho.t, true, true);
						cho.uppan.sqltip.setText("共"+cho.t.getRowCount()+"行记录！");
					}
				});
			    radioGroup.add(bo);
				pan.add(bo);
			}
			JOptionPane.showMessageDialog(Front.inFrame, pan,"选择商品分类   (数字代表商品数量)",0,new ImageIcon());
		}
		else if(e.getSource()==view){
			Sql.getTable(sql+" where 时价定义<>''", cho.t, this, true);
			cho.uppan.sqltip.setText("共"+cho.t.getRowCount()+"行记录！");
		}
	}
	
	//绑定时间
	private void bind(){
		String name[]=Sql.getString("select distinct 名称 from timeprice", this);
		Object val=JOptionPane.showInputDialog(null,"请选择时间价格定义名称：","下拉选择",3,Var.getIcon("米饭"),name,"");
		if(val!=null){
			curval=val.toString();
			Thread th=new Thread(this);
			th.start();
		}
	}
	//取消绑定
	private void can(){
		curval="";
		Thread th=new Thread(this);
		th.start();
	}
	public void run(){
		int k[]=cho.t.getSelectedRows();
		if(k.length==0){
			JOptionPane.showMessageDialog(Front.front,"没有选择要操作的行，可一次选择多行。");
		}
		else{
			cho.t.setEnabled(false);	//防止用户对表格操作，从而响应表格事件
			cho.uppan.sqltip.setForeground(Color.red);
			for(int m=0;m<k.length;m++){
				//选中此行
				cho.t.setRowSelectionInterval(k[m],k[m]); 
				
				cho.t.setValueAt(curval, k[m], colCount("时价定义"));
				
				//显示进度
				cho.uppan.sqltip.setText("当前处理第 "+(m+1)+" / "+k.length+" 行，勿必等待结束，否则至程序死机。");
				if((m+1)==k.length){
					cho.uppan.sqltip.setForeground(Color.black);
					cho.uppan.sqltip.setText("当前处理第 "+(m+1)+" / "+k.length+" 行，操作已完成。");
				}
			}
			
			//恢复选中的多行,不能保证间隔选择的行也有效
			cho.t.setRowSelectionInterval(k[0],k[k.length-1]); 
		}
		cho.t.setEnabled(true);
	}
	
	public void tableChanged(TableModelEvent e) {
		//首先找出当前对象的row and col
		int m=e.getFirstRow();	//int m=cho.t.getSelectedRow();
		int n=e.getColumn();	//用户对列顺序作了变更时，n值不会变
		
		if((m>=0)&&(n>=0)){
			n=colCount("时价定义");		//这样就找出当前在第几列
			
			//提交数据到数据库
			ArrayList<String> v=new ArrayList<String>();
			v.add(Sql.getval(cho.t, "编号", m));		//编号
			v.add(cho.t.getValueAt(m, n).toString());
			boolean boo=Sql.mysqlprocedure("timebind",v);
			
			if(!boo){
				//重新读取数据库，刷新值
				String ind=Sql.getval(cho.t, "编号", m);
				String temp[]=Sql.getString("select 时价定义 from menu where 编号="+ind, this);
				if(temp.length>0){
					//避免下一步赋值时响应事件，形成死循环
					cho.t.getModel().removeTableModelListener(this);
					cho.t.setValueAt(temp[0], m, n);
					cho.t.getModel().addTableModelListener(this);
				}
			}
		}
	}
	//根据列名返回列的序号
	private int colCount(String colname){
		for(int x=0;x<cho.t.getColumnCount();x++){
			if(cho.t.getColumnName(x).equals(colname)){
				return x;
			}
		}
		SouthPan.warn("列名："+colname+" 在表menu列中没有匹配列。", true);
		return -1;
	}
	
	
	/*
	 * 内部类,右键菜单
	 * */
	public class Menu_Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -182165400196L;
		Menu_Popup(){
			sub("全选");
			sub("取消选中行");
			addSeparator();  //加分隔线
			
			sub("绑定");
			sub("取消绑定");
			
			//原有的菜单项功能
			addSeparator();
			Popup_tab superpop=(Popup_tab)cho.t.getComponentPopupMenu();
			add(superpop.getMenu());
		}
		private void sub(String name){
			JMenuItem a = new JMenuItem(name);
			a.addActionListener(this);
			add(a);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getActionCommand().equals("全选")){
				if((cho.t!=null)&&(cho.t.getRowCount()>0)){
					cho.t.setRowSelectionInterval(0,cho.t.getRowCount()-1); 
				}
			}
			else if(e.getActionCommand().equals("取消选中行")){
				if((cho.t!=null)&&(cho.t.getRowCount()>0)){
					cho.t.removeRowSelectionInterval(0, cho.t.getRowCount()-1); 
				}
			}
			else if(e.getActionCommand().equals("绑定")){
				bind();
			}
			else if(e.getActionCommand().equals("取消绑定")){
				can();
			}
		}
	}
}
