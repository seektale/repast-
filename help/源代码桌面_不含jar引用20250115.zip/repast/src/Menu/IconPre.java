package Menu;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import root.Front;
public class IconPre extends JDialog implements MouseListener{
	private static final long serialVersionUID = -75135523549358803L;
	//账单预览对话框，如果对话框采用dispose()的方法，第次预览将占用两兆内存
	public IconPre(Icon icon){
		super(Front.front,"商品图片预览",true);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		
		//因为操作系统有任务栏，高度要多减一些：约30，满屏又不美观，所以再减26
		Integer sw=screenSize.width-16-26;
		Integer sh=screenSize.height-38-30-26;
		Integer w = icon.getIconWidth() ;
		Integer h = icon.getIconHeight() ;
		
		//宽大出屏幕
		if(sw<w && sh>h){
			icon = changeImage(icon, sw.doubleValue() / w.doubleValue());
		}
		//长大出屏幕
		else if(sw>w && sh<h){
			icon = changeImage(icon, sh.doubleValue() / h.doubleValue());
		}
		//长和宽都大于屏幕
		else if(sw<w && sh<h){
			double douw = sw.doubleValue() / w.doubleValue() ;
			double douh = sh.doubleValue() / h.doubleValue() ;
			double val = douw>douh ? douh : douw;
			icon = changeImage(icon, val);
		}
		
		JLabel con = new JLabel(icon);
		con.addMouseListener(this);
		
		setSize(icon.getIconWidth()+16,icon.getIconHeight()+38);
		setContentPane(con);
		setLocationRelativeTo(null); //初始位置在屏幕正中间
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Front.logo);
		setVisible(true);
	}
	
	//对于太大的图片，按比例缩放至当前屏幕适合的大小,n是一个小于1的数
	public Icon changeImage(Icon icon, double n) {
		Image img = ((ImageIcon) icon).getImage();
		// 构造Image对象
		int wideth = img.getWidth(null); 	// 得到源图宽
		int height = img.getHeight(null); 	// 得到源图长
		BufferedImage tag = new BufferedImage((int) (n * wideth), (int) (n * height), BufferedImage.TYPE_INT_RGB);
		tag.getGraphics().drawImage(img, 0, 0, (int) (n * wideth), (int) (n * height), null);
		Icon returnIcon = new ImageIcon(tag);
		return returnIcon;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		dispose();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
