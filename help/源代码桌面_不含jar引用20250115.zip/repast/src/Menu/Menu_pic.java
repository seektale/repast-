package Menu;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import desk_portal.MenuCard;
import pub.ConfigFile;
import pub.ModifiedFlowlayout;
import pub.Photo;
import root.Front;
import root.Sql;
public class Menu_pic extends JPanel implements ActionListener,DocumentListener,Runnable{
	private static final long serialVersionUID = -6411629019479635720L;
	private JButton selclass = new JButton("选择分类");
	private JTextField help = new JTextField(20);
	private JLabel msg = new JLabel();
	private JPanel card=new JPanel();
	private ArrayList<String[]> arr = new ArrayList<String[]>();
	private ExecutorService Pool = Executors.newSingleThreadExecutor();
	private boolean flag = false ;
	private String photonum[] = new String[]{};
	public Menu_pic(){
		setLayout(new BorderLayout());
   	    selclass.addActionListener(this);
   	    help.getDocument().addDocumentListener(this);
   	    msg.setForeground(Color.BLUE);
   	    JPanel nor = new JPanel(new FlowLayout(FlowLayout.LEFT));
   	    nor.add(selclass);
   	    nor.add(new JLabel("   商品名或助记符："));
   	    nor.add(help);
   	    nor.add(new JLabel("  可用施放方式载入图片(以jpg格式为主)  "));
   	    nor.add(msg);
   	    add(nor,BorderLayout.NORTH);
   	    
   	    card.setOpaque(false);
		card.setLayout(new ModifiedFlowlayout(FlowLayout.LEFT,5,5)); //向左对齐
		JScrollPane js=new JScrollPane(card);
		js.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
   	    add(js,BorderLayout.CENTER);
	}
	
	public void changedUpdate(DocumentEvent e) {}
	public void insertUpdate(DocumentEvent e) {
		if(flag) return ;
		
		//为减少对数据库的频繁读取，只对插入时行响应，并限制50行记录
		String sql = "select * from menu where 助记符 like '%"+help.getText()+"%' or 商品名 like '%"+help.getText()+"%' limit 0,50; " ;
		arr = Sql.getArrayToArrary(sql, this);
		Pool.submit(new Thread(this));
	}
	public void removeUpdate(DocumentEvent e) {}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==selclass){
			String sql = "select `分类`,COUNT(*),COUNT(num) from menu LEFT JOIN photo ON menu.`编号`=photo.num GROUP BY `分类` ORDER BY `编号`";
			ArrayList<String[]> arrtemp = Sql.getArrayToArrary(sql, this);
			JPanel pan=new JPanel(new GridLayout(arrtemp.size()/8+1, 8));
			ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
			for(String temp[] : arrtemp){
				JRadioButton bo=new JRadioButton(temp[0]+"   "+temp[1]+"/"+temp[2]);
				bo.setName(temp[0]);
				bo.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent ce) {
						if(flag) return ;
						JRadioButton rad=(JRadioButton)ce.getSource();
						//不进行返回数据量大小限制，因为menu表不是无限增长的表，也为了完整显示整个分类
						String sql = "select * from menu where 分类='"+rad.getName()+"' " ;
						arr = Sql.getArrayToArrary(sql, this);
						Pool.submit(new Thread(Menu_pic.this));
					}
				});
			    radioGroup.add(bo);
				pan.add(bo);
			}
			JOptionPane.showMessageDialog(Front.inFrame, pan,"选择商品分类  (分数代表商品数量 和 图片张数)",0,new ImageIcon());
		}
	}
	
	//使用线程的方式可以看到商品加载时的动态效果
	public void run() {
		flag = true;	//阻止后续线程进入
		
		card.removeAll();
		card.setVisible(false);
		card.setVisible(true);
		
		int x=arr.size();
		if(x==0) { flag=false; return; }
		
		final JScrollPane js=(JScrollPane)card.getParent().getParent();
		for(final String getstr[] : arr){
			//将行数据转成字符串数组
			ArrayList<String> val = new ArrayList<String>();
			for(String temp : getstr){val.add(temp);}
			//卡片菜单
			MenuCard cm=new MenuCard(val, js.getWidth(), true);
			cm.setComponentPopupMenu(new Pic_Popup(cm)); //右键菜单
			cm.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					if(e.getButton()==1){
						new Weipre(getstr[0]+"#"+getstr[4]);
					}
				}
			});
			//拖拽功能
			new DropTarget(cm, DnDConstants.ACTION_COPY_OR_MOVE,new drag(cm), true, null);
			card.add(cm);
		}
		//刷新
		card.setVisible(false);
		card.setVisible(true);
		
		//处理图片的加载
		int count = card.getComponentCount() ;
		photonum = Sql.getString("select num from photo", this);
		for (int k = 0 ; k < count ; k++){
			msg.setText("共"+arr.size()+"行记录，当前处理第:"+(k+1)+" 条记录");
			
			MenuCard mc = (MenuCard)card.getComponent(k);
			final int dishind = Integer.valueOf(mc.getval("编号"));
			if(!isphoto(photonum, mc.getval("编号"))) continue;
			
			mc.pic.addMouseListener(new MouseAdapter() {
				public void mouseClicked(MouseEvent e) {} //在鼠标松开时才响应
				public void mousePressed(MouseEvent e) { //在鼠标按下去时就响应
					Icon con = Photo.readIcon(dishind,true) ;
					if(con!=null)	new IconPre(con);
				}
			});
			
			Icon co=Photo.readIcon(dishind);
			if(co==null) continue;
			mc.pic.setIcon(co);
		}
		
		flag = false;	//复位
	}
	
	private boolean isphoto(String photonum[],String dishnum ){
		for(String temp : photonum){
			if(temp.equals(dishnum)) return true;
		}
		return false;
	}
	
	//将图片拖拽到目标菜品卡片上，菜品的图片便会更新
	class drag implements DropTargetListener{
		private MenuCard cm;
		drag(MenuCard cm){
			this.cm=cm;
		}
		@Override
		public void dragEnter(DropTargetDragEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void dragExit(DropTargetEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void dragOver(DropTargetDragEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void drop(DropTargetDropEvent dtde) {
			if ((dtde.getDropAction() & DnDConstants.ACTION_COPY_OR_MOVE) != 0) {
				// Accept the drop and get the transfer data
				dtde.acceptDrop(dtde.getDropAction());
				Transferable transferable = dtde.getTransferable();
				try {
					List<?> fileList = (List<?>) transferable.getTransferData(DataFlavor.javaFileListFlavor);
					File transferFile = (File) fileList.get(0);
					
					//保存图片
					int dishind = Integer.valueOf(cm.getval("编号"));
					Photo.savepic(dishind, cm.getval("商品名"), transferFile);
					
					//刷新大小图片; flag.ind是商品编号
			    	Icon icon=Photo.Iconrefresh(dishind);
		        	if(icon!=null) cm.pic.setIcon(icon);
				} catch (Exception e) {}
			}
		}

		@Override
		public void dropActionChanged(DropTargetDragEvent arg0) {}
	}
	
	/*
	 * 内部类,右键菜单
	 * */
	public class Pic_Popup extends JPopupMenu implements ActionListener,Runnable{
		private static final long serialVersionUID = -182596465400196L;
		private JMenuItem a = new JMenuItem("导入图片 Import");
		private JMenuItem b = new JMenuItem("导出图片 Export");
		private JMenuItem c = new JMenuItem("一键导出到桌面 Export To Desk");
		private JMenuItem d = new JMenuItem("当前窗口全部导出至桌面 Export All");
		private JMenuItem e = new JMenuItem("查看大图 Image View");
		private JMenuItem f = new JMenuItem("删除图片 Delete Image");
		private MenuCard flag;
		private JLabel promsg = new JLabel();
		Pic_Popup(MenuCard mc){
			flag=mc;
			a.addActionListener(this);
			b.addActionListener(this);
			c.addActionListener(this);
			d.addActionListener(this);
			e.addActionListener(this);
			f.addActionListener(this);
			add(a);
			add(b);
			add(c);
			add(d);
			addSeparator();  //加分隔线
			add(e);
			addSeparator();
			add(f);
			addSeparator();
			add("拖放方式导入 Drag Image for Import");
		}
		@Override
		public void actionPerformed(ActionEvent err) {
			int dishind = Integer.valueOf(flag.getval("编号"));
			// TODO Auto-generated method stub
			if(err.getSource()==a){
				
		    	//默认选择当前用户桌面
				String tem = ConfigFile.getProperty("JFileChooserDir");
		    	if(tem==null || tem.isEmpty()) {
		    		final Properties props=System.getProperties();
		    		tem=props.getProperty("user.home")+File.separator+"desktop"+File.separator;
		    		ConfigFile.setProperty("JFileChooserDir", tem);
		    	}
		    	
		    	//选择目录  
		    	final JFileChooser fi=new JFileChooser(ConfigFile.getProperty("JFileChooserDir"));   	//打开当前目录
		    	int result=fi.showOpenDialog(Front.front);         	//打开对话框
		    	if(result==JFileChooser.APPROVE_OPTION){
		    		ConfigFile.setProperty("JFileChooserDir", fi.getSelectedFile().getParent()); //保存上一次打开的路经
		    		Photo.savepic(dishind,flag.getval("商品名"), fi.getSelectedFile());
		    	}
		    	
				//刷新小图片; flag.ind是商品编号
		    	Icon icon=Photo.Iconrefresh(dishind);
	        	if(icon!=null) flag.pic.setIcon(icon);
			}
			else if(err.getSource()==b){
				Photo.ExportIcon(dishind, true);
			}
			else if(err.getSource()==c){
				Photo.ExportIcon(dishind, false);
			}
			else if(err.getSource()==d){
				new Thread(this).start();
				JOptionPane.showMessageDialog(null, promsg);
			}
			else if(err.getSource()==e){
				//对话框显示大图片
				new IconPre(Photo.readIcon(dishind,true));
			}
			else if(err.getSource()==f){
				boolean temp=Sql.mysqlprocedure("menu_del_photo", flag.getval("编号"));
				if(temp){
					flag.pic.setIcon(null);
				}
			}
		}
		
		public void run() {
			//处理图片的导出
			int count = card.getComponentCount() ;
			for (int k = 0 ; k < count ; k++){
				promsg.setText("导出商品图片处理第:"+(k+1)+"/"+arr.size()+" 条记录");
				promsg.setPreferredSize(new Dimension(240,30));
				MenuCard mc = (MenuCard)card.getComponent(k);
				if(!isphoto(photonum, mc.getval("编号"))) continue;
				Photo.ExportIcon(Integer.valueOf(mc.getval("编号")), false);
			}
		}
	}
}
