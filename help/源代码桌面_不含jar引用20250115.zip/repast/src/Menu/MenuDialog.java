package Menu;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import pub.PinYin;
import root.Front;
import root.Sql;
//增加新商品
public class MenuDialog extends JDialog implements ActionListener,DocumentListener{     
	private static final long serialVersionUID = -7634497563911002862L;
	private JTextField text[];
	private JComboBox<String> box1=getbox("select distinct 科目 from menu;");
	private JComboBox<String> box2=getbox("select distinct 分类 from menu;");
	private JComboBox<String> box3=getbox("select 'love';");
	private JComboBox<String> box6=getbox("select distinct 单位 from menu;");
	
	private JCheckBox che9  = new JCheckBox("锁定 (锁定之后，商品暂时不可用)");
	private JCheckBox che10 = new JCheckBox("允许打折 (如果选中，商品才能打折)");
	
	private JButton ok=new JButton("添加新商品 S");
	private JButton exit=new JButton("返回 Q");
	private PinYin py = new PinYin();
	public MenuDialog(boolean boo){
		super(Front.front,true);
		int len=16;	//表menu的列数
		setLayout(new BorderLayout());
		JPanel te1=new JPanel(new GridLayout(len-4,1,6,6));
		te1.setPreferredSize(new Dimension(100,10));
		JPanel te2=new JPanel(new GridLayout(len-4,1,6,6));
		ArrayList<String> strcol = Sql.getcolname("menu",getClass().getName());
		text=new JTextField[len];
		
		box2.addActionListener(this);
		che10.setSelected(true);
		if(boo){
			box2.setEditable(false);
			box2.removeAllItems();
			box2.addItem("套餐");
		}
		else{
			box2.addPopupMenuListener(new PopupMenuListener() {
				public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
					diaclass();
					//box2.firePopupMenuCanceled();	//关闭弹出菜单没有效果
					box2.setVisible(false);	//先不可见，再可见，等效于关闭弹出菜单
					box2.setVisible(true);
				}
				public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {}
				public void popupMenuCanceled(PopupMenuEvent arg0) {}
			});
		}
		for(byte k=0;k<len;k++){
			//不需要的不显示
			if((k==0)||(k==12)||(k==13)||(k==14)){
				continue;
			}
			
			JLabel l=new JLabel(strcol.get(k)+"：",JLabel.RIGHT);
			l.setFont(new Font("楷体",Font.PLAIN,16));
			te1.add(l);
			
			if(k==1)		te2.add(box1);
			else if(k==2)	te2.add(box2);
			else if(k==3)	te2.add(box3);
			else if(k==6)	te2.add(box6);
			else if(k==9)	te2.add(che9);
			else if(k==10)	te2.add(che10);
			else {
				text[k]=new JTextField();
				te2.add(text[k]);
				if(k==4){
					text[k].getDocument().addDocumentListener(this);
				}
			}
		}
		if(boo){
			text[len-1].setEditable(false);	//备注不可使用
			text[len-1].setBackground(Color.LIGHT_GRAY);
		}
		
		text[5].setText("0");
		text[7].setText("0");
		text[8].setText("-1");
		
		JPanel Cen=new JPanel(new BorderLayout());
		Cen.setBorder(BorderFactory.createTitledBorder(""));
		Cen.add("West",te1);
		Cen.add("Center",te2);
		add("Center",Cen);
		
		Cen=new JPanel(new FlowLayout(FlowLayout.RIGHT,12,6));
		Cen.add(ok);
		Cen.add(exit);
		ok.addActionListener(this);
		exit.addActionListener(this);
		ok.setMnemonic(KeyEvent.VK_S);
		exit.setMnemonic(KeyEvent.VK_Q);
		add("South",Cen);
		
		setTitle("新增商品(支持90个分类，每个分类999个商品)");
		setSize(400,520);
		setResizable(false);
		setLocationRelativeTo(null);	//初始位置在屏幕正中间
		setVisible(true);
	}
	private JComboBox<String> getbox(String sql){
		String s[]=Sql.getString(sql, this);
		JComboBox<String> box=new JComboBox<String>(s);
		box.setEditable(true);
		return box;
	}
	private void diaclass(){
		String sql = "select `分类`,COUNT(*) from menu GROUP BY `分类` ORDER BY `编号`";
		ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
		JPanel pan=new JPanel(new GridLayout(arr.size()/8+1, 8));
		ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
		for(final String temp[] : arr){
			JRadioButton bo=new JRadioButton(temp[0]+"   "+temp[1]);
			bo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ce) {
					box2.setSelectedItem(temp[0]);
				}
			});
		    radioGroup.add(bo);
			pan.add(bo);
		}
		JOptionPane.showMessageDialog(Front.front, pan,"选择商品分类   (数字代表商品数量)",0,new ImageIcon());
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==ok){
			ArrayList<String> v=new ArrayList<String>();
			v.add(box1.getSelectedItem()+"");	//科目
			v.add(box2.getSelectedItem()+"");	//大类
			v.add(box3.getSelectedItem()+"");	//小类
			v.add(text[4].getText());			//菜名
			v.add(text[5].getText());			//价格
			v.add(box6.getSelectedItem()+"");	//单位
			v.add(text[7].getText());			//成本
			v.add(text[8].getText());			//库存
			if(che9.isSelected())	v.add("Y");	//锁定
			else v.add("N");
			if(che10.isSelected())	v.add("Y");	//允许打折
			else v.add("N");
			v.add(text[11].getText());			//助记符
			v.add(text[15].getText());			//备注
			//提交菜品
			Sql.mysqlprocedure("menu_add",v);
		}
		else if(e.getSource()==exit){
			dispose();
		}
		else if(e.getSource()==box2){
			String s=box2.getSelectedItem()+"";
			String str[]=Sql.getString("select distinct 小类 from menu where 分类='"+s+"';", this);
			DefaultComboBoxModel<String> d=new DefaultComboBoxModel<String>(str);
			box3.setModel(d);
		}
	}
	@Override
	public void insertUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		text[11].setText(py.String2Alpha(text[4].getText()));	//自动菜品助记符
		if(text[11].getText().contains("0")){
			text[11].setBackground(Color.PINK);
			return ;
		}
		text[11].setBackground(null);
	}
	@Override
	public void removeUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		insertUpdate(e);
	}
	@Override
	public void changedUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		
	}
}
