package bar;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import pub.DateUI;
import root.Front;
import root.Sql;
public class BarLog extends JPanel implements ActionListener{
	private static final long serialVersionUID = -5671013107914868347L;
	private JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JButton refresh=getButton("刷新");
	private JButton near=getButton("最近记录");
	private JButton back=getButton("商品退回");
	private JTextField text=new JTextField("",15);
	private JTextField date=new JTextField(10);
	private JTable t=Sql.getTable();
	
	//注意，默认查最近产生的数据，并且是倒序
	private String sql;
	private String col="索引,属性,商品编号,分类,商品名,实价,单位,数量,点单员,点单时间,备注";
	public BarLog(final String s){
		setOpaque(false);
	    setLayout(new BorderLayout());
	    text.getDocument().addDocumentListener(new DocumentListener() {
	    	private Popup up;	    	
			public void removeUpdate(DocumentEvent e) {
				insertUpdate(e);
			}
			public void insertUpdate(DocumentEvent e) {
				text.setName("");	//复位
				Popup p=new Popup(s);
				if(p.getComponentCount()>0){
					p.show(text, text.getWidth(),1);
					up=p;
				}
				else{
					if(up!=null) up.setVisible(false);
				}
			}
			public void changedUpdate(DocumentEvent e) {}
		});
	    date.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e){
				DateUI du = new DateUI();
				date.setText(du.toString());
				
				String d=date.getText();
				String v=text.getName();
				if(d.isEmpty()) return ;
				if((v==null)||(v.isEmpty())){
					sql="select "+col+" from dish where 台次=0 and date(点单时间)=date('"+d+"')";
					sql=sql+" union select "+col+" from hqdish where 台次=0 and date(点单时间)=date('"+d+"') order by 索引 desc";
				}
				else{
					sql="select "+col+" from dish where 台次=0 and date(点单时间)=date('"+d+"') and 商品名 ='"+v+"' ";
					sql=sql+" union select "+col+" from hqdish where 台次=0 and date(点单时间)=date('"+d+"') and 商品名 ='"+v+"' order by 索引 desc";
				}
				refresh();
			}
		});
	    
	    nor.add(new JLabel("  查询(商品名或助记符):"));
	    nor.add(text);
	    nor.add(new JLabel("  日期过滤:"));
	    nor.add(date);
	    t.addMouseListener(new MouseAdapter() {
	    	public void mouseClicked(MouseEvent e) {
				if(e.getClickCount()==2){
					dishback();
				}
			}
		});
	    add(nor,BorderLayout.NORTH);
	    add(new JScrollPane(t),BorderLayout.CENTER);
	}

	private JButton getButton(String s){
		JButton b=new JButton(s);
		b.addActionListener(this);
		nor.add(b);
		return b;
	}
	
	private void refresh(){
		if(sql!=null&&!sql.isEmpty()){
			int k=t.getSelectedRow();
			Sql.getArrayToTable(sql, this, t);
			Sql.TableAtt(t, true, false);
			if((k!=-1)&&(t.getRowCount()>k)){
				t.setRowSelectionInterval(k, k);
			}
			Sql.TableAtt(t, true, false);
		}
	};
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==refresh){
			refresh();
		}
		else if(e.getSource()==back){
			dishback();
		}
		else if(e.getSource()==near){
			sql="select "+col+" from dish where 台次=0";
			sql=sql+" union select "+col+" from hqdish where 台次=0 order by 索引 desc limit 0,100";
			refresh();
		}
	}
	
	private void dishback(){
		int k=t.getSelectedRow();
		if(k>=0){
			JPanel nor = new JPanel();
			nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
			//如果输入的值不在指定范围内，则getValue()时会得到默认值:1,如果不指定为double型，则自动取整
			final JSpinner num=new JSpinner(new SpinnerNumberModel(1,-100d,1000d,1));
			final JTextField money=new JTextField(8);
			JTextField remark=new JTextField(24);
		
			JPanel pan=new JPanel(new FlowLayout(FlowLayout.LEFT)); 
			JLabel lab=new JLabel("退回数量：");
			lab.setForeground(Color.RED);
			pan.add(lab);
			pan.add(num);
			lab=new JLabel("   退款金额：");
			lab.setForeground(Color.RED);
			pan.add(lab);
			pan.add(money);
			nor.add(pan);
			nor.add(Box.createVerticalStrut((8)));

			pan=new JPanel(new FlowLayout(FlowLayout.LEFT)); 
			pan.add(new JLabel("操作备注："));
			pan.add(remark);
			nor.add(pan);
			nor.add(new JSeparator());

			money.setEditable(false);
			money.setBackground(Color.MAGENTA);
			money.setText(Sql.getval(t, "实价", k));
			num.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					try{
						double val=Double.valueOf(num.getValue().toString());
						double price=Double.valueOf(Sql.getval(t, "实价", t.getSelectedRow()));
						money.setText(val*price+"");
					}catch (Exception e) {e.printStackTrace();}
				}
			});
			num.setValue(Double.valueOf(Sql.getval(t, "数量", k)));
			
			int m=JOptionPane.showConfirmDialog(Front.front, nor, "退回商品", 2, 1, new ImageIcon());
			if(m==0){
				ArrayList<String> v=new ArrayList<String>();
				v.add(Sql.getval(t, "索引", k));
				v.add(num.getValue().toString());
				v.add(remark.getText());
				Sql.mysqlprocedure("bar_back",v);
				refresh();
			}
		}
		else{
			JOptionPane.showMessageDialog(Front.front,"请先选择目标商品","错误 Error",0);
		}
	}
	
	/*
	 * 内部类
	 * */
	class Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -18259196L;
		Popup(String cla){
			String s=text.getText();
			if(!text.getText().isEmpty()){
				String sql="select 编号,商品名 from menu where '"+cla+"' like concat('%',分类,'%') " +
						"and (助记符 like '%"+s+"%' or 商品名 like '%"+s+"%') limit 0,32";
				JTable dishTable=Sql.getTable(sql, BarLog.this);
				
				for(int row=0;row<dishTable.getRowCount();row++){
					String m=dishTable.getValueAt(row, 0).toString();
					String n=dishTable.getValueAt(row, 1).toString();
					JMenuItem a = new JMenuItem(m+" "+n);
					a.addActionListener(this);
					add(a);
				}
			}
			setFocusable(false);	//这一句很重要
		}
		public void actionPerformed(ActionEvent e) {
			String s=e.getActionCommand();
			int ind=s.indexOf(" ");
			s=s.substring(ind+1);	//商品名

			text.setName(s); //保存商品名
			date.setText("");
			
			sql="select "+col+" from dish where 台次=0 and 商品名 = '"+s+"'";
			sql=sql+" union select "+col+" from hqdish where 台次=0 and 商品名 = '"+s+"' order by 索引 desc limit 0,100;";
			refresh();
		}
	}
}
