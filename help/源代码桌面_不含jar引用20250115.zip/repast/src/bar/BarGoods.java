package bar;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableColumnModel;
import Menu.MenuDialog;
import root.Front;
import root.Sql;
public class BarGoods extends JPanel implements ActionListener,DocumentListener{
	private static final long serialVersionUID = -5671013107914868347L;
	private JPanel nora=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JPanel norb=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JButton refresh=getButton("刷新");
	private JButton sale=getButton("商品售出");
	private JButton inout=getButton("商品入库/出库");
	private JButton add=getButton("添加商品");
	private JButton goodsClass=getButton("定义吧台商品类别");
	private JButton all=new JButton("所有吧台商品");;
	private JTextField text=new JTextField(15);
	private JTable t=Sql.getTable();
	private String sql="";
	private BarFrame bFrame;
	public BarGoods(BarFrame bFrame){
		this.bFrame=bFrame;
		setOpaque(false);
	    setLayout(new BorderLayout());
	    
	    text.getDocument().addDocumentListener(this);
	    nora.add(new JLabel("  助记符查询:"));
	    nora.add(text);
	    
	    norb.add(all);
	    all.addActionListener(this);
	    String barmenu[]=bFrame.cla.split(", ");
		for(String me : barmenu){
			if(me.isEmpty()) continue ;
			JButton b=new JButton(me);
			b.addActionListener(this);
			norb.add(b);
		}
	    
		JPanel nor=new JPanel();
		nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
	    nor.add(nora);
	    nor.add(new JSeparator());	//分割线
	    nor.add(norb);
	    add(nor,BorderLayout.NORTH);
	    add(new JScrollPane(t),BorderLayout.CENTER);
	    
	    t.addMouseListener(new MouseAdapter() {
	    	public void mouseClicked(MouseEvent e) {
	    		if(e.getClickCount()==2){
	    			dishsale();
	    		}
			}
		});
	    
	    sql="select * from menu where '"+bFrame.cla+"' like concat('%',分类,'%') order by 分类 limit 0,100";
	    refresh();	//默认显示频率前100的商品
	}
	
	private JButton getButton(String s){
		JButton b=new JButton(s);
		b.addActionListener(this);
		nora.add(b);
		return b;
	}
	
	private void refresh(){
		int k=t.getSelectedRow();
		Sql.getArrayToTable(sql, this, t);
		if((k!=-1)&&(t.getRowCount()>k)){
			t.setRowSelectionInterval(k, k);
		}
		int col=t.getColumnCount();
		TableColumnModel colmod=t.getColumnModel();
		//删除不需要的例
		while(t.getColumnCount()>col-4){
			t.removeColumn(colmod.getColumn(col-4));
		}
		
		Sql.TableAtt(t, true, false);
	};
	
	private void dishinout(){
		int k=t.getSelectedRow();
		if(k==-1){
			JOptionPane.showMessageDialog(Front.front,"请先选择目标商品","错误 Error",0);
			return ;
		}
		JPanel nor = new JPanel();
		nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
		JSpinner val=new JSpinner(new SpinnerNumberModel(1,-100d,1000d,1));
		JTextField remark=new JTextField(22);
		JRadioButton ma=new JRadioButton("入库");
		JRadioButton mb=new JRadioButton("出库");
		ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
		radioGroup.add(ma);
		radioGroup.add(mb);
		
		JPanel pan=new JPanel(new FlowLayout(FlowLayout.LEFT)); 
		pan.add(new JLabel("操作方式："));
		ma.setSelected(true);
		pan.add(ma);
		pan.add(mb);
		nor.add(pan);
		
		pan=new JPanel(new FlowLayout(FlowLayout.LEFT)); 
		pan.add(new JLabel("商品数量："));
		pan.add(val);
		nor.add(pan);
		
		pan=new JPanel(new FlowLayout(FlowLayout.LEFT)); 
		pan.add(new JLabel("操作备注："));
		pan.add(remark);
		nor.add(pan);
		nor.add(new JSeparator());
		
		int m=JOptionPane.showConfirmDialog(Front.front, nor, "商品入库/出库", 2, 1, new ImageIcon());
		if(m==0){
			ArrayList<String> v=new ArrayList<String>();
			v.add(Sql.getval(t, "编号", k));
			if(ma.isSelected()) v.add(ma.getText());
			if(mb.isSelected()) v.add(mb.getText());
			v.add(val.getValue().toString());
			v.add(remark.getText());
			Sql.mysqlprocedure("bar_inout",v);
			refresh();
		}
	}
	
	private void dishsale(){
		int k=t.getSelectedRow();
		if(k<0){
			JOptionPane.showMessageDialog(Front.front,"请先选择目标商品","错误 Error",0);
			return ; 
		}
		JPanel nor = new JPanel();
		nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
		final JSpinner num=new JSpinner(new SpinnerNumberModel(1,-100d,1000d,1));
		final JTextField money=new JTextField(10);
		JTextField remark=new JTextField(24);
	
		JPanel pan=new JPanel(new FlowLayout(FlowLayout.LEFT)); 
		pan.add(new JLabel("商品数量："));
		pan.add(num);
		pan.add(new JLabel("   总金额："));
		pan.add(money);
		nor.add(pan);
		nor.add(Box.createVerticalStrut((8)));

		pan=new JPanel(new FlowLayout(FlowLayout.LEFT)); 
		pan.add(new JLabel("操作备注："));
		pan.add(remark);
		nor.add(pan);
		nor.add(new JSeparator());

		money.setEditable(false);
		money.setBackground(Color.LIGHT_GRAY);
		money.setText(Sql.getval(t, "价格", k));
		num.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				try{
					double val = Double.valueOf(num.getValue().toString());
					double price=Double.valueOf(Sql.getval(t, "价格", t.getSelectedRow()));
					money.setText(val*price+"");
				}catch (Exception e) {System.out.println("数量不是有效数字");}
			}
		});
		
		int m=JOptionPane.showConfirmDialog(Front.front, nor, "售出商品: "+Sql.getval(t, "商品名", k), 2, 1, new ImageIcon());
		if(m==0){
			ArrayList<String> v=new ArrayList<String>();
			v.add("0");	//台次
			v.add(Sql.getval(t, "编号", k));
			v.add(num.getValue().toString());
			v.add(Sql.getval(t, "价格", k));
			v.add(remark.getText());
			Sql.mysqlprocedure("dish_order",v);
			refresh();
		}
	}
	
	public void changedUpdate(DocumentEvent arg0) {}
	public void insertUpdate(DocumentEvent arg0) {
		String s=text.getText();
		if(s.isEmpty()) return ;
		
		if(bFrame.cla.isEmpty()){
			JOptionPane.showMessageDialog(Front.front,"未定义隶属于吧台的商品类别","错误 Error",0);
		}
		else{
			sql="select * from menu where '"+bFrame.cla+"' like concat('%',分类,'%') " +
					"and (商品名 like '%"+s+"%' or 助记符 like '%"+s+"%') limit 0,100;";
			refresh();
		}
	}
	public void removeUpdate(DocumentEvent arg0) {
		insertUpdate(arg0);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==refresh){
			refresh();
		}
		else if(e.getSource()==add){
			new MenuDialog(false);
		}
		else if(e.getSource()==goodsClass){
			bFrame.part();
			//重新初始化
			norb.removeAll();
			norb.add(all);
			all.addActionListener(this);
			String barmenu[] = bFrame.cla.split(", ");
			for (String me : barmenu) {
				if (me.isEmpty()) continue ;
				JButton b = new JButton(me);
				b.addActionListener(this);
				norb.add(b);
			}
			norb.setVisible(false);
			norb.setVisible(true);
		}
		else if(e.getSource()==inout){
			dishinout();
		}
		else if(e.getSource()==sale){
			dishsale();
		}
		else if(e.getSource()==all){
			sql="select * from menu where '"+bFrame.cla+"' like concat('%',分类,'%') order by 分类 ";
		    refresh();
		}
		else{
			String s=e.getActionCommand();
			//看效果
			sql="select * from menu where 分类='"+s+"';";
		    refresh();
		}
	}
}
