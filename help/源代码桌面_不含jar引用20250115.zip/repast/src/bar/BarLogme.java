package bar;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import pub.DateUI;
import root.Sql;
public class BarLogme extends JPanel implements ActionListener{
	private static final long serialVersionUID = -5671013107914868347L;
	private JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JButton refresh=getButton("刷新");
	private JButton near=getButton("最近记录");
	private JTextField text=new JTextField("",15);
	private JTextField date=new JTextField(10);
	private JTable t=Sql.getTable();
	//注意，默认查最近产生的数据，并且是倒序
	private String sql;
	private String cla;
	public BarLogme(String s){
		cla=s;
		setOpaque(false);
	    setLayout(new BorderLayout());
	    
	    text.getDocument().addDocumentListener(new DocumentListener() {
	    	private Popup up;	    	
			public void removeUpdate(DocumentEvent e) {
				insertUpdate(e);
			}
			public void insertUpdate(DocumentEvent e) {
				text.setName("");	//复位
				Popup p=new Popup();
				if(p.getComponentCount()>0){
					p.show(text, text.getWidth(),1);
					up=p;
				}
				else{
					if(up!=null) up.setVisible(false);
				}
			}
			public void changedUpdate(DocumentEvent e) {}
		});
	    
	    date.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e){
				DateUI du = new DateUI();
				date.setText(du.toString());  
				
				String d = date.getText();
				String v = text.getName();
				if(d.isEmpty()) return ;
				if((v==null)||(v.isEmpty())){
					sql="select * from dish where date(点单时间)=date('"+d+"') and 台次!=0 and '"+cla+"' like concat('%',分类,'%')";
					sql=sql+" union select * from hqdish where date(点单时间)=date('"+d+"') and 台次!=0 and '"+cla+"' like concat('%',分类,'%') order by 索引 desc";
				}
				else{
					sql="select * from dish where date(点单时间)=date('"+d+"') and 台次!=0 and 商品名 ='"+v+"' and '"+cla+"' like concat('%',分类,'%')";
					sql=sql+" union select * from hqdish where date(点单时间)=date('"+d+"') and 商品名 ='"+v+"' and 台次!=0 and '"+cla+"' like concat('%',分类,'%') order by 索引 desc";
				}
				refresh();
			}
		});
	    
	    nor.add(new JLabel("  查询(商品名或助记符):"));
	    nor.add(text);
	    nor.add(new JLabel("  日期过滤:"));
	    nor.add(date);
	    add(nor,BorderLayout.NORTH);
	    add(new JScrollPane(t),BorderLayout.CENTER);
	}

	private JButton getButton(String s){
		JButton b=new JButton(s);
		b.addActionListener(this);
		nor.add(b);
		return b;
	}
	
	private void refresh(){
		if(sql!=null&&!sql.isEmpty()){
			int k=t.getSelectedRow();
			Sql.getArrayToTable(sql, this, t);
			Sql.TableAtt(t, true, false);
			if((k!=-1)&&(t.getRowCount()>k)){
				t.setRowSelectionInterval(k, k);
			}
			Sql.TableAtt(t, true, false);
		}
	};
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==refresh){
			refresh();
		}
		//最近一百条记录
		else if(e.getSource()==near){
			sql="select * from dish where '"+cla+"' like concat('%',分类,'%') and 台次!=0";
			sql=sql+" union select * from hqdish where '"+cla+"' like concat('%',分类,'%') and 台次!=0 order by 索引 desc limit 0,100;";
			refresh();
		}
	}
	
	/*
	 * 内部类
	 * */
	class Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -18259196L;
		Popup(){
			String s=text.getText();
			if(!text.getText().isEmpty()){
				String sql="select 编号,商品名 from menu where '"+cla+"' like concat('%',分类,'%') " +
						"and (助记符 like '%"+s+"%' or 商品名 like '%"+s+"%') limit 0,32";
				JTable dishTable=Sql.getTable(sql, BarLogme.this);
				
				for(int row=0;row<dishTable.getRowCount();row++){
					String m=dishTable.getValueAt(row, 0).toString();
					String n=dishTable.getValueAt(row, 1).toString();
					JMenuItem a = new JMenuItem(m+" "+n);
					a.addActionListener(this);
					add(a);
				}
			}
			setFocusable(false);	//这一句很重要
		}
		public void actionPerformed(ActionEvent e) {
			String s=e.getActionCommand();
			int ind=s.indexOf(" ");
			s=s.substring(ind+1);	//商品名
			
			text.setName(s); //保存商品名
			date.setText("");
			
			sql="select * from dish where '"+cla+"' like concat('%',分类,'%') and 商品名 = '"+s+"' and 台次!=0";
			sql=sql+" union select * from dish where '"+cla+"' like concat('%',分类,'%') and 商品名 = '"+s+"' and 台次!=0 order by 索引 desc limit 0,100;";
			refresh();
		}
	}
}
