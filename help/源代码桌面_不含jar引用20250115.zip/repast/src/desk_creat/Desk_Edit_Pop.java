package desk_creat;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.JSpinner.DefaultEditor;

import root.Front;
import root.Sql;
public class Desk_Edit_Pop extends JPopupMenu implements ActionListener{
	private static final long serialVersionUID = -182455400196L;
	private tableLab lab;
	private Desk_Table dt;
	private JMenuItem b = new JMenuItem("属性 Attribute");
	private JMenuItem e = new JMenuItem("新增台号 Add_Desk");
	private JMenuItem f = new JMenuItem("区域前辍(排序) Area_Number");
	private JMenuItem g = new JMenuItem("区域更名 Area_change");
	private JMenuItem h = new JMenuItem("区域新增 Area_add");
	private JMenuItem i = new JMenuItem("删除台号 Delete_Desk");	//删除某一区域的所有台号即为删除区域功能
	//传入参数，餐区、台号、标签、餐次
	public Desk_Edit_Pop(tableLab lab,Desk_Table dt){
		this.lab=lab;
		this.dt=dt;
		
		b.addActionListener(this);
		e.addActionListener(this);
		f.addActionListener(this);
		g.addActionListener(this);
		h.addActionListener(this);
		i.addActionListener(this);

		add(e);
		add(i);
		addSeparator();
		add(f);
		add(g);
		add(h);
		addSeparator();
		add(b);
	}
	public void actionPerformed(ActionEvent es) {
		ArrayList<String> v=new ArrayList<String>();
		//台号属性
		if(es.getSource()==b){
			String sql="select 别名,容客量,简述 from desk where 区域='"+lab.dep+"' and 台号="+lab.ind;
			String str[]=Sql.getString(sql, this);
			if(str.length>0){
				JPanel nor = new JPanel();
				nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
				JTextField name=new JTextField(str[0],20);
				JSpinner many=new JSpinner(new SpinnerNumberModel(1,0,Integer.MAX_VALUE,1));
				DefaultEditor editor = (DefaultEditor)many.getEditor();
				editor.getTextField().setEditable(false);
				many.setValue(Integer.valueOf(str[1]));
				many.setPreferredSize(new Dimension(233, 30));
				JTextArea info=new JTextArea(3,20);
				info.setLineWrap(true); 		//自动换行
		    	info.setWrapStyleWord(true);	//单词换行不拆分
				info.setText(str[2]);
				
				JPanel pan=new JPanel(new FlowLayout()); 
				pan.add(new JLabel("台号别名："));
				pan.add(name);
				nor.add(pan);
				
				pan=new JPanel(new FlowLayout()); 
				pan.add(new JLabel("最大容客："));
				pan.add(many);
				nor.add(pan);
				
				pan=new JPanel(new FlowLayout()); 
				pan.add(new JLabel("扼要简述："));
				pan.add(info);
				nor.add(pan);
				
				int action=JOptionPane.showConfirmDialog(Front.front,nor,"台号属性编辑",2,1,new ImageIcon());
				if(action==0){
					v.add(lab.dep);		//区域
					v.add(lab.ind+"");	//台号
					v.add(name.getText());		//别名
					v.add(many.getValue().toString());		//人数
					v.add(info.getText());		//备注
					Sql.mysqlprocedure("desk_attribute",v);
				}
			}
		}
		//添加台号
		else if(es.getSource()==e){
			String s=JOptionPane.showInputDialog(Front.front, "请输入 新台号的编号：", "0");
			if(s==null) return ;
			v.add(lab.dep);
			v.add(s);
			v.add("add");
			boolean b=Sql.mysqlprocedure("desk_add_del",v);
			if(b){
				reload();
			}
		}
		//删除台号
		else if(es.getSource()==i){
			int val=JOptionPane.showConfirmDialog(Front.front, "确定删除 "+lab.dep+lab.ind+"号台 吗？", i.getText(), 0);
			if(val==0){
				v.add(lab.dep);
				v.add(lab.ind+"");
				v.add("del");
				boolean b=Sql.mysqlprocedure("desk_add_del",v);
				if(b){
					reload();
				}
			}
		}
		//区域前辍
		else if(es.getSource()==f){
			String sql="select distinct 区域,前辍 from desk order by 前辍 asc";
			JTable t = new JTable();
			Sql.getArrayToTable(sql, this, t);
			JScrollPane temp=new JScrollPane(t);
			
			temp.setPreferredSize(new Dimension(280,280));
			int x=JOptionPane.showConfirmDialog(Front.front,temp,"区域排序(变更数据后请取消编辑状态)",2,1,new ImageIcon());
			if(x==0){
				for(int m=0;m<t.getRowCount();m++){
					ArrayList<String> vv=new ArrayList<String>();
					vv.add(t.getValueAt(m, 0)+"");
					vv.add("");	//新名字
					vv.add(t.getValueAt(m, 1)+"");	//前辍
					vv.add("newhead");
					Sql.mysqlprocedure("desk_area",vv);
				}
				reload();
			}
		}
		//区域更名
		else if(es.getSource()==g){
			String val=JOptionPane.showInputDialog(null,g.getText(),lab.dep);
			if(val==null) return ;
			
			v.add(lab.dep);
			v.add(val);	//新名字
			v.add("0");	//前辍
			v.add("newname");
			boolean b=Sql.mysqlprocedure("desk_area",v);
			if(b){
				reload();
			}
		}
		//区域新增
		else if(es.getSource()==h){
			String val=JOptionPane.showInputDialog(null,h.getText(),"新区域");
			if(val==null) return ;
			
			v.add(val);
			v.add("");	//新名字
			v.add("0");	//前辍
			v.add("add");
			boolean b=Sql.mysqlprocedure("desk_area",v);
			if(b){
				reload();
			}
		}
	}
	private void reload(){
		dt.init_Lab();		//重新初始化
		dt.actionPerformed(null);
	}
}
