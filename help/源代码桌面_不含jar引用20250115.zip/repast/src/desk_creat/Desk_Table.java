package desk_creat;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import pub.Var;
import root.Front;
import root.Sql;
import desk_portal.Desk_Frame;
import desk_portal.Desk_start;
public class Desk_Table extends JInternalFrame implements ActionListener,MouseListener{
	private static final long serialVersionUID = 732044458757668L;
	private final JPanel Pan=new JPanel(new BorderLayout());
	private final JButton refresh=new JButton("刷新");
	
	//卡片台号均放在cp里面
	private JPanel cp=new JPanel();	
	public tableLab[][] lab;
	private int lm,ln;

	public final JCheckBox ch1=new JCheckBox("未开台");
	public final JCheckBox ch2=new JCheckBox("已开台 0");
	public final JCheckBox ch3=new JCheckBox("挂起 0");
	public final JCheckBox ch4=new JCheckBox("已结账 0");
	public final JCheckBox tar=new JCheckBox("忽略挂起和已结账");
	public final JCheckBox liti=new JCheckBox("卡片特效");
	
	public Desk_Table(){
		
		super("表格方式 时态图",true,true,true,true);
		setContentPane(Pan);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
	    init_Lab();	//首次运行初始化
	    
	    Pan.add(nor(),BorderLayout.NORTH);
	    JPanel temp=new JPanel(new BorderLayout());
	    temp.add(cp,BorderLayout.NORTH);
	    
	    JScrollPane js=new JScrollPane(temp);
		js.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
   	    Pan.add(js,BorderLayout.CENTER);
   	    
   	    cp.setComponentPopupMenu(new newArea());
	    
	    ch1.addActionListener(this);
	    ch2.addActionListener(this);
	    ch3.addActionListener(this);
	    ch4.addActionListener(this);
	    tar.addActionListener(this);
	    liti.addActionListener(this);
	    
	    refresh.doClick();
	}
	
	public void init_Lab(){
		ln=Var.area(true).length;	//更新区域信息,如新增了餐区

		//更新lab
		String rowmax[]=Sql.getString("select max(台号) from desk", this);
		lm=Integer.valueOf(rowmax[0]);
		
		lab=new tableLab[lm+1][ln];
		
		//将lab加入cp中
		cp.removeAll();	//清空
		cp.setLayout(new GridLayout(lm+1,ln));
		for(int x=0;x<lm+1;x++){
			for(int y=0;y<ln;y++){
				lab[x][y]=new tableLab(Var.area()[y],x);
				lab[x][y].X=x;
				lab[x][y].Y=y;
				cp.add(lab[x][y]);
			}
		}
	}
	
	private JPanel nor(){
		JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT));
		refresh.addActionListener(this);
		p.add(refresh);
		p.add(ch1);
		p.add(ch2);
		p.add(ch3);
		p.add(ch4);
		p.add(tar);
		p.add(liti);
		ch1.setSelected(true);
		ch2.setSelected(true);
		JLabel cot=new JLabel("<html><body><font color=red>■</font><font color=green>●</font><font color=blue>▲</font><font color=black><b>★</b></font></body></html>");
		String s="<font color=white>■</font>空台<br><font color=blue>■</font>已开台<br><font color=red>■</font>脏台<br><font color=yellow>■</font>预定、维修、停用<br>"
				+"<font color=red>●</font>早餐<br><font color=green>●</font>中餐<br><font color=blue>●</font>晚餐<br><font color=black>●</font>夜宵、其它<br>"
				+"<font color=blue>▲</font>有挂起台次<br><font color=blue>★</font>有历史结账<br>";
		cot.setToolTipText("<html><body>"+s+"</body></html>");
		p.add(new JLabel("     "));
		p.add(cot);
		p.add(new JLabel("     在卡台区域单击右键可以增减卡台操作"));
		return p;
	}
	
	public void actionPerformed(ActionEvent e){
		
		Front.selected = refresh;
		
		//复位
		ch2.setText("已开台 0");
		ch3.setText("挂起 0");
		ch4.setText("已结账 0");
   	    
		for(final tableLab A[] : lab){
	    	for(tableLab B : A){
	    		B.setText("");
	    	}
	    }
		
   	    //第一行标题数据
	    for(int x=0;x<ln;x++){
		    lab[0][x].setBackground(Color.LIGHT_GRAY);
		    lab[0][x].setOpaque(true);
		    lab[0][x].setText(Var.area()[x]);
	    }
	    
	    final Desk_Table_EDT edt = new Desk_Table_EDT(this);
	    edt.execute();
	}
	
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent e) {
		tableLab p=(tableLab)e.getSource();
		p.setBackground(Color.pink);
	}
	public void mouseExited(MouseEvent e) {
		tableLab p=(tableLab)e.getSource();
		p.setBackground(null);
	}
	public void mousePressed(MouseEvent e) {
		tableLab lab=(tableLab)e.getSource();
		String dep=lab.dep;
		String ind=lab.ind;
		
		//点击了右键
		if(e.getButton() == MouseEvent.BUTTON3){
			Desk_Edit_Pop po = new Desk_Edit_Pop(lab,this);	//右键菜单
			po.show(e.getComponent(), e.getX(), e.getY());
		}
		
		//左键
		if(e.getButton() == MouseEvent.BUTTON1){
			String wh="WHERE 区域='"+dep+"' and 台号="+ind;
			String sql="SELECT '已开台' as '状态',台次,区域,台号,别名,选择时段 from deskgo "+wh+" and 开台时间 in (select 操作时间 from desk)";
			sql=sql+" UNION ALL ";
			sql=sql+"SELECT 状态,'X',区域,台号,别名,'' from desk "+wh+" and 状态!='已开台'";
			if(!tar.isSelected()){	//是否对挂起和已结账进行忽略
				sql=sql+" UNION ALL ";
				sql=sql+"SELECT '挂起',台次,区域,台号,别名,选择时段 from deskgo "+wh+" and 开台时间 not in (select 操作时间 from desk) and isnull(结账时间)";
				sql=sql+" UNION ALL ";
				sql=sql+"SELECT '已结账',台次,区域,台号,别名,选择时段 from deskgo "+wh+" and not isnull(结账时间)";
			}
			
			//注意表t结果至少有一行数据
			JTable t = Sql.getTable() ;
			Sql.getArrayToTable(sql, this, t);
			if(t.getRowCount()==0){
				JOptionPane.showMessageDialog(this, "没有关于 "+dep+" "+ind+"号台 的任何信息，请检查最近的sql语句。");
				return ;
			}
			
			if(t.getRowCount()==1){
				String temp=Sql.getval(t, "台次", 0);	//餐次
				if(temp.equals("X")){
					new Desk_start("0", dep, ind);
				}
				else{
					//保存状态
			    	Front.N = Front.front.NorthPanel.isVisible();
			    	Front.W = Front.front.WestPanel.isVisible();
			    	Front.S = Front.front.SouthPanel.isVisible();
			    	
					final Desk_Frame db = new Desk_Frame(Integer.valueOf(temp));
					Front.inFrame.add(db);
				}
				return ;
			}
			
			JScrollPane jsp=new JScrollPane(t);
			jsp.setPreferredSize(new Dimension(400, 200));
			int x=JOptionPane.showConfirmDialog(this,jsp,"选择目标台次",2,1,new ImageIcon());
			if(x!=0) return ;
			
			if(t.getSelectedRowCount()==1){
				String temp=Sql.getval(t, "台次", t.getSelectedRow());	//餐次
				if(temp.equalsIgnoreCase("X")){
					final Desk_start ds=new Desk_start("0", dep, ind);
					JOptionPane.showMessageDialog(this, ds, "开台信息", 1, new ImageIcon());
				}
				else{
					//保存状态
			    	Front.N = Front.front.NorthPanel.isVisible();
			    	Front.W = Front.front.WestPanel.isVisible();
			    	Front.S = Front.front.SouthPanel.isVisible();
			    	
					Desk_Frame db = new Desk_Frame(Integer.valueOf(temp));
					Front.inFrame.add(db);
				}
			}
			else{
				JOptionPane.showMessageDialog(this, "没有选择数据行。");
			}
		}
	}
	public void mouseReleased(MouseEvent e) {}
	
	class newArea extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -614056938789735110L;
		private JMenuItem a = new JMenuItem("新增营业区域");
	    private newArea(){
	    	a.addActionListener(this);
	    	add(a);
	    }
		public void actionPerformed(ActionEvent e) {
			String val=JOptionPane.showInputDialog(null,"增加营业区域","新区域");
			if(val==null) return ;
			
			ArrayList<String> v=new ArrayList<String>();
			v.add(val);
			v.add("");		//新名字
			v.add("0");		//前辍
			v.add("add");
			boolean boo=Sql.mysqlprocedure("desk_area",v);
			if(boo){
				init_Lab();
				Desk_Table.this.actionPerformed(null);
			}
		}
    }
}

//自定义标签JLabel
class tableLab extends JLabel{
	private static final long serialVersionUID = -6230401433705801172L;
	public String dep,ind,text;
	public int X,Y;
	public tableLab(String dep,int ind){
		super("",JLabel.CENTER);
		this.dep=dep;
		this.ind=ind+"";
	}
}

