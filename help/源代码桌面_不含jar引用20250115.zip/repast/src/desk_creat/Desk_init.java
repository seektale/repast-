package desk_creat;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.SwingWorker;
import pub.ModifiedFlowlayout;
import pub.Panel2D;
import pub.Var;
import root.Front;
import root.Sql;
public class Desk_init extends JInternalFrame implements ActionListener{
	private static final long serialVersionUID = 4198344442491908L;
	private JToolBar jtb = new JToolBar();	//放在上面的工具条
	private JPanel p=new JPanel();
    private dcing dcgo;
	private Desk_card_mouse dcm=new Desk_card_mouse();		//鼠标事件
    
	//建立一个可关闭、可更改大小、具有标题、可最大化与最小化的Internal Frame.
	//JInternalFrame(String title,boolean resizable,boolean closable,boolean maximizable,boolean iconifiable)
	public Desk_init(){
		super("卡片方式 时态图",true,true,true,true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
		Panel2D root=new Panel2D();
		root.setLayout(new BorderLayout());
		
		root.add("North",jtb);
		p.setLayout(new ModifiedFlowlayout(FlowLayout.LEFT,Var.deskhgap(),Var.deskvgap()));
		JScrollPane jj=new JScrollPane(p);
		//jj.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); //水平滚动条永不出现,也许不需要
		jj.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
		//p.addKeyListener(new PressKey());
		
		//透明效果，前两句一个都不能少
		p.setOpaque(false);
		jj.getViewport().setOpaque(false);
		jj.setOpaque(false);
		root.add("Center",jj);
		
		/*******************************************************************************/
		String sql="";
	   	for(int k=0;k<Var.area().length;k++){
	   		//状态，区域，台号，前辍，别名，台次，餐段，工号，开台时间
	   		sql="select desk.状态,desk.区域,desk.台号,desk.`前辍`,desk.`别名`,deskgo.`台次`,deskgo.`选择时段`,desk.`状态说明`,deskgo.`开台时间`,deskgo.锁台 from ";
	   		sql=sql+"desk LEFT JOIN deskgo on desk.`区域`=deskgo.`区域` and desk.台号=deskgo.台号 and desk.`操作时间`=deskgo.`开台时间` ";
	   		sql=sql+"WHERE desk.`区域`='"+Var.area()[k]+"' order by 台号;";
	   		addbutton(Var.area()[k],sql);
	   	}
	   	
	   	//排序中'前辍'可以保证餐区排序不会发生变动（只要前辍参数不变），deskgo.`开台工号` 目前这一列没有意义，备用吧
	   	sql="select desk.状态,desk.区域,desk.台号,desk.`前辍`,desk.`别名`,deskgo.`台次`,deskgo.`选择时段`,deskgo.`开台工号`,deskgo.`开台时间`,deskgo.锁台 from ";
   		sql=sql+"desk LEFT JOIN deskgo on desk.`区域`=deskgo.`区域` and desk.台号=deskgo.台号 and desk.`操作时间`=deskgo.`开台时间` ";
   		sql=sql+"order by 前辍,台号;";
	   	addbutton("全区域",sql);
	   	
	   	sql="select '已开台',desk.区域,desk.台号,desk.`前辍`,desk.`别名`,deskgo.`台次`,deskgo.`选择时段`,deskgo.`开台工号`,deskgo.`开台时间`,deskgo.锁台 from ";
   		sql=sql+"desk LEFT JOIN deskgo on desk.`区域`=deskgo.`区域` and desk.台号=deskgo.台号 and desk.`操作时间`=deskgo.`开台时间` ";
   		sql=sql+"WHERE desk.`状态`='已开台' order by 前辍,台号;";
	   	addbutton("已开台",sql);
	   	
	   	//这里是右连接
	   	sql="select '挂起',deskgo.区域,deskgo.台号,desk.`前辍`,desk.`别名`,deskgo.`台次`,deskgo.`选择时段`,deskgo.`开台工号`,deskgo.`开台时间`,deskgo.锁台 from ";
	   	sql=sql+"desk RIGHT JOIN deskgo on desk.`区域`=deskgo.`区域` and desk.台号=deskgo.台号 ";
	   	sql=sql+"WHERE isnull(`结账时间`) and 开台时间 not in (select 操作时间 from desk) order by 前辍,台号";
	   	addbutton("挂起",sql);
	   	
	   	//这里是右连接
	   	sql="select '已结账',区域,台号,'',`别名`,`台次`,`结账工号`,`选择时段`,`结账时间`,'' from deskgo where not isnull(结账时间) ";
	   	sql=sql+" order by 区域,台号";
	   	addbutton("已结账",sql);
	   	
	   	/******************************************************************************/
	   	
	   	try{	//触发第一个餐区按扭
		   	JButton tembu=(JButton)jtb.getComponent(0);
		   	tembu.doClick();
	   	}catch (Exception e) {}

	   	setContentPane(root);
	    setVisible(true);
	}
	private void addbutton(String title,String sql){
		JButton name=new JButton(title);
		int c=KeyEvent.VK_1+jtb.getComponentCount();
		if(c<=KeyEvent.VK_9){
			name.setText((char)c+name.getText());
			name.setMnemonic(c);	//注册快捷键
		}
		name.setFont(new Font("楷体",Font.PLAIN,18));
		name.addActionListener(this);
		name.setName(sql);
		name.setToolTipText("再次单击 或 按 ALT+对应数字 或 按空格键 可刷新！");
		jtb.add(name);  		//加入到工具条中
	}
	
	//与数据库连接有关的，不要在synchronized()中操作，否则当网连接不上，弹出对话框没有内容，关也关不掉
	//invokeAndWait：后面的程序必须等这个线程（参数中的线程）的东西执行完才能执行
	//invokeLater：      后面的程序和这个参数的线程对象可以并行，异步地执行
	public void actionPerformed(ActionEvent e) {
		
		JButton name=(JButton)e.getSource();
		Front.selected = name;		//记录当前选择的区域
		if(dcgo!=null)	dcgo.cancel(true);

		if(dcgo==null || dcgo.isCancelled() || dcgo.isDone()){
			p.removeAll();
			p.setVisible(false);
			p.setVisible(true);
			dcgo = new dcing(name.getName(),name.getText());
			dcgo.execute();
		}
	}
	
	//得到三天内的所有预定信息
	private ArrayList<String> checkbooking(String cmd){
		ArrayList<String> temp = new ArrayList<String>();
		if(cmd.equals("已开台")) return temp ;
		if(cmd.equals("挂起"))   return temp ;
		if(cmd.equals("已结账")) return temp ;
		String s="select 区域,台号,时段,抵达日期-date(now()) from booking where 抵达日期-date(now())>=0 and 抵达日期-date(now())<3";
		ArrayList<String[]> arr = Sql.getArrayToArrary(s, this);
		for(String val[] : arr){
			temp.add(val[0]+val[1]+val[2]+val[3]);
		}
		return temp;
	}
	
	class dcing extends SwingWorker<List<Desk_Card>, Desk_Card> {
		private String sql,name;
		private dcing(String sql,String name){
			this.sql = sql ;
			this.name = name ;
		}
		protected List<Desk_Card> doInBackground() throws Exception {
			List<Desk_Card> dcarr = new ArrayList<Desk_Card>();
			//从数据库中获取数据
			ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
			if(arr==null || arr.size()<=0) {
				arr = new ArrayList<String[]>();
			}
			ArrayList<String> val = checkbooking(name);
			//循环生成每一个卡台
			for(String temp[] : arr){
				Desk_Card de = new Desk_Card(temp,val);
				de.addMouseListener(dcm);
				publish(de);
				dcarr.add(de);
			}
			return dcarr ;
		}
		protected void process(List<Desk_Card> val){
			if(isCancelled()) return ;
			for(Desk_Card dc : val){
				p.add(dc);
				dc.setVisible(false);
				dc.setVisible(true);
			}
		}
		protected void done() {
			if(isCancelled()) return ;
			//换行
			//p.add(Box.createHorizontalStrut(1920));
			try {
				String temp = "";
				for(Desk_Card dc : get()){
					if(!temp.isEmpty() && !temp.equals(dc.val[1])){
						p.add(Box.createHorizontalStrut(p.getWidth()));
					}
					temp = dc.val[1] ;
					p.add(dc);
				}
				p.setVisible(false);
				p.setVisible(true);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
