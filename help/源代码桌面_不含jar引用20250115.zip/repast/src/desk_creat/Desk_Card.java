package desk_creat;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import pub.Var;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
import desk_portal.Desk_Frame;
import desk_portal.Desk_start;
public class Desk_Card extends JPanel{
	private static final long serialVersionUID = 414312453543L;
	private JLabel one=new JLabel();	//上层一行
	private JLabel two=new JLabel();	//下层一行
	public  String val[];	//状态，区域，台号，前辍，别名，台次，时段，结账方式,锁台
	private ArrayList<String> booking;
	private JLabel ico=new JLabel();
	public Desk_Card(String val[],ArrayList<String> booking) {
		this.val=val;
		this.booking=booking;
		setLayout(null);
		setPreferredSize(new Dimension(Var.deskw(), Var.deskh()));
		setBorder(BorderFactory.createRaisedBevelBorder()); 	//立体效果
		
		//将前辍加上台号
		if (val[2].length() == 1)	val[3]=val[3] + "0" + val[2];
		else						val[3]=val[3] + val[2];
		
		JPanel temp_Panel=new JPanel(new GridLayout(2, 1, 0, 0));
		temp_Panel.setOpaque(false);
		one.setFont(new Font(Var.deskfont(), Font.BOLD, Var.desktextsize()));
		two.setFont(new Font(Var.deskfont(), Font.BOLD, Var.desktextsize()));
		temp_Panel.add(one);
		temp_Panel.add(two);
		temp_Panel.setBounds(8, 5, Var.deskw(), Var.deskh()-8);
		
		ico.setFont(new Font("", Font.BOLD,18));
		ico.setCursor(Cursor.getPredefinedCursor(12));  //鼠标指针为手型
		if(!val[0].equals("已结账")){
			ico.setBounds(Var.deskw()-35, Var.deskh()-30, 22, 22);
			ico.setIcon(Var.getIcon("单选台号"));
			//ico.setText("✍");
			ico.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					sub_Popup popup = new sub_Popup();
					popup.show(ico, e.getX(), e.getY());
				}
			});
			
			//是否锁台,必须判断长度大于0，因为空字符串代表未开台不使用这个功能
			if((val[9].length()>0)&&(!val[9].equals("N"))){
					ico.setText("☂");
					ico.setIcon(null);
			}
			add(ico);
		}

		add(temp_Panel);
		
		setBackground(Var.getColor(val[0]));
		
		if(val[4].isEmpty())	val[4]=val[1];//one.setText(val[1]+"@"+val[3]);
		//else	one.setText(val[4]+"@"+val[3]);		//有别名则将餐区换别名
		one.setText("<html><body>"+val[4]+"<font color=gray>@"+val[3]+"</font></body></html>");
		
		if (val[0].equals("挂起")||val[0].equals("已结账")) {
			if(val[0].equals("已结账"))	two.setText(val[7]+val[5]);
			if(val[0].equals("挂起"))	two.setText(val[0]+val[5]);
			return ;
		}
		
		
		String color="black";
		if(val[0].equals("已开台")){
			val[0]="●";
			if(val[8].length()>16) val[0]=val[0]+val[8].substring(11,16);
			else val[0]=val[0]+"错误";
			
			//不同餐段不同色彩
			if(val[6].equals("早餐"))	color="red";
			if(val[6].equals("中餐"))	color="green";
			if(val[6].equals("晚餐"))	color="blue";
			if(val[6].equals("夜宵"))	color="yellow";
			if(val[6].equals("其它"))	color="white";
		}
		else if(val[0].equals("空台")){
			val[0]=getbooking();
		}
		else if(val[0].equals("预定")){
			val[0]="☏"+getbooking();
		}
		else if(val[0].equals("脏台")){
			val[0]="✘"+getbooking();
			//刚结完账的台号
			if(val[7].indexOf("自动变脏台")>=0) val[0]="￥"+getbooking();
		}
		else if(val[0].equals("联台")){
			val[0]=val[0]+val[7];
		}
		else{
			val[0]=val[0]+getbooking();
		}
		two.setText("<html></p><font color="+color+">" + val[0] + "</font></p></html>");
	}
	//最近三天的预定情况
	private String getbooking(){
		String res = "" ;
		String s = val[1]+val[2];
		
		for(int k=0; k<3; k++){
			int count = 0 ;
			String dd = "" ;
			if(booking.indexOf(s+"早餐"+k)>=0){
				dd="◆";
				count++;
			}
			if(booking.indexOf(s+"中餐"+k)>=0){
				dd="■";
				count++;
			}
			if(booking.indexOf(s+"晚餐"+k)>=0){
				dd="★";
				count++;
			}
			if(booking.indexOf(s+"夜宵"+k)>=0){
				dd="▲";
				count++;
			}
			//❶❷❸
			if(count==0) dd="_";
			if(count==2) dd="❷";
			if(count==3) dd="❸";
			if(count==4) dd="❹";
			res = res + dd ;
		}
		if(res.replace("_", "").isEmpty()) return "";
		return " "+res;
	}
	
	class sub_Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -1825543259196L;
		private JMenuItem lock = new JMenuItem("锁台  Lock_Desk");
		private sub_Popup(){
			sub("并台至...  Union_Desk");
			sub("取消并台  Union_Desk_Cancel");
			sub("换台至...  Change_Desk");
			addSeparator();  //加分隔线
			sub("挂起  Hangup_Desk");
			sub("复台已挂起台号  Back_Desk");
			addSeparator();
			sub("切换为：空台 Ready");
			sub("切换为：联台 Union");
			sub("切换为：脏台 Dirty");
			sub("切换为：维修 Repair");
			sub("切换为：停用 Stop");
			addSeparator();
			add(lock);
			sub("属性 Attribute");
			
			if(val[9].length()>0){
				if(val[9].equals("N")){
					lock.setText("锁台");
				}
				else{
					lock.setText("解锁  ( "+val[9]+" )");
					ico.setText("☂");
					ico.setIcon(null);
				}
			}
			else{
				lock.setEnabled(false);
			}
			lock.addActionListener(this);
		}
		private void sub(String s){
			JMenuItem a = new JMenuItem(s);
			a.addActionListener(this);
			add(a);
		}
		//并台
		private void uniondesk(){
			String sql="SELECT 台次,deskgo.区域,concat(desk.`前辍`,LPAD(deskgo.台号,2,'0')) as 台号,desk.`别名`,desk.`状态` " +
					   "FROM deskgo JOIN desk ON deskgo.`开台时间`=desk.`操作时间` ORDER BY desk.`前辍`,desk.`台号`";
			JTable up = Sql.getTable();
			Sql.getArrayToTable(sql, this, up);
			int k=JOptionPane.showConfirmDialog(Front.front,new JScrollPane(up),"选择目标台号",2,1,new ImageIcon());
			if(k==0){
				int row=up.getSelectedRow();
				if(row==-1){
					SouthPan.warn("没有选择目标台号 ？", 0, true);
					return ;
				}
				ArrayList<String> v=new ArrayList<String>();
				v.add(Sql.getval(up, "台次", row));		//目标台次
				v.add(val[5]);							//源台次
				Sql.mysqlprocedure("desk_union",v);

				//当即刷新看效果
				if(Front.selected!=null){
					Front.selected.doClick();	//刷新台号
				}
			}
		}
		//取消并台
		private void unioncancel(){
			String sql = " select DISTINCT 台次 from dishlog WHERE 动作='并台' AND locate('台次:"+val[5]+"',`说明`)>0 ";
			String me[] = Sql.getString(sql, this);
			
			if(me.length==0){
				JOptionPane.showMessageDialog(Front.front, "没有找到需要<取消并台>的商品","无效",0);
				return ;
			}
			
			ArrayList<String> v=new ArrayList<String>();
			v.add(val[5]);
			if(me.length==1){
				v.add(me[0]);
			}
			if(me.length>1){
				sql = "select 台次,区域,台号,别名,宾客人数,选择时段 from deskgo where 台次 in ("+sql+")";
				JTable up = Sql.getTable();
				Sql.getArrayToTable(sql, this, up);
				JScrollPane jspan = new JScrollPane(up) ;
				jspan.setPreferredSize(new Dimension(450, 120));
				int k=JOptionPane.showConfirmDialog(Front.front,jspan,"选择 <取消并台> 操作要恢复的卡台",2,1,new ImageIcon());
				if(k!=0) return ;
				int row=up.getSelectedRow();
				if(row==-1){
					SouthPan.warn("没有选择目标卡台 ？", 0, true);
					return ;
				}
				v.add(Sql.getval(up, "台次", row));
			}
			Sql.mysqlprocedure("desk_union_cancel",v);
			
			//当即刷新看效果
			if(Front.selected!=null){
				Front.selected.doClick();	//刷新台号
			}
		}
		private void chdesk(){
			JTable t = Sql.getTable();
			String sql="select 区域,concat(前辍,LPAD(台号,2,'0')) as 台号,别名,状态 from desk where 状态='空台' order by 前辍,台号;" ;
			Sql.getArrayToTable(sql, this, t);
			int action=JOptionPane.showConfirmDialog(Front.front,new JScrollPane(t),"请选择空台：",2,1,new ImageIcon());
			int row=t.getSelectedRow();
			if((action==0)&&(row>=0)){
				String a=Sql.getval(t, "区域", row);
				String b=Sql.getval(t, "台号", row);

				ArrayList<String> v=new ArrayList<String>();
				v.add(val[5]);
				v.add(a);
				v.add(b);
				Sql.mysqlprocedure("desk_change",v);
				
				//当即刷新看效果
				if(Front.selected!=null){
					Front.selected.doClick();	//刷新台号
				}
			}
		}
		private void Att(){
			String str[]=Sql.getString("select 别名,容客量,简述 from desk where 区域='"+val[1]+"' and 台号="+val[2], this);
			if(str.length>0){
				JPanel nor = new JPanel();
				nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
				JTextField name=new JTextField(str[0],20);
				JSpinner many=new JSpinner(new SpinnerNumberModel(1,0,Integer.MAX_VALUE,1));
				DefaultEditor editor = (DefaultEditor)many.getEditor();
				editor.getTextField().setEditable(false);
				many.setValue(Integer.valueOf(str[1]));
				many.setPreferredSize(new Dimension(233, 30));
				JTextArea info=new JTextArea(3,20);
				info.setLineWrap(true); 		//自动换行
		    	info.setWrapStyleWord(true);	//单词换行不拆分
				info.setText(str[2]);
				
				JPanel pan=new JPanel(new FlowLayout()); 
				pan.add(new JLabel("台号别名："));
				pan.add(name);
				nor.add(pan);
				
				pan=new JPanel(new FlowLayout()); 
				pan.add(new JLabel("最大容客："));
				pan.add(many);
				nor.add(pan);
				
				pan=new JPanel(new FlowLayout()); 
				pan.add(new JLabel("扼要简述："));
				pan.add(info);
				nor.add(pan);
				
				int action=JOptionPane.showConfirmDialog(Front.front,nor,"台号属性编辑",2,1,new ImageIcon());
				if(action==0){
					ArrayList<String> v=new ArrayList<String>();
					v.add(val[1]);	//区域
					v.add(val[2]);	//台号
					v.add(name.getText());				//别名
					v.add(many.getValue().toString());	//人数
					v.add(info.getText());				//备注
					Sql.mysqlprocedure("desk_attribute",v);
				}
			}
		}
		public void actionPerformed(ActionEvent e) {
			String s=e.getActionCommand();
			if(e.getSource()==lock){
				String how="N";
				if(lock.getText().startsWith("锁台")){
					how="Y";
				}
				
				ArrayList<String> v=new ArrayList<String>();
				v.add(how);
				v.add(val[5]);
				Sql.mysqlprocedure("desk_lock",v);
				
				//当即刷新看效果
				if(Front.selected!=null){
					Front.selected.doClick();	//刷新台号
				}
			}
			else if(s.startsWith("并台")){
				if(val[5].isEmpty()){
					SouthPan.warn("当前台号未开台,并台操作被忽略", 0, true);
					return ;
				}
				uniondesk();
			}
			else if(s.startsWith("取消并台")){
				if(val[5].isEmpty()){
					SouthPan.warn("当前台号未开台,并台操作被忽略", 0, true);
					return ;
				}
				unioncancel();
			}
			else if(s.startsWith("换台")){
				if(val[5].isEmpty()){
					SouthPan.warn("当前台号未开台,换台操作被忽略", 0, true);
					return ;
				}
				chdesk();
			}
			else if(s.startsWith("挂起")){
				if(val[5].isEmpty()){
					SouthPan.warn("当前台号未开台,挂起操作被忽略", 0, true);
					return ;
				}
				Sql.mysqlprocedure("bill_updesk",val[5]);
				//当即刷新看效果
				if(Front.selected!=null){
					Front.selected.doClick();	//刷新台号
				}
			}
			else if(s.startsWith("复台")){
				if(val[5].isEmpty()){
					SouthPan.warn("当前台号未开台,复台操作被忽略", 0, true);
					return ;
				}
				Sql.mysqlprocedure("bill_redesk",val[5]);
				//当即刷新看效果
				if(Front.selected!=null){
					Front.selected.doClick();	//刷新台号
				}
			}
			else if(s.startsWith("属性")){
				Att();
			}
			else{
				s=s.substring(4,s.indexOf(" "));

				String str="";
				if(s.equals("维修")||s.equals("停用")){
					str=JOptionPane.showInputDialog(Front.front, "请输入 "+s+" 事由：", "无");
				}
				if(str==null) return ;
				
				if(s.equals("联台")){
					JTable t = Sql.getTable();
					String sql="select 区域,concat(前辍,LPAD(台号,2,'0')) as 台号,别名,状态 from desk where 状态='已开台' order by 前辍,台号;" ;
					Sql.getArrayToTable(sql, this, t);
					int action=JOptionPane.showConfirmDialog(Front.front,new JScrollPane(t),"请选择目标卡台：",2,1,new ImageIcon());
					int row=t.getSelectedRow();
					if(action!=0) return ;
					if(row==-1){
						JOptionPane.showMessageDialog(Front.front, "未选择目标卡台", "提示：", 0);
						return ;
					}
					
					str=Sql.getval(t, "台号", row);
				}
				
				ArrayList<String> v=new ArrayList<String>();
				v.add(val[1]);
				v.add(val[2]);
				v.add(s);	//餐台状态值
				v.add(str);	//状态备注
				Sql.mysqlprocedure("desk_station_shift",v);
				
		    	//当即刷新看效果
				if(Front.selected!=null){
					Front.selected.doClick();	//刷新台号
				}
			}
		}
	}
}

class Desk_card_mouse extends MouseAdapter{
	Desk_card_mouse(){}
	private String mealk = "0" ;
	private JInternalFrame inf ;
	public void mousePressed(MouseEvent e) {
		Desk_Card d = (Desk_Card)e.getSource();
		
		// 查找被双击的餐台目前是否是开台，从而确定调用哪种方法
		if(d.val[5].isEmpty()){
			new Desk_start("0", d.val[1], d.val[2]);
			return ;
		}
		
		mealk = d.val[5] ;
		Front.N = Front.front.NorthPanel.isVisible();
    	Front.W = Front.front.WestPanel.isVisible();
    	Front.S = Front.front.SouthPanel.isVisible();
    	
		//左键, 隐藏
		if(e.getButton() == MouseEvent.BUTTON1){
			inf = ((JInternalFrame)Front.inFrame.getComponent(0));
			inf.setVisible(false);
			
			Front.front.NorthPanel.setVisible(false);
			Front.front.SouthPanel.setVisible(false);
			Front.front.WestPanel.setVisible(false);
			//Front.front.getJMenuBar().setVisible(false);
		}
	}
	
	@Override
	public void mouseReleased(MouseEvent e) {
		Desk_Frame temp = new Desk_Frame(Integer.valueOf(mealk));
		if(e.getButton() == MouseEvent.BUTTON1){
			//去掉边框
	    	temp.setBorder(BorderFactory.createEmptyBorder());
	    	//去掉标题栏
	    	BasicInternalFrameUI ui = (BasicInternalFrameUI)temp.getUI(); 
	    	ui.setNorthPane(null);
	    	inf.setVisible(true);
		}
		Front.inFrame.add(temp);
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		Desk_Card d=(Desk_Card)e.getSource();
		d.setBorder(BorderFactory.createEtchedBorder());
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		Desk_Card d=(Desk_Card)e.getSource();
		d.setBorder(BorderFactory.createRaisedBevelBorder()); 
	}
}
