package desk_creat;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import pub.Var;
import root.Front;
import root.Sql;
public class Desk_Design extends JInternalFrame implements ActionListener{
	private static final long serialVersionUID = 2955920470363246923L;
    private JPanel Pan=new JPanel(new GridLayout(1,2,3,1));
    private JPanel left=new JPanel(new BorderLayout(1,20));
    private JPanel right=new JPanel(new BorderLayout(1,20));
    //方块餐台属性
    private JTextField deskw=new JTextField();
    private JTextField deskh=new JTextField();
    private JTextField desk_hgap=new JTextField();
    private JTextField desk_vgap=new JTextField();
    private JComboBox<String> desk_fontstyle=new JComboBox<String>();
    private JTextField desk_size=new JTextField();
    private JButton desk_save=new JButton("应用");
    //方块菜品属性
    private JTextField dishw=new JTextField();
    private JTextField dishh=new JTextField();
    private JTextField dish_hgap=new JTextField();
    private JTextField dish_vgap=new JTextField();
    private JComboBox<String> dish_fontstyle=new JComboBox<String>();
    private JTextField dish_size=new JTextField();
    private JButton dish_save=new JButton("应用");
    private JCheckBox dishcol[];
    //logon
    private JLabel logon = new JLabel();
    public Desk_Design(){
		super("餐台设计",true,true,true,true);
		setContentPane(Pan);
	    setResizable(true);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    left.setBorder(BorderFactory.createTitledBorder(""));
	    right.setBorder(BorderFactory.createTitledBorder(""));
	    Pan.add(left);
	    Pan.add(right);
	    GraphicsEnvironment g = GraphicsEnvironment.getLocalGraphicsEnvironment();
		String fontName[] = g.getAvailableFontFamilyNames();
	    
	    //①
	    JPanel deskcolor=new JPanel(new GridLayout(2,4,6,3));
	    deskcolor.setBorder(BorderFactory.createTitledBorder("餐台状态颜色"));
	    deskcolor.add(but("空台"));
	    deskcolor.add(but("已开台"));
	    deskcolor.add(but("脏台"));
	    deskcolor.add(but("联台"));
	    deskcolor.add(but("维修"));
	    deskcolor.add(but("停用"));
	    deskcolor.add(but("挂起"));
	    deskcolor.add(but("已结账"));
	    left.add(deskcolor,BorderLayout.NORTH);
	    
	    //②
	    JPanel deskstyle=new JPanel(new BorderLayout(1,20));
	    JPanel pm=new JPanel(new GridLayout(4,4,6,3));
	    pm.setBorder(BorderFactory.createTitledBorder("方块餐台属性"));
	    pm.add(lab("方块宽度"));
	    pm.add(deskw);
	    pm.add(lab("方块高度"));
	    pm.add(deskh);
	    pm.add(lab("字体样式"));
		desk_fontstyle = new JComboBox<String>(fontName);
	    pm.add(desk_fontstyle);
	    pm.add(lab("字体大小"));
	    pm.add(desk_size);
	    pm.add(lab("水平间距"));
	    pm.add(desk_hgap);
	    pm.add(lab("垂直间距"));
	    pm.add(desk_vgap);
	    pm.add(new JLabel());
	    pm.add(new JLabel());
	    pm.add(new JLabel());
	    pm.add(desk_save);
	    desk_save.addActionListener(this);
	    deskstyle.add(pm,BorderLayout.NORTH);
	    left.add(deskstyle,BorderLayout.CENTER);
	    
	    //③
	    JPanel table_style=new JPanel(new BorderLayout(1,20));
	    JPanel tableCol=new JPanel(new GridLayout(4,5,6,3));
	    tableCol.setBorder(BorderFactory.createTitledBorder("菜品表格列表可显示列过滤(最多可编辑前20列)"));
	    ArrayList<String> col=Sql.getcolname("dish", getClass().getName());
	    dishcol=new JCheckBox[col.size()];
	    for(int m=0;m<col.size();m++){
	    	dishcol[m]=myBox(col.get(m));
	    	tableCol.add(dishcol[m]);
	    }
	    table_style.add(tableCol,BorderLayout.NORTH);
	    deskstyle.add(table_style,BorderLayout.CENTER);

	    logon.setBorder(BorderFactory.createTitledBorder("logon图片  (长或宽超过300像素将被缩放)"));
	    logon.setIcon(pub.Photo.readIcon("logo"));
	    logon.addMouseListener(new MouseAdapter() {
	    	public void mousePressed(MouseEvent arg0) {
				logoicon();
			}
		});
	    table_style.add(logon,BorderLayout.CENTER);
	    
	    //⑤
	    JPanel Tablecolor=new JPanel(new GridLayout(2,2,6,3));
	    Tablecolor.setBorder(BorderFactory.createTitledBorder("表格色彩"));
	    Tablecolor.add(but("表格前色彩"));
	    Tablecolor.add(but("表格后色彩"));
	    Tablecolor.add(but("表格选中色彩"));
	    JPanel tableheight=new JPanel(new BorderLayout());
	    tableheight.add("West",new JLabel("表格行高度："));
	    tableheight.add("Center",js(new SpinnerNumberModel(1,1,800,1)));    //表格高度组件
	    Tablecolor.add(tableheight);
	    right.add(Tablecolor,BorderLayout.NORTH);
	    
	    //⑥
	    JPanel dishstyle=new JPanel(new BorderLayout(1,20));
	    pm=new JPanel(new GridLayout(4,4,6,3));
	    pm.setBorder(BorderFactory.createTitledBorder("方块菜品属性"));
	    pm.add(lab("长方宽度"));
	    pm.add(dishw);
	    pm.add(lab("长方高度"));
	    pm.add(dishh);
	    pm.add(lab("字体样式"));
		dish_fontstyle = new JComboBox<String>(fontName);
	    pm.add(dish_fontstyle);
	    pm.add(lab("字体大小"));
	    pm.add(dish_size);
	    pm.add(lab("水平间距"));
	    pm.add(dish_hgap);
	    pm.add(lab("垂直间距"));
	    pm.add(dish_vgap);
	    pm.add(new JLabel());
	    pm.add(new JLabel());
	    pm.add(new JLabel());
	    pm.add(dish_save);
	    dish_save.addActionListener(this);
	    dishstyle.add("North",pm);
	    right.add(dishstyle,BorderLayout.CENTER);
	    
	    //⑦
	    JPanel dishColor=new JPanel(new BorderLayout(1,20));
	    JPanel dishset=new JPanel(new GridLayout(2,3,6,3));
	    dishset.setBorder(BorderFactory.createTitledBorder("方块菜品色彩"));
	    dishset.add(but("商品显示前景"));
	    dishset.add(but("商品显示背景"));
	    dishset.add(but("商品选中背景"));
	    
	    dishset.add(but("正常商品背景色彩"));
	    dishset.add(but("退单商品背景色彩"));
	    dishset.add(but("商品名称文字色彩"));
	    dishColor.add(dishset,BorderLayout.NORTH);
	    dishstyle.add(dishColor,BorderLayout.CENTER);
	    
	    initdesk();
	    initdish();
	    initdishcol();
    }
    
    // 有灰黑色背景自定义的标签类
    private JLabel lab(String s){
    	JLabel l=new JLabel("  "+s);
		l.setOpaque(true);
		l.setBackground(Color.LIGHT_GRAY);
		return l;
    }
    
    // 加工一个组件
    private JSpinner js(SpinnerNumberModel m){
    	JSpinner j=new JSpinner(m);
    	j.setValue(Var.getTableHeight(true));
		j.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				JSpinner temp = (JSpinner)e.getSource();
				ArrayList<String> v=new ArrayList<String>();
	    		v.add("tableheight");	//在数据库表general中的system分类中的区分字段
	    		v.add(temp.getValue().toString());
	    		Sql.mysqlprocedure("system_tableheight",v);
	    		Var.getTableHeight(true);	//更新值
			}
		});
    	return j;
    }
    
    // 自定义用于颜色选择的按扭
    private JButton but(String s){
    	final JButton t=new JButton(s);
    	t.setContentAreaFilled(false);
    	t.setBackground(Color.white);
    	t.setOpaque(true);
    	t.setToolTipText(s);
    	t.setBackground(Var.getColor(t.getText()));
    	t.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton temp=(JButton)e.getSource();
				Color c =JColorChooser.showDialog(null, "色彩选择", t.getBackground());
				if(c==null) return ;
				
				ArrayList<String> v=new ArrayList<String>();
    			v.add(temp.getText());
    			v.add(c.getRGB()+"");
    			Sql.mysqlprocedure("system_Color",v);
    			
    			//移除，这样就起到从数据库中重新读取数据，从而刷新数据。不需重新登陆便可看到效果
    			Var.myColor.remove(temp.getText());
    			t.setBackground(Var.getColor(temp.getText()));
			}
		});
    	return t; 
    }
    
    // 复选框加工
    private JCheckBox myBox(String s){
    	JCheckBox j=new JCheckBox(s);
    	j.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String ind="";
				String s="";
				for(int k=0;k<dishcol.length;k++){
					if(!dishcol[k].isSelected()){	//将没有选中的记录下来
						ind=ind+k+",";
						s=s+dishcol[k].getText()+",";
					}
				}
				if(ind.length()>0) ind=ind.substring(0,ind.length()-1);
				if(ind.length()>0) s=s.substring(0,ind.length()-1);
				ArrayList<String> v=new ArrayList<String>();
				v.add("dishcol");	//在数据库表general中的system分类中的区分字段
				v.add(ind);
				v.add(s);
				Sql.mysqlprocedure("system_dishcol",v);
				Var.dishcol=null;	//复位，以便从新从数据库中读取新值
				initdishcol();		//刷新自身
			}
		});
    	return j;
    }
    
    private void logoicon(){
    	JFileChooser chooser = new JFileChooser();
		int result = chooser.showOpenDialog(null);
		if (result != JFileChooser.APPROVE_OPTION) return ;
		
		String path = chooser.getSelectedFile().getPath();
		pub.Photo.ImportLogo(new File(path));
		
		logon.setIcon(pub.Photo.readIcon("logo"));
    }
    
	public void actionPerformed(ActionEvent ea) {
		if(ea.getSource()==desk_save){
			ArrayList<String> v=new ArrayList<String>();
			v.add(deskw.getText());
			v.add(deskh.getText());
			v.add(desk_hgap.getText());
			v.add(desk_vgap.getText());
			v.add(desk_fontstyle.getSelectedItem()+"");
			v.add(desk_size.getText());
			Sql.mysqlprocedure("system_deskSize",v);
			Var.deskw=0;
			Var.deskh=0;
			Var.desk_hgap=0;
			Var.desk_vgap=0;
			Var.desk_font=null;
			Var.desk_textsize=0;
			initdesk();
		}
		else if(ea.getSource()==dish_save){
			ArrayList<String> v=new ArrayList<String>();
			v.add(dishw.getText());
			v.add(dishh.getText());
			v.add(dish_hgap.getText());
			v.add(dish_vgap.getText());
			v.add(dish_fontstyle.getSelectedItem()+"");
			v.add(dish_size.getText());
			Sql.mysqlprocedure("system_dishSize",v);
			
			Var.dishw=0;
			Var.dishh=0;
			Var.dish_hgap=0;
			Var.dish_vgap=0;
			Var.dish_font=null;
			Var.dish_textsize=0;
			initdish();
		}
	}
	private void initdesk(){
		deskw.setText(Var.deskw()+"");
		deskh.setText(Var.deskh()+"");
		desk_hgap.setText(Var.deskhgap()+"");
		desk_vgap.setText(Var.deskvgap()+"");
		desk_fontstyle.setSelectedItem(Var.deskfont());
		desk_size.setText(Var.desktextsize()+"");
	}
	private void initdish(){
		dishw.setText(Var.dishw()+"");
		dishh.setText(Var.dishh()+"");
		dish_hgap.setText(Var.dishhgap()+"");
		dish_vgap.setText(Var.dishvgap()+"");
		dish_fontstyle.setSelectedItem(Var.dishfont());
		dish_size.setText(Var.dishtextsize()+"");
	}
	private void initdishcol(){
		//先全设为选中状态
		for(int k=0;k<dishcol.length;k++){
			dishcol[k].setSelected(true);
		}
		//再根据数据库中的值将对应目标设为不选中状态
		String str[]=Var.getDishCol().split(",");
		for(String temp : str){
			int m=Integer.valueOf(temp);
			dishcol[m].setSelected(false);
		}
	}
}
