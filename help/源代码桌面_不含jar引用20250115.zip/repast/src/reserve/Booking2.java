package reserve;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import pub.DateUI;
import pub.Lunar;
import pub.Popup_tab;
import pub.Var;
import root.Front;
import root.Sql;
//import sun.swing.table.DefaultTableCellHeaderRenderer;
public class Booking2 extends JPanel implements ActionListener{
	private static final long serialVersionUID = 73204458757668L;
	private final JLabel msg=new JLabel();
	private int maxrow=0;
	private final JButton up=new JButton("＜");
	private final JButton down=new JButton("＞");
	private final JButton mydate=new JButton("指定首列日期");
	private int slip=0;
	private JTable t;
	private final HashMap<String, String> hm=new HashMap<String, String>();
	private ArrayList<String[]> desk ;
	private HashMap<Integer, String> week ;
	public Booking2(ArrayList<String[]> desk, HashMap<Integer, String> week){
		this.desk = desk ;
		this.week = week ;
		setLayout(new BorderLayout());
	    add(nor(),BorderLayout.NORTH);
   	    String temp[]=Sql.getString("select max(台号) from desk", this);
   	    maxrow=Integer.valueOf(temp[0]);
   	    
   	    up.addActionListener(this);
   	    down.addActionListener(this);
   	    mydate.addActionListener(this);
   	    
   	    init();
	}
	
	private JPanel nor(){
		final JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT));
		final JButton b=new JButton("刷新");
		b.addActionListener(this);
		p.add(b);
		p.add(up);
		p.add(down);
		p.add(mydate);
		p.add(msg);
		msg.setForeground(Color.BLUE);
		String s="<html><body>［<font color=red>●</font>早餐、<font color=green>●</font>" +
				 "中餐、<font color=blue>●</font>晚餐、<font color=black>●</font>夜宵,其它、" +
				 "<font color=red>▲</font>该台次当天预定数有多个］、□ 昨天及以前、◇ 今天、○ 明天及以后</body></html>";
		p.add(new JLabel(s));
		return p;
	}
	
	private void init(){
	    //不可编辑
	    t=new JTable(new DefaultTableModel(0,0){
    		private static final long serialVersionUID = 354854820819L;
	        public boolean isCellEditable(int row, int column) {
	        	return false;
	        }
		});
	    
	    // 设置table表头居中
	    //DefaultTableCellHeaderRenderer thr = new DefaultTableCellHeaderRenderer();
	    final DefaultTableCellRenderer thr = new DefaultTableCellRenderer();
	    thr.setHorizontalAlignment(JLabel.CENTER);
	    t.getTableHeader().setDefaultRenderer(thr);
	    
	    // 设置table内容居中
	    DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
	    tcr.setHorizontalAlignment(JLabel.CENTER);
	    t.setDefaultRenderer(Object.class, tcr);
	    
	    // 设置不能重新排序各列
        t.getTableHeader().setReorderingAllowed(false);
        t.setSelectionBackground(Color.lightGray);
	    
	    //t.setBackground(Color.lightGray);
	    t.setShowGrid(true);
	    //t.setShowHorizontalLines(true);
	    //t.setShowVerticalLines(true);
	    //一次只能选择一行
	    t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    //只能选择单元格
	    t.setCellSelectionEnabled(true);
	    t.setComponentPopupMenu(new Popup_tab(t));
	    t.addMouseListener(new MouseAdapter() {
	    	public void mousePressed(MouseEvent e) {
	    		Point point = e.getPoint();
	            int row = t.rowAtPoint(point);
	            int col = t.columnAtPoint(point);
	    		String colname=t.getColumnName(col);
	    		row++;
	    		String val=hm.get(colname+row);
	    		if(val==null) return ;
	    		JOptionPane.showMessageDialog(Front.front, val, "预定信息   "+colname+" "+row, 1, new ImageIcon());
			}
		});
	    t.addMouseMotionListener(new MouseMotionListener() {
			public void mouseMoved(MouseEvent e) {
				Point point = e.getPoint();
	            int row = t.rowAtPoint(point);
	            int col = t.columnAtPoint(point);
	    		String colname=t.getColumnName(col);
	    		
	    		//从desk表中找数据项
	    		for(String temp[] : desk){
	    			String a = temp[0];	//餐区
	    			String b = temp[1];	//台号
	    			String c = temp[2];	//别名
	    			if(a.equals(colname)&&(b.equals((row+1)+""))){
	    				if(c.isEmpty()){
	    					t.setToolTipText(null);	//关闭
	    				}
	    				else{
	    					t.setToolTipText(c);	//显示
	    				}
	    				break;
	    			}
	    		}
			}
			public void mouseDragged(MouseEvent e) {}
		});
	    
	    add(new JScrollPane(t),BorderLayout.CENTER);
	}
	public void refresh(){
		hm.clear();	//复位
	    //注意这里的查询语句条件，大于条件必须要
		final String sql="SELECT 区域,台号,抵达日期,时段,宾客单位,宾客姓氏,电话,时段,人数,标准,定金,备注 from booking " +
	    		   "WHERE to_days(抵达日期)-to_days(now())>="+slip+" and to_days(抵达日期)-to_days(now())<="+9+slip;
	    final ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
	    final ArrayList<String[]> val=new ArrayList<String[]>();
	    for(int m=1;m<=maxrow;m++){
	    	ArrayList<String> sub=new ArrayList<String>();
	    	for(String areaval : Var.area()){
	    		//从desk表中找数据项
	    		boolean flag=true;
	    		for(String dv[] : desk){
	    			String s1 = dv[0];	//餐区
	    			String s2 = dv[1];	//台号
	    			if(areaval.equals(s1)&&(m+"").equals(s2)){
	    				String s=inforun(arr,s1,s2);
	    				String num = m<10 ? "  0"+m : "  "+m;
	    				sub.add("<html><body>"+num+"&nbsp"+s+"</body></html>");
	    				flag=false;
	    				break;
	    			}
	    		}
	    		if(flag) sub.add("");
	    	}
	    	String temp[] = new String[sub.size()];
	    	val.add(sub.toArray(temp));
   	    }
	    
	    if(val.size()>0){
	    	String ss[][]=new String[val.size()][val.get(0).length];
	    	for(int m=0;m<val.size();m++){
	    		ss[m]=val.get(m);
	    	}
	    	//更新数据
			DefaultTableModel mod=(DefaultTableModel)t.getModel();
			mod.setDataVector(ss,Var.area());
	    }
	}

	private String inforun(ArrayList<String[]> arr, String dep, String ind){
		String a="";
		final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		//先得到时间，并退一天，再设定到指定日期
		final Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)-1+slip);
		for(int k=0;k<9;k++){
			cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)+1);//每次循环加一天
			String date=df.format(cal.getTime());
			
			//比对 时间，餐区，台号，看有没有预定
			int times=0;
			String temp="";
			for(int m=0;m<arr.size();m++){
				String s1=arr.get(m)[0]; //餐区
				String s2=arr.get(m)[1]; //台号
				String s3=arr.get(m)[2]; //时间2012-05-24
				String s4=arr.get(m)[3]; //餐段
				if(s1.equals(dep)&&s2.equals(ind)&&(s3.equals(date))){
					String hmval=hm.get(s1+s2);
					if(hmval==null) hmval="";
					hmval=hmval+arr.get(m)[2]+"  单位："+arr.get(m)[4]+"\n"+"姓名："+arr.get(m)[5]+"   电话："+arr.get(m)[6]+"   餐别："+
						arr.get(m)[7]+"   人数："+arr.get(m)[8]+"   标准："+arr.get(m)[9]+"   定金："+
						arr.get(m)[10]+"   备注："+arr.get(m)[11];
					hm.put(s1+s2, hmval+"\n\n");
					
					if(times==0){
						if(s4.equals("早餐"))		temp="<font color=red>●</font>";
						else if(s4.equals("中餐"))	temp="<font color=green>●</font>";
						else if(s4.equals("晚餐"))	temp="<font color=blue>●</font>";
						else 						temp="<font color=black>●</font>";
					}
					times=times+1;	//记录该台当天预定数量
				}
			}
			if(times==0) temp="<font color=gray>○</font>";
			//if(times==1) temp=temp;
			if(times>1)	 temp="<font color=red>▲</font>";

			if((k==2)||(k==5)) temp=temp+"＿";
			
			//历史预定
			if((slip<0)&&(k<Math.abs(slip))){
				temp=temp.replace("●", "■");
				temp=temp.replace("○", "□");
			}
			//当日预定
			if((slip<=0)&&(k==Math.abs(slip))){
				temp=temp.replace("●", "◆");
				temp=temp.replace("○", "◇");
			}
			a=a+temp;
		}
		return a;
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==up)	slip--;
		if(e.getSource()==down)	slip++;
		if(e.getSource()==mydate){
			DateUI du = new DateUI();
			if(du.toString().isEmpty()) return ;
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			try {
				Date date = df.parse(du.toString());
				Date now = new Date();
				long k = (date.getTime()-now.getTime())/1000/3600/24;
				slip=(int)k;
			} catch (ParseException e1) {
				JOptionPane.showMessageDialog(Front.front, "日期格式转换失败");
				return  ;
			} 
		}
		
		final Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)+slip);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		Lunar l=new Lunar(cal);	//农历
		int k = cal.get(Calendar.DAY_OF_WEEK);
		msg.setText("首列日期："+df.format(cal.getTime())+"  农历："+l.toString()+"  "+week.get(k));
		
		refresh();
	}
}
