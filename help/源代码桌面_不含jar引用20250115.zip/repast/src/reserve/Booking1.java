package reserve;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import pub.DateUI;
import pub.Lunar;
import pub.Popup_tab;
import pub.Var;
import root.Front;
import root.Sql;
public class Booking1 extends JPanel{
	private static final long serialVersionUID = -761637253411750702L;
	private JButton add=new JButton("新增预定");
	private JButton stat=new JButton("状态变更");
	private JTable t = Sql.getTable();
	private JLabel msg = new JLabel();
	public Booking1(final HashMap<Integer, String> week){
		setLayout(new BorderLayout());
   	    add.setForeground(Color.BLUE);
   	    stat.setForeground(Color.BLUE);
   	    BSelect bs=new BSelect(t);
   	    bs.down.add(add);
   	    bs.down.add(stat);
   	    bs.down.add(new JLabel("   查询结果最多返回1000条数据,如超出1000条记录，请指定日期精确查询"));
   	    bs.down.add(msg);
   	    msg.setForeground(Color.BLUE);
		add("North",bs);
		
		t.setComponentPopupMenu(new bookPop(true));	//加一个右键菜单功能
		t.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e){
				if (e.getClickCount() == 2){
					sub(false);
		        }
			}
			public void mousePressed(MouseEvent e){
				String d = Sql.getval(t, "抵达日期", t.getSelectedRow());
				String arr[]=d.split("-");
				Calendar cd = Calendar.getInstance();
				cd.set(Integer.valueOf(arr[0]), Integer.valueOf(arr[1])-1, Integer.valueOf(arr[2]));
				
				Lunar l=new Lunar(cd);	//农历
				int k = cd.get(Calendar.DAY_OF_WEEK);
				msg.setText("   ［抵达日期："+d+"  农历："+l.toString()+"  "+week.get(k)+"］");
			}
		});
		t.getModel().addTableModelListener(new TableModelListener() {
			public void tableChanged(TableModelEvent arg0) {
				msg.setText("");
			}
		});
		
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sub(true);
			}
		});
		stat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookPop bb = new bookPop(false);
				bb.show(stat, 1, stat.getHeight());
			}
		});
		
		add("Center",new JScrollPane(t));
		//默认显示今天之后的所有预定，防止日期有误，对返回数量限制1000条
		Sql.getArrayToTable("select * from booking where 抵达日期>=date(now()) limit 0,1000;", this, t);
		Sql.TableAtt(t, false, true);
	}
		
	private String get(String colname){
		if(t.getSelectedRow()==-1)	return "";
		return Sql.getval(t, colname, t.getSelectedRow());
	}
	private JLabel lab(String s){
		JLabel l=new JLabel(s,JLabel.RIGHT);
		l.setFont(new Font(null,Font.BOLD,15));
		return l;
	}
	
	//对话框
	public void sub(boolean b){
		JPanel con=new JPanel(new BorderLayout(0,8));
		JTextField station=new JTextField();
		station.setBackground(Color.LIGHT_GRAY);
		station.setEditable(false);
		JComboBox<String> timediv=new JComboBox<String>(new String[]{"早餐","中餐","晚餐","夜宵","其它"});
		final JTextField area=new JTextField();
		String sql="select value from general where name='消费标准'";
		JComboBox<String> stand=new JComboBox<String>(Sql.getString(sql, this));	//餐标
		stand.addItem("");
		stand.setSelectedItem("");
		sql="select name_chinese from account where department='销售部'";
		JComboBox<String> sale=new JComboBox<String>(Sql.getString(sql, this));
	    sale.setEditable(true);
	    sale.addItem("");
	    sale.setSelectedItem("");
	    
	    JComboBox<String> market = new JComboBox<String>(Var.getMarket());
	    market.addItem("");
	    market.setSelectedItem("");
	    
		JTextField name=new JTextField();
		JTextField company=new JTextField();
		JCheckBox vip=new JCheckBox("VIP 客户");
		final JTextField arrtime=new JTextField();
		final JTextField lunar=new JTextField();
		final JTextField desknum=new JTextField("0");
		desknum.setBackground(Color.PINK);
		desknum.setEditable(false);
		final JTextField alias=new JTextField();
		alias.setBackground(Color.PINK);
		alias.setEditable(false);
		JSpinner people=new JSpinner(new SpinnerNumberModel(1,0,1000,1));
		//不可手功操作，只能按上下键
		DefaultEditor editor = (DefaultEditor)people.getEditor();
		editor.getTextField().setEditable(false);
		JTextField money=new JTextField("0");
		JTextField phone=new JTextField();
		JTextArea remark=new JTextArea("备注");
		area.setEditable(false);
		area.setBackground(Color.PINK);
		area.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent arg0) {
				String sql="select 区域,concat(前辍,LPAD(台号,2,'0')) as 台号,别名 from desk order by 前辍,台号;";
				JTable t=new JTable();
				Sql.getArrayToTable(sql, Booking1.this, t);
				Sql.TableAtt(t, true, false);
				JScrollPane js = new JScrollPane(t);
				js.setPreferredSize(new Dimension(100, 400));
				int action=JOptionPane.showConfirmDialog(Front.front,js,"请选择目标卡台(台号)：",2,1,new ImageIcon());
				int row=t.getSelectedRow();
				if((action==0)&&(row>=0)){
					String a = t.getValueAt(row, 0).toString();
					String b = t.getValueAt(row, 1).toString();
					String c = t.getValueAt(row, 2).toString();
					area.setText(a);
					desknum.setText(b);
					alias.setText(c);
				}
			}
		});
		
		arrtime.setBackground(Color.PINK);
		arrtime.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e){
				DateUI du = new DateUI();
				//阳历
				if(du.toString().isEmpty())	return ;
				arrtime.setText(du.toString());
				//农历
				Lunar l = new Lunar(du.toString());
			    lunar.setText("农历:"+l.toString());
			}
		});
		
		//北面,不可编辑的信息显示在此组件上
		String msg="预定号:"+get("预定号")+"、记录员:"+get("记录员")+"<br>记录时间："+get("记录时间");
		JLabel info=new JLabel("<html><body>"+msg+"<p></body></html>");
		info.setBorder(BorderFactory.createTitledBorder(""));
		info.setFont(new Font(null,Font.BOLD,16));
		con.add(info,BorderLayout.NORTH);
		
		//网格布局,参数：行数与列数，水平与垂直间距
		JPanel left=new JPanel(new GridLayout(13,1,6,3));
		left.add(lab("状态："));
		left.add(lab("销售员："));
		left.add(lab("宾客姓氏："));
		left.add(lab("宾客单位："));
		left.add(lab("vip："));
		left.add(lab("抵达日期："));
		left.add(lab("区域："));
		left.add(lab("时段："));
		left.add(lab("人数："));
		left.add(lab("标准："));
		left.add(lab("定金："));
		left.add(lab("电话："));
		left.add(lab("市场来源："));
		con.add(left,BorderLayout.WEST);
		
		JPanel timePan=new JPanel(new GridLayout(1,1));
		timePan.add(arrtime);
		timePan.add(lunar);
		lunar.setEditable(false);
		
		JPanel right=new JPanel(new GridLayout(13,1,6,3));
		right.add(station);
		right.add(sale);
		right.add(name);
		right.add(company);
		right.add(vip);
		right.add(timePan);
		JPanel local=new JPanel(new GridLayout(1,3,1,1));
		local.add(area); local.add(desknum); local.add(alias);
		right.add(local);
		right.add(timediv);
		right.add(people);
		right.add(stand);
		right.add(money);
		right.add(phone);
		right.add(market);
		con.add(right,BorderLayout.CENTER);
		
		remark.setBorder(BorderFactory.createTitledBorder(""));
		remark.setBackground(Color.lightGray);
		remark.setPreferredSize(new Dimension(300, 80));
		remark.setWrapStyleWord(true);
		remark.setLineWrap(true);
		con.add(remark,BorderLayout.SOUTH);
		
		//初始化
		if(b){
			station.setText("未到");
			SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
			arrtime.setText(sd.format(new Date()));
		}
		else{
			station.setText(get("状态"));
			sale.setSelectedItem(get("销售员"));
			name.setText(get("宾客姓氏"));
			company.setText(get("宾客单位"));
			if(get("vip").equals("Y"))	vip.setSelected(true);
			arrtime.setText(get("抵达日期"));
			area.setText(get("区域"));
			desknum.setText(get("台号"));
			alias.setText(get("别名"));
			timediv.setSelectedItem(get("时段"));
			people.setValue(Integer.valueOf(get("人数")));
			stand.setSelectedItem(get("标准"));
			money.setText(get("定金"));
			phone.setText(get("电话"));
			remark.setText(get("备注"));
			market.setSelectedItem(get("市场来源"));
		}
		
		Lunar l=new Lunar(arrtime.getText());
	    lunar.setText("农历:"+l.toString());
		
		//开始弹出对话框
		do{
			int action=JOptionPane.showConfirmDialog(Front.front,con,"预定管理",2,1,new ImageIcon());
			if(action!=0) break;
			
			if(area.getText().isEmpty()){
				JOptionPane.showMessageDialog(Front.front,"台号不能为空，请选择台号","错误 Error",0);
				continue;
			}
			
			ArrayList<String> v=new ArrayList<String>();
			if(b)	v.add("0");
			else	v.add(get("预定号"));
			
			v.add(sale.getSelectedItem()+"");
			v.add(name.getText());
			v.add(company.getText());
			if(vip.isSelected()) v.add("Y");
			else v.add("N");
			v.add(arrtime.getText());
			v.add(area.getText());
			v.add(desknum.getText());
			v.add(timediv.getSelectedItem().toString());
			v.add(people.getValue().toString());
			v.add(stand.getSelectedItem().toString());
			v.add(money.getText());
			v.add(phone.getText());
			v.add(market.getSelectedItem().toString());
			v.add(remark.getText());
			
			//提交
			boolean result = Sql.mysqlprocedure("booking",v);
			if(result){
				if(b){
					//新增预定直接刷新整个表
					Sql.getArrayToTable("select * from booking where 抵达日期>=date(now())", this, t);
					Sql.TableAtt(t, false, false);
				}
				else{
					//更新当前数据行
					String exe = "select * from booking where 预定号="+get("预定号");
					String val[] = Sql.getString(exe, this);
					for(int n=1; n<t.getColumnCount(); n++){
						t.setValueAt(val[n], t.getSelectedRow(), n);
					}
				}
			}
			else{
				continue;
			}
			break;
		}while(true);
	}
	
	
	/* 内部类
	 * 留言表右键菜单
	 * */
	class bookPop extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -182729372900196L;
		private JMenuItem a = new JMenuItem("转为登记  Register");
		private JMenuItem b = new JMenuItem("未到 No_Arrive");
		private JMenuItem c = new JMenuItem("已到  Arrive");
		private JMenuItem d = new JMenuItem("待定  Indeterminate");
		private JMenuItem e = new JMenuItem("等待  Wait");
		private JMenuItem f = new JMenuItem("取消  Cancel");
		private JMenuItem g = new JMenuItem("删除  Delete");
		public bookPop(boolean boo){
			a.addActionListener(this);
			b.addActionListener(this);
			c.addActionListener(this);
			d.addActionListener(this);
			e.addActionListener(this);
			f.addActionListener(this);
			g.addActionListener(this);
			a.setName("转为登记");
			b.setName("未到");
			c.setName("已到");
			d.setName("待定");
			e.setName("等待");
			f.setName("取消");
			g.setName("删除");
			add(a);
			addSeparator();
			add(b);
			add(c);
			add(d);
			add(e);
			addSeparator();
			add(f);
			add(g);
			
			//原有的菜单项功能
			if(boo){
				addSeparator();
				Popup_tab superpop=(Popup_tab)t.getComponentPopupMenu();
				add(superpop.getMenu());
			}
		}
		public void actionPerformed(ActionEvent es) {
			int row = t.getSelectedRow();
			if(row==-1){
				JOptionPane.showMessageDialog(this,"请先选择一条预定记录");
				return ;
			}
			
			JMenuItem stat=(JMenuItem)es.getSource();
			String id=Sql.getval(t, "预定号", row);
			String re = "" ; //不要设为: null
			if(es.getSource()==d||es.getSource()==e||es.getSource()==f||es.getSource()==g){
				re = JOptionPane.showInputDialog(Front.front, "请说明 ["+stat.getText()+"] 原由：");
				if(re==null) return ;
			}
			
			ArrayList<String> arr = new ArrayList<String>();
			arr.add(id);
			arr.add(stat.getName());
			arr.add(re);
			boolean boo = Sql.mysqlprocedure("bookingstation",arr);
			if(boo){
				String sql = "select * from booking where 预定号="+t.getValueAt(row, 0);
				String val[] = Sql.getString(sql, this);
				if(val.length==0){
					DefaultTableModel model = (DefaultTableModel)t.getModel();
					model.removeRow(row);
				}
				else{
					for(int k=1; k<t.getColumnCount(); k++){
						t.setValueAt(val[k], row, k);
					}
				}
			}
		}
	}
}
