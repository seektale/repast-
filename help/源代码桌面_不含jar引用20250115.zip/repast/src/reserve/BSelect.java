package reserve;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;

import log.AdvSelect;
import pub.DateUI;
import root.Front;
import root.Sql;
public class BSelect extends JPanel implements ActionListener{
	private static final long serialVersionUID = -4720373867305301786L;
	private JButton timediv = new JButton("时间段查询");
	private JButton today = new JButton("当天预定");
	private JButton tommo = new JButton("明天预定");
	private JButton after = new JButton("后天预定");
	private JButton afall = new JButton("今天往后的所有预定");
	private JButton day = new JButton("查询某一天的预定");
	private JButton month = new JButton("查询某一个月的预定");
	private JButton adv = new JButton("高级查询");
	private JTable t;
	private JPanel up = new JPanel(new FlowLayout(FlowLayout.LEFT));
	public  JPanel down = new JPanel(new FlowLayout(FlowLayout.LEFT));
	public BSelect(JTable t){
		this.t=t;
		setLayout(new FlowLayout(FlowLayout.LEFT));
		setLayout(new GridLayout(2,1));
		
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));	//一行一行的布局
	    add(up);
	    add(new JSeparator());	//分割线
	    add(down);
		
		up.add(timediv);
		up.add(today);
		up.add(tommo);
		up.add(after);
		up.add(afall);
		up.add(day);
		up.add(month);
		up.add(adv);
		timediv.addActionListener(this);
		today.addActionListener(this);
		tommo.addActionListener(this);
		after.addActionListener(this);
		afall.addActionListener(this);
		day.addActionListener(this);
		month.addActionListener(this);
		adv.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==adv){
			new AdvSelect("booking", t);
			return ;
		}
		
		String sql = "" ;
		
		if(e.getSource()==timediv){
			sql=sub("select * from booking where 抵达日期 >= date('@StartTime') and 抵达日期 <= date('@EndTime') limit 0,1000 ");
			if(sql==null || sql.isEmpty()) return ;
		}
		else if(e.getSource()==today){
			sql="select * from booking where 抵达日期 = date(now())";
		}
		else if(e.getSource()==tommo){
			sql="select * from booking where 抵达日期 - date(now()) = 1";
		}
		else if(e.getSource()==after){
			sql="select * from booking where 抵达日期 - date(now()) = 2";
		}
		else if(e.getSource()==afall){
			sql="select * from booking where 抵达日期 >=date(now()) limit 0,1000";
		}
		else if(e.getSource()==day){
			DateUI du = new DateUI();
			if(du.toString().isEmpty()) return ;
			sql="select * from booking where 抵达日期 = date('"+du.toString()+"')";
		}
		else if(e.getSource()==month){
			Calendar c=Calendar.getInstance();
			int AA = c.get(Calendar.YEAR) ;
			int BB = c.get(Calendar.MONTH)+1 ;
			String val=JOptionPane.showInputDialog(Front.front,"请输入年份与月份，格式：xxxx-xx",AA+"-"+BB);
			if(val==null) return ;
			
			String temp[]=val.split("-");
			if(temp.length!=2){
				JOptionPane.showMessageDialog(null,"格式不正确","Format Error",0);
				return ;
			}
			sql="select * from booking where year(抵达日期)= "+temp[0]+" and month(抵达日期) = "+temp[1]+" limit 0,1000";
		}
		
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, false, false);
	}
	
	//时间选择对话框
	private String sub(String sql){
		//初始化
		Calendar c = Calendar.getInstance();
		int Year = c.get(Calendar.YEAR);
		int Month = c.get(Calendar.MONTH) + 1;
		int day = c.get(Calendar.DAY_OF_MONTH);
		
		//日期
		JSpinner yeara=new JSpinner(new SpinnerNumberModel(Year,1900, 2200, 1));
		JSpinner montha = new JSpinner(new SpinnerNumberModel(1, 1,12, 1));
		JSpinner daya = new JSpinner(new SpinnerNumberModel(1, 1, 31,1));
		JPanel datePanela=DatePanel(yeara,montha,daya);
		
		JSpinner yearb=new JSpinner(new SpinnerNumberModel(Year,1900, 2200, 1));
		JSpinner monthb = new JSpinner(new SpinnerNumberModel(Month, 1,12, 1));
		JSpinner dayb = new JSpinner(new SpinnerNumberModel(day, 1, 31,1));
		JPanel datePanelb=DatePanel(yearb,monthb,dayb);
		
		JPanel p=new JPanel(new GridLayout(2, 2));
		p.add(new JLabel("  开始时间..."));
		p.add(new JLabel("  结束时间..."));
		p.add(datePanela);
		p.add(datePanelb);
		int action=JOptionPane.showConfirmDialog(Front.front,p,"选择时间段",2,1,new ImageIcon());
		if(action==0){
			String time1=yeara.getValue().toString()+"-"+montha.getValue().toString()+"-"+daya.getValue().toString();
			String time2=yearb.getValue().toString()+"-"+monthb.getValue().toString()+"-"+dayb.getValue().toString();
			//时间替换后查询
			sql = sql.replace("@StartTime", time1);
			sql = sql.replace("@EndTime", time2);
			return sql;
		}
		return null;
	}
	
	private JPanel DatePanel(JSpinner yearSpin,JSpinner monthSpin,JSpinner daySpin){
		JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		//年
		yearSpin.setEditor(new JSpinner.NumberEditor(yearSpin, "####"));
		datePanel.add(yearSpin);
		datePanel.add(new JLabel("年"));
		//月
		datePanel.add(monthSpin);
		datePanel.add(new JLabel("月"));
		//日
		datePanel.add(daySpin);
		datePanel.add(new JLabel("日"));
		
		return datePanel;
	}
}
