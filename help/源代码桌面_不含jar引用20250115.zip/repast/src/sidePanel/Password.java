package sidePanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import root.Front;
import root.Sql;
public class Password extends JDialog implements ActionListener,KeyListener{
	private static final long serialVersionUID = 4720246671093648959L;
	private JPasswordField a=new JPasswordField(""); 
	private JPasswordField b=new JPasswordField(""); 
	private JPasswordField c=new JPasswordField("");
	private JButton ok=new JButton("确定 Submit");
	private JButton cancel=new JButton("取消 Cancel");
	public Password(){
		super(Front.front, true);
		setSize(250, 150);
		
		JPanel con=new JPanel(new BorderLayout());
		con.setBorder(BorderFactory.createTitledBorder(""));
		con.setBackground(Color.orange);
		
		JPanel we=new JPanel(new GridLayout(3, 1));
		we.setOpaque(false);
		we.add(new JLabel("旧密码：",JLabel.RIGHT));
		we.add(new JLabel("新密码：",JLabel.RIGHT));
		we.add(new JLabel("确认新密码：",JLabel.RIGHT));
		con.add(we,BorderLayout.WEST);
		
		we=new JPanel(new GridLayout(3, 1));
		we.setOpaque(false);
		we.add(a);
		we.add(b);
		we.add(c);
		con.add(we,BorderLayout.CENTER);
		
		we=new JPanel(new FlowLayout(FlowLayout.CENTER));
		we.setOpaque(false);
		we.add(ok);
		we.add(cancel);
		con.add(we,BorderLayout.SOUTH);
		
		a.setBackground(Color.LIGHT_GRAY);
		ok.addActionListener(this);
		cancel.addActionListener(this);
		a.addKeyListener(this);
		b.addKeyListener(this);
		c.addKeyListener(this);
		ok.addKeyListener(this);
		cancel.addKeyListener(this);
		
		JPanel temp=new JPanel(new BorderLayout());
		temp.setBorder(BorderFactory.createRaisedBevelBorder());
		temp.add(con,BorderLayout.CENTER);
		setContentPane(temp);
		setLocationRelativeTo(null);
		setUndecorated(true);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==cancel){
			dispose();
			return ;
		}
		
		String s=new String(a.getPassword());
		String m=new String(b.getPassword());
		String n=new String(c.getPassword());
		if(s.isEmpty()||m.isEmpty()){
			JOptionPane.showMessageDialog(Front.front,"新旧密码均不能为空，请输入...","错误 Error",0);
		}
		else if(m.equals(n)){
			ArrayList<String> v=new ArrayList<String>();
			v.add(new String(a.getPassword()));
			v.add(m);
			boolean boo=Sql.mysqlprocedure("password",v);
			if(boo)	System.exit(0);
		}
		else{
			JOptionPane.showMessageDialog(Front.front,"确认 新密码 有误，新密码 不一致！","警告 Warning",2);
		}
	}
	@Override
	public void keyPressed(KeyEvent k) {
		//响应回车键
		if(k.getKeyCode()==KeyEvent.VK_ENTER){
			if(k.getSource()==a)		b.requestFocus();
			if(k.getSource()==b)		c.requestFocus();
			if(k.getSource()==c)		ok.requestFocus();
			if(k.getSource()==ok)		ok.doClick();
			if(k.getSource()==cancel)	dispose();
		}
		//按ESC键退出
		if(k.getKeyCode()==KeyEvent.VK_ESCAPE){
			dispose();
		}
	}
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
