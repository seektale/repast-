package sidePanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import root.Front;
import root.Sql;
public class Meal_node extends JDialog implements ActionListener{
	private static final long serialVersionUID = -7911151577088045362L;
	private JTable t=Sql.getTable();
	private JButton ok=new JButton("开始班结 S");
	private JButton refresh=new JButton("刷新表单 R");
	private JLabel msg=new JLabel("注意：班结后账单将不能再修改。");
	private String sql = "SELECT `结账工号`,DATE(`结账时间`) AS 日期,COUNT(*) AS 账单数量 FROM deskgo " +
	  					 "WHERE NOT ISNULL(`结账时间`) GROUP BY DATE(`结账时间`),`结账工号`";
	private JButton dayover ;
	public Meal_node(JButton dayover){
		super(new JFrame(),true);
		this.dayover=dayover;
		setTitle("班结");
		setIconImage(Front.logo);
		setSize(500, 260);					//窗口大小
		setLocationRelativeTo(null);		//初始位置在屏幕正中间
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		JPanel con=new JPanel(new BorderLayout());
		setContentPane(con);
		
		JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));
		nor.add(ok);
		nor.add(refresh);
		nor.add(msg);
		ok.addActionListener(this);
		refresh.addActionListener(this);
		ok.setMnemonic(KeyEvent.VK_S);
		refresh.setMnemonic(KeyEvent.VK_R);
		con.add(nor,BorderLayout.NORTH);
		con.add(new JScrollPane(t),BorderLayout.CENTER);
		
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, false, true);
		
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==refresh){
			Sql.getArrayToTable(sql, this, t);
			Sql.TableAtt(t, false, true);
			return ;
		}
		
		if(e.getSource()==ok){
			int row = t.getSelectedRow();
			if(row<0){
				JOptionPane.showMessageDialog(null, "请选择要班结的用户","注意",0);
				return ;
			}
			
			boolean boo=Sql.mysqlprocedure("node_bill",t.getValueAt(row, 0).toString());
			if(boo)	msg.setText("班结成功,自动刷新表单");
			//刷新表格
			Sql.getArrayToTable(sql, this, t);
			Sql.TableAtt(t, false, true);
		}
		
		
		//提示昨天及之前的要班结
		String sql = "select count(*) from deskgo where date(now())-date(结账时间)>0";
		String cn[] = Sql.getString(sql, this);
		if(cn.length>0 && Integer.valueOf(cn[0])>0){
			dayover.setBackground(Color.YELLOW);
		}
		else{
			dayover.setBackground(null);
		}
	}
}
