package sidePanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import root.Front;
import root.Sql;
public class SouthPan extends JTabbedPane implements ChangeListener{
	private static final long serialVersionUID = -5258360673264282223L;
	private final Chat ch=new Chat();
	private static int times_warn=0;	//警告消息数量计数器
	private static int times_sql=0;		//sql消息数量计数器
	private final static JTextArea  console	  	= new JTextArea("",0,0);
	private final static JTextField console_tip = new JTextField("sql luange");
	private final static JTextArea  warn		= new JTextArea("",0,0);
	private final static JTextField warn_tip	= new JTextField("");
	private final static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
	private static Icon mi = new ImageIcon();
	public SouthPan() {
    	
		//setTabPlacement(JTabbedPane.TOP);//设置标签置放位置
		addTab("Console  ",co("cmd"),Pan_con(),"终端");
		addTab("Warning  ",co("warn"),Pan_warn(),"警告信息");
		ch.setName("chat");
    	addTab("Chat  ",co("chat"),ch,"通信");
    	addTab("Hide(F8) ",co("hideico"),new JPanel(),"隐藏(F8)");
    	
    	setPreferredSize(new Dimension(0,300));
    	addChangeListener(this);
    	setOpaque(false);
    	mi = new ImageIcon(getClass().getClassLoader().getResource("pic/mi.png"));
	}
	private Icon co(String s) {
		final Icon con=new ImageIcon(this.getClass().getClassLoader().getResource("shortico/"+s+".png"));
		return con;
	}
	
	//终端面板
	private JPanel Pan_con(){
    	console.setLineWrap(true); 		//自动换行
    	console.setWrapStyleWord(true);	//单词换行不拆分
    	console.setBackground(Color.lightGray);
    	final JPanel p=new JPanel(new BorderLayout());
    	p.setOpaque(false);
    	console.setOpaque(false);
    	final JScrollPane scrollp=new JScrollPane(console);
    	scrollp.getViewport().setOpaque(false);
    	p.add(scrollp,BorderLayout.CENTER);
    	p.add(console_tip,BorderLayout.SOUTH);
    	console_tip.setEditable(false);
    	console_tip.setOpaque(false);
    	return p;
	}
	
	//警告面板
	private JPanel Pan_warn(){
		warn.setLineWrap(true);
		warn.setWrapStyleWord(true);
		warn.setBackground(Color.lightGray);
    	final JPanel p=new JPanel(new BorderLayout());
    	p.setOpaque(false);
    	p.add("Center",new JScrollPane(warn));
    	p.add("South",warn_tip);
    	warn_tip.setEditable(false);
    	return p;
	}
	
	//写入警告信息
	public static void warn(String s,boolean boo){
		warn(s, 2, boo, null);
	}
	public static void warn(String s,int k,boolean boo){
		warn(s, k, boo, null);
	}
	public static void warn(String s,int k,boolean boo, JTable t){
		
		times_warn++;
		warn_tip.setText(times_warn+": "+s);
		warn.append(df.format(new Date())+" ("+times_warn+")\n"+s+"\n\n");
		
		if(boo){
			//这里的图标mi最好不要从数据库中读取，因为无法保证数据库是可用的，会导致程序死机
			if(k==0) JOptionPane.showMessageDialog(t==null ? Front.front : t, s,"参考信息",k);		 //错误信息,用系统图标
			else	 JOptionPane.showMessageDialog(t==null ? Front.front : t, s,"参考信息",k, mi);	 //正确信息,用自定义图标
		}
		System.out.println(s);
	}
	//写入sql语句
	public static void writesql(String sql){
		//终端窗口同步显示
    	times_sql++;
    	SouthPan.console_tip.setText(times_sql+"："+sql);
    	SouthPan.console.append(""+df.format(new Date())+"  ("+times_sql+")\n"+sql+"\n\n");
    	//System.out.println(sql);
	}
	
	public void stateChanged(ChangeEvent e) {
		
		final int k = getSelectedIndex();
		if(k==2){	//chat
			ch.stop_timer();	//关闭聊天闪动提示
			final String s[]=Sql.getString("select remark from general where name='note' and item=@enname;", this);
			if(s.length>0)	ch.chread.setText(s[0]);
		}
		
		if(k==getComponentCount()-1){
			if(isVisible())	setVisible(false);
			else	setVisible(true);
			setSelectedIndex(0);	//防止可见时，当前选项卡在最后一个
		}
	}
}
