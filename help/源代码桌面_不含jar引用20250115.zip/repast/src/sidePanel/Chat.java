package sidePanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.Timer;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import pub.Var;
import root.Front;
import root.Sql;
public class Chat extends JPanel implements ActionListener,Runnable{
	private static final long serialVersionUID = -6816918299423611217L;
	private final JTextPane window=new JTextPane();
	public final JTextArea chread=new JTextArea();
	private final JTextField msg=new JTextField("将消息加上括号，消息将弹出。");
	
	private int port=5001;				      // 端口
	private MulticastSocket socket;           // 声明建立组播组使用的MulticastSocket类
	private InetAddress group;                // 声明建立组播组使用的组播组地址
	private final Timer timer=new Timer(800,this);  // 定时器
	
	private final Icon con1=new ImageIcon(this.getClass().getClassLoader().getResource("shortico/chat.png"));
	private final Icon con2=new ImageIcon(this.getClass().getClassLoader().getResource("shortico/chatnull.png"));
	private boolean con=true;
	public Chat(){
		setLayout(new GridLayout(1, 2));
		JPanel right=new JPanel(new BorderLayout());
		window.setBackground(new Color(230,230,240));
		window.setEditable(false);
		
		chread.setBackground(new Color(230,230,240));
		chread.setForeground(Color.black);
		chread.setLineWrap(true);		//自动换行
		chread.setWrapStyleWord(true);
		
		add(new JScrollPane(window));
		add(right);
		right.add("Center",new JScrollPane(chread));
		
		JPanel sou=new JPanel(new BorderLayout());
		msg.addActionListener(this);
		sou.add(msg,BorderLayout.CENTER);
		final JButton ok=new JButton("发送");
		ok.addActionListener(this);
		sou.add(ok,BorderLayout.EAST);
		right.add("North",sou);
		
		final JButton save=new JButton("保存笔记");
		save.addActionListener(this);
		right.add("South",save);
		
		//写入帮助信息
		final ArrayList<String[]> arr = Sql.getArrayToArrary("select item,value,remark from general where name='help';", this);
		for(final String tem[] : arr) {
			write_msg(tem[0]+" "+tem[1], tem[2]);
		}
		
		final Thread th=new Thread(this);
		th.start();
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==timer){
			if(con){
				TP().setIconAt(2, con2);
				con=false;
			}else{
				TP().setIconAt(2, con1);
				con=true;
			}
		}
		if(e.getActionCommand().contains("笔记")) {
			if(chread.getText().isEmpty()) {
				final int k=JOptionPane.showConfirmDialog(Front.front,"记事本中的内容将为空，确定保存吗？","清空记事本",0,1,Var.getIcon("米饭"));
				if(k==0) Sql.mysqlprocedure("note_save", "");
				return;
			}
			Sql.mysqlprocedure("note_save", chread.getText());
		}
		//发送按扭以及文本框的回车事件
		else{
			send();	//发送
		}
	}
	private JTabbedPane TP(){
		final JTabbedPane tab=(JTabbedPane)getParent();
		return tab;
	}
	
	public void stop_timer(){
    	TP().setIconAt(2, con1);
		timer.stop();
    }
	
	private void down(String s){
		final Calendar c=Calendar.getInstance();
		//window.append("\n\n"+c.getTime()+"："+s);
		stat("\n\n"+c.getTime()+"："+s, Color.RED);
		//保证窗口自动滑到最底部
		//JViewport js=(JViewport)window.getParent();
		//js.setViewPosition(new Point(0, 99999));
	}
	
	//输出消息
	private void write_msg(String title,String msg){
		//window.append("\n\n"+title+"\n"+msg);
		stat("\n"+title, Color.BLACK);
		if( (msg.startsWith("(") && msg.endsWith(")")) || (msg.startsWith("（") && msg.endsWith("）"))) {
			stat(msg, Color.RED);
			JOptionPane.showMessageDialog(Front.front, msg, "急要信息 Exigence Message", 1, null);
		}
		else {
			stat(msg, Color.BLUE);
		}
	}
	
	// 根据传入的颜色及文字，将文字插入文本域
	private void stat(String msg, Color textColor) {
		final SimpleAttributeSet set = new SimpleAttributeSet();
		StyleConstants.setForeground(set, textColor);	// 设置文字颜色
		final Document doc = window.getStyledDocument();
		try {
			doc.insertString(doc.getLength(), msg+"\n", set);// 插入文字
			window.selectAll();
			//迫使滚动条自动滚动到最后面
			if(window.getSelectedText()!=null){
				window.setCaretPosition(window.getSelectedText().length());  
			}
		} catch (BadLocationException e){}
	}
	
	//接收消息
    public void run(){
    	//暂停5秒再启动，原因为每次登陆时有偶尔出错的情况，问题出在下面的代码中，具体原因不明
    	try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//获取端口及组播地址
		final String s[]=Sql.getString("select value from general where name='通信' and (item='端口' or item='组播地址') order by item", this);
		if(s.length>0){
			try{
				port=Integer.valueOf(s[0]);             // 设置组播组的监听端口
				group = InetAddress.getByName(s[1]);    // 设置组播组的地址为239.0.0.0
				socket = new MulticastSocket(port);   	// 初始化MulticastSocket类并将端口号与之关联
				socket.setTimeToLive(1);                // 设置组播数据报的发送范围为本地网络
				//socket.setSoTimeout(100000);            // 设置套接字的接收数据报的最长时间
				socket.joinGroup(group);              	// 加入此组播组
				
				final Calendar c=Calendar.getInstance();
				//window.append(c.getTime()+" server start at "+s[1]+":"+port+" port...");
				stat("\n"+c.getTime()+" server start at "+s[1]+":"+port+" port...\n通信方式使用了组播的方式进行同网段的通信，跨网段无法完成通信。", Color.BLACK);
			}
			catch (Exception e) {
				down("从数据库读取配置信息并初始化通信变量失败"+e.toString());
			}
		}
		
		String message="";
		String val[];
		final DatagramPacket packet = new DatagramPacket(new byte[512], 512); // 初始化DatagramPacket
    	while((socket!=null)&&(!socket.isClosed())){
    		try{
    			packet.setData(new byte[512]);			//一定要复位
    			socket.receive(packet);       			// 通过MulticastSocket实例端口从组播组接收数据
    			message=new String(packet.getData());	// 将接受的数据转换成字符串形式
    			val=message.trim().split("&&");			//记得先去掉首尾空格
    			write_msg(val[0],val[1]);
    		}catch(Exception e){
    			down("读取组播消息出现异常"+e.toString());
    		}
    		
			//闪动有新消息
    		if(TP().getSelectedIndex()!=2){
    			timer.start();
    		}
    	}
    }
    
    //发送消息同时也会发向自己
	public void send(){
		final String s=msg.getText().trim();
		if(s.isEmpty()) return ;
		
		final Calendar c=Calendar.getInstance();
		final String title=WestPan.curuser.getText()+" "+c.getTime();
		
		final byte[] data = (title+"&&"+s).getBytes(); // 将用户要发送的数据转换为字节形式并
		//存储在数组中
		final DatagramPacket packet = new DatagramPacket(data, data.length, group, port); // 初始化DatagramPacket
		
		try {
			socket.send(packet);    // 通过MulticastSocket实例端口向组播组发送数据
		}catch(Exception e) {
			down("发送组播数据出现异常\n"+e.toString());
		}

		//写入数据库
		final boolean boo=Sql.mysqlprocedure("chat",s);
		if(boo)	msg.setText("");
		else	down("消息写入数据库失败");
    }
	
	/*
	//UDP通信方式，备用
	private void sendudp() {
		try {
			DatagramSocket socket = new DatagramSocket();
			
			byte data[]=new byte[]{'a','b','c','d'};
			DatagramPacket packet= new DatagramPacket(data,data.length,InetAddress.getByName("127.0.0.1"), 1114);
			socket.send(packet);
			
			socket.close();
		} catch (UnknownHostException e) {
			System.err.println("Exception: host could not be found");
		} catch (Exception e) {
			System.err.println("Exception: " + e);
			e.printStackTrace();
		}
	}
	
	Thread readudp=new Thread(new Runnable() {
		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				DatagramSocket socket = new DatagramSocket(1114);
				DatagramPacket packet = new DatagramPacket(new byte[512], 512);
				
				do{
					socket.receive(packet);
					System.out.println(new String(packet.getData()).trim());
				}while(true);

			} catch (Exception e) {
				System.err.println("Exception: host could not be found"+e.toString());
			}
		}
	});
	*/
}
