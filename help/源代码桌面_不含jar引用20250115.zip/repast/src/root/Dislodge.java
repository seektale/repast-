package root;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
class Dislodge extends JInternalFrame{
	private static final long serialVersionUID = -19551378863350L;
	private JPanel con = new JPanel(new BorderLayout());
	private JTabbedPane tab=new JTabbedPane();
	public Dislodge(){
		super("删除历史数据",true,true,true,true);
		
		JLabel lab = new JLabel("警告：删除历史数据后，无法恢复；请谨慎操作",JLabel.CENTER);
		lab.setForeground(Color.RED);
		lab.setFont(new Font("楷体", Font.BOLD, 26));
		
		con.add(tab,BorderLayout.CENTER);
		con.add(lab,BorderLayout.SOUTH);
		
		setContentPane(con);
	    setResizable(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    setVisible(true);
	    
	    // 以线程方式启用，这样不会卡顿
	    Thread th = new Thread(new Runnable() {
			public void run() {
				tab.add("账单数据",new JScrollPane(getbill("账单数据")));
				tab.add("吧台商品记录",new JScrollPane(getbarlog("吧台商品记录")));
				tab.add("预定历史",new JScrollPane(getbooking("预定历史")));
				tab.add("出单记录",new JScrollPane(getprint("出单记录")));
				tab.add("系统日志记录",new JScrollPane(getsyslog("系统日志记录")));
				tab.add("AR/VIP操作记录",new JScrollPane(getarlog("AR/VIP操作记录")));
				tab.add("聊天记录",new JScrollPane(getchatlog("聊天记录")));
				tab.add("IC卡日志",new JScrollPane(getcardlog("IC卡日志")));
			}
		});
		th.start();
	}
	
	private JPanel getbill(String title){
		String sql="select year(结账时间),MONTH(结账时间),COUNT(*) from hqdeskgo GROUP BY year(结账时间),month(结账时间)";
		String cmd="delete from hqdeskgo where year(结账时间)=MM and MONTH(结账时间)=GG";
		JPanel pan = getme(sql,cmd,title);
		
		JPanel nor = new JPanel();
		BoxLayout layout=new BoxLayout(nor, BoxLayout.Y_AXIS); //垂直布局
		nor.setLayout(layout);
		nor.add(pan);
		nor.add(Box.createVerticalStrut((18)));
		nor.add(new JSeparator());
		
		JTextArea info = new JTextArea(0,10);
		info.setText("阐述：每一个账单包含大量数据，其中hqdeskgo表包含一条开台记录；" +
				"billstyle表包含一条或多条结算记录；hqdish表包含了当前账单的所有商品信息，一个商品对应一条记录；" +
				"hqdishlog表包含了当前账单商品的操作日志，每一个商品的的每一次信息变更对应一条记录。" +
				"删除一个账单，意味着与之关联的所有信息均被删除。\n\n仅限 ROOT 超级用户操作");
		info.setWrapStyleWord(true);
		info.setLineWrap(true);
		info.setFont(new Font("楷体", Font.BOLD, 18));
		info.setBackground(Color.LIGHT_GRAY);
		info.setForeground(Color.BLUE);
		info.setEditable(false);

		nor.add(new JScrollPane(info));
		return nor ;
	}
	
	private JPanel getbooking(String title){
		String sql="select year(抵达日期),MONTH(抵达日期),COUNT(*) from booking GROUP BY year(抵达日期),month(抵达日期)";
		String cmd="delete from booking where year(抵达日期)=MM and MONTH(抵达日期)=GG";
		return getme(sql,cmd,title);
	}
	
	private JPanel getbarlog(String title){
		//注意，吧台商品的台次为0
		String sql="select year(点单时间),MONTH(点单时间),COUNT(*) from hqdish where 台次=0 GROUP BY year(点单时间),month(点单时间)";
		String cmd="delete from hqdish where year(点单时间)=MM and MONTH(点单时间)=GG and 台次=0 ";
		return getme(sql,cmd,title);
	}
	
	private JPanel getprint(String title){
		String sql="select year(print_time),MONTH(print_time),COUNT(*) from print_job GROUP BY year(print_time),month(print_time)";
		String cmd="delete from print_job where year(print_time)=MM and MONTH(print_time)=GG";
		return getme(sql,cmd,title);
	}
	
	private JPanel getsyslog(String title){
		String sql="select year(time),MONTH(time),COUNT(*) from syslog GROUP BY year(time),month(time)";
		String cmd="delete from syslog where year(time)=MM and MONTH(time)=GG";
		return getme(sql,cmd,title);
	}
	
	private JPanel getarlog(String title){
		String sql="select year(time),MONTH(time),COUNT(*) from viplog GROUP BY year(time),month(time)";
		String cmd="delete from viplog where year(time)=MM and MONTH(time)=GG";
		return getme(sql,cmd,title);
	}
	
	private JPanel getchatlog(String title){
		String sql="select year(time),MONTH(time),COUNT(*) from chat GROUP BY year(time),month(time)";
		String cmd="delete from chat where year(time)=MM and MONTH(time)=GG";
		return getme(sql,cmd,title);
	}
	private JPanel getcardlog(String title){
		String sql="select year(time),MONTH(time),COUNT(*) from cardlog GROUP BY year(time),month(time)";
		String cmd="delete from cardlog where year(time)=MM and MONTH(time)=GG";
		return getme(sql,cmd,title);
	}
	
	private JPanel getme(String sql, final String cmd, String title){
		ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
		ArrayList<String> year = new ArrayList<String>();
		
		//找出所有年份
		for(String val[] : arr){
			if(year.indexOf(val[0])>=0)	continue;
			year.add(val[0]);
		}
		
		JPanel pan = new JPanel(new GridLayout(year.size(), 12, 5, 5));
		pan.setBorder(BorderFactory.createTitledBorder(""));
		for(String ye : year){
			for(int k = 1 ; k<=12 ; k++){
				final JLabel va = new JLabel("",JLabel.CENTER);
				for(String val[] : arr){
					//年份与月份相等
					if(val[0].equals(ye) && val[1].equals(k+"")){
						va.setText(val[2]);
					}
				}
				if(va.getText().isEmpty()){
					va.setText("<html><body>"+title+"<br><font size=4 color=black>"+ye+"年"+k+"月"+"<font>" +
							   "<br>&nbsp</body></html>");
				}
				else{
					va.setText("<html><body>"+title+"<br><font size=4 color=red>"+ye+"年"+k+"月"+"<font>" +
							   "<br><font size=4 color=red>数量:"+va.getText()+"<font></body></html>");
					
					final String yes = ye;
					final String ks = k+"";
					va.addMouseListener(new MouseAdapter() {
						public void mousePressed(MouseEvent arg0) {
							String exec = cmd.replace("MM", yes);
							exec = exec.replace("GG", ks);
							handler(exec,va);
						}
					});
				}
				va.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));//立体感
				pan.add(va);
			}
		}
		pan.setToolTipText(cmd);
		return pan ;
	}
	
	private void handler(String cmd, JLabel lab){
		JPasswordField passw=new JPasswordField();
		int k = JOptionPane.showConfirmDialog(null, passw, "删除前认证密码", 0);
		if(k!=0) return ;
		
		ArrayList<String> val = new ArrayList<String>();
		val.add(new String(passw.getPassword()));
		val.add(cmd);
		boolean boo = Sql.mysqlprocedure("deleteolddata", val);
		if(boo){
			lab.setText(lab.getText().replace("数量:", "已删除"));
			lab.setText(lab.getText().replace("red", "blue"));
		}
	}
}

