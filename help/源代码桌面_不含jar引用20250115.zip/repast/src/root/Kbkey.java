package root;
import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.HashMap;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
public class Kbkey extends JDialog implements ActionListener{
	private static final long serialVersionUID = 9149451437716596585L;
	private final JButton back = new JButton("退格");
	private final JButton clear = new JButton("清除");
	private final JButton exit = new JButton("退出");
	private final JButton shift = new JButton("切换");
	private final JButton leftko = new JButton("(");
	private final JButton rightko = new JButton(")");
	private final JButton dot = new JButton("点");
	private final JButton ok = new JButton("ok");
	private final HashMap<String, Integer> hm = new HashMap<String, Integer>();
	private Robot robot ;
	private static boolean flag = false ;
	public Kbkey(JDialog dia){
		
		super(dia, "Keyboard", false);
		if(flag) return ;
		
		back.addActionListener(this);
		dot.addActionListener(this);
		clear.addActionListener(this);
		shift.addActionListener(this);
		exit.addActionListener(this);
		leftko.addActionListener(this);
		rightko.addActionListener(this);
		ok.addActionListener(this);
		
		hm.put("A", KeyEvent.VK_A);
		hm.put("B", KeyEvent.VK_B);
		hm.put("C", KeyEvent.VK_C);
		hm.put("D", KeyEvent.VK_D);
		hm.put("E", KeyEvent.VK_E);
		hm.put("F", KeyEvent.VK_F);
		hm.put("G", KeyEvent.VK_G);
		hm.put("H", KeyEvent.VK_H);
		hm.put("I", KeyEvent.VK_I);
		hm.put("J", KeyEvent.VK_J);
		hm.put("K", KeyEvent.VK_K);
		hm.put("L", KeyEvent.VK_L);
		hm.put("M", KeyEvent.VK_M);
		hm.put("N", KeyEvent.VK_N);
		hm.put("O", KeyEvent.VK_O);
		hm.put("P", KeyEvent.VK_P);
		hm.put("Q", KeyEvent.VK_Q);
		hm.put("R", KeyEvent.VK_R);
		hm.put("S", KeyEvent.VK_S);
		hm.put("T", KeyEvent.VK_T);
		hm.put("U", KeyEvent.VK_U);
		hm.put("V", KeyEvent.VK_V);
		hm.put("W", KeyEvent.VK_W);
		hm.put("X", KeyEvent.VK_X);
		hm.put("Y", KeyEvent.VK_Y);
		hm.put("Z", KeyEvent.VK_Z);
		
		hm.put("0", KeyEvent.VK_0);
		hm.put("1", KeyEvent.VK_1);
		hm.put("2", KeyEvent.VK_2);
		hm.put("3", KeyEvent.VK_3);
		hm.put("4", KeyEvent.VK_4);
		hm.put("5", KeyEvent.VK_5);
		hm.put("6", KeyEvent.VK_6);
		hm.put("7", KeyEvent.VK_7);
		hm.put("8", KeyEvent.VK_8);
		hm.put("9", KeyEvent.VK_9);
		hm.put("", KeyEvent.VK_SPACE);
		
		final JPanel pan = new JPanel(new GridLayout(4, 3));
		for(int k=1 ; k<=9 ; k++){
			final JButton b = new JButton(""+k);
			b.addActionListener(this);
			b.setForeground(Color.BLUE);
			b.setFont(new Font("", Font.BOLD, 20));
			b.setPreferredSize(new Dimension(46, 46));
			pan.add(b);
		}
		
		final JButton zeor = new JButton("0");
		zeor.addActionListener(this);
		zeor.setForeground(Color.BLUE);
		zeor.setFont(new Font("", Font.BOLD, 20));
		pan.add(dot);
		pan.add(zeor);
		pan.add(ok);
		
		
		final JPanel cen = new JPanel(new GridLayout(3, 1));
		final JPanel cen1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		String keyval[]=new String[]{"Q","W","E","R","T","Y","U","I","O","P"};
		for(int k=0 ; k<keyval.length ; k++){
			cen1.add(sub(keyval[k]));
		}
		cen.add(cen1);
		
		JPanel cen2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		keyval=new String[]{"A","S","D","F","G","H","J","K","L"};
		for(int k=0 ; k<keyval.length ; k++){
			cen2.add(sub(keyval[k]));
		}
		cen.add(cen2);
		
		JPanel cen3 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		keyval=new String[]{"Z","X","C","V","B","N","M",""};
		for(int k=0 ; k<keyval.length ; k++){
			cen3.add(sub(keyval[k]));
		}
		cen.add(cen3);
		
		final JPanel west = new JPanel(new GridLayout(3,2));
		west.setPreferredSize(new Dimension(110, 40));
		west.add(back);
		west.add(clear);
		west.add(leftko);
		west.add(rightko);
		west.add(shift);
		west.add(exit);
		
		try {
			robot = new Robot();
		} catch (AWTException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		final JPanel root = new JPanel(new BorderLayout());
		root.add(pan, BorderLayout.EAST);
		root.add(cen, BorderLayout.CENTER);
		root.add(west, BorderLayout.WEST);
		
		setSize(740, 180);
		setContentPane(root);
		setAlwaysOnTop(true);
		setResizable(false);			//没有窗体左上角小图标
		setFocusableWindowState(false);	//窗体不能得到焦点
		//setIconImage(Front.logo);
		
		final Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
		int width  = (int)screensize.getWidth();
		int height = (int)screensize.getHeight();
		setLocation(width/2-getWidth()/2, height-220);
		
		addWindowListener(new WindowListener() {
			public void windowOpened(WindowEvent e) {}
			public void windowIconified(WindowEvent e) {}
			public void windowDeiconified(WindowEvent e) {}
			public void windowDeactivated(WindowEvent e) {}
			public void windowClosing(WindowEvent e) {
				flag = false ;
			}
			public void windowClosed(WindowEvent e) {
				flag = false ;
			}
			public void windowActivated(WindowEvent e) {}
		});
		flag = true ;
		
		setVisible(true);
	}
	
	private JButton sub(String s){
		JButton b = new JButton(s);
		b.addActionListener(this);
		b.setForeground(Color.BLUE);
		b.setFont(new Font("", Font.BOLD, 15));
		b.setPreferredSize(new Dimension(42, 42));
		return b ;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == dot){
			robot.keyPress(110);  //46 受输入法干扰
			robot.keyRelease(110);
			return ;
		}
		if(e.getSource() == back){
			robot.keyPress(KeyEvent.VK_BACK_SPACE);  
			robot.keyRelease(KeyEvent.VK_BACK_SPACE);
			return ;
		}
		if(e.getSource() == leftko){
			robot.keyPress(KeyEvent.VK_SHIFT);
			robot.keyPress(KeyEvent.VK_9);
			robot.keyRelease(KeyEvent.VK_9);
			robot.keyRelease(KeyEvent.VK_SHIFT);
			return ;
		}
		if(e.getSource() == rightko){
			robot.keyPress(KeyEvent.VK_SHIFT);
			robot.keyPress(KeyEvent.VK_0);
			robot.keyRelease(KeyEvent.VK_0);
			robot.keyRelease(KeyEvent.VK_SHIFT);
			return ;
		}
		if(e.getSource() == ok){
			robot.keyPress(KeyEvent.VK_ENTER);  
			robot.keyRelease(KeyEvent.VK_ENTER);
			return ;
		}
		if(e.getSource() == clear){
			//ctrl + a 组合键
		    robot.keyPress(KeyEvent.VK_CONTROL);
		    robot.keyPress(KeyEvent.VK_A);
		    robot.keyRelease(KeyEvent.VK_A);
		    robot.keyRelease(KeyEvent.VK_CONTROL);
		    
			robot.keyPress(KeyEvent.VK_BACK_SPACE);  
			return ;
		}
		if(e.getSource() == shift){
			//ctrl + shift 组合键
		    robot.keyPress(KeyEvent.VK_CONTROL);
		    robot.keyPress(KeyEvent.VK_SHIFT);
		    robot.keyRelease(KeyEvent.VK_SHIFT);
		    robot.keyRelease(KeyEvent.VK_CONTROL);
			return ;
		}
		if(e.getSource() == exit){
			dispose();
			return ;
		}

		robot.keyPress(hm.get(e.getActionCommand()));
		robot.keyRelease(hm.get(e.getActionCommand()));
	}
}
