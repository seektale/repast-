package root;
//本类用于锁定登陆
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
public class Logon_again extends JDialog implements ActionListener,KeyListener{
	private static final long serialVersionUID = 2085064154510225538L;
	private JTextField acc=new JTextField();
	private JTextField name=new JTextField();
	private JPasswordField passw=new JPasswordField();  	 //密码框
	private JButton logon = new JButton("登陆 Logon");
	private JButton exit = new JButton("退出 Exit");
	private Icon key= new ImageIcon(this.getClass().getClassLoader().getResource("pic/keyagain.png"));
	public Logon_again(){
		super(Front.front, true);
		setSize(500, 300);					//登陆窗口大小
		setUndecorated(true);				//没有边框
		setLocationRelativeTo(null);		//初始位置在屏幕正中间
		
		BgPan p=new BgPan("pic/logon_bg.jpg","icon30"); 
		p.setLayout(null);
		p.setOpaque(false);
		
		//3个标签文本右对齐
		JLabel user=new JLabel("Account：",JLabel.RIGHT);  
		JLabel ip=new JLabel("Password：",JLabel.RIGHT);
		
		//3个标签文本的位置
		user.setBounds(180, 40,  120, 30);
		ip.setBounds(180, 140, 120, 30);
		p.add(user);
		p.add(ip);
		
		name.setEditable(false);
		name.setFocusable(false);
		name.setBackground(Color.LIGHT_GRAY);
		acc.setText(Logon.myds.getUser());
		
		acc.addKeyListener(this);
		passw.addKeyListener(this);
		passw.setFont(new Font("Courier New",Font.BOLD,16));
		logon.addActionListener(this);
		logon.addKeyListener(this);
		exit.addActionListener(this);
		exit.addKeyListener(this);
		
		acc.setBounds(310, 40, 150, 30);
		name.setBounds(310, 75, 150, 30);
		passw.setBounds(310, 140, 150, 30);
		logon.setBounds(140, 240, 100, 40);
		exit.setBounds(280, 240, 100, 40);

		p.add(acc);
		p.add(name);
		p.add(passw);
		p.add(logon);
		p.add(exit);

		JLabel osk  = new JLabel(key);
		osk.setBounds(20, 220, 64, 64);
		osk.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				new Kbkey(Logon_again.this);
			}
		});
		p.add(osk);
		
		JPanel con=new JPanel(new BorderLayout());
		con.setBorder(BorderFactory.createRaisedBevelBorder());
		con.add(p,BorderLayout.CENTER);
		setContentPane(con);

		setVisible(true);
	}
	
	//检查并登陆
	private void check(){
		if(acc.getText().isEmpty()){
			JOptionPane.showMessageDialog(this, "帐号不能为空 ？","错误",2);
			acc.requestFocus();
			return ;
		}
		if(passw.getPassword().length==0){
			JOptionPane.showMessageDialog(this, "密码不能为空","错误",2);
			passw.requestFocus();
			return ;
		}
		
    	String en=acc.getText();
    	String password=new String(passw.getPassword());
        en=en.trim();			//去掉首尾空格
    	en=en.toLowerCase();	//转换为小写
        password=password.trim();			//去掉首尾空格
    	password=password.toLowerCase();	//转换为小写
    	
    	Logon.myds.setUser(en);
    	Logon.myds.setPassword(password);
        try {
            Sql.con = Logon.myds.getConnection();
            Sql.con.setAutoCommit(true);	//自动提交
            Sql.init(true);					//登陆成功后初始化数据
        	dispose();						//关闭登陆对话框
        }
        catch (Exception e) {
        	e.printStackTrace();
        	String s=e.getMessage();
        	//只取第一行的重点错误信息，因为断网的错误信息太长了,满屏都是
        	if(s.indexOf("\n")>0)	s=s.substring(0,s.indexOf("\n"));
        	s= s+"\n\n可能原因：①用户名 或 密码 错误。②与服务器的连接存在问题。";
        	JOptionPane.showMessageDialog(null,s,"登陆失败",0);
		}
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==exit)	System.exit(0);
		if (e.getSource()==logon)	check();
	}
	
	// 响应键盘事件:回车键
	public void keyPressed(KeyEvent k){
		if(k.getKeyCode()==KeyEvent.VK_ENTER){
			if(k.getSource()==exit)	System.exit(0);
			if(k.getSource()==logon) check();
			if(k.getSource()==acc)	passw.requestFocus();
			if(k.getSource()==passw) check();
		}
	}
	public void keyReleased(KeyEvent arg0) {}
	public void keyTyped(KeyEvent arg0) {}
}

