package root;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.table.DefaultTableColumnModel;

import pub.Popup_tab;
public class Welcome extends JPanel{
	private static final long serialVersionUID = 86013197311437467L;
	private JTable msg=Sql.getTable();		//留言表
	public Welcome(){
		//后三个boolean值分别对应最小化，最大化，关闭按扭
		setLayout(new BorderLayout(8,8));
		
		add(new Lineup(),BorderLayout.CENTER);
		
		JPanel east=getstat();
		east.setPreferredSize(new Dimension(400, 0));
		add(east,BorderLayout.EAST);
		
		JPanel sou=new JPanel(new BorderLayout(8,8));
		sou.setOpaque(false);
		sou.setPreferredSize(new Dimension(0, 300));
		
		msg.setComponentPopupMenu(new MsgPop(msg));		//加一个右键菜单功能
		JScrollPane ts=TableOpaque(msg,"留言 (将消息加上英文括号],登陆时消息会弹出)");
		ts.setPreferredSize(new Dimension(400, 0));
		sou.add(ts,BorderLayout.EAST);
		
		String sql="select 状态,宾客姓氏,宾客单位,区域,台号,别名,时段,抵达日期 from booking where date(抵达日期)>=date(now());";
		JTable t= Sql.getTable();
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
		ts=TableOpaque(t,"预定(含当日)");
		sou.add(ts,BorderLayout.CENTER);
		add(sou,BorderLayout.SOUTH);
		
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
	    initMsg();	//初始化留言表
	}
	private JPanel getstat(){
		final JPanel pan = new JPanel();
		pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));	//一行一行的布局
		pan.setOpaque(false);
		
		//前辍只是为了排序
		String sql = "SELECT `区域`,`状态`,COUNT(*),`前辍` FROM desk  GROUP BY 区域,状态 UNION " +
					 "SELECT '统计',`状态`,COUNT(*),'前辍' FROM desk GROUP BY 状态 ORDER BY `前辍` ";
		ArrayList<String[]> arr=Sql.getArrayToArrary(sql, this);
		final ArrayList<String> stat = new ArrayList<String>();
		final ArrayList<String> area = new ArrayList<String>();
		final HashMap<String, String> keyval=new HashMap<String, String>();
		for(String temp[] : arr){
			if(stat.indexOf(temp[1])<0) stat.add(temp[1]);
			if(area.indexOf(temp[0])<0) area.add(temp[0]);
			keyval.put(temp[0]+temp[1], temp[2]);
		}
		
		final JPanel nor=new JPanel(new GridLayout(area.size()+1, stat.size()+1));
		nor.setOpaque(false);
		nor.add(new JLabel(""));
		for(String temp : stat){
			nor.add(new JLabel(temp));
		}
		for(String temp : area){
			nor.add(new JLabel(temp));
			for(String tem : stat){
				nor.add(new JLabel(keyval.get(temp+tem)));
			}
		}
		pan.add(nor);
		
		sql = "SELECT `结算方式`,SUM(`金额`) FROM billstyle WHERE `台次` IN (SELECT `台次` FROM deskgo " +
			  "WHERE NOT ISNULL(结账时间)) GROUP BY `结算方式` UNION " +
			  "SELECT '总金额',SUM(`金额`) FROM billstyle " +
			  "WHERE `台次` IN (SELECT `台次` FROM deskgo WHERE NOT ISNULL(结账时间))";
		arr=Sql.getArrayToArrary(sql, this);
		JPanel cen=new JPanel(new GridLayout(arr.size(),2));
		cen.setOpaque(false);
		for(String temp[] : arr){
			cen.add(new JLabel(temp[0]));
			cen.add(new JLabel(temp[1]));
		}
		
		JPanel tit=new JPanel(new FlowLayout(FlowLayout.LEFT));
	 	tit.add(new JLabel("账单收入(所有未班结账单)："));
	 	tit.setOpaque(false);
	 	pan.add(Box.createVerticalStrut((12)));
	 	pan.add(tit);
		pan.add(new JSeparator());	//分割线
		pan.add(cen);
		
		tit=new JPanel(new FlowLayout(FlowLayout.LEFT));
	 	tit.add(new JLabel("吧台自营收入(不包含卡台售出的吧台商品)："));
	 	tit.setOpaque(false);
	 	pan.add(Box.createVerticalStrut((12)));
	 	pan.add(tit);
		pan.add(new JSeparator());	//分割线
		sql = "select '总金额',sum(实价*数量*折扣) from dish where 属性='' and 台次=0 ";
		arr=Sql.getArrayToArrary(sql, this);
		cen=new JPanel(new GridLayout(arr.size(),2));
		cen.setOpaque(false);
		for(String temp[] : arr){
			cen.add(new JLabel(temp[0]));
			cen.add(new JLabel(temp[1]));
		}
		pan.add(cen);
		
		JPanel bor=new JPanel(new BorderLayout());
		bor.setOpaque(false);
		bor.setBorder(BorderFactory.createTitledBorder("运营状态"));
		bor.add(pan,BorderLayout.NORTH);
		
		sql = "SELECT '正常', COUNT(*) from deskgo WHERE 开台时间 in (select 操作时间 from desk where 状态='已开台') and isnull(结账时间) " +
		  "UNION ALL SELECT '挂起', COUNT(*) from deskgo WHERE 开台时间 not in (select 操作时间 from desk) and isnull(结账时间) " +
		  "UNION ALL SELECT '已结账', COUNT(*) from deskgo WHERE not isnull(结账时间) ";
		arr=Sql.getArrayToArrary(sql, this);
		String deskin="";
		for(String temp[] : arr){
			deskin = deskin+temp[0]+":"+temp[1]+"   ";
		}
		bor.add(new JLabel("账单统计 》   "+deskin+"",JLabel.CENTER),BorderLayout.SOUTH);
		
		return bor;
	}
	private JScrollPane TableOpaque(JTable t,String title){
		final JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBorder(BorderFactory.createTitledBorder(title));
		scrollPane.getViewport().setOpaque(false);				//将JScrollPane设置为透明
		scrollPane.setOpaque(false);							//将中间的viewport设置为透明
		scrollPane.setViewportView(t);							//装载表格
		return scrollPane;
	}
	private void initMsg(){
		refreshMsg();	//赋值
		
		//将留言内容显示在标题上
		msg.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e){
				if(e.getClickCount()==2){
					msg.getComponentPopupMenu().show(msg, e.getX(), e.getY());
					return ;
				}
				
				int k=msg.getSelectedRow();
				if(k!=-1){
					String temp=msg.getValueAt(k, 3).toString();
					JViewport view=(JViewport)msg.getParent();
					JScrollPane jp=(JScrollPane)view.getParent();
					if(temp.isEmpty()) temp = " "; //空字符串给一个空格
					jp.setBorder(BorderFactory.createTitledBorder(temp));
				}
			}
		});
		
		//弹出加括号的消息
		String toshow="";
		for(int k=0;k<msg.getRowCount();k++){
			String s=msg.getValueAt(k, 3).toString();
			if((s.startsWith("("))&&(s.endsWith(""))){
				toshow=toshow+s+"\n";
			}
		}
		if(!toshow.isEmpty()){
			JOptionPane.showMessageDialog(this, toshow);
		}
	}
	
	//刷新留言表
	private void refreshMsg(){
		//刷新,注意使用倒序，这样最新的数据在最上面显示
		String s="select number as 序号_Num,item as 工号_Account,value as 时间_Time," +
				"remark as 消息_Message from general where name='留言' order by number desc;";
		//刷新,注意使用倒序，这样最新的数据在最上面显示
		Sql.getArrayToTable(s, this, msg);
		Sql.autoWidthC(msg);
		
		DefaultTableColumnModel dcm = (DefaultTableColumnModel)msg.getColumnModel(); // 获取列模型
		dcm.getColumn(0).setPreferredWidth(0);
		dcm.getColumn(0).setMinWidth(0);
		dcm.getColumn(0).setMaxWidth(0);
		dcm.getColumn(2).setPreferredWidth(0);
		dcm.getColumn(2).setMinWidth(0);
		dcm.getColumn(2).setMaxWidth(0);
	}

	/* 内部类
	 * 留言表右键菜单
	 * */
	class MsgPop extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -182455400196L;
		private final JMenuItem a = new JMenuItem("发布留言 Send_Message");
		private final JMenuItem b = new JMenuItem("查看 View");
		private final JMenuItem c = new JMenuItem("编辑 Edit");
		private final JMenuItem d = new JMenuItem("删除 Delete");
		private JTable t;
		public MsgPop(JTable t){
			this.t=t;
			a.addActionListener(this);
			b.addActionListener(this);
			c.addActionListener(this);
			d.addActionListener(this);
			add(a);
			add(b);
			add(c);
			addSeparator();
			add(d);
			
			//原有的菜单项功能
			addSeparator();
			Popup_tab superpop=(Popup_tab)t.getComponentPopupMenu();
			add(superpop.getMenu());
		}
		public void actionPerformed(ActionEvent es) {
			if(es.getSource()==a){
				final String val=JOptionPane.showInputDialog(this);
				if(val==null || val.isEmpty()) return ;
				Sql.mysqlprocedure("msg_add",val);
				refreshMsg();
				return ;
			}
			
			int row = t.getSelectedRow();
			if(row==-1){
				JOptionPane.showMessageDialog(this,"请选择一条留言");
				return ;
			}
			
			if(es.getSource()==b){
				JOptionPane.showMessageDialog(this, t.getValueAt(row, 2).toString()+"\n"+t.getValueAt(row, 3).toString());
			}
			if(es.getSource()==c){
				String val=JOptionPane.showInputDialog(this,"",t.getValueAt(row, 3).toString());
				if(val!=null){
					ArrayList<String> v=new ArrayList<String>();
					v.add(t.getValueAt(row, 0).toString());
					v.add(val);
					Sql.mysqlprocedure("msg_edit",v);
				}
			}
			if(es.getSource()==d){
				String id=t.getValueAt(row, 0).toString();
				Sql.mysqlprocedure("msg_del",id);
			}
			refreshMsg();
		}
	}
}
