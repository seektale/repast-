package root;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;
import pub.ConfigFile;
import pub.Photo;
import pub.TableCellc;
import pub.Var;
public class Lineup extends JPanel implements ActionListener {
	
	private static final long serialVersionUID = 372324416161492304L;
	private JPanel nor=new JPanel(new BorderLayout());
	private JPanel left=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JPanel right=new JPanel(new FlowLayout(FlowLayout.RIGHT));
	private JLabel msg=new JLabel();
	private Getnum pop=new Getnum();
	public  JButton get=getButton("取号",KeyEvent.VK_G,true,"号码自动顺延");
	private JButton print=getButton("打印",KeyEvent.VK_P,false,"取号时会自动打印");
	private JButton comming=getButton("入场",KeyEvent.VK_O,true,"可以选中指定行入场,任何状态均可入场,同时自动语音播报");
	private JButton cancel=getButton("作废",KeyEvent.VK_C,false,"一次只能作废一条记录,任何状态均可作废");
	private JButton delete=getButton("删除",KeyEvent.VK_D,false,"支持多选批量删除,只有作废和已入场的才能删除");
	private JButton refresh=getButton("刷新",KeyEvent.VK_R,false,"");
	private JButton set=getButton("设置",KeyEvent.VK_S,false,"");
	
	private JComboBox<String> place=new JComboBox<String>();
	private JTextArea text=new JTextArea(5,3);
	
	private JTable t = Sql.getTable();
	public Lineup(){
		setBorder(BorderFactory.createTitledBorder("叫号排队"));
		setOpaque(false);
		setLayout(new BorderLayout());
	
		msg.setFont(new Font("",Font.BOLD,26));
		msg.setForeground(Color.red);

		left.add(msg);
		nor.setOpaque(false);
		left.setOpaque(false);
		right.setOpaque(false);
		nor.add(left,BorderLayout.CENTER);
		JPanel temp=new JPanel(new BorderLayout());
		temp.setOpaque(false);
		temp.add(right,BorderLayout.SOUTH);
		nor.add(temp,BorderLayout.EAST);
		add(nor,BorderLayout.NORTH);
		add(TableOpaque(t),BorderLayout.CENTER);
		t.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION); //恢复多行选择功能
		
		place.setToolTipText("com端口需要在32位jre或jdk下才可运行");
		refresh.doClick();
	}
	private JButton getButton(String s,int key,boolean boo,String tip){ 
		JButton b=new JButton(s);
		b.addActionListener(this);
		b.setMnemonic(key);
		b.setToolTipText("快捷键  Alt+"+(char)key+" "+tip);
		if(boo){
			b.setFont(new Font("",Font.BOLD,22));
			b.setForeground(Color.blue);
			left.add(b);
		}
		else{
			right.add(b);
		}
		b.setOpaque(false);
		return b;
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==get){
			pop.show(get, 0, get.getHeight());
		}
		else if(e.getSource()==print){
			final String ps = ConfigFile.getProperty("LineupPrintSite");
			if(ps==null || ps.trim().isEmpty()){
				JOptionPane.showMessageDialog(Front.front,"未配置热敏打印机站点，无法完成打印。","注意 Error",0);
				return;
			}
			if(check()==null) return;
			byte b[] = Photo.getline(check());
			if(b==null) return;
			
			if(ps.toUpperCase().startsWith("COM")){
				try {
					Photo.Printcom(b, ps);
				}
				catch (Exception err) {
					JOptionPane.showMessageDialog(Front.front, err.getMessage()+"\n注意：COM只能在32位的JDK或JRE环境中运行，不支持64位环境。", "错误", 0);
					err.printStackTrace();
				}
				return;
			}
			final Thread th = new Thread(new Runnable() {
				public void run() {
					Photo.printbin(b, ps, true); //网络热敏打印机以线程方式运行,以免卡住界面
				}
			});
			th.setDaemon(true);
			th.start();
		}
		else if(e.getSource()==comming){
			int k = t.getSelectedRow();
			if(check()!=null){
				boolean b=pro("comming",check());
				if(b){
					String s=Sql.getval(t, "号码", k);
					if(s.length()==1) s="00"+s;
					if(s.length()==2) s="0"+s;
					msg.setText(" "+s+"入场");
					final String temp = ConfigFile.getProperty("LineupVoice").replace("$num", s);
					if(!temp.isEmpty()) {
						final Thread th = new Thread(new Runnable() {
							public void run() {
								speek(temp); //以线程方式运行,以免卡住界面
							}
						});
						th.setDaemon(true);
						th.start();
					}
				}
			}
		}
		else if(e.getSource()==cancel){
			if(check()!=null){
				pro("cancel", check());
			}
		}
		else if(e.getSource()==delete){
			if(check()!=null){
				int tem = JOptionPane.showConfirmDialog(Front.front, "删除后不可恢复，确定要删除吗？", "注意", 2);
				if(tem!=0) return;
				int ind[]=t.getSelectedRows();
				String val[]=new String[ind.length];
				for(int k=0;k<ind.length;k++){
					val[k]=Sql.getval(t, "索引", ind[k]);
				}
				for(int k=0;k<ind.length;k++){
					boolean b=pro("delete", val[k]); //支持批量删除
					if(!b) break;
				}
			}
		}
		else if(e.getSource()==refresh){
			Sql.getArrayToTable("select * from line;", this, t);
			Sql.TableAtt(t, true, false);
			
			t.setName("-1");	//复位
			for(int k=0;k<t.getRowCount();k++){
				String s=Sql.getval(t, "状态", k);
				if(s.equals("准备")){
					t.setName(k+"");
					//默认选中当前行
					t.setRowSelectionInterval(k, k);
				} 
			}
			t.setDefaultRenderer(Object.class, new TableCellc(Integer.valueOf(t.getName())));
		}
		else if(e.getSource()==set){
			int k = JOptionPane.showConfirmDialog(this, getSet(), "语音及打印点设置", 2, 1, new ImageIcon());
			if(k==0) {
				ConfigFile.setProperty("LineupPrintSite",place.getSelectedItem().toString());
				ConfigFile.setProperty("LineupVoice",text.getText().trim());
			}
		}
	}
	private JPanel getSet(){
		JPanel p = new JPanel(new BorderLayout());
		text.setBackground(Color.LIGHT_GRAY);
		text.setLineWrap(true);		//自动换行
		text.setWrapStyleWord(true);
		if(place.getItemCount()==0){
			String printSite[] = Sql.getString("select 站点 from print_config;", this);
			place.addItem("COM1");
			place.addItem("COM2");
			for(String temp : printSite) place.addItem(temp);
		}
		
		text.setText(ConfigFile.getProperty("LineupVoice"));
		place.setSelectedItem(ConfigFile.getProperty("LineupPrintSite"));
		
		p.add(new JLabel("入场语音文本设计,入场号码用$num代表(使用jacob技术,需要Window7及以上完整版系统支持):      "),BorderLayout.NORTH);
		p.add(new JScrollPane(text), BorderLayout.CENTER);
		
		final JPanel sou = new JPanel(new FlowLayout(FlowLayout.LEFT));
		sou.add(new JLabel("打印机站点选择："));
		sou.add(place);
		final JButton test = new JButton("语音测试");
		test.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				speek(text.getText());
			}
		});
		sou.add(test);
		p.add(sou, BorderLayout.SOUTH);
		return p ;
	}
	private String check(){
		int k=t.getSelectedRow();
		if(k==-1){
			JOptionPane.showMessageDialog(Front.front,"请先选择要操作的数据项","注意 Error",0);
			return null;
		}
		return Sql.getval(t, "索引", k);
	}
	private boolean pro(String action,String ind){
		final ArrayList<String> v=new ArrayList<String>();
		v.add(action);
		v.add(ind);
		boolean b=Sql.mysqlprocedure("lineup",v);
		refresh.doClick();		//刷新
		return b;
	}
	private JScrollPane TableOpaque(JTable t){
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.getViewport().setOpaque(false);	//将JScrollPane设置为透明
		scrollPane.setOpaque(false);				//将中间的viewport设置为透明
		scrollPane.setViewportView(t);				//装载表格
		return scrollPane;
	}
	
	// 语音播放仅限Win10及以上,dll文件复制到C:\Windows\System32或jre\bin
	private void speek(String val) {
		final ActiveXComponent sap = new ActiveXComponent("Sapi.SpVoice");
		sap.setProperty("Volume", new Variant(100));
		sap.setProperty("Rate", new Variant(2));
		final Dispatch sapo = sap.getObject();
		Dispatch.call(sapo, "Speak", new Variant(val));
		sapo.safeRelease();
		sap.safeRelease();
	}
	
	class Getnum extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = 864686570524460874L;
		public Getnum(){
			String val[]=Var.getLine_class();
			if(val.length>0){
				for(int k=0;k<val.length;k++){
					final JMenuItem me = new JMenuItem(val[k]);
					me.addActionListener(this);
					add(me);
					if((k+1)!=val.length) addSeparator();
				}
			}
			else{
				final JMenuItem me = new JMenuItem("普通");
				me.addActionListener(this);
				add(me);
			}
		}
		public void actionPerformed(ActionEvent e) {
			String s=e.getActionCommand();
			if(pro(s,"0")){
				//选中最后一行,然后打印当前选中行的热敏单
				if(t.getRowCount()>0) t.setRowSelectionInterval(t.getRowCount()-1, t.getRowCount()-1);
				print.doClick();
				
				//刷新是为了取消当前选择行，将窗口滚动到最下面，显示刚刚取到的号码
				if(t.getRowCount()>0) t.removeRowSelectionInterval(0, t.getRowCount()-1);
				t.scrollRectToVisible(new Rectangle(0, t.getHeight(), 20, 20)); 
			}
		}
	}
}
