package root;
import java.awt.AWTException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
public class Numkey extends JDialog implements ActionListener{
	private static final long serialVersionUID = 9149451437716596585L;
	private JButton back = new JButton("退格");
	private JButton clear = new JButton("清除");
	private JButton exit = new JButton("退出");
	private JButton dot = new JButton("点");
	private JButton ok = new JButton("ok");
	private Robot robot ;
	private static boolean flag = false ;
	public Numkey(JDialog dia){
		super(dia,"数字键盘",false);
		if(flag) return ;
		
		back.addActionListener(this);
		dot.addActionListener(this);
		clear.addActionListener(this);
		exit.addActionListener(this);
		ok.addActionListener(this);
		
		JPanel pan = new JPanel(new GridLayout(5, 3));
		for(int k=1 ; k<=9 ; k++){
			JButton b = new JButton(""+k);
			b.addActionListener(this);
			b.setForeground(Color.BLUE);
			b.setFont(new Font("", Font.BOLD, 20));
			pan.add(b);
		}
		
		JButton zeor = new JButton("0");
		zeor.addActionListener(this);
		zeor.setForeground(Color.BLUE);
		zeor.setFont(new Font("", Font.BOLD, 20));
		pan.add(dot);
		pan.add(zeor);
		pan.add(ok);
		
		pan.add(back);
		pan.add(clear);
		pan.add(exit);
		
		try {
			robot = new Robot();
		} catch (AWTException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		setSize(200, 240);
		setContentPane(pan);
		setAlwaysOnTop(true);
		//setResizable(false);			//没有窗体左上角小图标
		setFocusableWindowState(false);	//窗体不能得到焦点
		setIconImage(Front.logo);
		
		if(dia!=null){
			Point po = dia.getLocationOnScreen();
			setLocation(po.x+dia.getWidth(), po.y);
			Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
			if(po.x+dia.getWidth()+200>screensize.width || po.y<=0){
				setLocationRelativeTo(null);	//初始位置在屏幕正中间
			}
		}
		else{
			setLocationRelativeTo(null);	//初始位置在屏幕正中间
		}
		
		addWindowListener(new WindowListener() {
			public void windowOpened(WindowEvent e) {}
			public void windowIconified(WindowEvent e) {}
			public void windowDeiconified(WindowEvent e) {}
			public void windowDeactivated(WindowEvent e) {}
			public void windowClosing(WindowEvent e) {
				flag = false ;
			}
			public void windowClosed(WindowEvent e) {
				flag = false ;
			}
			public void windowActivated(WindowEvent e) {}
		});
		flag = true ;
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == dot){
			robot.keyPress(110); //46受输入法干扰
			return ;
		}
		if(e.getSource() == back){
			robot.keyPress(KeyEvent.VK_BACK_SPACE);  
			return ;
		}
		if(e.getSource() == ok){
			robot.keyPress(KeyEvent.VK_ENTER);  
			return ;
		}
		if(e.getSource() == clear){
			//ctrl + a 组合键
		    robot.keyPress(KeyEvent.VK_CONTROL);
		    robot.keyPress(KeyEvent.VK_A);
		    robot.keyRelease(KeyEvent.VK_A);
		    robot.keyRelease(KeyEvent.VK_CONTROL);
		    
			robot.keyPress(KeyEvent.VK_BACK_SPACE);  
			return ;
		}
		if(e.getSource() == exit){
			dispose();
			return ;
		}
		
		int k = Integer.valueOf(e.getActionCommand());
		switch (k) {
		case 0:
			robot.keyPress(KeyEvent.VK_0);
			break;
		case 1:
			robot.keyPress(KeyEvent.VK_1);
			break;
		case 2:
			robot.keyPress(KeyEvent.VK_2);
			break;
		case 3:
			robot.keyPress(KeyEvent.VK_3);
			break;
		case 4:
			robot.keyPress(KeyEvent.VK_4);
			break;
		case 5:
			robot.keyPress(KeyEvent.VK_5);
			break;
		case 6:
			robot.keyPress(KeyEvent.VK_6);
			break;
		case 7:
			robot.keyPress(KeyEvent.VK_7);
			break;
		case 8:
			robot.keyPress(KeyEvent.VK_8);
			break;
		case 9:
			robot.keyPress(KeyEvent.VK_9);
			break;
		default:
			break;
		}
	}
}
