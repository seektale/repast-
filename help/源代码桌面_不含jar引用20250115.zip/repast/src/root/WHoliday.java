package root;
//查找节日，时间以数据库服务器时间为准
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import pub.Lunar;
public class WHoliday extends JLabel{
	private static final long serialVersionUID = 3243546644382968L;
	private Calendar today = Calendar.getInstance();
	private ArrayList<String[]> arr ;
	private int year,month,day;
	public WHoliday(){
		setFont(new Font("隶书",Font.BOLD,24));
		setForeground(Color.blue);
		setComponentPopupMenu(new visi());
		
		//从服务器上得到时间
		String time[]=Sql.getString("select year(now()), month(now()), day(now())", this);
		if(time.length==0) return ;
		
		today.set(Calendar.YEAR, Integer.valueOf(time[0]));
		today.set(Calendar.MONTH, Integer.valueOf(time[1]) - 1); //月份是从0到11
		today.set(Calendar.DATE, Integer.valueOf(time[2]));
		
		year  = today.get(Calendar.YEAR);			//得到年份
		month = today.get(Calendar.MONTH)+1;		//得到月份
		day   = today.get(Calendar.DAY_OF_MONTH);	//得到日期
		
		/*********************************************************************************/
		
		Lunar lun = new Lunar(today);
		String lunval[] = lun.todate();
		String lunmonth = lunval[2];	//农历月份
		String lunday   = lunval[3];	//农历日期
		
		//当月的最后一个星期几
		int week    = today.get(Calendar.DAY_OF_WEEK);						//当天星期几，返回数字
		//int maxday 	= today.getActualMaximum(Calendar.DAY_OF_MONTH);	//当月共有几天
		//int numweek = today.get(Calendar.WEEK_OF_MONTH);					//当月第几周
		//int maxweek = today.getActualMaximum(Calendar.WEEK_OF_MONTH);		//当月共有几周
		int NOweek  = today.get(Calendar.DAY_OF_WEEK_IN_MONTH);				//比如：今天是星期2，返回当月是第几个星期2
		int maxNOweek = today.getActualMaximum(Calendar.DAY_OF_WEEK_IN_MONTH);	//比如：今天是星期2，返回当月共有几个星期2
		
		if(week==1) week=7;	else week=week-1;	//将星期几进行转换，注意：星期一到星期日对应的数字为：2，3，4，5，6，7，1
		
		//查询数据库中的节日信息
		String sql = "select holiday,remark from holiday " +
					 "where (part='公历' and time='"+month+"-"+day+"') " +
					 "or    (part='农历' and time='"+lunmonth+"-"+lunday+"') " +
					 "or    (part='第几周' and time='"+month+"-"+NOweek+"-"+week+"')";
		if(NOweek==maxNOweek)	sql=sql+" or (part='最后一周' and time='"+month+"-"+week+"')";
		
		arr = Sql.getArrayToArrary(sql, this);
		othere();	//加入需要计算才能得出的节日

		/*******************************************************************************/
		
		//没有节日
		if(arr.size()==0)	return;
		
		if(arr.size()==1){
			setText("["+arr.get(0)[0]+"] ");
			if(!arr.get(0)[1].isEmpty()) setToolTipText(arr.get(0)[1]);
			return ;
		}
		
		setText("["+arr.get(0)[0]+"] (更多) ");
		String tip = "";
		for(String temp[] : arr){
			tip = tip + "[※"+temp[0]+"※]<br>";
			if(temp[1].isEmpty()) continue ;
			tip = tip +"<font color=blue>"+ temp[1]+"</font><br>";
		}
		setToolTipText("<html><body>"+tip+"</body></html>");
	}
	
	private void othere(){
		//当天是否为复活节
		if(islife()){
			String temp[]=new String[]{"复活节","春分月圆后的第一个星期日"};
			arr.add(temp);
		}
		//当天是否是除夕
		if(eve()){
			String temp[]=new String[]{"除夕","农历十二月最后一天"};
			arr.add(temp);
		}
		//当天是否为二月最后一天
		if(month==2 && day==today.getActualMaximum(Calendar.DAY_OF_MONTH)){
			String temp[]=new String[]{"居住","二月最后一天"};
			arr.add(temp);
		}
		//是否为耶稣受难日Good Friday，复活节前一个星期五
		if(yesu()){
			String temp[]=new String[]{"耶稣受难日Good Friday","复活节前一个星期五"};
			arr.add(temp);
		}
	}
	
	//耶稣受难日Good Friday，复活节前一个星期五
	private boolean yesu(){
		int val[] = life();
		Calendar c = Calendar.getInstance();
		c.set(Calendar.YEAR, year);
		c.set(Calendar.MONTH, val[0] - 1);			//月份是从0到11
		c.set(Calendar.DATE, val[1]);

		//日期回滚,找到前一个星期五
		do{
			c.roll(Calendar.DATE, -1);
		}while(c.get(Calendar.DAY_OF_WEEK)!=6);

		//比较这找到的这个星期五是否是今天的日期
		if(c.get(Calendar.YEAR)==year && c.get(Calendar.MONTH)==month && c.get(Calendar.DAY_OF_MONTH)==day){
			return true;
		}
		return false;
	}

	//今天是否是复活节
	private boolean islife(){
		int val[] = life();
		if(month==val[0] && day==val[1]) return true;
		return false;
	}
	
	//计算复活节
	private int[] life(){
		int n = year-1900;
		int a = n%19;							//int a = mod(n,19); 求余
		int q = (int)Math.floor(n/4); 			//int q = floor(n/4);最大整数
		int b = (int)Math.floor((7*a+1)/19); 
		int m = (11*a+4-b)%29; 
		int w = (n+q+31-m)%7; 
		int d = 25-m-w;
		
		//得出答数即可定出复活节的日期。若为正数，月份为4月，如为负数，月份为3月。若为0，则为3月31日。
		if(d>0)	return new int[]{4,d};
		if(d<0)	return new int[]{3,d*-1};
		return new int[]{4,d};
	}
	
	//计算除夕
	private boolean eve(){
		//当天农历
		Lunar lun=new Lunar(today);
		String s1[]=lun.todate();
		
		//第二天的农历
		today.roll(Calendar.DATE, 1); //往前加一天
		lun=new Lunar(today);
		String s2[]=lun.todate();
		today.roll(Calendar.DATE, -1); //往后一还原日期时间
		
		int a=Integer.valueOf(s1[1]);	//当天的农历是哪一年
		int b=Integer.valueOf(s2[1]);	//次日的农历是哪一年
		if(b==1+a)	return true;
		return false; 
	}
	
	
	/* 内部类
	 * */
	class visi extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -1832375685800196L;
		public visi(){
			JMenuItem a = new JMenuItem("隐藏 Hide");
			a.addActionListener(this);
			add(a);
		}
		public void actionPerformed(ActionEvent es) {
			WHoliday.this.setVisible(false);
		}
	}
}

