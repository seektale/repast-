package root;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import pub.ConfigFile;
import pub.Panel2D;
public class Logon extends JDialog implements ActionListener,KeyListener,MouseListener,MouseMotionListener{
	private static final long serialVersionUID = 2085064154510225538L;
	public final static MysqlDataSource myds = new MysqlDataSource();
	private final JTextField acc=new JTextField();
	private final JTextField name=new JTextField();
	private final JPasswordField passw=new JPasswordField();  	//密码框
	
	private final JTextField server_ip=new JTextField("",10);
	private final JTextField server_port=new JTextField("",6);
	private final JTextField server_db=new JTextField("",6);
	
	private final Panel2D sou=new Panel2D();
	private final JButton Testdb = new JButton("Test/Save");
	private final JButton Scandb = new JButton("Scan");
	private final JCheckBox Mandb = new JCheckBox("启用数据库");
	
	private final JLabel png_con = new JLabel();
	private final Icon Tcon1=new ImageIcon(this.getClass().getClassLoader().getResource("pic/con_ok.png"));
	private final Icon Tcon2=new ImageIcon(this.getClass().getClassLoader().getResource("pic/con_fail.png"));
	private final Icon up=new ImageIcon(this.getClass().getClassLoader().getResource("pic/server_up.png"));
	private final Icon down= new ImageIcon(this.getClass().getClassLoader().getResource("pic/server_down.png"));
	private final Icon close= new ImageIcon(this.getClass().getClassLoader().getResource("pic/close.png"));
	private final Icon weicon= new ImageIcon(this.getClass().getClassLoader().getResource("pic/weicon.png"));
	private final Icon key= new ImageIcon(this.getClass().getClassLoader().getResource("pic/key.png"));
	private final Icon numkey= new ImageIcon(this.getClass().getClassLoader().getResource("pic/keynum.png"));
	private final Icon clear= new ImageIcon(this.getClass().getClassLoader().getResource("pic/clear.png"));
	private final JButton updown = new JButton(down);
	private final JLabel testmsg = new JLabel();
	private final HashMap<String, String> a=new HashMap<String, String>();
	private final HashMap<String, String> b=new HashMap<String, String>();
	
	private final String tip="用户名不区分大小写,支持中英文名登陆 <br>六位及以上密码可直接输密码登陆<br><br>安卓手机可下载APK安装";
	private final JLabel pix=new JLabel("<html><body><font color=white>"+tip+"</font></html></body>");
	private final JButton logon = new JButton("登陆 Logon");
	private final JButton exit  = new JButton(close);
	private final Mariadb_Init mar = new Mariadb_Init();
	
	public Logon(){
		
		super(new JFrame(),true);
		setSize(500, 300);				//登陆窗口大小
		setUndecorated(true);			//没有边框
		setLocationRelativeTo(null);	//初始位置在屏幕正中间
		addMouseListener(this);
		addMouseMotionListener(this);
		
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("外观应用失败");
		}
		
		final BgPan p=new BgPan("pic/logon_bg.jpg", "icon30"); 
		p.setLayout(null);
		p.setOpaque(false);
		
		//3个标签文本右对齐
		final JLabel user=new JLabel("账号：",JLabel.RIGHT);  
		final JLabel ip=new JLabel("密码：",JLabel.RIGHT);
		
		//3个标签文本的位置
		user.setBounds(180, 40,  120, 30);
		ip.setBounds(180, 140, 120, 30);
		updown.setBounds(16, 260, 40, 30);
		p.add(user);
		p.add(ip);
		p.add(updown);
		
		updown.setContentAreaFilled(false);	//没有背景
		updown.setBorder(null);				//没有边框
		updown.setFocusable(false);			//没有焦点
		updown.setFocusPainted(false);		//没有选中时的图片边框
		
		exit.setContentAreaFilled(false);	//没有背景
		exit.setBorder(null);				//没有边框
		exit.setFocusPainted(false);		//没有选中时的图片边框
		
    	acc.setOpaque(false);
		acc.getDocument().addDocumentListener(new myname());
		acc.setFont(new Font("",Font.BOLD,12));
		passw.setFont(new Font("Courier New",Font.BOLD,20));
		passw.setToolTipText("默认密码123456, default password 123456");
		passw.setOpaque(false);
		name.setEditable(false);
		name.setOpaque(false);
		name.setFocusable(false);
		
		updown.addActionListener(this);
		updown.addKeyListener(this);
		acc.addKeyListener(this);
		passw.addKeyListener(this);
		logon.addActionListener(this);
		logon.addKeyListener(this);
		exit.addActionListener(this);
		exit.addKeyListener(this);
		
		acc.setBounds(310, 40, 150, 30);
		name.setBounds(310, 75, 150, 30);
		passw.setBounds(310, 140, 150, 30);
		logon.setBounds(190, 250, 120, 40);
		exit.setBounds(450, 260, 28, 28);
		
		server_ip.setBackground(Color.lightGray);
		server_port.setBackground(Color.lightGray);
		server_db.setBackground(Color.lightGray);
		
		p.add(acc);
		p.add(name);
		p.add(passw);
		p.add(server_ip);
		p.add(server_port);
		p.add(server_db);
		p.add(logon);
		p.add(exit);
		
		pix.setBounds(30, 30, 240, 100);
		p.add(pix);
		
		final JLabel apk2 = new JLabel(weicon);
		final JLabel osk  = new JLabel(key);
		final JLabel Nokey  = new JLabel(numkey);
		final JLabel ClearAccount  = new JLabel(clear);
		p.add(apk2);
		p.add(osk);
		p.add(Nokey);
		p.add(ClearAccount);
		apk2.setFocusable(false);
		osk.setFocusable(false);
		Nokey.setFocusable(false);
		ClearAccount.setFocusable(false);
		apk2.setBounds(30, 160, 32, 32);
		osk.setBounds(80, 160, 32, 32);
		Nokey.setBounds(460, 140, 32, 32);
		ClearAccount.setBounds(460, 40, 32, 32);
		
		osk.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				new Kbkey(Logon.this);
			}
		});
		Nokey.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				passw.requestFocus();
				new Numkey(Logon.this);
			}
		});
		ClearAccount.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				acc.setText("");
				name.setText("");
			}
		});
		apk2.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(ConfigFile.getProperty("apkurl").isEmpty()){
					JOptionPane.showMessageDialog(Logon.this, "配置文件conf/repast.properties中没有apkurl的参数,可以在[系统设置]中system选项完善");
					return ;
				}
				new wei(Logon.this.getLocationOnScreen());
			}
		});
		
		final JPanel sub=new JPanel(new FlowLayout(FlowLayout.LEFT));
		sub.setOpaque(false);
		sub.add(new JLabel("服务器:"));
		sub.add(server_ip);
		sub.add(new JLabel(":"));
		sub.add(server_port);
		sub.add(new JLabel("数据库:"));
		sub.add(server_db);
		sub.add(png_con);
		
        JPanel box=new JPanel(null);
        box.setOpaque(false);
        box.add(sub);  
        sub.setBounds(0, 5, 400, 30);
		sou.add(box);
		
        box=new JPanel(null);
        box.setOpaque(false);
        box.add(testmsg);
        box.add(Testdb);  
        box.add(Scandb);
        box.add(Mandb);
        testmsg.setBounds(8, 0, 400, 30);
        Scandb.setBounds(320, 6, 64, 23);
        Mandb.setBounds(390, 6, 100, 23);
        Testdb.setBounds(223, 6, 90, 23);
        Testdb.addActionListener(this);
        Scandb.addActionListener(this);
        
		sou.add(box);
		sou.setOpaque(false);
		sou.setLayout(new GridLayout(2, 1));
		sou.setPreferredSize(new Dimension(500, 80));
		sou.setVisible(false);
		
		final JPanel con=new JPanel(new BorderLayout());
		con.setLayout(new BorderLayout());
		con.setBorder(BorderFactory.createRaisedBevelBorder());
		con.add(p,BorderLayout.CENTER);
		con.add(sou,BorderLayout.SOUTH);
		setContentPane(con);
        
		Mandb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ConfigFile.setProperty("Maria", Mandb.isSelected());
				if(Mandb.isSelected()) MariaStart();
				else MariaStop();
			}
		});
        
		//初始化IP和端口
		server_ip.setText(ConfigFile.getProperty("ServerName"));
	    server_port.setText(ConfigFile.getProperty("Port"));
	    server_db.setText(ConfigFile.getProperty("DatabaseName"));
	    acc.setText(ConfigFile.getProperty("UserName"));
	    acc.setCaretPosition(acc.getText().length());	//光标放在最后面
	    
		if(ConfigFile.getProperty("Maria").equalsIgnoreCase("Y")) {
        	Mandb.doClick(); //启动数据库
        }
		else {
			initlog();	//初始化log登陆
		}
		setVisible(true);
	}
	
	private void MariaStart() {
		MariaMsg("正在启动本地数据库 请稍等 ... ");
		Mandb.setEnabled(false);
		final Thread th=new Thread(new Runnable() {
			public void run() {
				try {
					final Socket soc = new Socket("localhost", 3306);
					soc.close();
					JOptionPane.showMessageDialog(null, "错误：端口 3306 已经在使用中(数据库可能已经在运行中),请先结束相关进程或重起电脑。");
					Mandb.setEnabled(true);
					MariaMsg("启动本地数据库已中止。");
					return;
				} 
				catch (Exception e) {}
				try {
					mar.init(); //在需要时初始化,不要在new时初始化
					if(mar.db!=null) mar.db.start();
					MariaMsg("启动本地数据库过程已完成,端口:3306");
					initlog();
				} 
				catch (Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
					MariaMsg("启动本地数据库异常：", e.getMessage());
				}
				finally {
					Mandb.setEnabled(true);
				}
			}
		});
		th.setDaemon(true);
		th.start();
	}
	private void MariaStop() {
		MariaMsg("正在关闭本地数据库 ... ");
		Mandb.setEnabled(false);
		final Thread th=new Thread(new Runnable() {
			public void run() {
				try {
					if(mar.db!=null) mar.db.stop();
					MariaMsg("关闭本地数据库过程已完成。");
				} 
				catch (Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
					MariaMsg("关闭本地数据库异常：", e.getMessage());
				}
				finally {
					Mandb.setEnabled(true);
				}
			}
		});
		th.setDaemon(true);
		th.start();
	}
	private void MariaMsg(String msg) {
		MariaMsg(msg, "");
	}
	private void MariaMsg(String msg, String info) {
		pix.setText("<html><body><bold><font color=red size=6>"+msg+info+"</font></bold></html></body>");
	}
    
	private void initlog(){
		testmsg.setText("正在对数据库进行连接测试...");
		final Thread th=new Thread(new Runnable() {
			public void run() {
				Testdb.setEnabled(false);
				if(logonTest()){
					png_con.setIcon(Tcon1);
			    	testmsg.setText("测试数据库连接成功");
			    	ConfigFile.setProperty("ServerName",server_ip.getText()); //保存配置到文件
			        ConfigFile.setProperty("Port",server_port.getText());
			        ConfigFile.setProperty("DatabaseName",server_db.getText());
				}
				else{
					png_con.setIcon(Tcon2);
			    	testmsg.setText("测试数据库连接失败");
					if(!sou.isVisible()) updown.doClick();
				}
				Testdb.setEnabled(true);	//恢复可用
			}
		});
		th.setDaemon(true);
		th.start();
	}
	
	private boolean logonTest() {
		
		final String ip=server_ip.getText();
		final String port=server_port.getText();
		final String db=server_db.getText();
		if(server_ip.getText().isEmpty() || server_port.getText().isEmpty()) {
			testmsg.setText("单击Scan扫描同网段服务器 (WIN7及以上系统)");
			if(!sou.isVisible()) updown.doClick();
			return false;
		}
		
    	//在 正试 连接之前加一个端口测试是为了提高公网连接时的成功率，仅此而已
		final Socket socket = new Socket();
		final SocketAddress add = new InetSocketAddress(ip, Integer.valueOf(port));
		try {
			socket.connect(add, 5000); //5秒
			socket.close();
			testmsg.setText("测试端口正常,开始连接...");
		} catch (IOException e1) {
			testmsg.setText("测试端口异常,尝试连接...");
		}
		
		boolean result = false;
		Connection con = null ;
		try {
			final MysqlDataSource ds = new MysqlDataSource();
	    	ds.setPassword("123456");
	    	ds.setUser("log");
	    	ds.setURL("jdbc:mysql://"+ip+":"+port+"/"+db);
	        con = ds.getConnection();
	        con.setAutoCommit(true);	//自动提交
	        
	        //读取用户名等信息
	        final String sql="select name_english,name_chinese from account;";
	        final PreparedStatement pstmt = con.prepareStatement(sql);
	        final ResultSet rs=pstmt.executeQuery();
			
			rs.beforeFirst();
			final ArrayList<String> mm = new ArrayList<String>();
			final ArrayList<String> nn = new ArrayList<String>();
			while(rs.next()){
	    		a.put(rs.getString(1), rs.getString(2));
	    		b.put(rs.getString(2), rs.getString(1));
	    		mm.add(rs.getString(1));
	    		nn.add(rs.getString(2));
			}
			
			// 菜单
			//name.setComponentPopupMenu(new namePop(mm, nn));
			final namePop pop = new namePop(mm,nn);
			if(name.getMouseListeners().length>0){
				name.removeMouseListener(name.getMouseListeners()[0]);
			}
			name.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					pop.show(name, name.getWidth(), 0);
				}
			});
			result = true ;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			try {
				if(con!=null) con.close();
			} catch (SQLException e) {e.printStackTrace();}
		}
		return result;
	}
	
	//仅用密码登陆时先找到帐号
	private boolean getAccount(){
		
		if(a.size()==0){
			if(!sou.isVisible()) updown.doClick();
			JOptionPane.showMessageDialog(this, "找不到服务器，请先检查服务器参数。","错误",2);
			return false;
		}
		
		boolean result = false;
		
		String sql=new String(passw.getPassword());
		sql="select distinct User from mysql.user where Password=Password('"+sql+"')";
		Connection con = null ;
		try{
			final MysqlDataSource ds = new MysqlDataSource();
	    	ds.setPassword("123456");
	    	ds.setUser("log");
	    	ds.setServerName(server_ip.getText());
	    	ds.setPort(Integer.valueOf(server_port.getText()));
	    	ds.setDatabaseName(server_db.getText());
	    	
			con = ds.getConnection();
	        con.setAutoCommit(true);	//自动提交
	        
	        final PreparedStatement pstmt = con.prepareStatement(sql);
	        final ResultSet rs=pstmt.executeQuery();

			rs.last();
			int k=rs.getRow();
			if(k==0){
				JOptionPane.showMessageDialog(this, "密码不正确","错误",2);
			}
			else if(k>1){
				JOptionPane.showMessageDialog(this, "密码 太简单 或 发生重复","错误",2);
			}
			else{
				rs.beforeFirst();
				rs.next();
				acc.setText(rs.getString(1));
				result = true ;
			}
		}
		catch (Exception e) {
			JOptionPane.showMessageDialog(this, "系统初始登陆错误,可能原因:网络异常","错误",2);
			e.printStackTrace();
		}
		finally{
			try {
				if(con!=null) con.close();
			} catch (SQLException e) {e.printStackTrace();}
		}
		return result ;
	}
	
	//检查并登陆
	private void check() {
		
		//仅用密码登陆时先找到帐号
		boolean boo=true;
		if((passw.getPassword().length>=6)&&(acc.getText().isEmpty())){
			boo=getAccount();
		}
		if(!boo) return;
		
		if(acc.getText().isEmpty()){
			JOptionPane.showMessageDialog(this, "帐号不能为空 ？","错误",2);
			acc.requestFocus();
			return;
		}
		if(passw.getPassword().length==0){
			JOptionPane.showMessageDialog(this, "密码不能为空","错误",2);
			passw.requestFocus();
			return;
		}
		
		if(Testdb.isEnabled()){
			final String fullname=name.getText();
			String en="";
			if(fullname.isEmpty()){
				en=acc.getText();
			}
			else{
				en=fullname.substring(0, fullname.indexOf(" @ "));
			}
			creatConnection(en);
		}
		else{
			if(!sou.isVisible()) updown.doClick();
		}
	}
	
	//用于登陆窗口认证时创建数据库连接
    private void creatConnection(String en) {
    	
    	final String ip=server_ip.getText();
    	final String port=server_port.getText();
    	final String db=server_db.getText();
    	String password=new String(passw.getPassword());
    	
        //注意：有时linux上的mysql必须指定编码
        //String url="jdbc:mysql://"+ip+":"+port+"/repast?characterEncoding=utf8";
    	
        en=en.trim();			//去掉首尾空格
    	en=en.toLowerCase();	//转换为小写
        password=password.trim();			//去掉首尾空格
    	password=password.toLowerCase();	//转换为小写
    	
    	myds.setPassword(password);
    	myds.setUser(en);
    	myds.setServerName(ip);
    	myds.setPort(Integer.valueOf(port));
    	myds.setDatabaseName(db);
    	
    	try {
			myds.setConnectTimeout(3000);	//反而是这个为登陆超时限制3秒
		} 
    	catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
    	//事实证明这个是有效的，限制超时3秒,但如果一个数据查询需要5秒才能返回结果，会导致连接断开
    	//对超时的判断应采用：if(!conn.isValid(3)) conn = null ;
    	//myds.setSocketTimeout(3000); 
    	//myds.setSocketTimeout(0);取消超时限制
    	//myds.setNetTimeoutForStreamingResults();
    	
    	//下面三句都不起作用
    	//ds.setLoginTimeout(1000);
    	//ds.setConnectTimeout(1000);
    	//ds.setUseSSL(true); 性能大打折扣
    	//Sql.con = DriverManager.getConnection(url, en, password); 已过时
    	//myds.setURL("jdbc:mysql://192.168.1.144:3306/study"); 已过时
    	//myds.setTcpKeepAlive(true);
    	//myds.setAutoReconnect(true);
    	//myds.setLocalSocketAddress("");
    	//ds.setCharacterEncoding("UTF8");
    	
        try {
            Sql.con = myds.getConnection();
            Sql.con.setAutoCommit(true);	//自动提交
            Sql.init(false);				//登陆成功后初始化数据
            ConfigFile.setProperty("UserName", en); //缓存上一次的登陆名
        	dispose();						//关闭登陆对话框
        }
        catch (Exception e) {
        	e.printStackTrace();
        	String s=e.getMessage();
        	//只取第一行的重点错误信息，因为断网的错误信息太长了,满屏都是
        	if(s.indexOf("\n")>0)	s=s.substring(0,s.indexOf("\n"));
        	s= s+"\n\n可能原因：①用户名 或 密码 错误 。②与服务器的连接存在问题。";
        	JOptionPane.showMessageDialog(null,s,"登陆失败",0);
		}
    }
    
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==exit)	System.exit(0);
		if (e.getSource()==logon)	check();
		if(e.getSource()==Testdb)	initlog();
		if(e.getSource()==Scandb)	scan();
		if(e.getSource()==updown){
			if(sou.isVisible()){
				setSize(500, 300);//登陆窗口大小
				sou.setVisible(false);
				updown.setIcon(down);
			}
			else{
				setSize(500, 380);
				sou.setVisible(true);
				updown.setIcon(up);
			}
		}
	}
	//响应键盘事件:回车键,ESC键
	public void keyPressed(KeyEvent k){
		if(k.getKeyCode()==KeyEvent.VK_ENTER){
			if(k.getSource()==exit)		System.exit(0);
			if(k.getSource()==logon)	check();
			if(k.getSource()==acc)		passw.requestFocus();
			if(k.getSource()==passw)	check();
		}
		if(k.getKeyCode()==KeyEvent.VK_ESCAPE){
			System.exit(0);
		}
	}
	public void keyReleased(KeyEvent arg0) {}
	public void keyTyped(KeyEvent arg0) {}
	
	//自动寻找同网段服务器
	private void scan(){
		//一但扫描，端口复位为3306
		server_port.setText("3306");	//默认3306
		//固定大小的池，设定并发线程数不要超过50个
		final ExecutorService Pool = Executors.newFixedThreadPool(50);
		final ArrayList<String> arrip = getLocalIPList();
		for(String ip : arrip){
			//从本机IP列表中取出一个IP进行处理，并从255个主机中寻找服务器，估且认为其子网掩码为255.255.255.0
			//如果根据子网掩码找，子网掩码为255.255.240.0 则要找的主机太多了，不现实。
			if(ip.startsWith("127")) continue;
			int flag=ip.lastIndexOf(".");
			ip=ip.substring(0, flag+1);
			
			for(int n=0; n<255; n++){
				//首先要扫描的是服务器名为smosu的主机,一般要将服务器的名字定义为smosu
				String temp="";
				if(n==0) temp="smosu";
				else temp=ip+n;
				final String myip=temp;
				
				//扫描，每一个IP启动一个线程
				Pool.submit(new Runnable() {
					public void run() {
						testmsg.setText(myip+" 开始测试");
						System.out.println(myip+" 开始测试");
						
						Socket s=null;
						try {
							s = new Socket();
							final SocketAddress add = new InetSocketAddress(myip, 3306);
							s.connect(add, 2000);	//设定超时时间为2秒
							
							server_ip.setName("Y");	//标记已找到一个可用IP
							server_ip.setText(myip);
							/**
					         * shutdown调用后，不可以再submit新的task，已经submit的将继续执行
					         * shutdownNow试图停止当前正执行的task，并返回尚未执行的task的list
					         */
					        Pool.shutdownNow();
							Testdb.doClick();	//初始化log登陆
						} 
						catch (Exception e) {
							//选判断还未找到IP时才有下面的动作
							if(server_ip.getName()==null){
								testmsg.setText(myip+" 不可用 (正在自动寻找服务器)");
							}
							System.out.println(myip+" 不可用 (正在自动寻找服务器)");
						}
						finally{
							try {s.close();} catch (IOException e) {}
						}
					}
				});
			}
		}
	}

	/**
     * IceWee 2013.07.19
     * 获取本地IP列表（针对多网卡情况）
     * 测试表明无线网卡也能读取到，不活动的网卡不会出现在列表中
     * @return
     */
    private ArrayList<String> getLocalIPList() {
        ArrayList<String> ipList = new ArrayList<String>();
        try {
        	final Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            NetworkInterface networkInterface;
            Enumeration<InetAddress> inetAddresses;
            InetAddress inetAddress;
            String ip;
            while (networkInterfaces.hasMoreElements()) {
                networkInterface = networkInterfaces.nextElement();
                inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    inetAddress = inetAddresses.nextElement();
                    if (inetAddress != null && inetAddress instanceof Inet4Address) { // IPV4
                        ip = inetAddress.getHostAddress();
                        ipList.add(ip);
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return ipList;
    }
	
	class myname implements DocumentListener{
		public void insertUpdate(DocumentEvent e) {
			String en=acc.getText();
			en=en.trim();			//去掉首尾空格
	    	en=en.toLowerCase();	//转换为小写
	    	
		    if(a.get(en)==null){		//英文名登陆
		    	if(b.get(en)==null){	//中文名登陆
		    		name.setText("");
		    	}
		    	else{
		    		name.setText(b.get(en)+" @ "+en);
		    	}
		    }
		    else{
		    	name.setText(en+" @ "+a.get(en));
		    }
		}
		@Override
		public void removeUpdate(DocumentEvent e) {
			// TODO Auto-generated method stub
			if(!acc.getText().isEmpty()){
				insertUpdate(e);
			}
		}
		@Override
		public void changedUpdate(DocumentEvent e) {
			// TODO Auto-generated method stub
		}
	}
	
	//登陆窗口可移动
	private Point origin = new Point();
	public void mouseDragged(MouseEvent e) {
		// 当鼠标拖动时获取窗口当前位置
		Point p = getLocation();
		// 设置窗口的位置
		setLocation(p.x + e.getX() - origin.x, p.y + e.getY()- origin.y);
	}
	public void mouseMoved(MouseEvent e) {}
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		origin=e.getPoint();
	}
	public void mouseReleased(MouseEvent e) {}

	
	/* 
	 * 用户表右键菜单
	 * */
	class namePop extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -18274352342900196L;
		public namePop(ArrayList<String> mm, ArrayList<String> nn){
			for(String temp : mm){
				JMenuItem a = new JMenuItem(temp+" @ "+nn.get(mm.indexOf(temp)));
				a.addActionListener(this);
				add(a);
			}
			//addSeparator();
		}
		public void actionPerformed(ActionEvent e) {
			String s = e.getActionCommand() ;
			//name.setText(s);
			acc.setText(s.substring(0, s.indexOf(" @ ")));
		}
	}
}


class wei extends JDialog{
	private static final long serialVersionUID = -75177839358803L;
	private BufferedImage img ;
	public wei(Point p){
		super(new JFrame(), "手机扫描二维码", true);
		img = createImage();
		
		if(p.x-260<=0 || p.y<=0){
			setLocationRelativeTo(null);	//屏幕正中间
		}
		else{
			setLocation(p.x-260, p.y);		//登陆框左边
		}
		
		setSize(260, 260);
		setIconImage(Front.logo);
		//setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
	}
	
    private BufferedImage createImage() {
    	final String val = ConfigFile.getProperty("apkurl");
        Hashtable<EncodeHintType, Object> hints = new Hashtable<>();
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        //hints.put(EncodeHintType.MARGIN, 1);
        BitMatrix bitMatrix=null;
        try {
        	bitMatrix = new MultiFormatWriter().encode(val, BarcodeFormat.QR_CODE, 200, 200, hints);
        }catch (Exception e) {
			return null;
		}
        int width = bitMatrix.getWidth();
        int height = bitMatrix.getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                image.setRGB(x, y, bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
            }
        }
        return image;
    }
    
	
	public void paint(Graphics g) {
		g.drawImage(img,0,10,this.getWidth(),this.getHeight(),this);
	}
}



/*
去掉了本地下载的功能，代码供学习参考

InputStream in = this.getClass().getResourceAsStream("phone.apk");
// 默认选择当前用户桌面
Properties props = System.getProperties();
String sel = props.getProperty("user.home") + "\\desktop\\phone.apk";
File f = new File(sel);
try {
	if(!f.exists()) f.createNewFile();
	FileOutputStream out = new FileOutputStream(f);
	int total = in.available();
	while(in.available()>0){
		out.write(in.read());
		int process = total - in.available();
		msg.setText("<html><body>正在将手机点单APK程序复制到用户桌面，请稍等... " +
		"<br>完成进度："+process/1000+"KB / "+total/1000+"KB</body></html>");
	}
	in.close();
	out.close();
}
catch (Exception err) {err.printStackTrace();return;}
if(!sou.isShowing()) updown.doClick();
msg.setText("<html><body><font color=blue>文件已保存到桌面，安装到手机即可使用。" +
		"<br>请参考弹出的本机IP地址和端口<font></body></html>");
*/

