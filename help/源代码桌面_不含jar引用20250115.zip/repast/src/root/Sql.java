package root;
import java.awt.Color;
import java.awt.Component;
import java.sql.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import pub.ConfigFile;
import pub.Photo;
import pub.Popup_tab;
import pub.TableCella;
import pub.Var;
import sidePanel.SouthPan;
import sidePanel.WestPan;
public class Sql{
    public  static Connection con = null ;
	private static CallableStatement cs ;
	//首次登陆 或 重复登陆后初始化参数
	//代码执行到这里般可能是synchronized static ArrayList<String[]> getArray()方法间接到这理的
	//重新登陆会初始化登陆，初始化登陆又会调用上面的这个方法，但这个方法又是加了同步锁的，
	//所以程序会死机，因为不上线，锁就不会释放，将登陆初始化代码单独隔离开执行
	public static void init(boolean relogon){
		
		final String enname = Logon.myds.getUser();
		if(enname.equalsIgnoreCase("log")){
			JOptionPane.showMessageDialog(null, "log是系统辅助账号,不允许登陆！","限制登陆",0);
			System.exit(0);
		}
		
		if(enname.equalsIgnoreCase("root")) { //自动修复管理员权限
			try {
				final Statement stmt = con.createStatement();
				stmt.execute("FLUSH PRIVILEGES;");
				stmt.execute("GRANT all PRIVILEGES on *.* to 'root'@'%' IDENTIFIED BY '123465' WITH GRANT OPTION;");
				stmt.execute("FLUSH PRIVILEGES;");
				stmt.close();
			}catch (SQLException e) {e.printStackTrace();}
		}
		
		String cnname="",full="N",lock="N";
		try {
			final String sql="select name_chinese,fullscreen,islock from account where name_english='"+enname+"'";
			final PreparedStatement pstmt = con.prepareStatement(sql);
			final ResultSet rs=pstmt.executeQuery();
			rs.next();
			cnname = rs.getString(1);
			full = rs.getString(2);
			lock = rs.getString(3);
			rs.close();
			pstmt.close();
		}
		catch (SQLException err) {
			JOptionPane.showMessageDialog(null, "无法获取当前用户的部分属性\n"+err.getMessage(),"信息丢失",0);
		}
		if(full.equalsIgnoreCase("Y"))	Front.style=true;
		if((!enname.equalsIgnoreCase("root")) && lock.equalsIgnoreCase("Y")){
			JOptionPane.showMessageDialog(null, "帐号已被锁定，请与管理员联系！","限制登陆",0);
			System.exit(0);
		}
		
		WestPan.curuser.setText(enname+"@"+cnname);
        final Map<String,String> map = System.getenv();
		
    	//记录到数据库，并返回提示信息
    	final ArrayList<String> v=new ArrayList<String>();
    	v.add(map.get("COMPUTERNAME"));		//主机名
    	v.add(Var.getpc().toString());
    	mysqlprocedure("logon", v);
    	
    	//同步三张本地图片；如果是重复登陆，则不要反复执行
    	if(relogon) return;
    	
    	final Thread th = new Thread(new Runnable() {
			public void run() {
				
				//记录apk手机点单程序网址
				if(ConfigFile.getProperty("apkurl").isEmpty()){
					final String tempsql = "select value from general where name='system' and item='apkurl' " ;
					final String apk[] = getString(tempsql, "Sql.init()");
					if(apk.length>0){
						ConfigFile.setProperty("apkurl", apk[0]);
					}
				}
				
				//同步三张图片
				final String tempsql = "select item,remark from general where name='image' " ;
				final ArrayList<String[]>arr = getArrayToArrary(tempsql, "Sql.init()");
				for(final String temp[] : arr){
					if(temp[1].isEmpty()){
						// URL地址空禁用，不再使用本地缓存图片 (当从数据库中读取图片时会重新登记，从本地读取也会重新登记)
						ConfigFile.setProperty("icon"+temp[0], "");
						continue ;
					}
					try{Integer.valueOf(temp[0]);}catch (Exception e) {
						JOptionPane.showMessageDialog(Front.front, "general表image项配置错误\n"+temp[1], "严重错误 Serious_Error", 0);
						continue;
					}
					
					// 管理员登陆时要从网络即时更新图片到数据库
					if(enname.equalsIgnoreCase("root")){
						Photo.ImportAD(Integer.valueOf(temp[0]), temp[1]);
					}
					
					// 从数据库及时更新到本地缓存图片目录
					Photo.readIcon(Integer.valueOf(temp[0]), true);
				}
			}
		});
    	th.setDaemon(true);
    	th.start();
	}
    
	//不用加 synchronized 因为只有getTable()调用这个方法
    private static ResultSet getrs(String sql, String Local, JTable t){
    	//后续调用此方法的，则判断con为空时直接结束
    	if(con==null) return null ;
    	try {
    		//isValid方法是判断Connection是否有效,超时设为3秒，如果连接尚未关闭并且仍然有效，则返回 true;
			if(!con.isValid(3)) con = null ;
		}
    	catch (SQLException err) {
    		con = null ;
    		JOptionPane.showMessageDialog(t, "Connection.isValid(3)异常：\n"+err.getMessage());
		}
    	if(con==null) {
    		JOptionPane.showMessageDialog(t, "与数据库的连接已断开，需要重新登陆。");
    		Thread th = new Thread(new Runnable() {
    			public void run() {
    				new Logon_again(); 
    			}
    		});
        	th.start();
        	return null ;
        }
		
        try {
            //Statement stmt = con.createStatement();
        	//网上查知，PreparedStatement基本上取代了Statement，且更有效率
            //升级数据库后，下面一句不需要了，以前旧版本一定要先执行,否则至少在例名上出现乱码
        	//pstmt.executeQuery("set names utf8");
        	
        	if(sql.isEmpty()){
        		sql="select 'Import string is Empty for Query ?';";
        	}
        	SouthPan.writesql(sql);	//终端窗口同步显示
        	
        	final PreparedStatement pstmt = con.prepareStatement(sql);
        	return pstmt.executeQuery();
        }
        //不要使用上面登陆异常处理方法，因为网络断开后，第一次为网络异常，后面的则全变成了语法异常
        catch (java.sql.SQLException e) {
        	String err=e.toString();	//不要用e.getMessage()方法
        	
        	//要在前面,因为它包含在了SQLException
        	if(err.indexOf("java.net.SocketException")>=0){
        		SouthPan.warn("网络错误,如长时间没有操作,数据库可能主动断开连接,需要重新登陆",2,true,t);
        	}
        	else if(err.startsWith("java.sql.SQLException")){
        		SouthPan.warn("语法错误！请检查sql语句。位置["+Local+"]\n语句："+sql+"\n原因："+e.getMessage(),2,true,t);
        	}
        	else if(e.getMessage().contains("execute command denied") || 
        			e.getMessage().contains("SELECT command denied") || 
        			e.getMessage().contains("Access denied")){
        		SouthPan.warn("没有权限，请向管理员申请权限。位置["+Local+"]\n语句："+sql+"\n原因："+e.getMessage(),2,true,t);
        	}
        	else{
        		SouthPan.warn("结果集出错：位置["+Local+"]\n语句："+sql+"\n原因："+e.getMessage(),2,true,t);
        	}
        }
        return null;
    }
    
    public static String[] getString(String sql, Object ob){
    	String where = ob.getClass().getName() ;
    	if(ob instanceof String){
    		where = (String)ob ;
    	}

    	ArrayList<String[]> arr = getArrayToArrary(sql, where);
    	if(arr==null || arr.size()==0) return new String[0];
    	if(arr.size()>1 && arr.get(0).length>1){
    		String err="该sql语句："+sql+"\n得到的结果集其行数与列数均大于1,无法转字符串！\n Where:"+where;
			JOptionPane.showMessageDialog(Front.front, err);
			return new String[0];
    	}
    	
    	if(arr.size()==1) return arr.get(0);
    	String val[] = new String[arr.size()];
    	for(int k=0; k<arr.size(); k++){
    		val[k]=arr.get(k)[0];
    	}
    	return val ;
    }
    
    //表的列名
    public static ArrayList<String> getcolname(String Table_name,String where){
    	ArrayList<String[]> arr = getArrayToArrary("describe "+Table_name, where);
    	ArrayList<String> type = new ArrayList<String>();
    	for(String temp[] : arr){
    		type.add(temp[0]);
    	}
    	return type;
    }
    //表的列数据类型
    public static ArrayList<String> getcoltype(String Table_name,String where){
    	ArrayList<String[]> arr = getArrayToArrary("describe "+Table_name, where);
    	ArrayList<String> type = new ArrayList<String>();
    	for(String temp[] : arr){
    		type.add(temp[1]);
    	}
    	return type;
    }
    
    //规定，如果不传入对象表，则系统用new JTable()代替???
    public static JTable getTable(String sql, Object ob){
    	return getTable(sql, new JTable(), ob, false);
    }
    //返回一个空表，但给予不可编辑的功能
    public static JTable getTable(){
    	final JTable t=new JTable();
    	final DefaultTableModel mo=new DefaultTableModel(0,0){
    		private static final long serialVersionUID = 352121972230819L;
    		//不可编辑目标元素
	        public boolean isCellEditable(int row, int column) {
	        	return false;
	        }
    	};
    	
    	t.setModel(mo);
		t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //一次只能选择一行
		t.setAutoCreateRowSorter(true);  //单击标题排序
		
		//加一个右键导出功能
		t.setComponentPopupMenu(new Popup_tab(t));
		//Var.getTableHeight()方法千万不要又间接调用本方法，用否则会形成一个循环
		t.setRowHeight(Var.getTableHeight());
		return t;
    }
    //规定，传入的对象t不可为null
    public synchronized static JTable getTable(String sql, JTable t, Object ob, boolean isColor){
    	String where = ob.getClass().getName() ;
    	if(ob instanceof String){
    		where = (String)ob ;
    	}
    	
    	if(t==null) return new JTable();
		final ResultSet rs=getrs(sql, where, t);
		
		if(rs==null)	return new JTable();
		String[] columns_name;		//表的例名
	   	try {
	   		ResultSetMetaData md=rs.getMetaData();
			columns_name=new String[md.getColumnCount()];
			for(int m=0;m<md.getColumnCount();m++){
				columns_name[m]=md.getColumnName(m+1);
			}
		}
	   	catch(SQLException e1){
			SouthPan.warn(sql+"\n调用Sql.getTable()方法初始化例名失败。\n"+e1.toString(), true);
			return new JTable();
		}
		
		//向表中写入数据
		try{
			rs.last();
			String ss[][]=new String[rs.getRow()][columns_name.length];
			
			rs.beforeFirst();
			while(rs.next()){
				for (int i=0;i<columns_name.length;i++){
					String cat=rs.getString(i+1);
					ss[rs.getRow()-1][i]=cat;
				}
			}
			
			//关键一部，更新例名数据
			DefaultTableModel mod=(DefaultTableModel)t.getModel();
			mod.setDataVector(ss, columns_name);
		}
		catch (SQLException se) {
			SouthPan.warn(sql+"\n写入到表格中时未能成功,位置：Sql\n"+se.toString(), true);
            return t;
        }
		finally {
        	try{
        		rs.getStatement().close();
        		rs.close();
        	}catch (Exception e) {}
        }
		
		//加色
		if(isColor) t.setRowHeight(Var.getTableHeight());
		if(isColor) t.setDefaultRenderer(Object.class, new TableCella());
		autoWidthA(t);		//自动列宽
		
		return t;
    }
    
    /***************************************************************************************************/
    public static void getArrayToTable(String sql, Object ob, JTable t){
    	final ArrayList<String[]> arr = getArray(sql, ob, t);
    	if(arr.size()==0){
    		//清空表，表示没有查询到任何数据
    		while(t.getRowCount()>0){
    			((DefaultTableModel)t.getModel()).removeRow(0);
    		}
    		return ;
    	}
    	String col[] = arr.remove(0);
    	
    	final String val[][] = new String[arr.size()][];
    	for(int k=0;k<arr.size();k++){
    		val[k] = arr.get(k);
    	}
    	
    	//关键一步，更新数据
    	final DefaultTableModel mod=(DefaultTableModel)t.getModel();
		mod.setDataVector(val, col);
    }
    
    public static ArrayList<String[]> getArrayToArrary(String sql, Object ob){
    	final ArrayList<String[]> arr = getArray(sql, ob, null);
    	if(arr.size()>0) arr.remove(0);
    	return arr;
    }
    
    public static ArrayList<String> getArrayListToColumn(String tablename, Object ob){
    	final ArrayList<String[]> arr = getArray("describe "+tablename, ob, null);
    	arr.remove(0);
    	final ArrayList<String> val = new ArrayList<String>();
    	for(String[] temp : arr){
    		val.add(temp[0]);	//第一列是列名
    	}
    	return val;
    }
    
    private synchronized static ArrayList<String[]> getArray(String sql, Object ob, JTable t){
    	String where = ob.getClass().getName() ;
    	if(ob instanceof String){
    		where = (String)ob ;
    	}
    	
    	final ResultSet rs=getrs(sql, where, t);
		if(rs==null) return new ArrayList<String[]>();
		
		final ArrayList<String[]> val = new ArrayList<String[]>();
		try{
			ResultSetMetaData md=rs.getMetaData();
			int col = md.getColumnCount();
			
			//将列名加入到第一的位置
			String arr[] = new String[col];
			for(int m=0;m<col;m++){
				arr[m]=md.getColumnName(m+1);
				if(arr[m]==null) arr[m]="";
			}
			val.add(arr);
			
			//向后续中写入数据
			while(rs.next()){
				arr = new String[col];
				for (int i=0;i<col;i++){
					arr[i] = rs.getString(i+1);
					if(arr[i]==null) arr[i]="";
				}
				val.add(arr);
			}
		}
		catch (SQLException se) {
			SouthPan.warn(sql+"\n读取数据未能成功,位置：Sql.getArray()\n"+se.toString(), 2, true, t);
			return new ArrayList<String[]>();
        }
		finally{
        	try{
        		if(rs!=null && rs.getStatement()!=null) rs.getStatement().close();
        		if(rs!=null) rs.close();
        	}catch (Exception e) {}
        }
		return val;
		
		//指定列名
		//DefaultTableModel t_model=(DefaultTableModel)t.getModel();
		//t_model.setColumnIdentifiers(columns_name);
    }
    /***************************************************************************************************/
    /*
    //如果用java来提交事务,则使用以下方法，但以下方法已弃用，仅供学习之用
    public static void Transaction1(String sql[]){
        try {
        	//将commit设置为回滚
        	con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            for(int m=0;m<sql.length;m++){
            	stmt.addBatch(sql[m]);
            }
            int k[]=stmt.executeBatch();//提交事务 ,返回值为受影响的行数
            con.setAutoCommit(true);
        }catch (SQLException e) {}
    }
    */
    
    //调用数据库中的存储过程,第一个参数为存储过程名，第二个为传参
    public static boolean mysqlprocedure(String pro,String val){
    	final ArrayList<String> v=new ArrayList<String>();
    	v.add(val);
    	return mysqlprocedure(pro,v);
    }
    public static boolean mysqlprocedure(String pro){
    	return mysqlprocedure(pro,new ArrayList<String>());
    }
    //为了防止多线程调用存储过程时发生阻塞，要用到同步关键字
    public synchronized static boolean mysqlprocedure(String pro,ArrayList<String> v){
    	String val="?";
		for(int k=0;k<v.size();k++)	{val=val+",?";}
		String sql = "{call "+pro+"("+val+")}";
        try{
            cs = (CallableStatement)con.prepareCall(sql);
            cs.registerOutParameter(1, Types.VARCHAR);	//输出型参数
            //cs.setString(2, hostName);				//输入型参数
            for(int k=0;k<v.size();k++){
            	cs.setString(k+2, v.get(k));
            }
            cs.execute();	//总是返回boolean型的值false
            //如果要得到结果集应使用rs = cs.executeQuery();

            if(cs.getWarnings()!=null){
            	SouthPan.warn("存储过程"+pro+"返回的警告信息：\n"+cs.getWarnings(),true);
            }
            
            //事务中输出的提示信息，即得到第一个输出型参数的值
            final String sqlout = cs.getString(1);
            if(sqlout==null){
            	String s="存储过程 "+pro+" 的输出变量 sqlout 为 null!\n";
            	s=s+"这种情况一般是存储过程代码有误或传参错误导致异常，为使存储过程能够回滚，加有如下代码：\n";
            	s=s+"DECLARE EXIT HANDLER FOR sqlexception ROLLBACK;\n";
            	s=s+"但该代码导致存储过程不返回任何消息。请行先将该代码注释掉 或 检查传入参数 后再调试！";
            	SouthPan.warn(s,true);
            }
            else if(sqlout.isEmpty()){
            	SouthPan.warn("调用存储过程:"+pro,false);	//显示一下你做过什么
            	//人为规定存储过程输出变量sqlout为空字符串时不作响应，说明一切正常,但返回false
            	//注意的是，存储过程中的输出变量sqlout默认是null。如果存储过程正确，需要记得给其赋值空字符串
            }
            else{
            	//用输了变量的第一个字符标记是否对话框显示，并规定只对带字母'Y','N'前辍的才返回true
            	//'Y' 标记是用来显示对话框回应的。且存储过程执行成功
            	if(sqlout.startsWith("Y")){
            		SouthPan.warn("Procedure:〖"+pro+"〗Out："+sqlout,true);
            		return true;	
            	}
            	//'N' 标记是用来不显示对话框回应的。且存储过程执行成功
            	else if(sqlout.startsWith("N")){
            		SouthPan.warn("Procedure:〖"+pro+"〗Out："+sqlout,false);
            		return true;
            	}
            	//没有标记的情况，存储过程返回执行失败
            	else{
            		SouthPan.warn("Procedure:〖"+pro+"〗Out："+sqlout,0,true);
            		return false;
            	}
            }
        }
        catch(Exception e){
			String s = e.getMessage();
			if (s == null) {
				// 比如，cat连接到了数据库，然后root删除了cat账号，当cat调用存储过程时e.getMessage就为空。
				s = "异常消息为空，可能帐号不存在，或其它不明原因。";
			}
			else if (s.startsWith("execute command denied to user")) {
				s = "没有权限，请向管理员申请。\n" + s;
			}
			SouthPan.warn("调用数据库中的存储过程" + pro + "异常: \n" + s, true);
        }
        finally{
        	//不再使用就关闭
        	try{cs.close();}catch (Exception e) {};
        }
        return false;
        //乱码解决 str=new String(str.getBytes("ISO-8859-1"),"utf-8");
        //注意:如果你的存储过程不返还结果集,你需要用cstmt.executeUpdate()或cstmt.execute(),而不是cstmt.executeQuery();
    }
    
    /*
     * 专用于账单预览,传入的参数：餐次，页码，模板
     * */
    public static ArrayList<ArrayList<String>> procedure_bill(String a,String b,String templet,String isnew,String showback,String showlist){
    	SouthPan.warn("调用存储过程:bill_view",false);
        try{
        	final String sql = "{call bill_view(?,?,?,?,?,?,?)}";
            cs = (CallableStatement)con.prepareCall(sql);
            cs.registerOutParameter(1, Types.VARCHAR);	//输出型参数
            //cs.setString(2, hostName);				//输入型参数
            cs.setString(2, a);
            cs.setString(3, b);
            cs.setString(4, templet);
            cs.setString(5, isnew);
            cs.setString(6, showback);
            cs.setString(7, showlist);
        }catch (Exception e) {
			// TODO: handle exception
		}
        return mysqlprocedure();
    }
    private static ArrayList<ArrayList<String>> mysqlprocedure(){
    	final ArrayList<ArrayList<String>> v=new ArrayList<ArrayList<String>>();
        try{
            boolean boo=cs.execute();
			while (boo) {
				final ArrayList<String> sub=new ArrayList<String>();
				v.add(sub);
				final ResultSet rs = cs.getResultSet();
				
				while (rs != null && rs.next()) {
					//先得到列数
					ResultSetMetaData md=rs.getMetaData();
					int col=md.getColumnCount();
					
					//对于有多列的数据，则顺序连接起来
					String temp="";
					for(int x=1;x<=col;x++){
						temp = temp + rs.getString(x);
					}
					sub.add(temp);
				}
				boo = cs.getMoreResults(); //检查是否存在更多结果集
			}
			
			//错误处理
			String sqlout = cs.getString(1);
			if(sqlout!=null){
				SouthPan.warn(sqlout,true);
			}
			
			//非billview表sqltext语法错误消息显示在这，但要先修改存储过程错误处理方式
			if(cs.getWarnings()!=null){
            	SouthPan.warn("存储过程billview返回的警告信息：\n"+cs.getWarnings(),true);
            }
        }catch(Exception e){
			String s = e.getMessage();
			if (s == null) {
				// 比如，cat连接到了数据库，然后root删除了cat账号，当cat调用存储过程时e.getMessage就为空。
				s = "异常消息为空，可能帐号不存在，或其它不明原因。";
			}
			else if (s.startsWith("execute command denied to user")) {
				s = "没有权限，请向管理员申请。\n" + s;
			}
			SouthPan.warn("调用数据库中的存储过程billview异常: \n" + s, true);
        }finally{
        	try{cs.close();}catch (Exception e) {}
        }
        return v;
    }
    
    /***************************************************************************************/
    
    //根据列名和第几组从表格中得到对应值,公共调用
	public static String getval(JTable t,String colname,int row){
		int col=-1;
		for(int k=0;k<t.getColumnCount();k++){
			if(t.getColumnName(k).equals(colname)){
				col=k;
				break;
			}
		}
		if(col==-1){
			String s="";
			for(int k=0;k<t.getColumnCount();k++){
				s=s+t.getColumnName(k)+",";
			}
			SouthPan.warn("未能从表中找到列名为："+colname+" 的一列，请检查！\n所有列名如下："+s, false);
			return "";
		}
		String tempval=t.getValueAt(row, col)+"";	//因为null+""的值为字符串"null"
		if(tempval.equals("null")) tempval="";
		return tempval;
	}

	//保留两位小数点,注意考虑负数-.23 , .21
	public static String twodot(double val){
		final DecimalFormat df=new DecimalFormat(".##");	//保留小数点后两位
		String s=df.format(val);
		char c=s.charAt(0);
		char b=s.charAt(1);	//double转字符串后一般都至少有2个长度
		
		//如果是正数如：.23，则检查第一位是不是点号
		if(c=='.') s="0"+s;
		
		//如果是负数如：-.23，则检查第一位是不是减号以及第二位是不是点号
		if((c=='-')&&(b=='.')) s=s.replace("-", "-0");
		return s;
	}
	//将文本框内的值转成double,不做作任何其它修饰
	public static double toDouble(String s,double d){
		try {
			d=Double.valueOf(s);
		} catch (Exception e) {
			// TODO: handle exception
			SouthPan.warn("字符串:"+s+" 转double转数字失败。返回默认值：0.0", false);
		}
		return d;
	}
	
	//边框效果
	public static Border getBorder(int k,String s){
		return getBorder(k,s,new Color(59,59,59));
	}
	public static Border getBorder(int k,String s,Color c){
		//传入参数k=0时，可得到下一行代码效果
		Border titledBorder=BorderFactory.createTitledBorder(s);
		//嵌入效果,好像突出来了
		if(k==1) titledBorder=new TitledBorder(new BevelBorder(BevelBorder.LOWERED,null,null,null,null),s,TitledBorder.LEFT,TitledBorder.TOP,null,c);
		//浮雕化效果,比较弱，边界发白软细
		else if(k==2)	titledBorder=new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,null,null),s,TitledBorder.LEFT,TitledBorder.TOP,null,c); 
		//边框为黑色
		else if(k==3)	titledBorder=BorderFactory.createLineBorder(c);
		return titledBorder;
		
		//设置边框方法setBorder(Border); 
		//setBorder方法内的参数也可以是TitledBorder
		//去掉边框
	    //Border oldBorder=this.getBorder();	//放在改变边框之前
	    //setBorder(BorderFactory.createEmptyBorder());
	    //恢复边框 
	    //this.setBorder(oldBorder);
	}
	
	public static void TableAtt(JTable t,Boolean autoWidth,Boolean color){
		if(autoWidth) autoWidthB(t);
		else autoWidthA(t);
		if(color) t.setDefaultRenderer(Object.class, new TableCella());
	}
	
	//以所有列宽的平均值为标准
	private static void autoWidthA(JTable table){
		if(table==null || table.getRowCount()==0) return ;
		//找到每一列数据中数据长度最长的一个并将其长度作为列宽,实际表明，大部分求平均值UI界面更友好
		final DefaultTableColumnModel dcm = (DefaultTableColumnModel)table.getColumnModel(); // 获取列模型
		for(int col=0;col<table.getColumnCount();col++){
			int maxwidth = 0;
			for (int row=0; row<table.getRowCount(); row++){
				final TableCellRenderer rend = table.getCellRenderer (row, col);  
				final Object value = table.getValueAt (row, col);
				final Component comp = rend.getTableCellRendererComponent (table,value,false,false,row,col);  
			    //maxwidth = Math.max (comp.getPreferredSize().width, maxwidth);
			    maxwidth = maxwidth+comp.getPreferredSize().width;
			}
			//dcm.getColumn(col).setPreferredWidth(maxwidth);
			if(table.getRowCount()>0) dcm.getColumn(col).setPreferredWidth(maxwidth/table.getRowCount());
		}
		/*	如果表列头太长，而该列数据值太短，则应以表列头的宽为准，用下面的方法
		TableCellRenderer headerRenderer = column.getHeaderRenderer();  
		if (headerRenderer == null)  headerRenderer = table.getTableHeader().getDefaultRenderer();  
		Object headerValue = column.getHeaderValue();  
		Component headerComp =  headerRenderer.getTableCellRendererComponent (table,headerValue,false,false,0,col);  
		maxwidth = Math.max (maxwidth,headerComp.getPreferredSize().width);  */
	}
	
	//以最大的列宽为标准
	private static void autoWidthB(JTable table){
		if(table==null || table.getRowCount()==0) return ;
		final DefaultTableColumnModel dcm = (DefaultTableColumnModel)table.getColumnModel(); // 获取列模型
		int totalwidth = 0 ;
		for(int col=0;col<table.getColumnCount();col++){
			int maxwidth = 0;
			for (int row=0; row<table.getRowCount(); row++){
				final TableCellRenderer rend = table.getCellRenderer (row, col);  
				final Object value = table.getValueAt (row, col);
				final Component comp = rend.getTableCellRendererComponent (table,value,false,false,row,col);  
			    maxwidth = Math.max (comp.getPreferredSize().width, maxwidth);
			}
			dcm.getColumn(col).setPreferredWidth(maxwidth);
			totalwidth = totalwidth + maxwidth ;
		}
		
		//如果总列宽大于表格的宽度，则改用平均列宽更美观
		if(table.getWidth()>0 && table.getWidth()<totalwidth){
			autoWidthA(table);
		}
	}
	
	//强制以最大的列宽为标准
	public static void autoWidthC(JTable table){
		if(table==null || table.getRowCount()==0) return ;
		final DefaultTableColumnModel dcm = (DefaultTableColumnModel)table.getColumnModel(); // 获取列模型
		int totalwidth = 0 ;
		for(int col=0;col<table.getColumnCount();col++){
			int maxwidth = 0;
			for (int row=0; row<table.getRowCount(); row++){
				final TableCellRenderer rend = table.getCellRenderer (row, col);  
				final Object value = table.getValueAt (row, col);
				final Component comp = rend.getTableCellRendererComponent (table,value,false,false,row,col);  
			    maxwidth = Math.max (comp.getPreferredSize().width, maxwidth);
			}
			dcm.getColumn(col).setPreferredWidth(maxwidth);
			totalwidth = totalwidth + maxwidth ;
		}
	}
}
