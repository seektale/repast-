package root;
import java.awt.Color;
import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import ch.vorburger.exec.ManagedProcessException;
import ch.vorburger.mariadb4j.DB;
import ch.vorburger.mariadb4j.DBConfiguration;
import ch.vorburger.mariadb4j.DBConfigurationBuilder;

public class Mariadb_ResetPassword extends JDialog {

	private static final long serialVersionUID = 1678755796114973038L;
	private final JTextPane txt = new JTextPane();
	
	public Mariadb_ResetPassword() {
		
		super(new JFrame(), true);
		setContentPane(new JScrollPane(txt));
		setSize(500, 300);
		setLocationRelativeTo(null);
		setTitle("Maria Root Password Reset");
		//setUndecorated(true);
		
		txt.setBackground(new Color(230,230,240));
		txt.setEditable(false);
		
		final String jarPath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		final String dbPath = new File(jarPath).getParent() + File.separator + "dblocal";
		if (new File(dbPath).exists() == false) {
			JOptionPane.showMessageDialog(this, "无法完成密码重置,因为没有找到数据库目录：" + dbPath);
			return;
		}
		
		write("检测到配置文件 conf/repast.properties 参数 RootPasswordReset=Y 要求重置密码。", Color.RED);
		write("准备启动线程，将 Maria 数据库超级账户 root 的密码重置为：123456", Color.BLACK);
		final Thread th = new Thread(new Runnable() {
			public void run() {
				try {
					init(dbPath);
					write("已结束，提示：root用户在每次登陆时自动恢复所有权限：GRANT all PRIVILEGES on *.* to 'root'@'%' IDENTIFIED BY '123465' WITH GRANT OPTION", Color.BLACK);
				} catch (Exception e) {
					e.printStackTrace();
					write("Maria 数据库启动失败：", Color.RED);
				}
			}
		});
		th.setDaemon(true);
		th.start();
		
		setVisible(true);
	}
	
	private void init(final String path) throws Exception {
		
		write("正在配置 Maria 数据库为 --skip-grant-tables=on 启动模式 ... ");
		final DBConfiguration dbConfiguration = DBConfigurationBuilder.newBuilder().setPort(3306).setDataDir(path)
				.addArg("--user=root")
				.addArg("--skip-grant-tables=on")	//这一句是关键
				.addArg("--skip-name-resolve")
				.addArg("--character-set-server=utf8")
				.addArg("--character-set-client=utf8")
				.build();
		
		final DB db = DB.newEmbeddedDB(dbConfiguration);
		write("正在启动 Maria 数据库，目录："+path);
		db.start();
		
		// 系统关闭时执行
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			try {
				if(db!=null) db.stop();
			} catch (ManagedProcessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}));
		
		/*-------------------------------------------执行SQL---------------------------------------------------*/
		
		write("正在连接到 Maria 数据库(127.0.0.1:3306) ... ");
		final MysqlDataSource myds = new MysqlDataSource();
    	myds.setServerName("127.0.0.1");
    	myds.setPort(3306);
    	myds.setDatabaseName("mysql");
    	
		try {
			final Connection con = myds.getConnection();
			con.setAutoCommit(true);	//自动提交
			final Statement stmt = con.createStatement();
			write("执行SQL语句：FLUSH PRIVILEGES");
			stmt.execute("FLUSH PRIVILEGES;");
			write("执行SQL语句：ALTER USER 'root'@'localhost' IDENTIFIED BY '123456'");
			stmt.execute("ALTER USER 'root'@'localhost' IDENTIFIED BY '123456';"); //不一定好使,在某些特定环境下才有效
			write("再次执行SQL语句：FLUSH PRIVILEGES");
			stmt.execute("FLUSH PRIVILEGES;");
			stmt.close();
			con.close();
			write("已关闭与  Maria 数据库的连接。");
		}
		catch (SQLException e) {
			e.printStackTrace();
			write("连接到 Maria 数据库后执行SQL语句发生了异常："+e.getMessage(), Color.RED);
		}
		
		/*-------------------------------------------关闭数据库---------------------------------------------------*/
		
		write("正在关闭  Maria 数据库 ... ");
		try {
			if(db!=null) db.stop();
			write("关闭  Maria 数据库已完成 。");
		} catch (ManagedProcessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			write("关闭 Maria 数据库发生了异常："+e.getMessage(), Color.RED);
		}
	}
	
	private void write(String msg) {
		write(msg, Color.BLUE);
	}
	private void write(String msg, Color textColor) {
		final SimpleAttributeSet set = new SimpleAttributeSet();
		StyleConstants.setForeground(set, textColor);	// 设置文字颜色
		final Document doc = txt.getStyledDocument();
		try {
			doc.insertString(doc.getLength(), msg+"\n", set);// 插入文字
			txt.selectAll();
			//迫使滚动条自动滚动到最后面
			if(txt.getSelectedText()!=null){
				txt.setCaretPosition(txt.getSelectedText().length());  
			}
		} 
		catch (BadLocationException e){}
	}
	
}
