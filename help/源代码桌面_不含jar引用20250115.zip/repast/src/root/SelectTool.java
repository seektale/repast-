package root;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
public class SelectTool extends JDialog implements ActionListener{
	private static final long serialVersionUID = 628339174127004718L;
	private final JPanel Pan=new JPanel(new BorderLayout());
	private final JComboBox<String> text=new JComboBox<String>();
	private final JTable t=Sql.getTable();
	public SelectTool(){
	    //表来源 `information_schema`.`tables`
	    text.addItem("select tables.`TABLE_NAME`, tables.`TABLE_COMMENT` from information_schema.tables " +
	    			 "where (tables.`TABLE_SCHEMA` = 'repast') #查看所有表格信息");
	    text.addItem("show variables like 'character%' #查看编码设置");
	    text.addItem("show processlist #在线用户");
	    text.addItem("SHOW profiles;  #查找sql耗时瓶颈，需要用SET profiling=1 开启");
	    text.addItem("show global status like 'uptime'; #数据库运行工作时间，单位：秒");
	    //text.addItem("show global variables like '%timeout%' #连接超时时间");
	    text.setEditable(true);
	    
	    text.addActionListener(this);
		Pan.add("North",text);
		Pan.add("Center",new JScrollPane(t));
		
		setContentPane(Pan);
	    setTitle("数据库查询工具");
	    setSize(920,600);
	    setAlwaysOnTop(true);
	    setLocationRelativeTo(null);
	    setIconImage(Front.logo);
	    setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		Sql.getArrayToTable(text.getSelectedItem().toString(), this, t);
		Sql.TableAtt(t, true, false);
		final String temp=text.getSelectedItem().toString();
		boolean boo = true;
		for(int k=0;k<text.getItemCount();k++){
			if(text.getItemAt(k).toString().equals(temp)){
				boo = false;
				break;
			}
		}
		if(boo) text.addItem(temp);
	}
}

