package root;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JInternalFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import pub.Popup_tab;
public class SysOption extends JInternalFrame{
	private static final long serialVersionUID = -193113501378863350L;
	//为了简化复杂度，也为了限制对系统图片如logo的修改，不提供对图片的修改功能
	private JPanel Pan=new JPanel(new BorderLayout());
	private JTree tree=new JTree(new DefaultMutableTreeNode("参数类别"));
	private JTable t=Sql.getTable();
	public SysOption(){
		super("系统选项",true,true,true,true);
		setContentPane(Pan);
	    setResizable(true);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
		Pan.add(new JScrollPane(t), BorderLayout.CENTER);
		Pan.add(new JScrollPane(tree), BorderLayout.WEST);
		
	    initTree();
		t.setComponentPopupMenu(new SysOption_Popup(t));
		t.setCellSelectionEnabled(true);	//一次只能选择一个单元格
	}
	
	private void initTree(){
		DefaultTreeModel treeModel = (DefaultTreeModel)tree.getModel();
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			//节点变化事件
			public void valueChanged(TreeSelectionEvent arg0){
				refresh();
			}
		});
		
		//由DefaultTreeModel的getRoot()方法取得根节点.
		DefaultMutableTreeNode rootNode = (DefaultMutableTreeNode) treeModel.getRoot();
		//删除所有子节点.
		rootNode.removeAllChildren();
		//根据数据库中的信息，新创立节点
		String ss[] = Sql.getString("select distinct name from general", this);
		for (String temp : ss) {
			DefaultMutableTreeNode su = new DefaultMutableTreeNode(temp);
			rootNode.add(su);
		}
		//刷新节点
		treeModel.reload();
		tree.setOpaque(false);	//否则背景为白色
	}
	
	//更新数据
	private void refresh(){
		//首先得到当前选择的节点
		String name="";
		TreePath treepath = tree.getSelectionPath();
		if (treepath != null){
			DefaultMutableTreeNode selectedNode=(DefaultMutableTreeNode)treepath.getLastPathComponent();
			name= selectedNode.toString();
		}

		String sql="select * from general where name='"+name+"'";
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
	}
	
	/*
	 * 内部类	右键菜单
	 */
	class SysOption_Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -1825964425400196L;
		private JTable Tab;
		SysOption_Popup(JTable Tab){
			this.Tab=Tab;
			JMenuItem edit = new JMenuItem("编辑当前参数");
			JMenuItem clear = new JMenuItem("清空值");
			JMenuItem a = new JMenuItem("新增数据行");
			JMenuItem b = new JMenuItem("删除数据行");
			
			edit.addActionListener(this);
			clear.addActionListener(this);
			a.addActionListener(this);
			b.addActionListener(this);

			add(edit);
			add(clear);
			addSeparator();
			add(a);
			add(b);
			
			//原有的菜单项功能
			addSeparator();
			Popup_tab su=new Popup_tab(t);
			add(su.getMenu());
		}
		public void actionPerformed(ActionEvent e) {
			ArrayList<String> v=new ArrayList<String>();
			if(e.getActionCommand().equals("删除数据行")){
				int k=Tab.getSelectedRow();
				if(k==-1){
					JOptionPane.showMessageDialog(null, "没有选择要删除的数据行!");
					return ;
				}
				v.add(Tab.getValueAt(k,0)+"");	//索引
				v.add("del");
				//提交
				Sql.mysqlprocedure("sysoption",v);
			}
			
			//新增数据行
			else if(e.getActionCommand().equals("新增数据行")){
				v.add(Tab.getValueAt(0,0)+"");	//第一行第一列的索引作为新数据的模型
				v.add("add");
				//提交
				Sql.mysqlprocedure("sysoption",v);
			}
			else if(e.getActionCommand().equals("编辑当前参数")){
				int m = t.getSelectedRow();
				int n = t.getSelectedColumn();
				if(m<0 || n<0) return ;
				
				String val = t.getValueAt(m, n).toString();
				val = JOptionPane.showInputDialog("请输入参数：",val);
				if(val==null) return ;
				
				//主键查找
				String primarykey = t.getValueAt(m, 0).toString();
				v.add(primarykey);
				v.add(n+"");		//第几列
				v.add(val);
				Sql.mysqlprocedure("sysoption_edit",v);
			}
			else{
				int m = t.getSelectedRow();
				int n = t.getSelectedColumn();
				//主键查找
				String primarykey = t.getValueAt(m, 0).toString();
				v.add(primarykey);
				v.add(n+"");		//第几列
				v.add("");
				Sql.mysqlprocedure("sysoption_edit",v);
			}
			
			//不管是否成功，都刷新
			refresh();
		}
	}
}
