package ignore;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import root.Front;
import root.Sql;

/*
 * 已废弃，20231106
 * */

public class MailSend extends JDialog implements ActionListener{
	private static final long serialVersionUID = 9149459916596585L;
	private JButton exit = new JButton("退出");
	private JButton ok = new JButton("发送");
	private JLabel tip = new JLabel("消息");
	private JTextArea text = new JTextArea();
	private String old = "" ;
	public MailSend(){
		super(Front.front, "电邮反馈问题或意见  (发送邮箱需要开启POP3/SMTP服务)", true);
		
		exit.addActionListener(this);
		ok.addActionListener(this);
		ok.setFocusable(false);
		
		JPanel pan = new JPanel(new BorderLayout());
		pan.setBorder(BorderFactory.createTitledBorder(""));
		text.setLineWrap(true); 		//自动换行
    	text.setWrapStyleWord(true);	//单词换行不拆分
		pan.add(new JScrollPane(text), BorderLayout.CENTER);
		
		JPanel sou = new JPanel(new FlowLayout());
		sou.add(ok);
		sou.add(exit);
		pan.add(sou, BorderLayout.SOUTH);
		pan.add(tip, BorderLayout.NORTH);
		
		setSize(500, 300);
		setContentPane(pan);
		setAlwaysOnTop(true);
		//setResizable(false);			//没有窗体左上角小图标
		setIconImage(Front.logo);
		setLocationRelativeTo(null);	//初始位置在屏幕正中间
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==exit){
			dispose();
			return ;
		}
		if(e.getSource()==ok){
			if(text.getText().trim().isEmpty())	return ;
			
			if(text.getText().equals(old)){
				tip.setText(" 请务重复发送相同内容的电邮。 ");
				return ;
			}
			
			Thread th = new Thread(new Runnable() {
				public void run() {
					sub();
				}
			});
			th.start();
		}
	}
	private void sub(){
		tip.setText(" 正在发送邮件... ");
		String sql=" select item,value,remark from general where name='电邮' ";
		ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
		if(arr.size()==0){
			tip.setText(" 查询数据库初始化参数失败。 ");
			return ;
		}
		String sendname="",sendpsd="",receive="";
		for(String temp[] : arr){
			if(temp[0].equals("发送者")){
				sendname = temp[1] ;
				sendpsd  = temp[2] ;
				continue ;
			}
			if(temp[0].equals("接收者")){
				receive = temp[1] ;
				tip.setText(" 正在发送邮件...  (发送至："+receive+")");
			}
		}
		send(sendname, sendpsd, receive);
	}
	
	private void send(String sendname, String sendpsd, String receive){
		// 找出发送者邮件的域名
		int k = sendname.indexOf("@");
		if(k<=0){
			tip.setText(" 发送者邮件格式不正确: "+sendname);
			return ;
		}
		String domain = sendname.substring(k+1);
		domain = "smtp."+domain ;	// "smtp.qq.com"
		
		//szteaport@163.com  paul5198
		Properties props = new Properties();
		//设置邮件服务器地址，连接超时， 时限 等信息
		props.put("mail.smtp.host", domain);
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.connectiontimeout", "10000");
		props.put("mail.smtp.timeout", "10000");
		
		/*
		//创建缺省的session对象
		Session session = Session.getDefaultInstance(props, null);

		//创建message对象
		Message msg = new MimeMessage(session);

		//设置发件人和收件人
		try{
			//发送者　szteapot@163.com paul5198
			InternetAddress addressFrom = new InternetAddress(sendname);
			msg.setFrom(addressFrom);
			
			//接收者
			InternetAddress addressTo = new InternetAddress(receive);
			msg.setRecipient(Message.RecipientType.TO, addressTo);

			//设置邮件标题，中文编码
			//subject = MimeUtility.encodeText(new String(subject.getBytes(), "GB2312"), "GB2312", "B");
			msg.setSubject("Smosu餐饮软件系统反馈与意见"); 
			msg.setText(text.getText());
			Transport transport = session.getTransport("smtp");
	        transport.connect(domain, sendname, sendpsd);
	        transport.sendMessage(msg, msg.getAllRecipients());
	        transport.close();
	        
	        tip.setText(" 邮件发送成功");
	        old=text.getText();
		}
		catch(Exception e){
			System.out.print(e);
			tip.setText(" 邮件发送失败");
			JOptionPane.showMessageDialog(this, "发生错误,信息如下：\n"+e.getMessage()+"\n"+e.toString(),"发生错误",0);
		}
		*/
	}
}
