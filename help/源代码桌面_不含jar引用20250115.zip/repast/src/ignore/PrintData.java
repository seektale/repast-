package ignore;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.Timer;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import pub.ConfigFile;
import pub.Photo;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class PrintData extends JDialog implements ActionListener{
	private static final long serialVersionUID = 66885153653730386L; 
	private int mealnum,dishind;
	private JButton refresh;
	private JPanel dia = new JPanel(new BorderLayout());
	private JLabel tip = new JLabel("tip",JLabel.CENTER);
	private Timer time = new Timer(300, this);
	private int thnum = 0;
	private boolean hold = false, flag = true ;
	
	/*
	 * 方法已过时，这里仅用于学习之用。(2015-10-31)
	 * */
	
	//传入的值为台次,商品索引数组
	public PrintData(int mealnum, int dishind, JButton refresh,int k){
		super(Front.front, "热敏打印机出单实时状态",true);
		this.mealnum = mealnum ;
		this.dishind = dishind ;
		this.refresh = refresh ;
		
		tip.setForeground(Color.RED);
		hminit();
	}
	// hold 标示出单是否叫起
	public PrintData(int mealnum, int dishind, JButton refresh, boolean hold, int k){
		super(Front.front, "热敏打印机出单实时状态",true);
		this.mealnum = mealnum ;
		this.dishind = dishind ;
		this.refresh = refresh ;
		this.hold = hold ;
		
		tip.setForeground(Color.RED);
		hminit();
	}
	
	private void hminit(){
		String config[]=Sql.getString("select 站点 from print_config", this);
		if(config.length==0){
			SouthPan.warn("热敏打印机站点没有进行任何配置。", true);
			return ;
		}
		
		//规定传过来的值的商品索引为0时代表全部出单。
		String sql="";
		if(dishind==0){
			sql = "select binary_check("+mealnum+",0)" ;
		}
		else{
			sql = "select binary_check("+mealnum+","+dishind+")" ;
		}
		
		//检查出单条件结果
		String check[] = Sql.getString(sql, this);
		//没有返回结果
		if(check.length==0) return ;
		//返回结果提示有错误
		if(check[0].startsWith("Error")){
			SouthPan.warn(check[0], true);
			refresh.doClick();
			return ;
		}
		
		//开台读取数据并打印
		String site[] = check[0].split("&");
		time.start();
		thnum=site.length;
		
		JPanel pan = new JPanel(new FlowLayout());
		for(String val : site){
			String temp=ConfigFile.getProperty("PrintCom");
			if(val.startsWith("COM") && temp.isEmpty()){
				thnum-- ;
				continue ;
			}
			
			JTextPane info = new JTextPane();
			info.setEditable(false);
			info.setText("站点：["+val+"] ...\n\n");
			JScrollPane infosp = new JScrollPane(info);
			infosp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			infosp.setPreferredSize(new Dimension(140,180));
			pan.add(infosp);
			print(val, info);
		}
		
		dia.add(tip,BorderLayout.NORTH);
		dia.add(pan,BorderLayout.CENTER);
		
		int width = 140*pan.getComponentCount()+50<300 ? 300 : 140*pan.getComponentCount()+50 ;
		setContentPane(dia);
		setSize(new Dimension(width, 250));
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);	// 初始位置在屏幕正中间
		setVisible(true);
	}
	
	//以线程的方式起动，以免打印机连接不上被主线程被卡住，好像死机了一样
	private void print(final String site, final JTextPane info){
		Thread th = new Thread(new Runnable() {
			public void run() {
				stat("从数据库读取信息...",Color.BLACK,info);
				//byte b[] = Photo.getsitebin(mealnum, dishind, site, hold);
				byte b[] = null ;
				if(b==null){
					stat("读取信息失败？",Color.RED,info);
					thnum--;
					return ;
				}
				
				stat("发往热敏打印机...",Color.GREEN,info);
				
				if(site.startsWith("COM")){
					try {
						String temp=ConfigFile.getProperty("PrintCom");
						// 打包之后测试会卡在这里，可能是因为运行环境由JDK变成了jre，但发布之后配置好dll就好了
						Photo.Printcom(b, temp);
					}
					catch (Exception err) {
						stat("错误, "+err.getMessage(),Color.RED,info);
						err.printStackTrace();
					}
					stat("本地串口打印结束！",Color.BLUE,info);
				}
				else{
					boolean result = Photo.printbin(b, site, false);
					if(result){
						stat("恭喜,出单成功！",Color.BLUE,info);
						String sql = "select binary_result("+mealnum+","+dishind+",'"+site+"','Y')";
						/*
						String how=Photo.selFX(sql);
						stat("\n已提交打印结果:\n"+how,Color.BLUE,info);
						SouthPan.warn("已提交["+site+"]打印结果:"+how, false);
						*/
					}
					else{
						flag = false ; //标记有打印失败的站点
						stat("出单失败",Color.RED,info);
						String sql = "select binary_result("+mealnum+","+dishind+",'"+site+"','N')";
						/*
						String how=Photo.selFX(sql);
						stat("\n已提交打印结果:\n"+how,Color.RED,info);
						SouthPan.warn("已提交["+site+"]打印结果:"+how, false);
						*/
					}
				}
				thnum--;
			}
		});
		th.start();
	}
	
	// 根据传入的颜色及文字，将文字插入文本域
	public void stat(String msg, Color textColor, JTextPane info) {
		SimpleAttributeSet set = new SimpleAttributeSet();
		StyleConstants.setForeground(set, textColor);	// 设置文字颜色
		StyleConstants.setFontSize(set, 12);			// 设置字体大小
		Document doc = info.getStyledDocument();
		try {
			doc.insertString(doc.getLength(), msg+"\n", set);// 插入文字
			info.selectAll();
			//迫使滚动条自动滚动到最后面
			if(info.getSelectedText()!=null){
				info.setCaretPosition(info.getSelectedText().length());  
			}
			info.requestFocus();
		} catch (BadLocationException e){}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(thnum==0){
			tip.setText("打印已结束");
			tip.setForeground(Color.BLUE);
			
			//全部打印方式下待所有进程结束后, 还需要写入打印结果
			if(dishind==0){
				String sql = "select binary_write("+mealnum+")";
				/*
				String how = Photo.selFX(sql);
				tip.setText(tip.getText()+"（统计："+how+"）");
				tip.setToolTipText(tip.getText());
				*/
			}
			
			refresh.doClick();
			time.stop();
			
			if(flag) dispose();		//全部打印成功则自动关闭对话框
			return ;
		}
		
		//│┄┆╲╱
		String ss=tip.getText().substring(tip.getText().length()-1);
		if(ss.equals("┄")) ss="╲";
		else if(ss.equals("╲")) ss="│";
		else if(ss.equals("│"))  ss="╱";
		else if(ss.equals("╱")) ss="┄";
		else ss="┄";
		tip.setText("请勿关闭，当前正有:"+thnum+" 个打印任务在运行...  "+ss);
	}
}
