package ignore;
import java.awt.AWTException;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import pub.ConfigFile;

/*
 * 已废弃，20231106
 * */

public class Db_backup extends JPanel implements ActionListener{
	private static final long serialVersionUID = 6355131094418880160L;
	private JButton dataRestore=new JButton("恢复数据");
	private JButton dataBackup=new JButton("执行备份");
	private JRadioButton one = new JRadioButton("主数据库repast(重要)");
	private JRadioButton two = new JRadioButton("练习数据库study");
	private JRadioButton all = new JRadioButton("所有数据库(包含了账户及权根信息)");
	
	private JTextField filePath_backup=new JTextField(30);
	private JTextField filePath_restore=new JTextField(30);
	private JPasswordField psd=new JPasswordField(20);
	private JTextField server=new JTextField("localhost", 20);
	private String path=ConfigFile.getProperty("DataBackupPath");
	private JTextField tip=new JTextField(70);
	private JTextArea remark = new JTextArea(8,10);
	public Db_backup(String serip){
		server.setText(serip);
	  	setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));	//一行一行的布局
	  	
	  	JPanel temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		psd.setFont(new Font("隶书",Font.BOLD,12));
		temp.add(new JLabel("请认证密码："));
		temp.add(psd);
		temp.add(new JLabel("  数据库操作仅限超级用户 root 执行"));
		add(temp);
		
		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		server.setFont(new Font("隶书",Font.BOLD,12));
		temp.add(new JLabel("服务器地址："));
		temp.add(server);
		temp.add(new JLabel("  可填写域名; 如果是本地主机, 可输入 localhost 或 127.0.0.1"));
		add(temp);
		
		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
		radioGroup.add(one);
		radioGroup.add(two);
		radioGroup.add(all);
		one.setSelected(true);
		temp.add(new JLabel("目标数据库："));
		temp.add(one);
		temp.add(two);
		temp.add(all);
		add(temp);
		add(new JSeparator());
		add(Box.createVerticalStrut((22)));
		
		JPanel center = new JPanel(new GridLayout(1, 2));
    	JPanel backup=backuppan();
    	backup.setBorder(BorderFactory.createTitledBorder("数据备份 Data_backup"));
    	center.add(backup);
    	JPanel res=restore();
    	res.setBorder(BorderFactory.createTitledBorder("数据恢复 Data_restore"));
    	center.add(res);
    	add(center);
    	
    	add(Box.createVerticalStrut((20)));
    	temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(tip);
		tip.setBackground(Color.LIGHT_GRAY);
		tip.setEditable(false);
		add(temp);
		
		dataBackup.addActionListener(this);
		dataRestore.addActionListener(this);
		
    	try{
    		InputStream in = this.getClass().getResourceAsStream("db.txt");
        	BufferedReader rea = new BufferedReader(new InputStreamReader(in,"utf8"));
    		do {
    			String val = rea.readLine();
    			if(val==null) break;
    			remark.setText(remark.getText()+val+"\n");
    		} while (true);
    		rea.close();
    		in.close();
    	}catch (Exception e) {
			e.printStackTrace();
		}
    	remark.setCaretPosition(0);
		add(new JScrollPane(remark));
	}
	private JPanel backuppan(){
		JPanel pan=new JPanel();
		pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));	//一行一行的布局

		JButton cho=new JButton("选择路经");
		final Properties props=System.getProperties();
		final SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");
		if((path==null)||(path.isEmpty())){
			path=props.getProperty("user.home")+"\\Smosu\\DataBackup.sql";
		}
		if(!path.endsWith(".sql")) path=path+".sql";
		int PointIndex=path.lastIndexOf(".");
		path=path.substring(0, PointIndex);
		path=path+"("+sd.format(new Date())+").sql";
		filePath_backup.setText(path);
		
		cho.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser = new JFileChooser();
				chooser.setSelectedFile(new File(props.getProperty("user.home")+"\\Smosu\\DataBackup.sql"));
				int result = chooser.showSaveDialog(null);
				if (result == JFileChooser.APPROVE_OPTION) {
					String s = chooser.getSelectedFile().getPath();
					//在修饰日期之前保存路经
					ConfigFile.setProperty("DataBackupPath",s);
					//加上日期
					if(!s.endsWith(".sql")) s=s+".sql";
					int PointIndex=s.lastIndexOf(".");
					s=s.substring(0, PointIndex);
					s=s+"("+sd.format(new Date())+").sql";
					filePath_backup.setText(s);
				}
				
				//显示命令提示
				String cmd="mysqldump -u root -p --opt --routines --default-character-set=utf8 --all-databases ";
			    if(one.isSelected()){
			    	cmd = "mysqldump -u root -p --opt --routines --default-character-set=utf8 repast ";
			    }
			    if(two.isSelected()){
			    	cmd = "mysqldump -u root -p --opt --routines --default-character-set=utf8 study ";
			    }
			    cmd = cmd + " -h "+server.getText()+" >"+filePath_backup.getText();;
			    tip.setText(cmd);
			}
		});
		
		JPanel temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("存储位置："));
		temp.add(cho);
		pan.add(temp);
		
		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(filePath_backup);
		pan.add(temp);
		
		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("备份结束后命令窗口自动关闭，并打开备份目录"));
		pan.add(temp);
		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JLabel balab = new JLabel("数据库引擎 InnoDB 支持热备份，备份速度较快。");
		balab.setForeground(Color.BLUE);
		temp.add(balab);
		pan.add(temp);
		pan.add(new JSeparator());
		
		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(dataBackup);
		pan.add(temp);
		
		return pan;
	}
	private JPanel restore(){
		JPanel pan=new JPanel();
		pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));	//一行一行的布局
		
		JButton cho=new JButton("选择文件");
		cho.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Properties props=System.getProperties();
				JFileChooser chooser = new JFileChooser();
				chooser.setSelectedFile(new File(props.getProperty("user.home")+"\\Smosu\\dbbackup.sql"));
				chooser.setFileFilter(new FileFilter() {
					public String getDescription() {
						return "*.sql";
					}
					public boolean accept(File arg0) {
						if(arg0.getName().endsWith(".sql")) return true;
						return false;
					}
				});
				int result = chooser.showOpenDialog(null);
				
				if (result == JFileChooser.APPROVE_OPTION) {
					String s = chooser.getSelectedFile().getPath();
					filePath_restore.setText(s);
				}
				
				//显示命令提示
				String cmd="mysql -u root -p --default-character-set=utf8 -h "+server.getText();
			    if(one.isSelected()) cmd=cmd+" repast";
			    if(two.isSelected()) cmd=cmd+" study";
			    tip.setText(cmd);
			}
		});
		
		JPanel temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("文件来源："));
		temp.add(cho);
		pan.add(temp);
		
		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(filePath_restore);
		pan.add(temp);
    	
		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("还原主数据库repast时，如果文件选择错误，会导致失败"));
		pan.add(temp);
		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JLabel balab = new JLabel("还原过程缓慢，可能需数分钟 甚至 数小时。");
		balab.setForeground(Color.RED);
		temp.add(balab);
		pan.add(temp);
		pan.add(new JSeparator());

		temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(dataRestore);
		pan.add(temp);
    	
		return pan;
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==dataBackup) {
			BackupExec();
		}
		else if(e.getSource()==dataRestore) {
			RestoreExec();
		}
	}
	
	private void RestoreExec(){
		if(psd.getPassword().length==0){
			JOptionPane.showMessageDialog(null,"密码不能为空","错误 Error",0);
			return ;
		}
		if(server.getText().isEmpty()){
			JOptionPane.showMessageDialog(null,"服务器地址不能为空","错误 Error",0);
			return ;
		}
		if(filePath_restore.getText().isEmpty()){
			JOptionPane.showMessageDialog(null,"未选择需要恢复的数据库文件(*.sql)","错误 Error",0);
			return ;
		}
		
		Robot robot=null;
		try {
			robot = new Robot();
		} catch (AWTException e1) {
			e1.printStackTrace();
		}
		//Window + R 组合键
	    robot.keyPress(KeyEvent.VK_WINDOWS);
	    robot.keyPress(KeyEvent.VK_R);
	    robot.keyRelease(KeyEvent.VK_WINDOWS);
	    robot.keyRelease(KeyEvent.VK_R);
	    
	    stop();
		setSystemClipboard("cmd");
		past(robot);
	    robot.keyPress(KeyEvent.VK_ENTER);
		
		//登陆mysql数据库命令
	    stop();
	    path="mysql -u root -p --default-character-set=utf8 -h "+server.getText();
	    if(one.isSelected()) path=path+" repast";
	    if(two.isSelected()) path=path+" study";
	    
	    setSystemClipboard(path);
		cmdpast(robot);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		//输入密码回车登陆
		stop();
		setSystemClipboard(new String(psd.getPassword()));
		cmdpast(robot);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		//输入指定文件回车开始恢复
		stop();
		setSystemClipboard("source "+filePath_restore.getText());
		cmdpast(robot);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		//刷新缓存中的权限
		stop();
		setSystemClipboard("flush privileges");
		cmdpast(robot);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		//退出mysql窗口
		stop();
		setSystemClipboard("quit");
		cmdpast(robot);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		stop();
		setSystemClipboard("已结束还原操作 Finish");
		cmdpast(robot);
	}
	
	private void BackupExec(){
		if(psd.getPassword().length==0){
			JOptionPane.showMessageDialog(null,"密码不能为空","错误 Error",0);
			return ;
		}
		if(server.getText().isEmpty()){
			JOptionPane.showMessageDialog(null,"服务器地址不能为空","错误 Error",0);
			return ;
		}
		
		Robot robot=null;
		try {
			robot = new Robot();
		} catch (AWTException e1) {
			e1.printStackTrace();
		}
		//Window + R 组合键
	    robot.keyPress(KeyEvent.VK_WINDOWS);
	    robot.keyPress(KeyEvent.VK_R);
	    robot.keyRelease(KeyEvent.VK_WINDOWS);
	    robot.keyRelease(KeyEvent.VK_R);
	    
	    stop();
		setSystemClipboard("cmd");
		past(robot);
	    robot.keyPress(KeyEvent.VK_ENTER);

		//输入mysql数据备份命令
	    stop();
	    path="mysqldump -u root -p --opt --routines --default-character-set=utf8 --all-databases ";
	    if(one.isSelected()){
	    	path="mysqldump -u root -p --opt --routines --default-character-set=utf8 repast ";
	    }
	    if(two.isSelected()){
	    	path="mysqldump -u root -p --opt --routines --default-character-set=utf8 study ";
	    }
	    path = path + " -h "+server.getText()+" >"+filePath_backup.getText();;
	    
	    setSystemClipboard(path);
		cmdpast(robot);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		//输入密码回车开始备份数据
		stop();
		setSystemClipboard(new String(psd.getPassword()));
		cmdpast(robot);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		//备份完毕之后打开备份目录
		stop();
		setSystemClipboard("explorer "+filePath_backup.getText().substring(0, filePath_backup.getText().lastIndexOf("\\")));
		cmdpast(robot);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		//退出cmd窗口
		stop();
		setSystemClipboard("exit");
		cmdpast(robot);
		robot.keyPress(KeyEvent.VK_ENTER);
	}
	
	//模拟系统打开运行窗口并启动程序
	public static void handle(){
		try{
			Runtime.getRuntime().exec("osk.exe");
			return ;
	    }catch(IOException io){
	    	System.out.println("启动osk.exe失败，系统将自动手功在运行窗口输入osk命令启动");
	    }
	    
		Robot robot=null;
		try {
			robot = new Robot();
		} catch (AWTException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//Window + R 组合键
	    robot.keyPress(KeyEvent.VK_WINDOWS);
	    robot.keyPress(KeyEvent.VK_R);
	    robot.keyRelease(KeyEvent.VK_WINDOWS);
	    robot.keyRelease(KeyEvent.VK_R);
	    
	    stop();
	    setSystemClipboard("osk");
		past(robot);
	    robot.keyPress(KeyEvent.VK_ENTER);  //回车启动软键盘
	}
	
	// 需要暂停一会，否则程序代码执行太快，系统反应不过来，结果只是打开了运行界面
	private static void stop(){
	    try {
			Thread.sleep(500);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	// 粘贴组合键
	private static void past(Robot robot){
		robot.keyPress(KeyEvent.VK_CONTROL);  
		robot.keyPress(KeyEvent.VK_V);  
		robot.keyRelease(KeyEvent.VK_V);   
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}
	
	// cmd下的粘贴
	private void cmdpast(Robot robot){
		robot.keyPress(KeyEvent.VK_ALT);  
		robot.keyPress(KeyEvent.VK_SPACE);  
		robot.keyRelease(KeyEvent.VK_SPACE);   
		robot.keyRelease(KeyEvent.VK_ALT);
		
		robot.keyPress(KeyEvent.VK_E);  
		robot.keyRelease(KeyEvent.VK_E);   
		
		robot.keyPress(KeyEvent.VK_P);  
		robot.keyRelease(KeyEvent.VK_P);   
	}
	
	// 设置剪切板的内容
	private static void setSystemClipboard(String s) {
		StringSelection ss = new StringSelection(s);
		Clipboard sysClb = Toolkit.getDefaultToolkit().getSystemClipboard();
		sysClb.setContents(ss, null);
	}


	//输入字符,由于用户 输入法 不确定，这种方式在非英文输入法下无法完成任务
	/*
	private void input(Robot robot,String s){
		for (char c : s.toCharArray()) {
			if (c >= '0' && c <= '9') {
				robot.keyPress((int) c);
				robot.keyRelease((int) c);
			} 
			else if (c >= 'a' && c <= 'z') {
				c = (char) ((int) c - 32);
				robot.keyPress((int) c);
				robot.keyRelease((int) c);
			} 
			else if (c >= 'A' && c <= 'Z') {
				robot.keyPress(KeyEvent.VK_SHIFT);
				robot.keyPress(c);
				robot.keyRelease(c);
				robot.keyRelease(KeyEvent.VK_SHIFT);
			}
			else if (c == '>') {
				//robot.keyPress(KeyEvent.);
				//robot.keyRelease((int) c);
			} 
			else{
				robot.keyPress((int) c);
				robot.keyRelease((int) c);
			}
		}
	} */
}
