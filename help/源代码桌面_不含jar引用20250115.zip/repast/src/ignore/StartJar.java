package ignore;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import javax.swing.JOptionPane;

//图标下载：https://www.icosky.com/cat/culture-icons/
//用 launch4j 或 exe4j 打包成 exe

public class StartJar {
	
	public static void main(String[] args) {
		
		//用户双击本jar文件的情况下：从本jar文件同目录下查找要启动的launcher.jar文件,但打包成exe后实测位置变了
		//final String path = StartJar.class.getClass().getResource("/").getPath();
		//String tem = new File(path+"launcher.jar").getPath();
		
		//但可通过jdk上一级或两级目录来寻找同目录下的jar文件,因为打包成EXE时有指定jdk位置，注意程序发布时的目录名不要用jre或jdk开头
		final File up1 = new File(System.getProperty("java.home")).getParentFile();
		final File up2 = new File(System.getProperty("java.home")).getParentFile().getParentFile(); //有的JDK要上两级目录
		
		/*-------------------------------------找可用的jar文件--------------------------------------*/
		
		final String dirname = up1.getName().toLowerCase();
		final File f = (dirname.startsWith("jdk") || dirname.startsWith("jre")) ? up2 : up1;
		final File fl[] = f.listFiles(new FileFilter() {
			public boolean accept(File pathname) {
				if(pathname.isDirectory()) return false;
				if(pathname.getName().toLowerCase().endsWith(".jar")) return true;
				return false;
			}
		});
		if(fl.length==0) {
			JOptionPane.showMessageDialog(null, "JDK或JRE路经下找不到可用的jar文件："+f.getPath()+"\n环境路经："+System.getProperty("java.home"),"没有找到要启动的jar文件",3);
			return;
		}
		
		String jarfile = fl[0].getPath(); //默认取第一个jar文件
		for(final File ff : fl) {
			if(ff.getName().equalsIgnoreCase("launcher.jar") || ff.getName().equalsIgnoreCase("run.jar") || ff.getName().equalsIgnoreCase("exe.jar")) {
				jarfile=ff.getPath(); //指定文件名优先
				break;
			}
		}
		
		/*-------------------------------------启动找到的JAR文件---------------------------------------*/
		
		try {
            // 创建一个新的进程并执行命令行
            final ProcessBuilder pb = new ProcessBuilder("java", "-jar", jarfile);
            final Process process = pb.start();
            
            // 等待进程执行完毕
            process.waitFor();
            
            // 检查进程的退出值
            if (process.exitValue() == 0) {
                System.out.println("Jar文件成功启动！");
            } 
            else {
                JOptionPane.showMessageDialog(null, "启动 Jar 文件时出现错误："+jarfile);
            }
        } 
		catch (IOException | InterruptedException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
		
	}
}
