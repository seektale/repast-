package ignore;
import java.awt.print.PrinterException;
import java.text.MessageFormat;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;
//下面的程序可以应用到串口连接的热敏打印机,但不支持中文，页面设置里面的纸张来源选择连续进纸
public class Comprint extends SwingWorker<Object, Object>{
	public JTextArea text = new JTextArea();
	
    public static void main(String[] args){
    	new Comprint();
    }
    public Comprint(){
        text.setText("test is china root maint ");
        this.execute();
    }
    
    protected Object doInBackground(){
        try{
        	//text.print();
            text.print(new MessageFormat(""), new MessageFormat(""), true, null, null, true);
        }
        catch (PrinterException ex){
            // Opps... cant print. Insert error handling code here.
        }
        return null;
    }
}
