package ignore;
import java.awt.*;
import java.awt.geom.*;//注意此包加载
import javax.swing.*;
/**
 * 制作一个圆形按钮时，需要做两件事：
 * 第一件事是重载一个适合的绘图方法以画出一个图形
 * 第二件事是设置一些事件使得只有当单击图形按钮的范围中的时候才会做出响应*/
public class Button_Circle extends JButton{
	private static final long serialVersionUID = 315846546L;
	public Button_Circle(String label){
		super(label);
		//获取按钮的最佳大小
		Dimension size=getPreferredSize();
		//调整按钮的大小,使之变成一个方形
		size.width=size.height=Math.max(size.width,size.height);
		setPreferredSize(size);
		//使jbutton不画背景,即不显示方形背景,而允许我们画一个圆的背景
		setContentAreaFilled(false);
	}
	//画图的按钮的背景和标签
	public void paintComponents(Graphics g){  //与下面的只相差一个s，有待研究
		super.paintComponents(g);
	}
	protected void paintComponent(Graphics g){
		if(getModel().isArmed()){
			//getModel方法返回鼠标的模型ButtonModel
			//如果鼠标按下按钮，则buttonModel的armed属性为真
			g.setColor(Color.LIGHT_GRAY);
		}
		else if(getModel().isRollover()){g.setColor(Color.red);} //如果移动到上面
		else {g.setColor(getBackground());}
		//fillOval方法画一个矩形的内切椭圆,并且填充这个椭圆
		g.fillOval(0,0,getSize().width-1,getSize().height-1);
  
		//调用父类的paintComponent画按钮的标签和焦点所在的小矩形
		super.paintComponent(g);
	}
	
	//用简单的弧充当按钮的边界
	protected void paintBorder(Graphics g){
		g.setColor(getForeground());
		//drawOval方法画矩形的内切椭圆,但不填充,只画出一个边界
		g.drawOval(0,0,getSize().width-1,getSize().height-1);
		//super.paintBorder(g);
	}
	
	Shape shape;//用于保存按钮的形状,有助于侦听单击按钮事件
	//判断鼠标是否点在按钮上
	public boolean contains(int x,int y){
		//如果按钮边框,位置发生改变,则产生一个新的形状对象
		if((shape==null)||(!shape.getBounds().equals(getBounds()))){
			//构造椭圆型对象
			shape=new Ellipse2D.Float(0,0,getWidth(),getHeight());
		}
		//判断鼠标的x,y坐标是否落在按钮形状内
		return shape.contains(x,y);
	}
}
