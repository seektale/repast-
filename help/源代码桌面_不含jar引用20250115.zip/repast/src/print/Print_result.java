package print;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import log.AdvSelect;
import pub.DateUI;
import root.Sql;
public class Print_result extends JPanel implements ActionListener,MouseListener{
	private static final long serialVersionUID = -60160101688002130L;
	private JButton far=new JButton("最近200条");
	private JButton MyDate=new JButton("查看指定日期");
	private JButton adv=new JButton("高级查询");
	private JTable tc=Sql.getTable();
	private JTable ts=Sql.getTable();
	public Print_result(){
		setLayout(new BorderLayout());
		//北面
    	JPanel up=new JPanel();
		up.setLayout(new FlowLayout(FlowLayout.LEFT,8,5));
		far.addActionListener(this);
		MyDate.addActionListener(this);
		adv.addActionListener(this);
		tc.addMouseListener(this);
		up.add(far);
		up.add(MyDate);
		up.add(adv);
		up.add(new JLabel("最新的数据会显示在最上面"));
		add(up,BorderLayout.NORTH);
		
		JScrollPane jsts=new JScrollPane(ts);
		jsts.setPreferredSize(new Dimension(0, 90));
		
		//中间
		JSplitPane jsp = new JSplitPane();
		jsp.setOrientation(JSplitPane.VERTICAL_SPLIT);
		jsp.setLeftComponent(new JScrollPane(tc));
		jsp.setRightComponent(jsts);
		add(jsp,BorderLayout.CENTER);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==far){
			Sql.getArrayToTable("select * from print_job order by ind desc limit 0,200 ;", this, tc);
			Sql.TableAtt(tc, true, false);
		}
		else if(e.getSource()==MyDate){
			DateUI du = new DateUI();
			if(du.toString().isEmpty()) return ;
			String sql="select * from print_job where date(print_time)='"+du.toString()+"'";
			Sql.getArrayToTable(sql, this, tc);
			Sql.TableAtt(tc, true, false);
		}
		else if(e.getSource()==adv){
			new AdvSelect("print_job", tc);
		}
	}
	public void mouseClicked(MouseEvent e) {
		int k=tc.getSelectedRow();
		String str=tc.getValueAt(k, 2)+"";
		//两张表联合起来
		str="select * from dishlog where 商品索引="+str+" union all select * from hqdishlog where 商品索引="+str;
		Sql.getArrayToTable(str, this, ts);
		Sql.TableAtt(ts, true, true);
	}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
}
