package print;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.Timer;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import pub.ConfigFile;
import pub.Photo;
import root.Front;
import root.Sql;
// 用于全部一起下单,二进制数据的组成及编码GBK均在存储过程中完成
public class PrintDB extends JDialog implements ActionListener{
	private static final long serialVersionUID = 66885153653730386L; 
	private int mealnum;
	private JButton refresh;
	private JPanel dia = new JPanel(new BorderLayout());
	private JLabel tip = new JLabel("tip", JLabel.CENTER);
	private Timer time = new Timer(300, this);
	private int thnum = 0;
	private boolean hold = false ;
	private HashMap<String[], byte[]> hm ;
	private final ArrayList<String[]> over = new ArrayList<String[]>();
	
	// 传入的值为台次,商品索引数组
	public PrintDB(int mealnum, JButton refresh){
		super(Front.front, "热敏打印机出单实时状态", true);
		this.mealnum = mealnum ;
		this.refresh = refresh ;
		hminit();
	}
	// hold 标示出单是否叫起
	public PrintDB(int mealnum, JButton refresh, boolean hold){
		super(Front.front, "热敏打印机出单实时状态",true);
		this.mealnum = mealnum;
		this.refresh = refresh;
		this.hold = hold;
		hminit();
	}
	
	private void hminit() {
		
		tip.setForeground(Color.RED);
		hm = Photo.getBinDB(mealnum, hold ? "Y" : "N");
		if(hm.isEmpty()) return ;
		
		final Iterator<?> iter = hm.entrySet().iterator();
		final ArrayList<String> site = new ArrayList<String>();
		
		while (iter.hasNext()){
			@SuppressWarnings("rawtypes")
			final Map.Entry entry = (Map.Entry)iter.next();
			final String[] key = (String[])entry.getKey();
			if(!site.contains(key[2])){
				site.add(key[2]);
			}
		}
		
		//开台整理数据并打印
		time.start() ;
		thnum = site.size() ;
		
		final JPanel pan = new JPanel(new FlowLayout());
		for(final String val : site) {
			
			String temp=ConfigFile.getProperty("PrintCom");
			if(val.toUpperCase().startsWith("COM") && temp.isEmpty()){
				thnum-- ;
				continue ;
			}
			
			JTextPane info = new JTextPane();
			info.setEditable(false);
			info.setText("站点：["+val+"] ...\n\n");
			final JScrollPane infosp = new JScrollPane(info);
			infosp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			infosp.setPreferredSize(new Dimension(130,190));
			pan.add(infosp);
			print(val, info);
		}
		
		dia.add(tip, BorderLayout.NORTH);
		dia.add(pan, BorderLayout.CENTER);
		
		int width = 130*pan.getComponentCount()+50<300 ? 300 : 130*pan.getComponentCount()+50 ;
		setContentPane(dia);
		setSize(new Dimension(width, 250));
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);	// 初始位置在屏幕正中间
		setVisible(true);
	}
	
	//根据站点得到打印数据流
	private byte[] getbin(String site){
		final Iterator<?> iter = hm.entrySet().iterator();
		byte[] temp = new byte[0];
		while (iter.hasNext()){
			@SuppressWarnings("rawtypes")
			final Map.Entry entry = (Map.Entry)iter.next();
			final String[] key = (String[])entry.getKey();
			byte val[] = (byte[])entry.getValue();
			if(site.equalsIgnoreCase(key[2])) {
				//java 合并两个byte数组
				final byte[] C = new byte[temp.length + val.length];
				System.arraycopy(temp, 0, C, 0, temp.length);
				System.arraycopy(val, 0, C, temp.length, val.length);
				temp = C ;
			}
		}
		return temp ;
	}
	//根据站点得到热敏打印机的地址和端口
	private String[] getadd(String site) {
		final Iterator<?> iter = hm.entrySet().iterator();
		while(iter.hasNext()) {
			@SuppressWarnings("rawtypes")
			final Map.Entry entry = (Map.Entry)iter.next();
			final String[] key = (String[])entry.getKey();
			if(site.equalsIgnoreCase(key[2])){
				return new String[]{key[0], key[1]};
			}
		}
		return new String[]{"", "9100"};
	}
	
	//以线程的方式起动，以免打印机连接不上被主线程被卡住，好像死机了一样
	private void print(final String site, final JTextPane info){
		final Thread th = new Thread(new Runnable() {
			public void run() {
				
				stat("读取数据流信息...",Color.BLACK,info);
				byte b[] = getbin(site);
				stat("发往热敏打印机...",Color.GREEN,info);
				
				if(site.toUpperCase().startsWith("COM")){
					try {
						//打包之后测试会卡在这里，可能是因为运行环境由JDK变成了jre，但发布之后配置好dll就好了
						final String comMsg = Photo.Printcom(b, ConfigFile.getProperty("PrintCom"), false);
						stat(comMsg,Color.RED,info);
					}
					catch (Exception err) {
						stat("错误, "+err.getMessage(),Color.RED,info);
						err.printStackTrace();
					}
					stat("已结束！",Color.BLUE,info);
				}
				else{
					final String add[] = getadd(site);
					boolean result = Photo.printbin(b, site, false, add[0], Integer.valueOf(add[1]));
					if(result){
						stat("恭喜,出单成功！", Color.BLUE, info);
						over.add(new String[]{site,"Y"});
					}
					else{
						stat("出单失败",Color.RED,info);
						over.add(new String[]{site,"N"});
					}
				}
				thnum--;
			}
		});
		th.setDaemon(true);
		th.start();
	}
	
	// 根据传入的颜色及文字，将文字插入文本域
	private void stat(String msg, Color textColor, JTextPane info) {
		SimpleAttributeSet set = new SimpleAttributeSet();
		StyleConstants.setForeground(set, textColor);	// 设置文字颜色
		StyleConstants.setFontSize(set, 12);			// 设置字体大小
		Document doc = info.getStyledDocument();
		try {
			doc.insertString(doc.getLength(), msg+"\n", set);// 插入文字
			info.selectAll();
			//迫使滚动条自动滚动到最后面
			if(info.getSelectedText()!=null){
				info.setCaretPosition(info.getSelectedText().length());  
			}
			info.requestFocus();
		} catch (BadLocationException e){}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(thnum==0){
			tip.setText("打印已结束");
			tip.setForeground(Color.BLUE);
			
			//全部打印方式下待所有进程结束后, 还需要写入打印结果
			boolean flag = true ;
			
			String AA="", BB="" ;
			for(String temp[] : over){
				AA = AA + temp[0] + "&" ;
				BB = BB + temp[1] ;
				if(temp[1].equals("N")) flag = false ;
			}
			
			System.out.println("出单结果参考::::::"+AA+"   "+BB);
			
			// 反馈打印结果
			String sql = "select binary_result_go("+mealnum+",'"+AA+"','"+BB+"')";
			String submit_result[] = Sql.getString(sql, PrintDB.this);
			if(submit_result.length==1){
				tip.setText(tip.getText()+"（"+submit_result[0]+"）");
				tip.setToolTipText(tip.getText());
			}
			
			time.stop();
			if(flag) dispose();		//全部打印过程执行完成则自动关闭对话框
			refresh.doClick();
			return ;
		}
		
		//│┄┆╲╱
		String ss=tip.getText().substring(tip.getText().length()-1);
		if(ss.equals("┄")) ss="╲";
		else if(ss.equals("╲")) ss="│";
		else if(ss.equals("│"))  ss="╱";
		else if(ss.equals("╱")) ss="┄";
		else ss="┄";
		tip.setText("请勿关闭，当前正有:"+thnum+" 个打印任务在运行...  "+ss);
	}
}
