package com.dmumu.phone.repast.other;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.dmumu.phone.repast.R;

public class AboutActivity extends AppCompatActivity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //取消状态栏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        String url=null;
        String title=null;
        if(getIntent().getExtras()!=null) {
            url = getIntent().getExtras().getString("url");
            title = getIntent().getExtras().getString("title");
        }

        web = findViewById(R.id.web);

        init();

        final SharedPreferences share = getSharedPreferences("val", Context.MODE_PRIVATE);

        //加载一个网页，如果网页中包含文件上传功能，这里无法实现，过程太复杂。
        //web.loadUrl("file:///android_asset/errpage.html"); //加载本地网页
        web.loadUrl("https://"+share.getString("address", "repast.dmumu.com"));
        web.setWebChromeClient(new WebChromeClient()); //alert的支持

        //复写shouldOverrideUrlLoading()方法，使得打开网页时不调用系统浏览器， 而是在本WebView中显示
        web.setWebViewClient(new WebViewClient() {

            private int count = 0; //防止反复来回切换

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return super.shouldOverrideUrlLoading(view, url);
                //view.loadUrl(url);
                //return true;
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                setTitle(url);
            }
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                //加载出错, 进行http与https自动切换
                Toast.makeText(getApplication(), error.getDescription().toString(), Toast.LENGTH_LONG).show();
                if(count>3) return;
                count++;
                final String str = request.getUrl().toString().toLowerCase();
                if(str.startsWith("http://")) web.loadUrl("https://"+request.getUrl().toString().substring(7));
                if(str.startsWith("https://")) web.loadUrl("http://"+request.getUrl().toString().substring(8));
            }
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                //https连接接收处理，证书错误依然访问
                handler.proceed();
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                //设定加载结束的操作
                setTitle(web.getTitle());
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home: //标题栏左上角的返回键点击事件
                finish();
                return true;
            default:
                return false;
        }
    }

    private void init() {

        //声明WebSettings子类
        WebSettings webSettings = web.getSettings();

        //如果访问的页面中要与Javascript交互，则webview必须设置支持Javascript
        webSettings.setJavaScriptEnabled(true);
        // 设置允许JS弹窗
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

        //设置自适应屏幕，两者合用
        webSettings.setUseWideViewPort(true); //将图片调整到适合webview的大小
        webSettings.setLoadWithOverviewMode(true); // 缩放至屏幕的大小

        //缩放操作
        webSettings.setSupportZoom(true); //支持缩放，默认为true。是下面那个的前提。
        webSettings.setBuiltInZoomControls(true); //设置内置的缩放控件。若为false，则该WebView不可缩放
        webSettings.setDisplayZoomControls(false); //隐藏原生的缩放控件

        //其他细节操作
        webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK); //关闭webview中缓存
        webSettings.setAllowFileAccess(true); //设置可以访问文件
        webSettings.setLoadsImagesAutomatically(true); //支持自动加载图片
        webSettings.setDefaultTextEncodingName("utf-8");//设置编码格式

        webSettings.setAppCacheEnabled(true);//是否使用缓存
        webSettings.setDomStorageEnabled(true);//DOM Storage
    }

    @Override
    protected void onDestroy() {
        // 在 Activity 销毁（ WebView ）的时候，先让 WebView 加载null内容，然后移除 WebView，再销毁 WebView，最后置空。
        if (web != null) {

            web.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            web.clearHistory();

            ((ViewGroup)web.getParent()).removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}