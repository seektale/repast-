package com.dmumu.phone.repast;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.dmumu.phone.repast.activity.CaptureActivity;
import com.dmumu.phone.repast.hotprint.HotPrinterCmd;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class FragmentB extends Fragment {
    private static final String ARG_SECTION_NUMBER = "section_number";
    private ArrayList<String[]> arrayList=new ArrayList<>();
    private TextView header,footer;
    private ListView dishscroll = null;
    private MyAdater dishscrollAdater = new MyAdater();
    private Button godata, goprintlist, goscan;
    private String dishind,dishMount,dishname ;
    private SwipeRefreshLayout downRefresh = null;
    private boolean placeflag = true ;
    public FragmentB() {
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, 2);
        setArguments(args);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_two, container, false);

        downRefresh = (SwipeRefreshLayout)rootView.findViewById(R.id.swipelayout);
        downRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            public void onRefresh() {
                handler.sendEmptyMessageDelayed(4, 300);
            }
        });

        dishscroll = (ListView)rootView.findViewById(R.id.dishscroll);
        header = new TextView(rootView.getContext());
        header.setGravity(Gravity.CENTER);
        header.setTextSize(20);
        header.setTextColor(Color.BLUE);
        header.setText("待提交商品临时清单");

        footer = new TextView(rootView.getContext());
        footer.setGravity(Gravity.CENTER);
        footer.setTextSize(16);
        //footer.setTextColor(Color.BLUE);

        dishscroll.addHeaderView(header);
        dishscroll.addFooterView(footer);
        dishscroll.setAdapter(dishscrollAdater);
        dishscroll.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                placeflag = true ;
                if(event.getX()/v.getWidth()<0.9){ //太靠右点击不响应
                    placeflag = false ;
                }
                return false;
            }
        });
        dishscroll.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(placeflag) return ;
                if (position>0 && position<dishscroll.getCount()-1){
                    Object ob = dishscrollAdater.getItem(position);
                    dishind = ((String[])ob)[0];
                    dishMount = ((String[])ob)[5];
                    dishname = ((String[])ob)[2];
                    amountb().show();
                }
            }
        });

        goscan = rootView.findViewById(R.id.goscan);
        goscan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //打开扫描界面扫描条形码或二维码
                Intent openCameraIntent = new Intent(getActivity(),CaptureActivity.class);
                startActivityForResult(openCameraIntent, 0);
            }
        });

        goprintlist = rootView.findViewById(R.id.goprintlist);
        goprintlist.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //handler.sendEmptyMessage(4);
                ((MyApp)getActivity().getApplication()).local_hotprint(0);
            }
        });

        godata = rootView.findViewById(R.id.godata);
        godata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPreMenu(); //先刷新数据
                if (arrayList==null || arrayList.size()==0){
                    Toast.makeText(getView().getContext(), "没有可用于提交的商品", Toast.LENGTH_SHORT).show();
                    return ;
                }
                dishscrollAdater.notifyDataSetChanged();
                final Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        selDesk();
                    }
                });
                th.setDaemon(true);
                th.start();
            }
        });

        return rootView;
    }

    private void getPreMenu(){
        //String col[] = { "num", "cla", "name", "price", "unit", "amount"};
        //Cursor cur = db.query("premenu", null, null, null, null, null, null);
        arrayList = ((MyApp)getActivity().getApplication()).selSQLite("select num,cla,name,price,unit,amount from premenu");
    }
    private ArrayList<String[]> getPreMenuAll(){
        final ArrayList<String[]> arr = ((MyApp)getActivity().getApplication()).selSQLite("select num,cla,name,price,unit,amount from premenu");
        return arr;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data==null) return ;
        if (resultCode!=0) return ;

        String val = data.getStringExtra("result");
        String sp[] = val.split("#");
        if(sp.length==2){
            String col[] = { "num", "cla", "name", "price", "unit", "lock" };
            String where = "num='"+sp[0]+"'and name='"+sp[1]+"'"; //匹配 商品编号 和 名称
            ArrayList<String[]> temparr = ((MyApp)getActivity().getApplication()).selSQLite(col, where);

            if (temparr == null || temparr.size()==0){
                dia("该商品信息不存在，可能需要同步商品：\n"+val);
                return;
            }

            ((MyApp)getActivity().getApplication()).pre(temparr.get(0)[0],1);
            getPreMenu(); //刷新未提交商品列表
            dishscrollAdater.notifyDataSetChanged();
            return ;
        }

        String col[] = { "num", "cla", "name", "price", "unit", "lock" };
        String where = "name='"+val+"'";  //String where = "ma='"+val+"'"; 旧代码用了ma列，但实际没有
        ArrayList<String[]> temparr = ((MyApp)getActivity().getApplication()).selSQLite(col, where);
        if (temparr == null || temparr.size()==0){
            dia("通过 条行码/二维码 未找到商品\n可能需要同步商品：\n"+val);
            return;
        }

        ((MyApp)getActivity().getApplication()).pre(temparr.get(0)[0],1);
        //刷新未提交商品列表
        getPreMenu();
        dishscrollAdater.notifyDataSetChanged();

        // mysql.sendmsg(handler,true,"不能识别的信息格式：\n"+val);
    }

    private void dia(String val){
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setTitle("扫描结果");
        builder.setMessage(val);
        builder.setPositiveButton("好的", null);
        builder.create().show();
    }

    public Handler handler=new Handler(){
        public void handleMessage(final Message msg){
            switch (msg.what){
                case 1 :
                    builder.create().show();
                    break;
                case 3 :
                    //显示提交商品后返回的错误信息
                    Bundle bundle = msg.getData();
                    AlertDialog.Builder bu = new AlertDialog.Builder(getView().getContext());
                    bu.setTitle("错误");
                    bu.setIcon(android.R.drawable.ic_dialog_info);
                    bu.setMessage(bundle.getString("msg"));
                    bu.setNegativeButton("确定", null);
                    bu.create().show();
                    //刷新未提交商品列表
                    getPreMenu();
                    dishscrollAdater.notifyDataSetChanged();
                    break;
                case 4 :
                    if(downRefresh.isRefreshing()) downRefresh.setRefreshing(false);
                    //刷新未提交商品列表 ,  Fragment显示时 MainActivity 调用
                    getPreMenu();
                    dishscrollAdater.notifyDataSetChanged();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    private class MyAdater extends BaseAdapter {
        @Override
        public int getCount() {
            if (arrayList==null) return 0;
            return arrayList.size();
        }
        public void notifyDataSetChanged(){
            if (arrayList!=null && arrayList.size()>0){
                //BigDecimal bd = new BigDecimal("1.00");
                double money = 0.0;
                for (String temp[] : arrayList){
                    money = money + Double.valueOf(temp[3]) * Double.valueOf(temp[5]);
                }
                footer.setText("商品条目数: "+getCount()+"       总金额: "+String.format("%.2f", money));
            }
            else{
                if(footer!=null) footer.setText("");
            }
            super.notifyDataSetChanged();
        }
        @Override
        public Object getItem(int position) {
            return arrayList.get(position-1);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final String temp[]=arrayList.get(position);

            View v = LayoutInflater.from(FragmentB.this.getView().getContext()).inflate(R.layout.orderover, null);
            TextView b = v.findViewById(R.id.desdishx);
            TextView price = v.findViewById(R.id.desprice);

            //b.setText(temp[0]+" "+temp[2]+"["+temp[1]+"]\n￥: "+temp[3]+"  /"+temp[4]+"       数量:"+temp[5]);
            b.setGravity(View.TEXT_ALIGNMENT_TEXT_START);   //左对齐
            b.setTextColor(Color.BLACK);

            b.setBackgroundResource(R.drawable.fang);
            b.getBackground().setAlpha(180);
            b.setTextSize(15);
            b.setText(Html.fromHtml("<font><B>" +
                    temp[0]+" "+temp[2]+"["+temp[1]+"]" +
                    "</B></font><br><font color=\'blue\'>" +
                    "￥: "+temp[3]+"  /"+temp[4]+"</font>"));

            price.setTextColor(Color.BLACK);
            price.setText(Html.fromHtml("<font>数量："+temp[5]+"</font>"));
            return v;
        }
    }

    //修改预点数量选择对话框
    private AlertDialog amountb(){

        View v = LayoutInflater.from(getView().getContext()).inflate(R.layout.amountlayout, null);
        final Button up = v.findViewById(R.id.add);
        final Button down = v.findViewById(R.id.del);
        final EditText val = v.findViewById(R.id.amount); //限制了只能输入数字
        val.setText(dishMount);
        val.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{
                    Double.valueOf(val.getText().toString());
                    val.setTextColor(Color.BLUE);
                }catch (Exception e){
                    val.setTextColor(Color.RED);
                }
            }
            public void afterTextChanged(Editable s) {}
        });

        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return;
                }
                BigDecimal bd = new BigDecimal(val.getText().toString()); //不要用double,会出现很多小数位
                val.setText(bd.add(new BigDecimal("1")).toString());
            }
        });
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return;
                }
                BigDecimal bd = new BigDecimal(val.getText().toString());
                val.setText(bd.add(new BigDecimal("-1")).toString());

            }
        });

        final AlertDialog.Builder builder = new AlertDialog.Builder(getView().getContext());
        builder.setTitle(dishname);
        builder.setView(v);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                double k = 1.0;  //默认为1
                try{k = Double.valueOf(val.getText().toString());}catch (Exception e){}
                ((MyApp)getActivity().getApplication()).updatePreMenu(dishind, k);
                handler.sendEmptyMessage(4);
            }
        });
        builder.setNeutralButton("删除", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ((MyApp)getActivity().getApplication()).clearPreMenu(dishind);
                handler.sendEmptyMessage(4);
            }
        });
        builder.setNegativeButton("返回", null);

        AlertDialog Dia=builder.create();
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);  //动画效果
        return Dia;
    }

    private AlertDialog.Builder builder;
    //台号选择
    private void selDesk(){

        builder = new AlertDialog.Builder(getView().getContext());
        //builder.setTitle("已开台列表,请选择");
        builder.setIcon(android.R.drawable.ic_dialog_info);

        final ArrayList<String[]> arr = new ArrayList<>();
        if(((MyApp)getActivity().getApplication()).getMode()==false) {  //本地模式
            builder.setTitle("本地模式：已开台列表");
            final ArrayList<String[]> arrtem = ((MyApp)getActivity().getApplication()).selSQLite("select area,num,head,alias,mealnum from desk where state='已开台' order by head,CAST(num AS REAL)");
            if (arrtem == null) return;
            for(String[] s : arrtem) arr.add(s);
        }
        else {
            builder.setTitle("在线模式：已开台列表");
            final ArrayList<String[]> arrtem = ((MyApp)getActivity().getApplication()).sel("select desk.区域,desk.台号,desk.前辍,desk.别名,deskgo.台次 from desk left join deskgo " +
                    "on desk.`区域`=deskgo.`区域` and desk.台号=deskgo.台号 and desk.`操作时间`=deskgo.`开台时间` " +
                    "where desk.状态='已开台' order by desk.前辍,desk.台号 ;");
            if (arrtem == null) return;
            for(String[] s : arrtem) arr.add(s);
        }

        String temp[]=new String[arr.size()];
        for (int k=0; k<arr.size(); k++) {
            String desknum = arr.get(k)[1];
            desknum = desknum.length()==1 ? "0"+desknum : desknum;
            desknum = arr.get(k)[2]+desknum;
            temp[k]=arr.get(k)[0]+"  "+desknum;
            if(!arr.get(k)[4].isEmpty()) temp[k]=temp[k]+"  台次:"+arr.get(k)[4];
            temp[k]=temp[k]+"  "+arr.get(k)[3];
        }
        builder.setItems(temp, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, final int which) {
                final String meal = arr.get(which)[4];
                final Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        submitDish(meal);
                    }
                });
                th.setDaemon(true);
                th.start();
            }
        });
        //第一个按扭
        builder.setPositiveButton("吧台提交", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                final Thread th = new Thread(new Runnable() {
                    public void run() {
                       submitDishbar();  //提交到吧台的商品其台次为 0
                    }
                });
                th.setDaemon(true);
                th.start();
            }
        });
        builder.setNegativeButton("取消返回", null);
        handler.sendEmptyMessage(1);
    }

    //提交商品
    private void submitDish(String meal){
        ArrayList<String[]> arr = getPreMenuAll();
        final String cols = "attr,mealnum,dishnum,dishitem,dishdiv,dishdivsub,dishname,price,unit,count,discount,print,staff,dishtime,remark";
        for (String temp[] : arr){
            if(((MyApp)getActivity().getApplication()).getMode()==false) {  //本地模式
                final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
                final String date = df.format(new Date());// new Date()为获取当前系统时间，也可使用当前时间戳
                ((MyApp)getActivity().getApplication()).excSQLite("insert into dish("+cols+") values('',"+meal+",'"+temp[0]+"','','"+temp[1]+"','','"+temp[2]+"','"+temp[3]+"','"+temp[4]+"','"+temp[5]+"','1','0','admin@本地','"+date+"','')");
                ((MyApp)getActivity().getApplication()).clearPreMenu(temp[0]);
                handler.sendEmptyMessage(4);
                continue;
            }
            //初始化参数
            ArrayList<String> val=new ArrayList<String>();
            val.add(meal);	        //餐次
            val.add(temp[0]);		//菜品编号
            val.add(temp[5]);	    //数量
            val.add(temp[3]);		//价格
            String res = ((MyApp)getActivity().getApplication()).pro("dish_order_init",val);

            if (res.contains("点单成功")){
                //删除数据
                ((MyApp)getActivity().getApplication()).clearPreMenu(temp[0]);
                //存储过程会显示结果，这里同步刷新一下
                handler.sendEmptyMessage(4);
                continue;
            }

            //以对话框方式显示返回的错误消息
            Message m=new Message();
            Bundle bundle=new Bundle();
            bundle.putString("msg",res);
            m.setData(bundle);
            m.what=3;
            handler.sendMessage(m);
            //提交失败则结束
            break;
        }
    }

    //提交商品, 专门用于提交到吧台, 和上面的略有区别
    private void submitDishbar(){
        ArrayList<String[]> arr = getPreMenuAll();
        for (String temp[] : arr){
            //初始化参数
            ArrayList<String> val=new ArrayList<String>();
            val.add("0");	        //餐次
            val.add(temp[0]);		//菜品编号
            val.add(temp[5]);	    //数量
            val.add(temp[3]);		//价格
            val.add("Android终端提交");
            String res = ((MyApp)getActivity().getApplication()).pro("dish_order", val);

            if (res.contains("点单成功")){
                //删除数据
                ((MyApp)getActivity().getApplication()).clearPreMenu(temp[0]);
                //存储过程会显示结果，这里同步刷新一下
                handler.sendEmptyMessage(4);
                continue;
            }

            //以对话框方式显示返回的错误消息
            Message m=new Message();
            Bundle bundle=new Bundle();
            bundle.putString("msg",res);
            m.setData(bundle);
            m.what=3;
            handler.sendMessage(m);
            //提交失败则结束
            break;
        }
    }
}