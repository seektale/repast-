package com.dmumu.phone.repast;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.dmumu.phone.repast.hotprint.HotPrinterCmd;
import com.dmumu.phone.repast.other.NFCActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Created by root on 14-12-25.
 * 结论:
 1.使用Environment.getExternalStorageDirectory可以得到系统的sdcard路径，不过这个一般在各个手机上都是一样的。
 2.使用context.getExternalFilesDir可以得到系统为程序在sdcard上分配的存储路径，据说放在这里卸载程序时目录也会被删除;
 3.使用context.getFileDir可以获得程序的data目录的files子目录，如果有小文件，sdcard又不存在时可以选择放这里。

 android的官方文档上说，采用Enviroment.getExternalStorageDirectory()方法可以得到android设备的外置存储(即外插SDCARD)，
 如果android设备有外插SDCARD的话就返回外插SDCARD的根目录路径，如果android设备没有外插SDCARD的话就返回android设备的内置SDCARD的路径。
 这套方案很快就被否决了，因为Enviroment类的这个方法里面的路径也是写死的，只有原生的android系统才使用这套方案，被更改过的anroid体统很多设备的路径都改了。
 */

public class MyApp extends Application {

    private Activity act;
    private static MyApp instance = null;
    public static MyApp getInstance() {
        return instance;
    }
    public static Connection conn;  //连网用的数据库连接
    public static String pwd;       //用户没有选择【记住密码】的情况下用这个登记时记录下来的密码
    public static int contimeout = 5;
    private String path;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle bundle) {
                act=activity;
            }

            @Override
            public void onActivityStarted(Activity activity) {
                act=activity;
            }

            @Override
            public void onActivityResumed(Activity activity) {
                act=activity;
            }

            @Override
            public void onActivityPaused(Activity activity) {
                act=activity;
            }

            @Override
            public void onActivityStopped(Activity activity) {}

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {}

            @Override
            public void onActivityDestroyed(Activity activity) {}
        });
    }

    public String getPath() {
        if(path==null || path.isEmpty()) {
            // getFilesDir()：它返回你app所在的内部存储器的目录结构 。
            // getCacheDir()：它返回你app临时缓存文件的内部存储器的目录结构
            path = getExternalFilesDir(null).getPath();
            Log.i("存储目录:", path);
        }
        return path;
    }

    //获取当前工作模式
    public boolean getMode() {
        return getMode(null);
    }
    public boolean getMode(final Boolean boo) {
        final SharedPreferences share = getSharedPreferences("val", Context.MODE_PRIVATE);
        if(boo!=null) {
            final SharedPreferences.Editor editor=share.edit();
            editor.putBoolean("model", boo); //标记为在线或本地模式
            editor.commit();
        }
        return share.getBoolean("model", true); //默认网络模式
    }

    //弹出错误消息框
    private void sendmsg(final boolean flag, final String val){
        sendmsg(false, val, "消息");
    }
    private void sendmsg(final boolean flag, final String val, final String title){
        if(act==null) return;
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(flag) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(act);
                    builder.setIcon(android.R.drawable.ic_dialog_alert);
                    builder.setTitle(title);
                    builder.setMessage(val);
                    builder.setPositiveButton("确定", null);
                    builder.create().show();
                    return;
                }
                Toast.makeText(act, val, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // 显示输入对话框模块，公共调用
    public void showInputDialog(final String title, final String hint, final Object ob) {
        if(act==null) return;
        final AlertDialog.Builder builder = new AlertDialog.Builder(act);
        builder.setTitle(title);
        // 设置EditText作为对话框的内容
        //final LinearLayout.LayoutParams layoutparams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        //layoutparams.setMargins(20,20,20,20);
        final EditText input = new EditText(act);
        //input.setLayoutParams(layoutparams);
        input.setHint(hint);
        builder.setView(input);
        // 设置确认按钮的监听器
        builder.setPositiveButton("确认 OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ob.equals(input.getText().toString());
            }
        });
        // 设置取消按钮的监听器
        builder.setNegativeButton("取消 Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {}
        });
        // 创建并显示对话框
        builder.create().show();
    }

    //发出声音，raw目录下的beep.ogg是用于二维码扫描时发出的声音
    public synchronized void beep(final int time) {
        if(act==null) return;
        final ToneGenerator mToneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
        mToneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, time); //500
        final Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                try{Thread.sleep(time);}catch (Exception e){}
                mToneGenerator.stopTone();
                mToneGenerator.release();
            }
        });
        th.setDaemon(true);
        th.start();
    }

    //对网络进行预先检查是否依然有效
    private boolean checkconn(){

        if(conn == null) return getcon(); //重新登陆

        //检查是否超时
        try {
            conn.isValid(3) ;
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        sendmsg(false,"连接超时,自动恢复连接");
        return getcon(); //重新登陆
    }

    //连接数据库, 外部仅 LogonActivity.java 调用
    public boolean getcon() {

        if(conn!=null) try{conn.close();} catch (SQLException e) {}
        conn = null;
        final SharedPreferences share = getSharedPreferences("val", Context.MODE_PRIVATE);
        final String account = share.getString("account", "");
        final String password = share.getBoolean("save", false) ? share.getString("password", "") : pwd;
        final String address = share.getString("address", ""); //默认值
        final String port = share.getString("port", "");
        final String dbname = share.getString("dbname", "");

        if(account.isEmpty() || password==null || password.isEmpty()){
            sendmsg(true,"请先登陆");
            return false;
        }

        final ExecutorService executor = Executors.newSingleThreadExecutor();
        final FutureTask<String> future = new FutureTask<>(new Callable<String>() {
            //使用Callable接口作为构造参数
            public String call() {
                try {
                    //conn = DriverManager.getConnection("jdbc:mysql://"+address+":"+port+"/"+dbname, account, password); 需要指明ssl为false
                    //这里要注意，只能使用UTF-8，使用UTF8 则sql语句中的中文乱码变成？号，从而报错
                    //if(act!=null) act.setTitle("正在连接...");
                    conn = DriverManager.getConnection("jdbc:mysql://"+address+":"+port+"/"+dbname+"??useUnicode=true&characterEncoding=UTF-8&useSSL=false", account, password);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    return e.getMessage();
                }
                return null;
            }
        });
        executor.execute(future);

        try {
            //取得结果，同时设置超时执行时间为5秒。同样可以用future.get()，不设置执行超时时间取得结果
            //但后续联通3G网络测试表明，这个连接过程至少都在10秒以上 (注意使用3Gnet 而非3Gwap),一但登陆成功，后面的需要连网的操作又很顺畅了
            String err = future.get(contimeout*1000, TimeUnit.MILLISECONDS);
            if(err!=null) {
                if(err.startsWith("Communications link failure")){
                    sendmsg(true,"网络错误,请保证网络可用\n"+err);
                }
                else{
                    sendmsg(true,"账号 或 密码错误\n"+err);
                }
                conn = null ;
                return false;
            }

            //必须初始化登陆
            try{
                CallableStatement cs = conn.prepareCall("{call logon(?,?,?)}");
                cs.registerOutParameter(1, Types.VARCHAR);	//输出型参数
                cs.setString(2, "Android"); //输入型参数
                cs.setString(3, "MAC Address 0000-0000-0000"); //后期不再获取MAC地址，因为权限的原因，各版本获取方式也不一样
                cs.execute();
                return true;
            }
            catch (Exception e) {
                Log.i("执行存储过程", "登陆初始化失败");
                e.printStackTrace();
                sendmsg(true,e.getMessage());
                conn = null ;
                return false;
            }
        } catch (InterruptedException e) {
            future.cancel(true);
        } catch (ExecutionException e) {
            future.cancel(true);
        } catch (TimeoutException e) {
            future.cancel(true);
            sendmsg(true,"检查数据库配置，连接数据库超时 "+contimeout+" 秒："+e.getMessage());
            conn = null ;
        } finally {
            executor.shutdown();
        }
        return false;
    }

    //查询mysql数据库
    public synchronized ArrayList<String[]> sel(String sql){
        if(!checkconn()) return null ;
        ArrayList<String[]> arrayList=new ArrayList<String[]>();
        try {
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //Statement st=conn.createStatement();
            //ResultSet rs=st.executeQuery(sql);

            ResultSetMetaData md=rs.getMetaData();
            int col=md.getColumnCount();

            while (rs.next()){
                String temp[]=new String[col];
                for(int k=0;k<temp.length;k++){
                    temp[k]=rs.getString(k+1);
                    if (temp[k]==null) temp[k]="";
                    else if(temp[k].equals("null")) temp[k]="";
                }
                arrayList.add(temp);
            }

            rs.close();
            st.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
            Log.i("查询数据库", "连接数据库异常");
            sendmsg(true,e.getMessage());
            return null;
        }

        return arrayList;
    }

    //执行存储过程
    public synchronized String pro(String name, ArrayList<String> arr){
        if(!checkconn()) return "执行存储过程前网络检查不可用" ;

        String val="?";
        for(String temp : arr)	{val=val+",?";}
        val = "{call "+name+"("+val+")}";
        CallableStatement cs=null;
        try{
            cs = conn.prepareCall(val);
            cs.registerOutParameter(1, Types.VARCHAR);	//输出型参数
            for(int k=0;k<arr.size();k++){
                cs.setString(k+2, arr.get(k));          //输入型参数
            }
            cs.execute();	//总是返回boolean型的值false
            //如果要得到结果集应使用rs = cs.executeQuery();
        }
        catch (Exception e) {
            Log.i("执行存储过程", "执行存储过程异常");
            e.printStackTrace();
            String head="";
            if(e.getMessage().contains("execute command denied")){
                head = "没有权限，请向管理员申请！";
            }
            sendmsg(true, head+"\n"+e.getMessage());
            return "执行存储过程异常："+e.getMessage();
        }

        String sqlout = "";
        try {
            if(cs.getWarnings()!=null){
                Log.i("执行存储过程", "执行存储过程发出警告:"+cs.getWarnings());
                return "执行存储过程发出警告:\n"+cs.getWarnings();
            }
            sqlout = cs.getString(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        //事务中输出的提示信息，即得到第一个输出型参数的值
        if(sqlout==null){
            String s="存储过程 "+name+" 的输出变量 sqlout 为 null!\n";
            s=s+"这种情况一般是存储过程代码有误或传参错误导致异常，为使存储过程能够回滚，加有如下代码：\n";
            s=s+"DECLARE EXIT HANDLER FOR sqlexception ROLLBACK;\n";
            s=s+"但该代码导致存储过程不返回任何消息。请行先将该代码注释掉 或 检查传入参数 后再调试！";
            Log.i("执行存储过程", s);
            return s;
        }
        if(sqlout.isEmpty()){
            sqlout="结果为空字符串";
            Log.i("执行存储过程", "执行存储过程结果:结果为空字符串");
            return "执行存储过程结果:结果为空字符串";
            //人为规定存储过程输出变量sqlout为空字符串时不作响应，说明一切正常,但返回false
            //注意的是，存储过程中的输出变量sqlout默认是null。如果存储过程正确，需要记得给其赋值空字符串
        }

        //显示执行存储过程得到的结果
        sendmsg(false,sqlout);
        Log.i("执行存储过程", "执行存储过程结果:"+sqlout);
        return sqlout;
    }

    //供程序调用，读取本地图片
    public Bitmap readimg(final String num, final String dishname) {
        final String file = dishname.replace("/","|")+"@"+num;
        if(new File(getPath()+"/repastdir/"+file).exists()==false) return null;
        final Bitmap bitmap= BitmapFactory.decodeFile(getPath()+"/repastdir/"+file);
        return bitmap;
    }

    // 专用于同步，所有的图片读取均间接从这里得到
    private synchronized void readIcon(String dishnum) {
        if(!checkconn()) return ;

        InputStream is = null;
        ResultSet rs = null;
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement("select num,name,img from photo where num="+dishnum);
            rs = pstmt.executeQuery();

            rs.first();
            is = rs.getBinaryStream("img");
            if(is==null) return ;

            String num = rs.getString("num");
            String name = rs.getString("name");
            saveimg(is, num, name); //保存到本地,注意，大图img列可能存在值，但实际上有时会没有图片，或二进制数据不是图片
        }
        catch (Exception e) {
            Log.i("读取图片", "获得大图片失败");
            e.printStackTrace();
            sendmsg(true,"获得图片失败\n"+e.getMessage());
        }
        finally {
            try {
                is.close();
                rs.close();
                pstmt.close();
            } catch (Exception e) {}
        }
    }

    //保存图片，外部仅MainActivity.java调用。
    public void saveimg(InputStream is, String num, String name) throws Exception {

        final File dirFile = new File(getPath()+"/repastdir");
        if(!dirFile.exists()) {
            dirFile.mkdirs();
        }
        name = name.replace("/","|");
        final FileOutputStream fos = new FileOutputStream(getPath()+"/repastdir/"+name+"@"+num); //可以不用加后辍.jpg

        byte[] bytes = new byte[1024];
        int len = 0;
        while((len = is.read(bytes)) != -1) fos.write(bytes, 0, len);
        fos.close();
    }

    //同步图片
    public static String ImgMsg="";
    public void synmenu(final Handler handler, SharedPreferences share){
        if(!checkconn()) return ;

        ImgMsg="正在清空repastdir目录(不含数据库)。";
        handler.sendEmptyMessage(6);

        deletephote();

        boolean b = syngoods(handler, share); //先同步菜谱
        if(b==false) return;

        String sql="select `编号` FROM menu INNER JOIN photo ON `编号`=num WHERE !ISNULL(img) ";
        final ArrayList<String[]> arr = sel(sql);
        if(arr==null) return ;
        for(final String val[] : arr){
            readIcon(val[0]);
            //图片同步进度显示
            ImgMsg="当前完成第:" + arr.indexOf(val) + "/" + arr.size() + " 张图。";
            handler.sendEmptyMessage(6);
        }
    }

    //删除所有图片，外部仅MainActivity调用
    public void deletephote() {
        final File f = new File(getPath()+"/repastdir");
        if (f.isDirectory()) {
            final File[] childFiles = f.listFiles();
            if(childFiles!=null && childFiles.length>0) {
                for(final File temp : childFiles) {
                    if(temp.getName().toLowerCase().startsWith("menu.db")==false) temp.delete(); //不要把数据库删除了,有两个文件：menu.db 和 menu.db-journal(自动生成的)
                }
            }
        }
    }

    //同步菜谱
    private boolean syngoods(Handler handler, SharedPreferences share) {
        if(!checkconn()) return false;

        SQLiteDatabase db = initFirst();
        if (db==null) return false;

        //先查询数据库， isnull的结果为0或1
        String sql=" select 编号,分类,商品名,价格,单位,锁定,助记符,isnull(img),库存 from menu left join photo on `编号`=num ";
        ArrayList<String[]> arr = sel(sql);
        if (arr==null || arr.size()==0) return false;

        //再删除本地数据
        try {
            //第二个参等效于where
            db.delete("menu", " 1=1 ", null);
            db.delete("premenu", " 1=1 ", null); //确保所有点的预点商品来自新菜谱
            //db.execSQL("drop table if exists menu");
            //db.execSQL("drop table if exists premenu");
        }
        catch (Exception e) {
            Log.i("同步商品","删除表出錯");
        }

        //写入本地数据
        int k=0;
        for (String val[] : arr) {
            db.execSQL(" insert into menu values (?,?,?,?,?,?,?,?,?) ", val);
            k++;
            //图片同步进度显示
            ImgMsg="写入商品: "+k+"/"+arr.size() ;
            handler.sendEmptyMessage(6);
        }
        db.close();

        //同步菜谱版本
        sql = " select value from general where name='system' and item='menuversion' ";
        ArrayList<String[]> menuversion = sel(sql);
        int ver = 0 ;
        if(menuversion != null && menuversion.size()==1){
            try{
                ver = Integer.valueOf(menuversion.get(0)[0]) ;
                SharedPreferences.Editor editor=share.edit();
                editor.putInt("menuversion", ver);
                editor.commit();
            }catch (Exception e){};
        }
        return true;
    }

    public boolean addmenu(String val) { //添加一个测试商品 或 同步本地文本中的商品
        boolean flag = false;
        SQLiteDatabase db = initFirst();
        if (db==null) return flag;
        try {
            if(val==null) db.delete("menu", " 1=1 ", null); //val为null代表要清空商品
            else db.execSQL(" insert into menu values (?,?,?,?,?,'N',?,'1','-1') ", val.split(" "));
            flag = true;
        }
        catch (Exception e){
            e.printStackTrace();
            sendmsg(true, "输入的值：\n"+val+"\n\n出错原因：\n"+e.getMessage(), "出错了,可能格式不规范");
        }
        finally {
            db.close();
        }
        return flag;
    }

    public void excSQLite(String sql) { //通用执行
        SQLiteDatabase db = initFirst();
        if (db==null) return;
        db.execSQL(sql);
        db.close();
    }
    public ArrayList<String[]> selSQLite(String sql) { //通用查询
        SQLiteDatabase db = initFirst();
        if (db==null) return null;
        Cursor cur = db.rawQuery(sql, null);
        ArrayList<String[]> arrayList=new ArrayList<>();
        cur.moveToFirst();
        int colnum = cur.getColumnCount();
        while (!cur.isAfterLast()){
            String temp[]=new String[colnum];
            for (int k=0; k<colnum; k++) temp[k] = cur.getString(k);
            arrayList.add(temp);
            cur.moveToNext();
        };
        if(!cur.isClosed()) cur.close();
        db.close();
        return arrayList;
    }

    public ArrayList<String[]> selSQLite(String col[], String where){ //定制查询
        SQLiteDatabase db = initFirst();
        if (db==null) return null;

        Cursor cur = db.query("menu", col,  where, null, null, null, null);
        if (where!=null && where.contains("help like")){
            //商品查询时，为节约内存，只显示前1000行数据
            cur = db.query("menu", col, where, null, null, null, null, "1000");
        }

        ArrayList<String[]> arrayList=new ArrayList<String[]>();
        cur.moveToFirst();
        while (!cur.isAfterLast()){
            String temp[]=new String[col.length];
            for (int k=0; k<col.length; k++){
                temp[k] = cur.getString(k);
            }
            arrayList.add(temp);
            cur.moveToNext();
        };
        if(!cur.isClosed()) cur.close();
        db.close();
        return arrayList;
    }

    public void pre(final String dishnum, final double num) {
        SQLiteDatabase db = initFirst();
        if (db==null) return;
        String col[] = { "num", "cla", "name", "price", "unit"};
        ArrayList<String[]> arr = selSQLite(col, "num="+dishnum);
        if(arr==null || arr.size()==0) {
            sendmsg(true, "商品编号在本地查询中不存在："+dishnum, "没找到");
            return;
        }
        db.execSQL(" insert into premenu values (?,?,?,?,?,?) ", new String[]{ arr.get(0)[0], arr.get(0)[1], arr.get(0)[2], arr.get(0)[3], arr.get(0)[4], num+"" });
        db.close();
    }

    public void clearPreMenu(String dishnum){
        SQLiteDatabase db = initFirst();
        if (db==null) return ;
        db.delete("premenu"," num=?", new String[]{dishnum});
    }
    public void updatePreMenu(String dishnum, Double amount){
        SQLiteDatabase db = initFirst();
        if (db==null) return ;
        ContentValues values = new ContentValues();
        values.put("amount",amount);
        db.update("premenu", values, " num=? ", new String[]{dishnum});
    }

    //点单时，数量选择对话框，有三个地方要调用这里
    public AlertDialog amount(Context context, final String temp[]){
        View v = LayoutInflater.from(context).inflate(R.layout.amountlayout, null);
        final EditText val;
        Button up,down;
        val = v.findViewById(R.id.amount);
        val.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    Double.valueOf(val.getText().toString());
                    val.setTextColor(Color.BLUE);
                }catch (Exception e){
                    val.setTextColor(Color.RED);
                }
            }
            public void afterTextChanged(Editable s) {}
        });
        up =  v.findViewById(R.id.add);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return;
                }
                BigDecimal bd = new BigDecimal("1"); //不要用double,会出现很多小数位
                try{bd = new BigDecimal(val.getText().toString());}catch (Exception e){}
                val.setText(bd.add(new BigDecimal("1")).toString());
            }
        });
        down = v.findViewById(R.id.del);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return;
                }
                BigDecimal bd = new BigDecimal("1"); //默认为1
                try{bd = new BigDecimal(val.getText().toString());}catch (Exception e){}
                val.setText(bd.add(new BigDecimal("-1")).toString());
            }
        });

        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(temp[2]);
        String dishnum[] = new String[3];
        for (int k = 0 ; k<3; k++){
            dishnum[k]="点单数量   "+(k+1)+" "+temp[4] + "     小计 " + new BigDecimal(temp[3]).multiply(new BigDecimal(k+1));
        }
        builder.setItems(dishnum, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int which) {
                pre(temp[0],which+1);
            }
        });
        builder.setView(v);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Double k = val.getText().toString().isEmpty() ? 0 : Double.valueOf(val.getText().toString());
                pre(temp[0], k);
            }
        });
        builder.setNegativeButton("取消", null);
        builder.setNeutralButton("写入NFC", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(act==null) return;
                final Intent intent = new Intent(act, NFCActivity.class);
                intent.putExtra("dishnum", temp[0]);
                startActivity(intent);
            }
        });

        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);
        return Dia;
    }


    /****************************************************************************************************************************/

    //首次登陆数据库应做初始化
    public SQLiteDatabase initFirst() {

        //创建目录
        File dirFile = new File(getPath()+"/repastdir");
        if (!dirFile.exists()){
            boolean temp = dirFile.mkdirs();
            if(!temp) {
                sendmsg(true, "文件夹创建失败,无法在存储卡上新建目录文件夹\n"+getPath());
                return null;
            }
        }

        //创建数据库文件
        File dbfile = new File(getPath()+"/repastdir/menu.db");
        if (!dbfile.exists()) {
            try {
                boolean temp = dbfile.createNewFile();
                if(!temp) {
                    sendmsg(true, "数据库创建失败,无法在存储卡上创建数据库文件\n"+getPath());
                    return null;
                }
            } catch (IOException e) {
                e.printStackTrace();
                sendmsg(true, "数据库创建异常,无法在存储卡上新建数据库文件\n"+e.getMessage());
                return null;
            }
        }

        SQLiteDatabase db = null;
        try{
            db = SQLiteDatabase.openOrCreateDatabase(getPath()+"/repastdir/menu.db", null, null);
        }
        catch (Exception e){
            e.printStackTrace();
            sendmsg(true, "操作数据库文件出错，SQLiteDatabase对象初始化失败\n"+e.getMessage());
            return null;
        }

        //初始化数据库
        final boolean HavePrintTable = tabIsExistss("printset", db);
        final boolean HaveMenuTable = tabIsExistss("menu", db);
        final boolean HaveDeskTable = tabIsExistss("desk", db);
        try {
            db.execSQL("create table if not exists printset(ind int primary key, text varchar, xx varchar, yy varchar, align varchar)"); //@@now, @@code
            db.execSQL("create table if not exists menu(num varchar, cla varchar, name varchar, price varchar, unit varchar, lock varhcar, help varchar, photo int, stock double)");
            db.execSQL("create table if not exists premenu(num varchar, cla varchar, name varchar, price varchar, unit varchar, amount double)");
            db.execSQL("create table if not exists desk(state varchar, area varchar, num varchar, head varchar, alias varchar, mealnum int, mealdiv varchar, staff varchar, mealtime varchar, desklock varchar, guestnum varchar, statetip varchar)");
            db.execSQL("create table if not exists dish(ind integer primary key AUTOINCREMENT, attr varchar, mealnum int, dishnum varchar, dishitem varchar, dishdiv varchar, dishdivsub varchar, dishname varchar, price varchar, unit varchar, count varchar, discount varchar, print varchar, staff varchar, dishtime varchar, remark varchar)");
            if(HavePrintTable==false) InitText(db);
            if(HaveMenuTable==false) {  //只有在创建表时才写入默认商品，仅用于用户体验
                db.execSQL("insert into menu values(1000,'菜品','临时菜','100.00','份','N','lsc',1,-1)");
                db.execSQL("insert into menu values(1001,'主食','米饭','2.00','碗','N','mf',0,100)");
                db.execSQL("insert into menu values(1002,'主食','稀饭','2.00','碗','N','xf',0,200)");
                db.execSQL("insert into menu values(1003,'主食','面条','20.00','碗','N','mt',0,300)");
                db.execSQL("insert into menu values(1004,'主食','馒头','2.00','份','N','mt',0,10)");
                db.execSQL("insert into menu values(1005,'主食','饺子','20.00','份','N','jz',0,0)");
                db.execSQL("insert into menu values(1006,'主食','面包','10.00','份','N','mb',0,-1)");
                db.execSQL("insert into menu values(1007,'酒水','白酒','200.00','瓶','N','bj',1,-1)");
                db.execSQL("insert into menu values(1008,'酒水','饮料','5.00','瓶','N','yl',1,-1)");
                db.execSQL("insert into menu values(1009,'其它','纸巾','2.00','盒','N','zj',1,-1)");
                db.execSQL("insert into menu values(1010,'主食','饼','8.00','份','N','b',1,-1)");
                db.execSQL("insert into menu values(1011,'菜品','汤','30.00','份','N','t',0,-1)");
                db.execSQL("insert into menu values(1012,'菜品','鱼','50.00','份','N','y',0,-1)");
                db.execSQL("insert into menu values(1013,'菜品','鸡','30.00','份','Y','j',0,-1)");
                db.execSQL("insert into menu values(1014,'菜品','鸭','30.00','份','Y','y',0,-1)");
                db.execSQL("insert into menu values(1015,'菜品','肉','80.00','份','N','r',0,-1)");
                db.execSQL("insert into menu values(1016,'菜品','火锅','150.00','份','N','hg',0,-1)");
                db.execSQL("insert into menu values(1017,'菜品','青菜','8.00','份','N','qc',0,-1)");
                db.execSQL("insert into menu values(1018,'菜品','炒面','10.00','份','N','cm',0,-1)");
                db.execSQL("insert into menu values(1019,'菜品','炒饭','12.00','份','N','cf',0,-1)");
                db.execSQL("insert into menu values(1020,'菜品','蛋糕','60.00','份','Y','dg',0,-1)");
                db.execSQL("insert into menu values(1021,'辅助','通用商品一','1.00','份','N','tysp',1,-1)");
                db.execSQL("insert into menu values(1022,'辅助','通用商品二','2.00','份','N','tysp',1,-1)");
                db.execSQL("insert into menu values(1023,'辅助','通用商品三','3.00','份','N','tysp',1,-1)");
                db.execSQL("insert into menu values(1024,'辅助','通用商品五','5.00','份','N','tysp',1,-1)");
                db.execSQL("insert into menu values(1025,'辅助','通用商品十','10.00','份','N','tysp',1,-1)");
                db.execSQL("insert into menu values(1026,'辅助','通用商品二十','20.00','份','N','tysp',1,-1)");
                db.execSQL("insert into menu values(1027,'辅助','通用商品五十','50.00','份','N','tysp',1,-1)");
                db.execSQL("insert into menu values(1028,'辅助','通用商品一佰','100.00','份','N','tysp',1,-1)");
                db.execSQL("insert into menu values(1029,'辅助','通用商品二佰','200.00','份','N','tysp',1,-1)");
                db.execSQL("insert into menu values(1030,'辅助','通用商品五佰','500.00','份','N','tysp',1,-1)");
            }
            if(HaveDeskTable==false) {
                for(int k=0;k<99;k++) { //不要出现 3 位数
                    int ktem = k+1;
                    final String s = ktem<10 ? "00"+ktem : "0"+ktem;
                    db.execSQL("insert into desk values('空台','卡台', '"+s+"','1','本地',0,'','admin@本地','','N','0','')");
                    db.execSQL("insert into desk values('空台','包箱', '"+s+"','2','本地',0,'','admin@本地','','N','0','')");
                    if(k<80) db.execSQL("insert into desk values('空台','宴会厅','"+s+"','3','本地',0,'','admin@本地','','N','0','')");
                    if(k<80) db.execSQL("insert into desk values('空台','会议厅','"+s+"','4','本地',0,'','admin@本地','','N','0','')");
                    if(k<60) db.execSQL("insert into desk values('空台','大堂',  '"+s+"','5','本地',0,'','admin@本地','','N','0','')");
                    if(k<60) db.execSQL("insert into desk values('空台','其它',  '"+s+"','6','本地',0,'','admin@本地','','N','0','')");
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            sendmsg(true, "新建数据库表出错，无法创建商品表、预点商品表或打印设置表。\n"+e.getMessage());
            return null;
        }
        return db;
    }

    //判断某张表是否存在
    private boolean tabIsExistss(String tabName, SQLiteDatabase db) {
        boolean result = false;
        Cursor cursor = null;
        try {
            //db = this.getReadableDatabase();
            final String sql = "select count(*) as c from sqlite_master where type ='table' and name ='"+tabName.trim()+"' ";
            cursor = db.rawQuery(sql, null);
            if(cursor.moveToNext()){
                int count = cursor.getInt(0);
                if(count>0){
                    result = true;
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
        }
        return result;
    }

    /******************************************************** 获取网络上的图片并保存 ****************************************************************/

    public void NetPhoto(final String num, final String name, final Object obj) {

        if(act==null) return;
        final SharedPreferences share = getSharedPreferences("val", Context.MODE_PRIVATE);
        final String domain = share.getString("address", "repast.dmumu.com");

        final AlertDialog.Builder builder = new AlertDialog.Builder(act);
        builder.setMessage("因网络速率不同，同步网络图片进度会有差异，效果可能会有延时；Bing默认取最后一天，根据手机横屏或竖屏自动选择照片，可手动修改时间点。");
        final EditText input = new EditText(this);
        input.setHint("https://"+domain+"/img");
        input.setText("https://"+domain+"/img?num="+num); //默认地址
        builder.setView(input);
        builder.setTitle("输入完整的图片网址 URL");
        //第一个按扭
        builder.setPositiveButton("确认 OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String tem = input.getText().toString();
                if(tem.trim().isEmpty()) return;
                NetPhoto(num, name, tem, obj);
            }
        });
        //第二个按扭
        builder.setNegativeButton("Bing",null);
        builder.setNeutralButton("随机测试", null);
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();

        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
            long k = 0;
            @Override
            public void onClick(View v) {
                //https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=zh-CN
                input.setText("https://www.bing.com/HPImageArchive.aspx?format=js&idx="+k+"&n=1");
                k++;
                //alertDialog.dismiss();
            }
        });
        alertDialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            long k = 0;
            @Override
            public void onClick(View v) {
                if(k%4==0) {
                    int orientation = getResources().getConfiguration().orientation;
                    if(orientation == Configuration.ORIENTATION_PORTRAIT) input.setText("https://picsum.photos/1080/1920"); //横屏变竖屏
                    else input.setText("https://picsum.photos/1920/1080");
                }
                if(k%4==1) input.setText("https://cdn.seovx.com/?mom=302");
                if(k%4==2) input.setText("https://www.dmoe.cc/random.php"); //二元次
                if(k%4==3) input.setText("https://api.btstu.cn/sjbz/api.php"); //很慢
                k++;
                //alertDialog.dismiss();
            }
        });
    }

    private void NetPhoto(final String num, final String name, final String str, final Object obj) { //加载一个网络图片作为背景
        if(act==null) return;
        final Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                //Bing的图片要先解析Json
                String strurl = str;
                if(str.trim().toLowerCase().startsWith("https://www.bing.com/HPImageArchive".toLowerCase())) {
                    try {
                        final SSLContext sslContext = SSLContext.getInstance("TLS");
                        sslContext.init(null, new TrustManager[]{new X509TrustManager() {
                            @Override
                            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
                            @Override
                            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
                            @Override
                            public X509Certificate[] getAcceptedIssuers() {
                                return new X509Certificate[0];
                            }
                        }}, new SecureRandom());
                        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
                        HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                            @Override
                            public boolean verify(String hostname, SSLSession session) {
                                return true; //忽略证书错误
                            }
                        });
                        final URL imageUrl = new URL(str);
                        final InputStream inputStream = imageUrl.openConnection().getInputStream();
                        final Scanner s = new Scanner(inputStream).useDelimiter("\\A");
                        if (s.hasNext()) {
                            final JSONObject jsonObject = new JSONObject(s.next());
                            final JSONArray jsonArray = (JSONArray) jsonObject.get("images");
                            final int jsonlen = jsonArray.length();
                            for (int k = 0; k < jsonlen; k++) {
                                final JSONObject jtem = (JSONObject) jsonArray.get(k);
                                strurl = "https://www.bing.com" + jtem.get("url").toString(); //取URL地址
                            }
                        }
                        inputStream.close();
                        int orientation = getResources().getConfiguration().orientation;
                        if (orientation == Configuration.ORIENTATION_PORTRAIT) strurl = strurl.replace("1920x1080", "1080x1920"); //横屏变竖屏
                    }
                    catch (final Exception e) {
                        e.printStackTrace();
                        obj.equals("Bing图片JSON处理异常：" + e.getMessage());
                        return;
                    }
                }

                try {
                    final SSLContext sslContext = SSLContext.getInstance("TLS");
                    sslContext.init(null, new TrustManager[]{new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
                        @Override
                        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }
                    }}, new SecureRandom());

                    HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
                    HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true; //忽略证书错误
                        }
                    });

                    final URL imageUrl = new URL(strurl);
                    final InputStream inputStream = imageUrl.openConnection().getInputStream();
                    saveimg(inputStream, num, name); //保存图片到本地
                    inputStream.close();
                }
                catch (final Exception e) {
                    e.printStackTrace();
                    obj.equals("图片加载异常："+e.getMessage());
                    return;
                }
                obj.equals(null); //执行结束
            }
        });
        th.setDaemon(true);
        th.start();
    }

    /************************************************************** 与打印相关 **********************************************************************/

    //读取字节,数据流  打印账单
    public void getbill(int mealnum, String showback, String showlist, String site){
        //是否显示退单和套餐明细
        //byte bb[] = getbin("select convert(binary_bill("+mealnum+",'"+showback+"','"+showlist+"') using gbk)", handler);
        byte bb[] = getbin("select binary_bill("+mealnum+",'"+showback+"','"+showlist+"')");
        if(bb!=null) {
            boolean result = printbin(bb, site);
            if(result) sendmsg(true, "恭喜，账单打印成功。\n站点：" + site);
        }
    }
    //读取字节,数据流  打印清单
    public void getlist(int mealnum, String site){
        byte bb[] = getbin("select binary_list("+mealnum+",'"+site+"')");
        if(bb!=null){
            boolean result = printbin(bb, site);
            if(result) sendmsg(true, "恭喜，清单打印成功。\n站点：" + site);
        }
    }
    //读取字节,数据流  打印联单
    public void getunion(int mealnum, String site){
        byte bb[] = getbin("select binary_union("+mealnum+",'"+site+"')");
        if(bb!=null){
            boolean result = printbin(bb, site);
            if(result) sendmsg(true, "恭喜，联单打印成功。\n站点：" + site);
        }
    }

    //读取字节,数据流
    private synchronized byte[] getbin(String sql){
        if(!checkconn()) return null ;
        ResultSet rs = null;
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            rs.first();

            /* //改用下面的方法一切正常
            String val=rs.getString(1);
            byte[] A = new byte[]{};
            try{A=val.getBytes("GBK");}catch (Exception e) {}
            return A ;
            */
            return rs.getBytes(1);
        }
        catch (Exception e) {
            String errmsg = "";
            if (e.getMessage().contains("execute command denied")){
                errmsg = "没有权限,请向管理员申请\n";
            }
            sendmsg(true, errmsg+"[mysql.getbin()读取字节流异常]\n" + e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null) rs.close();
                if(pstmt!=null) pstmt.close();
            } catch (Exception e) {}
        }
        return null;
    }

    //读取字节,后来加的，从存储过程中得到binary_go
    public synchronized HashMap<String[], byte[]> getBinDB(int mealnum, String hold){
        CallableStatement cs = null ;
        HashMap<String[], byte[]> hm = new HashMap<>();
        try{
            cs = (CallableStatement)conn.prepareCall("{call binary_go(?,?,?)}");
            cs.registerOutParameter(1, Types.VARCHAR);	//输出型参数
            cs.setString(2, mealnum+"");			//输入型参数
            cs.setString(3, hold);
            cs.execute();

            if(cs.getWarnings()!=null){
                sendmsg(true, "[mysql.getBinDB()警告信息]\n" + cs.getWarnings().toString());
            }

            // 事务中输出的提示信息，即得到第一个输出型参数的值
            String sqlout = cs.getString(1);
            if(sqlout!=null && !sqlout.isEmpty()){
                sendmsg(true, "[mysql.getBinDB()返回消息]\n" + sqlout);
            }

            // 没有错误的情况下处理结果集
            if(cs.getWarnings()==null && sqlout==null){
                boolean hadResults = false;
                int flag = 0;	//如果打印两份，则会出现重复，但HashMap不充许重复键值对，所以加一个序号标识。
                do{
                    ResultSet rs = cs.getResultSet();
                    while(rs != null && rs.next()){
                        String temp[] = new String[7];
                        temp[0] = rs.getString(1);  //ip
                        temp[1] = rs.getString(2);  //port
                        temp[2] = rs.getString(3);  //site
                        temp[3] = "" + flag++;
                        hm.put(temp, rs.getBytes(4));   //binary
                    }
                    rs.close();
                    hadResults = cs.getMoreResults(); 	//检查是否存在更多结果集
                }while(hadResults);
            }
        }
        catch(Exception e){
            String s = e.getMessage();
            if (s == null) {
                // 比如，cat连接到了数据库，然后root删除了cat账号，当cat调用存储过程时e.getMessage就为空。
                s = "异常消息为空，可能帐号不存在，或其它不明原因。";
            }
            else if (s.startsWith("execute command denied to user")) {
                s = "没有权限，请向管理员申请。\n" + s;
            }
            sendmsg(true, "[mysql.getBinDB()調用异常]\n" + s);
        }
        finally{
            //不再使用就关闭
            try{cs.close();}catch (Exception e) {};
        }
        return hm ;
    }

    //不指定站点IP和端口时，自己根据站点名称找到IP和端口
    public boolean printbin(byte temp[], String site){

        //不指定打印机站点名，则默认是本地无数据库服务器时的预览菜单打印
        final SharedPreferences share = getSharedPreferences("val", Context.MODE_PRIVATE);
        String ipval = share.getString("printaddress", "192.168.1.222");
        String portval = share.getString("printport", "9100");
        try{Integer.valueOf(portval);}catch (Exception e){portval = "9100";}
        int port = Integer.valueOf(portval);

        if(site!=null && site.isEmpty()==false) {
            final ArrayList<String[]> config = sel("select 站点,IP,端口 from print_config where 站点='"+site+"';");
            if(config.size()==0 || config.get(0).length==0){
                sendmsg(true,"站点："+site+" 不存在，请正确配置打印机站点。", "错误");
                return false;
            }
            ipval = config.get(0)[1];					//IP地址
            port = Integer.valueOf(config.get(0)[2]);	//端口
        }
        return printbin(temp, site, ipval, port);
    }

    //打印数据, 外部仅PrintDB调用
    public synchronized boolean printbin(byte temp[], String site, final String ip, final int port){

        boolean result = true;
        Socket socket = new Socket() ;
        ObjectOutputStream output = null ;
        SocketAddress add = new InetSocketAddress(ip, Integer.valueOf(port)) ;
        try{
            socket.connect(add,3000);
            output=new ObjectOutputStream(socket.getOutputStream());

            byte LF = 0x0A;	//打印并走纸的标记
            byte ESC = 0x1B;
            int flag=0;

            //复位两次,有些热敏打印机复位一次不够
            output.write(new byte[] {ESC, '@'});
            output.write(new byte[] {ESC, '@'});

            for(int k=0;k<temp.length;k++){
                output.write(temp[k]);
                flag++;

                //如果热敏打印机缓存为1024字节，应在快达到这个数之前将数据发送出去
                if((temp[k]==LF)&&(flag>900)){
                    output.flush();
                    flag=0;

                    //复位两次
                    output.write(new byte[] {ESC, '@'});
                    output.write(new byte[] {ESC, '@'});
                }
            }
            output.flush();
            sendmsg(false,"已成功发送打印数据。");
        }
        catch (Exception e) {
            if(site==null || site.isEmpty()) site="本地";
            sendmsg(true,"打印机站点:"+site+" "+ip+":"+port+" 可能连接超时3秒,打印失败\n"+e.getMessage(), "警告");
            e.printStackTrace();
            result = false ;	//不要return false, 因为要下面的代码为关闭端口
        }
        finally{
            try {
                if(output!=null) output.close();
                if(socket!=null && !socket.isClosed()) socket.close();
            } catch (IOException e) {}
        }
        return result;
    }

    /*-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
    /*****************************************************  仅本地热敏小票无网络实现本地打印的功能  **********************************************************/
    /*-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

    private void InitText(SQLiteDatabase db) {

        int k=0;
        String val[] = new String[]{++k+"", "参考小票清单 List", "Y", "Y", "CENTER" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);
        kong(++k+"",db);   //空一行

        val = new String[]{++k+"", "名称     单价     数量     金额", "N", "N", "LEFT" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);

        val = new String[]{++k+"", "----------------------------------------------------", "N", "N", "CENTER" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);

        val = new String[]{++k+"", "@@dishorder   @@dishname", "N", "N", "LEFT" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);

        val = new String[]{++k+"", "@@dishnum     @@dishprice/@@dishunit     @@dishamount     @dishmoney", "N", "N", "LEFT" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);

        val = new String[]{++k+"", "----------------------------------------------------", "N", "N", "CENTER" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);

        val = new String[]{++k+"", "总数量：@@sumcount, 总金额：@@summoney", "Y", "N", "LEFT" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);
        kong(++k+"",db);   //空一行

        val = new String[]{++k+"", "打印时间：@@now", "Y", "N", "LEFT" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);
        kong(++k+"",db);   //空一行

        val = new String[]{++k+"", "盖章/签名： _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _", "N", "Y", "LEFT" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);
        kong(++k+"",db);   //空一行

        val = new String[]{++k+"", "@@ma", "N", "N", "CENTER" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);
        kong(++k+"",db);   //空一行

        qu(++k+"","about our：https://repast.dmumu.com ",db);
        kong(++k+"",db);   //空一行
    }
    private void qu(String k, String s, SQLiteDatabase db){
        String val[] = new String[]{k, s, "N", "N", "LEFT" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);
    }
    private void kong(String k, SQLiteDatabase db){
        String val[] = new String[]{k, "", "N", "N", "LEFT" };
        db.execSQL(" insert into printset values (?,?,?,?,?) ", val);
    }

    /*------------------------------------------------------  内容排版编辑  -------------------------------------------------------------*/

    //专供于读取打印信息时调用
    public ArrayList<String[]> local_hotprint_table(){
        SQLiteDatabase db = initFirst();
        if (db==null) return null;
        Cursor cur = db.rawQuery("select * from printset order by ind",null); //一定要排序
        final ArrayList<String[]> arrayList=new ArrayList<>();
        cur.moveToFirst();
        while (!cur.isAfterLast()){
            String temp[]=new String[5];
            for (int k=0; k<5; k++){
                temp[k] = cur.getString(k);
            }
            arrayList.add(temp);
            cur.moveToNext();
        };
        if(!cur.isClosed()) cur.close();
        db.close();
        return arrayList; //注意尽可能防止arrayList为null，减少出闪退现像发生
    }

    public boolean writetext(String ind, String text, String XX, String YY, String align){
        SQLiteDatabase db = initFirst();
        if (db==null) return false;
        db.execSQL(" replace into printset(ind,text,xx,yy,align) values(?, ?, ?, ?, ?) ", new String[]{ ind, text, XX, YY, align });
        return true;
    }

    public boolean writedelete(String ind) {
        SQLiteDatabase db = initFirst();
        if (db==null) return false;
        db.execSQL(" delete from printset where ind=? and ind!=1 ", new String[]{ ind }); //至少要保留一条数据，这样修改时才能新增
        return true;
    }

    /*------------------------------------------------------------ 本地打印功能,共三个方法一起实现 --------------------------------------------------------------*/

    public void local_hotprint(int mealnum) {

        if(act==null) return;
        //final String cols = "attr,mealnum,dishnum,dishitem,dishdiv,dishdivsub,dishname,price,unit,count,discount,print,staff,dishtime,remark";
        // 读取临时菜单 或 卡台 中的商品信息
        final ArrayList<String[]> menu =  selSQLite(mealnum==0 ? "select num,cla,name,price,unit,amount from premenu" : "select dishnum,dishdiv,dishname,price,unit,count from dish where mealnum="+mealnum);
        if(menu==null || menu.size()==0) {
            Toast.makeText(act, "没有需要打印的商品", Toast.LENGTH_SHORT).show();
            return;
        }

        final ArrayList<String[]> arr = local_hotprint_table();
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final HotPrinterCmd hp = new HotPrinterCmd(out);

        for (int k = 0; k < arr.size(); k++) {
            String text = arr.get(k)[1];
            if (text.contains("@@code")) { //二维码
                hp.getcode();
                continue; //直接返回处理下一个
            }
            if (arr.get(k)[1].contains("@@dish")) { //菜单
                final ArrayList<String[]> data = local_hotprint_menu(k, arr, menu);
                for(final String tem[] : data) local_hotprint_row(hp, tem[0], tem[1], tem[2], tem[3], menu);
                continue;
            }
            local_hotprint_row(hp, text, arr.get(k)[2], arr.get(k)[3], arr.get(k)[4], menu); //其它直接处理
        }
        try {
            hp.CutPaper(); //切纸
        } catch (Exception e) {
            e.printStackTrace();
        }
        final Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                printbin(out.toByteArray(), null);
            }
        });
        th.setDaemon(true);
        th.start();
    }
    private void local_hotprint_row(final HotPrinterCmd hp, String text, final String xx, final String yy, final String align, final ArrayList<String[]> menu) {

        //处理时间
        if (text.contains("@@now")) {
            final SimpleDateFormat sDateFormat  =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String  date =  sDateFormat.format(new Date());
            text=text.replace("@@now", date);
        }
        //处理数量
        if (text.contains("@@sumcount")) {
            double num = 0;
            for(final String menurow[] : menu) try{num+=Double.valueOf(menurow[5]);}catch (Exception e){};
            text=text.replace("@@sumcount", num+"");
        }
        //处理费用
        if (text.contains("@@summoney")) {
            double money = 0.0;
            for(final String menurow[] : menu) try{money=money+Double.valueOf(menurow[3])*Double.valueOf(menurow[5]);}catch (Exception e){};
            text=text.replace("@@summoney", String.format("%.2f", money));
        }

        if (xx.equals("Y") && yy.equals("Y")) {
            try {
                hp.doubleSizePrinter(text, align);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }
        if (xx.equals("Y") && yy.equals("N")) {
            try {
                hp.doublex(text, align);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }
        if (xx.equals("N") && yy.equals("Y")) {
            try {
                hp.doubley(text, align);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }
        if (xx.equals("N") && yy.equals("N")) {
            try {
                hp.standardPrinterLine(text, align);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    private ArrayList<String[]> local_hotprint_menu(final int k, final ArrayList<String[]> arr, final ArrayList<String[]> menu) {
        final ArrayList<String[]> data = new ArrayList<>();
        if(k>0 && arr.get(k-1)[1].contains("@@dish")) return data; //上一行有商品变量，说明已经执行过了
        int rownum = 0;
        for(final String menurow[] : menu) {
            rownum++;
            int kstart=k;
            while(kstart<arr.size() && arr.get(kstart)[1].contains("@@dish")) { //文本中有商品变量
                String text = arr.get(kstart)[1];
                text=text.replace("@@dishorder", rownum<10 ? rownum+" " : rownum+""); //10以下补一个空格，方便对齐
                text=text.replace("@@dishnum", menurow[0]);
                text=text.replace("@@dishcla", menurow[1]);
                text=text.replace("@@dishname", menurow[2]);
                text=text.replace("@@dishprice", menurow[3]);
                text=text.replace("@@dishunit", menurow[4]);
                text=text.replace("@@dishamount", menurow[5]);
                double money=0.0;
                try{money=Double.valueOf(menurow[3])*Double.valueOf(menurow[5]);}catch (Exception e){}
                text=text.replace("@@dishmoney", String.format("%.2f", money)); //保留两位小数
                data.add(new String[]{text, arr.get(kstart)[2], arr.get(kstart)[3], arr.get(kstart)[4]});
                kstart++; //处理下一行，直到没有商品变量
            }
        }
        return data;
    }

}