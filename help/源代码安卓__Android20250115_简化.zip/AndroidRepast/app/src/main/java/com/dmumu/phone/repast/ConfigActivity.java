package com.dmumu.phone.repast;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

public class ConfigActivity extends AppCompatActivity {

    private AutoCompleteTextView address;
    private TextInputEditText port;
    private TextInputEditText dbname;
    private TextView msg;
    private SharedPreferences share ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        share = getSharedPreferences("val", Context.MODE_PRIVATE);
        address = findViewById(R.id.foraddress);
        port = findViewById(R.id.forport);
        dbname = findViewById(R.id.fordbname);
        address.setText(share.getString("address", ""));
        port.setText(share.getString("port", ""));
        dbname.setText(share.getString("dbname", ""));

        msg = findViewById(R.id.msg);
        findViewById(R.id.selimsiiccid).setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               if (ActivityCompat.checkSelfPermission(ConfigActivity.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                   msg.setText("没有读取IMSI,ICCID的权限,请先赋予相关权限.");
                   //没有权限，向用户请求权限，字符串数组内是一个或多个要申请的权限，1是申请权限结果的返回参数，在onRequestPermissionsResult可以得知申请结果
                   ActivityCompat.requestPermissions(ConfigActivity.this, new String[]{Manifest.permission.READ_PHONE_STATE}, 1);
                   return;
               }
               TelephonyManager mTelephonyMgr = (TelephonyManager) ConfigActivity.this.getSystemService(Context.TELEPHONY_SERVICE);
               new AlertDialog.Builder(ConfigActivity.this)
                       .setTitle("当前手机主卡IMSI,ICCID号")
                       .setMessage("imsi:"+mTelephonyMgr.getSubscriberId()+"\niccid:"+mTelephonyMgr.getSimSerialNumber())
                       .setPositiveButton("确定", null)
                       .create()
                       .show();
           }
        });

        final Button b = findViewById(R.id.reg_button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b.requestFocus();
                if(address.getText().toString().isEmpty()) {
                    msg.setText("地址不能为空");
                    return;
                }
                if(dbname.getText().toString().isEmpty()) {
                    msg.setText("数据库名不能为空");
                    return;
                }
                if(port.getText().toString().isEmpty()) {
                    msg.setText("端口不能为空");
                    return;
                }
                try{
                    Integer.valueOf(port.getText().toString().trim());
                }catch (Exception e){
                    msg.setText("端口必须是int数字");
                    return;
                }

                //保存登陆参数
                final SharedPreferences.Editor editor=share.edit();
                editor.putString("address", address.getText().toString().trim());
                editor.putString("port", port.getText().toString().trim());
                editor.putString("dbname", dbname.getText().toString().trim());
                editor.commit();
                msg.setText("数据已保存哟,正在测试端口......");

                //尝试激活端口，如果不这么做，登陆经常出现超时现象,但这也不能保证什么。只是提高了登陆成功的效率
                final Thread th=new Thread(new Runnable() {
                    public void run() {
                        final Socket socket = new Socket() ;
                        final SocketAddress add = new InetSocketAddress(address.getText().toString().trim(), Integer.valueOf(port.getText().toString().trim()));
                        final StringBuffer msgval=new StringBuffer();
                        try {
                            socket.setSoTimeout(3000);              //这个也是超时设置，但也不是很好的起作用
                            socket.connect(add, 3000);  //限时3秒好像到了Android里面就不起作用了
                            socket.close();
                            msgval.append("数据已保存哟,端口测试正常.");

                        } catch (Exception e){
                            msgval.append("数据已保存哟,端口测试失败,检查参数...");
                        }

                        if(ConfigActivity.this.isFinishing()==true) return;
                        ConfigActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                msg.setText(msgval.toString());
                            }
                        });
                    }
                });
                th.setDaemon(true);
                th.start();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        //通过requestCode来识别是否同一个请求
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //用户同意，执行操作
            Toast.makeText(this, "现在你有权限了,请重新操作一次...", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}