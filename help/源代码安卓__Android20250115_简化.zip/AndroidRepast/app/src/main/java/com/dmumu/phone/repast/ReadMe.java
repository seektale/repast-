package com.dmumu.phone.repast;

/**
 *
 * Created by admin on 2024/11/23.
 *
 * activity, camera, decode, utils, 这四个包与使用相机扫描二维码有关，自己进行过一些定制
 *
 * escpos, 这个包专门处理热敏打印机相关的事务
 *
 * other, 这个包处理 NFC 和 gif 动画展示等一些不重要的功能
 *
 */

public class ReadMe {}
