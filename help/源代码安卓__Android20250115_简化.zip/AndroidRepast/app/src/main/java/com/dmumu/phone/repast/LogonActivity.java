package com.dmumu.phone.repast;
import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.hardware.fingerprint.FingerprintManagerCompat;
import android.support.v4.os.CancellationSignal;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Administrator on 2015/1/13.
 */
public class LogonActivity extends Activity {

    private AutoCompleteTextView account ;
    private EditText password ;
    private CheckBox save,auto ;
    private SharedPreferences share ;
    private TextView msg;

    private FingerprintManagerCompat fin;
    private FingerprintManagerCompat.AuthenticationCallback cb;
    private CancellationSignal cancellationSignal;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //取消标题栏
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        //取消状态栏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        //getWindow().setWindowAnimations(R.style.popwin_anim_style); //动画效果
        share = getSharedPreferences("val", Context.MODE_PRIVATE);

        Intent intent = getIntent();
        boolean autoLogon = intent.getBooleanExtra("auto",true);

        account = findViewById(R.id.foraccount);
        password = findViewById(R.id.forpassword);
        save = findViewById(R.id.forsave);
        auto = findViewById(R.id.forauto);
        msg = findViewById(R.id.msg);

        //初始化参数
        account.setText(share.getString("account", ""));
        password.setText(share.getString("password",""));
        save.setChecked(share.getBoolean("save", false)); //赋值会触发监听事件,所以代码要放在前面
        auto.setChecked(share.getBoolean("auto", false));
        final Set<String> set=share.getStringSet("accountlist",null);
        if (set!=null && set.size()>0) {
            final String str[]=new String[set.size()];
            set.toArray(str);
            //account.setText(str[str.length-1]); 不要显示
            final ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line, str);
            account.setAdapter(adapter);
            //account.setDropDownBackgroundResource(R.drawable.bg);
        }

        account.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                msg.setText("");
            }
        });

        password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                msg.setText("");
            }
        });

        save.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //保存登陆参数
                final SharedPreferences.Editor editor=share.edit();
                editor.putBoolean("save", isChecked);
                if(isChecked) {
                    final AlertDialog.Builder dialog=new AlertDialog.Builder(LogonActivity.this);
                    dialog.setTitle("注意");
                    dialog.setMessage("勾选<记住密码>时,即使手动断开服务器连接,网络模式下程序依然会在需要时尝试根据记住的密码自动连接服务器");
                    dialog.setPositiveButton("好的", null);
                    dialog.show();
                }
                else{
                    editor.putString("password","");    //清空密码
                }
                editor.commit();
            }
        });
        auto.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //保存登陆参数
                final SharedPreferences.Editor editor=share.edit();
                editor.putBoolean("auto", isChecked);
                editor.commit();
                if (isChecked) password.setInputType(128);
                else password.setInputType(129);
            }
        });

        Button logon=(Button)findViewById(R.id.forlogon);
        logon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logonOK();
            }
        });

        Button local=(Button)findViewById(R.id.forlocal);
        local.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MyApp)getApplication()).getMode(false); //标记为本地模式
                ingmsg("已切换为本地工作模式。");
                finish();
            }
        });

        findViewById(R.id.ServerConfig).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                final Intent intent = new Intent();
                intent.setClass(LogonActivity.this, ConfigActivity.class);
                LogonActivity.this.startActivity(intent);
            }
        });

        Toast.makeText(this,((MyApp)getApplication()).getMode() ? "当前模式为：在线模式":"当前模式为：本地模式", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResume() {
        super.onResume();
        // 每次从别的activity返回时，本方法会被执行
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "没有指纹识别模块或没有授予权限", Toast.LENGTH_SHORT).show();
            return;
        }
        //fin.authenticate(null, 0,cancellationSignal, cb, null);
        if(fin==null) fin = FingerprintManagerCompat.from(this);
        if(cancellationSignal==null) cancellationSignal = new CancellationSignal();
        if(cb==null) {
            cb = new FingerprintManagerCompat.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(FingerprintManagerCompat.AuthenticationResult result) { //认证成功后不再监听
                    super.onAuthenticationSucceeded(result);
                    Toast.makeText(LogonActivity.this,"指纹识别成功,正在自动登陆...", Toast.LENGTH_SHORT).show();
                    account.setText(share.getString("fingeraccount", ""));
                    password.setText(share.getString("fingerpassword", ""));
                    logonOK();
                }
                @Override
                public void onAuthenticationError(int errMsgId, CharSequence errString) {
                    super.onAuthenticationError(errMsgId, errString);
                    msg.setText(errMsgId+" "+errString);
                }
            };
        }
        fin.authenticate(null, 0, cancellationSignal, cb, null);
    }
    @Override
    public void onPause() {
        super.onPause();
        // 每次调用别的activity时，本方法会被执行
        if(cancellationSignal!=null) cancellationSignal.cancel(); //取消监听
        //释放，如果不这么做，有可能会导致重新监听出问题
        fin=null;
        cb=null;
        cancellationSignal=null;
    }

    //进入后台长时不显示时，这个最好关掉
    public void onStop(){
        super.onStop();
        finish();
    }

    private void logonOK(){

        if(account.getText().toString().toLowerCase().equals("log")){
            msg.setText("log 是系统辅助账号，限制登陆。");
            return ;
        }
        if (password.getText().toString().isEmpty()){
            msg.setText("密码不能为空？");
            return;
        }
        if(checknet()){
            msg.setText("唉哟 亲，没有网络耶？");
            return;
        }

        //注意区分大小写，以方便登陆
        final String acc = account.getText().toString().trim();
        final String pwd = password.getText().toString().trim();

        //在登陆之前保存登陆参数
        final SharedPreferences.Editor editor = share.edit();
        Set<String> set=share.getStringSet("accountlist",null);
        if (set==null){
            set = new HashSet<>();
        }
        set.add(acc);
        editor.putStringSet("accountlist", set);
        editor.putString("account", acc);
        if (save.isChecked()) editor.putString("password", pwd);
        MyApp.pwd = pwd; ////用户没有选择【记住密码】的情况下用这个记录密码
        editor.commit();

        ((MyApp)getApplication()).getMode(true); //标记为网络工作模式

        //连接数据库必须以线程的方式，否则不能连接数据库
        final Thread th=new Thread(new Runnable() {
            public void run() {

                ingmsg("正在连接数据库...");
                boolean boo = ((MyApp)getApplication()).getcon();
                if(!boo) {
                    ingmsg("登陆失败："+boo);
                    return;
                }

                //检查用户相关信息
                String sql = "select name_chinese,islock from account where name_english='"+acc+"';";
                final ArrayList<String[]> usercfg = ((MyApp)getApplication()).sel(sql);

                if(usercfg == null || usercfg.size()==0){
                    ingmsg("用户不存在。");
                    return ;
                }
                if(usercfg.get(0)[1].equals("Y")) {
                    ingmsg("当前用户被锁定，请联系管理员先解锁。");
                    return ;
                }

                ingmsg("登陆成功。");
                final Intent intent = new Intent();
                intent.putExtra("username", usercfg.get(0)[0]);   // 放入返回值
                intent.putExtra("menuversion","以前在登陆时检查菜单版本，已放弃");
                setResult(1, intent);     // 放入回传的值,并添加一个Code,方便区分返回的数据
                finish();

                //指纹登陆时只使用登陆成功过的账号和密码
                final SharedPreferences.Editor editor = share.edit();
                editor.putString("fingeraccount", acc);
                editor.putString("fingerpassword", pwd);
                editor.commit();
            }
        });
        th.setDaemon(true);
        th.start();
    }

    private void ingmsg(final String str) {
        if(LogonActivity.this.isFinishing()==true) return;
        LogonActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
               msg.setText(str);
            }
        });
    }

    /*
    private void lockmsg() {
        if(LogonActivity.this.isFinishing()==true) return;
        LogonActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(LogonActivity.this);
                builder.setMessage("当前用户被锁定，请联系管理员先解锁。\n");
                builder.setTitle("禁止登陆");
                builder.setPositiveButton("知道了",null);
                builder.create().show();
            }
        });
    }
    */

    private boolean checknet(){

        ConnectivityManager con = (ConnectivityManager)getSystemService(Activity.CONNECTIVITY_SERVICE);
        boolean wifi = con.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isConnectedOrConnecting();
        boolean internet = con.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isConnectedOrConnecting();

        if(internet){
            ((MyApp)getApplication()).contimeout = 20 ; //由于3G网络太慢，登陆超时定为20秒
            Toast.makeText(this, "注意：当前网络为 移动数据网络\n登陆过程可能需要较长时间，最长限制 20 秒", Toast.LENGTH_SHORT).show();
        }
        else{
            ((MyApp)getApplication()).contimeout = 5 ;  //确保网络切换是能恢复到默认超时的5秒
        }

        if( wifi | internet ) return false ;
        return true ;

        /*
        另外需要权限
        <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
        */
    }
}