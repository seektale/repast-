package com.dmumu.phone.repast.hotprint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HeaderViewListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import com.dmumu.phone.repast.MyApp;
import com.dmumu.phone.repast.R;
import java.util.ArrayList;

public class HotPrintText extends AppCompatActivity {
    private ArrayList<String[]> arrayList=new ArrayList<>();
    private ListView listView ;
    private TextView header,footer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hotprinttext);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        header = new TextView(getBaseContext());
        header.setGravity(Gravity.CENTER);
        header.setTextSize(16);
        header.setTextColor(Color.BLUE);
        footer = new TextView(getBaseContext());
        footer.setGravity(Gravity.CENTER);
        footer.setTextSize(14);
        footer.setText("\n文本中变量说明：@@now 当前时间，@@code 随机条形码，@@sumcount 总数量，@@summoney 总金额，@@dish 商品列表（@@dishorder 商品序号，@@dishnum 商品编码，@@dishcla 商品分类，@@dishname 商品名，@@dishprice 商品价格，@@dishunit 商品单位，@@dishamount 商品数量，@@dishmoney 商品费用）\n");

        listView = (ListView)findViewById(R.id.tabscroll);
        listView.addHeaderView(header);
        listView.addFooterView(footer);
        listView.setAdapter(new MyAdater());
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(arrayList==null || arrayList.size()==0) return;
                if(position==0) return; //header
                if(position==arrayList.size()+1) return; //footer
                final String ind = ((TextView)view).getHint().toString();
                for(final String[] tem : arrayList) {
                    if(tem[0].equalsIgnoreCase(ind)) {
                        edit(tem[0], tem[1], tem[2], tem[3], tem[4]);
                        break;
                    }
                }
            }
        });
        newdata();
    }
    private void newdata(){
        arrayList = ((MyApp)getApplication()).local_hotprint_table();
        if (arrayList != null){
            final HeaderViewListAdapter hAdapter = (HeaderViewListAdapter)listView.getAdapter();
            final MyAdater myadapter = (MyAdater)hAdapter.getWrappedAdapter();
            myadapter.notifyDataSetChanged();
            header.setText("共计 "+arrayList.size()+" 条记录,编号1无法删除\n系统使用GBK编码打印,修改编号代表新增条目");
            //((MyAdater)listView.getAdapter()).notifyDataSetChanged(); //更新数据,加了HeaderView后不能用这个了
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //返回到上一个Activity
        if (id == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        newdata();
    }

    private class MyAdater extends BaseAdapter {
        @Override
        public int getCount() {
            if (arrayList==null) return 0;
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return arrayList.get(position-1);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final String temp[] = arrayList.get(position);

            TextView b=new TextView(HotPrintText.this);
            b.setText(temp[0]+"   "+temp[2]+" "+temp[3]+" "+temp[4]+"\n"+temp[1]);
            b.setGravity(View.TEXT_ALIGNMENT_TEXT_START);    //左对齐
            b.setTextSize(18);
            b.setTextColor(Color.BLACK);
            b.setBackgroundResource(R.drawable.fanga);
            b.setHint(temp[0]);

            //透明度 取值：0－255
            b.getBackground().setAlpha(160);

            return b;
        }
    }

    private void edit(final String v0, final String v1, final String v2, final String v3, final String v4){

        final View v = LayoutInflater.from(this).inflate(R.layout.hotprinttextedit, null);
        final EditText fornum = v.findViewById(R.id.forno);
        fornum.setText(v0);
        final EditText fordes = v.findViewById(R.id.fordes);
        fordes.setText(v1);
        final RadioButton left = v.findViewById(R.id.forleft);
        if(v4.equals("LEFT")) left.setChecked(true);
        final RadioButton center = v.findViewById(R.id.forcenter);
        if(v4.equals("CENTER")) center.setChecked(true);
        final RadioButton right = v.findViewById(R.id.forright);
        if(v4.equals("RIGHT")) right.setChecked(true);
        final CheckBox XX = v.findViewById(R.id.forXX);
        if(v2.equals("Y")) XX.setChecked(true);
        final CheckBox YY = v.findViewById(R.id.forYY);
        if(v3.equals("Y")) YY.setChecked(true);

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("参数编辑");
        builder.setView(v);
        builder.setPositiveButton("确定 Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(check(fornum.getText().toString())) return;
                String xx="N", yy="N", align="CENTER";
                if(XX.isChecked()) xx="Y";
                if(YY.isChecked()) yy="Y";
                if(left.isChecked()) align="LEFT";
                if(right.isChecked()) align="RIGHT";
                boolean boo = ((MyApp)getApplication()).writetext(fornum.getText().toString(), fordes.getText().toString(), xx, yy, align);
                if(boo) newdata();
            }
        });
        builder.setNeutralButton("删除 Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(check(fornum.getText().toString())) return;
                boolean boo = ((MyApp)getApplication()).writedelete(fornum.getText().toString());
                if(boo) newdata();
            }
        });
        AlertDialog dia = builder.create();
        dia.show();
    }

    private boolean check(final String tem){
        if(tem.isEmpty()){
            Toast.makeText(this, "编号不能为空", Toast.LENGTH_SHORT).show();
            return true;
        }
        try{
            Long.valueOf(tem);
        }catch (Exception e){
            Toast.makeText(this, "编号必须为数字", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

}
