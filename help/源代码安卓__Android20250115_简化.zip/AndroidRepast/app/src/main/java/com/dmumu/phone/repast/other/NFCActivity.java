package com.dmumu.phone.repast.other;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.MifareClassic;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HeaderViewListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.dmumu.phone.repast.MyApp;
import com.dmumu.phone.repast.R;
import java.io.IOException;
import java.util.ArrayList;
// 参考文章：https://juejin.cn/post/7362574547209682979
public class NFCActivity extends AppCompatActivity {

    private NfcAdapter mNfcAdapter;
    private ListView listView ;
    private TextView header,footer;
    private ArrayList<String[]> arrayList=new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hotprinttext);  //共用相同的布局
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Check for available NFC Adapter
        //检测是否有NFC适配器
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (mNfcAdapter == null) Toast.makeText(this, "无权限或当前设备可能不支持；NFC is not available", Toast.LENGTH_LONG).show();
        if(mNfcAdapter!=null && !mNfcAdapter.isEnabled()) {
            Toast.makeText(this, "请在系统设置中先启用NFC功能！", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        for(int k=0; k<16; k++) {
            arrayList.add(new String[]{"第 "+(k+1)+" 扇区","","","",""});
        }

        header = new TextView(getBaseContext());
        header.setGravity(Gravity.CENTER);
        header.setTextSize(16);
        header.setTextColor(Color.BLUE);
        header.setText("\n默认16个扇区，当前密钥(KeyA)："+nfcpassword()+"\n");
        footer = new TextView(getBaseContext());
        footer.setGravity(Gravity.CENTER);
        footer.setTextSize(14);
        footer.setBackgroundResource(R.drawable.nfc);

        listView = findViewById(R.id.tabscroll);
        listView.addHeaderView(header);
        listView.addFooterView(footer);
        listView.setAdapter(new MyAdater());
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                if(arrayList==null) return;
                if(position==0) {password();return;} //header
                if(position==arrayList.size()+1) return; //footer
                ((MyApp)getApplication()).showInputDialog("输入字需要存储的字符串,注意每行(每次最多三行)不要超过16个字节", "自动转换为字节", new Object(){
                    @Override
                    public boolean equals(Object obj) {
                        if(obj!=null && obj.toString().isEmpty()==false) {
                            String s[] = obj.toString().split("\n");
                            for(int k=0; k<s.length; k++) nfc((position-1)*4+k, s[k]);
                        }
                        return super.equals(obj);
                    }
                });
            }
        });
        refresh();

        if(getIntent().getExtras()!=null) {
            String dishnum = getIntent().getExtras().getString("dishnum");
            nfc(4, dishnum);
            finish();
        }
    }

    private void refresh() {
        final HeaderViewListAdapter hAdapter = (HeaderViewListAdapter)listView.getAdapter();
        final MyAdater myadapter = (MyAdater)hAdapter.getWrappedAdapter();
        myadapter.notifyDataSetChanged();
    }

    private void password() {
        ((MyApp)getApplication()).showInputDialog("输入密码(0-9,A-F)", "FFFFFFFFFFFF", new Object(){
            @Override
            public boolean equals(Object obj) {
                if(obj!=null && obj.toString().isEmpty()==false) {
                    nfcpassword(obj.toString());
                    header.setText("\n新密码(KeyA)："+nfcpassword()+"\n");
                }
                return super.equals(obj);
            }
        });
    }

    private class MyAdater extends BaseAdapter {
        @Override
        public int getCount() {
            if (arrayList==null) return 0;
            return arrayList.size();
        }
        @Override
        public Object getItem(int position) {
            return arrayList.get(position-1);
        }
        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final String temp[] = arrayList.get(position);
            final TextView b=new TextView(NFCActivity.this);
            b.setText(temp[0]+"<br><font color=red>"+temp[1]+"</font><br>"+temp[2]+"<br>"+temp[3]+"<br><font color=blue>"+temp[4]+"</font>");
            if(position>0) b.setText(temp[0]+"<br>"+temp[1]+"<br>"+temp[2]+"<br>"+temp[3]+"<br><font color=blue>"+temp[4]+"</font>");
            b.setGravity(View.TEXT_ALIGNMENT_TEXT_START);    //左对齐
            b.setTextSize(18);
            b.setTextColor(Color.BLACK);
            b.setText(Html.fromHtml(b.getText().toString()));
            return b;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //返回到上一个Activity
        if (id == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResume() {
        super.onResume();
        //得到是否检测到ACTION_NDEF_DISCOVERED触发
        //if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction())) {}
        if (NfcAdapter.ACTION_TECH_DISCOVERED.equals(getIntent().getAction())){
            ((MyApp)getApplication()).beep(500);
            processIntent(getIntent());
        }
    }

    //重载Activity类方法处理当新Intent到来事件
    @Override
    public void onNewIntent(Intent intent) {
        // onResume gets called after this to handle the intent
        setIntent(intent);
    }

    /**
     * Parses the NDEF Message from the intent and prints to the TextView
     */
    private void processIntent(Intent intent) {

        // 取出封装在intent中的TAG
        Tag tagFromIntent = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        String msg = "NFC info:";
        for (String tech : tagFromIntent.getTechList()) {
            msg = msg + "\n" + tech ;
        }

        //读取TAG
        MifareClassic mfc = MifareClassic.get(tagFromIntent);
        try {
            String metaInfo = "";
            //Enable I/O operations to the tag from this TagTechnology object.
            mfc.connect();
            int type = mfc.getType();//获取TAG的类型
            int sectorCount = mfc.getSectorCount();//获取TAG中包含的扇区数
            String typeS = "";
            switch (type) {
                case MifareClassic.TYPE_CLASSIC:
                    typeS = "TYPE_CLASSIC";
                    break;
                case MifareClassic.TYPE_PLUS:
                    typeS = "TYPE_PLUS";
                    break;
                case MifareClassic.TYPE_PRO:
                    typeS = "TYPE_PRO";
                    break;
                case MifareClassic.TYPE_UNKNOWN:
                    typeS = "TYPE_UNKNOWN";
                    break;
            }
            metaInfo += "卡片类型：" + typeS + "\n共" + sectorCount + "个扇区\n共" + mfc.getBlockCount() + "个块\n存储空间: " + mfc.getSize() + "B\n";
            header.setText(metaInfo + "\n" + msg);

            for (int j = 0; j < sectorCount; j++) {
                //Authenticate a sector with key A.
                //boolean auth = mfc.authenticateSectorWithKeyA(j, MifareClassic.KEY_DEFAULT);
                boolean auth = mfc.authenticateSectorWithKeyA(j, hexStringToByteArray(nfcpassword()));
                if (auth) {
                    // 读取扇区中的块
                    int bCount = mfc.getBlockCountInSector(j);
                    int bIndex = mfc.sectorToBlock(j);
                    for (int i = 0; i < bCount; i++) {
                        final byte b[] = mfc.readBlock(bIndex);
                        if(arrayList!=null) arrayList.get(j)[i+1] = bytesToHexString(b)+" "+new String(b).trim();
                        bIndex++;
                    }
                }
                else {
                    if(arrayList!=null) arrayList.get(j)[1]="认证失败 authenticator failed";
                }
            }
            refresh();
        }
        catch (Exception e) {
            e.printStackTrace();
            header.setText("请重新刷卡，接触时间可能过短，异常：\n"+e.getMessage());
        }
    }

    /****************************************************************************************************************************/

    // 读写M1卡代码:
    private void nfc(final int block, final String val){
        if (mNfcAdapter == null) {
            Toast.makeText(this, "无权限或当前设备可能不支持；NFC is not available", Toast.LENGTH_LONG).show();
            return;
        }
        final Tag tagFromIntent = getIntent().getParcelableExtra(NfcAdapter.EXTRA_TAG);
        final MifareClassic mfc = MifareClassic.get(tagFromIntent);
        if(mfc==null) return;
        try {
            mfc.connect();
            final boolean auth = mfc.authenticateSectorWithKeyA(block/4, hexStringToByteArray(nfcpassword()));// 验证密码,默认MifareClassic.KEY_DEFAULT
            if (auth) {
                if(val==null) {
                    //String val = new String(mfc.readBlock(4)).trim() ;   // 读取M1卡的第4块即1扇区第0块
                    byte b[] = mfc.readBlock(block);
                    if(arrayList!=null) arrayList.get(block/4)[block % 4] = bytesToHexString(b)+" "+new String(b).trim();
                    refresh();
                }
                else {
                    //final SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                    //final String date = sDateFormat.format(new java.util.Date());
                    mfc.writeBlock(block, val.getBytes());     // 注意不要超过16个字符, 如写M1卡的第4块即1扇区第0块
                    Toast.makeText(this, "写入成功："+val, Toast.LENGTH_SHORT).show();
                    nfc(block, null);
                }
            }
            else{
                Toast.makeText(this, "认证失败", Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "异常：可能卡片不在磁场范围,"+e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            try { mfc.close();} catch (IOException e) {e.printStackTrace();}
        }
    }

    /*---------------------------------------------------  辅助方法  -------------------------------------------------------------*/

    // 把字节用  16 进制表示字节
    private String bytesToHexString(byte[] b) {
        String val = "" ;
        for (byte k : b) {
            String temp = Integer.toHexString(k & 0xFF);
            if(temp.length()==1) temp = "0"+temp ;
            val = val + temp ;
        }
        return val ;
    }

    private byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }

    private String nfcpassword(){
        return  nfcpassword(null);
    }
    private String nfcpassword(String str){
        final SharedPreferences share = getSharedPreferences("val", Context.MODE_PRIVATE);
        if(str==null) {
            return  share.getString("NFCpassword","FFFFFFFFFFFF");
        }
        final SharedPreferences.Editor editor=share.edit();
        editor.putString("NFCpassword", str);
        editor.commit();
        return str;
    }
}