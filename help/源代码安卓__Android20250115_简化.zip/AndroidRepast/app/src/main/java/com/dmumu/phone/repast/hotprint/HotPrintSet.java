package com.dmumu.phone.repast.hotprint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.dmumu.phone.repast.MyApp;
import com.dmumu.phone.repast.R;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Administrator on 2015/1/13.
 */
public class HotPrintSet extends Activity {
    private EditText address, port;
    private SharedPreferences share;
    private Button save,test,scan;
    private Toast mToast;
    private ProgressDialog pro;
    private ByteArrayOutputStream out;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hotprintset);

        //getWindow().setWindowAnimations(R.style.popwin_anim_style); //动画效果
        //requestWindowFeature(Window.FEATURE_NO_TITLE);  //不要标题
        share = getSharedPreferences("val", Context.MODE_PRIVATE);

        address = (EditText)findViewById(R.id.foraddress);
        port = (EditText)findViewById(R.id.forport);
        save = (Button)findViewById(R.id.forsave);
        test = (Button)findViewById(R.id.fortest);
        scan = (Button)findViewById(R.id.forscan);

        address.setText(share.getString("printaddress","192.168.1.222"));
        port.setText(share.getString("printport","9100"));

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (port.getText().toString().isEmpty()) port.setText("9100");
                //保存登陆参数
                SharedPreferences.Editor editor = share.edit();
                editor.putString("printaddress", address.getText().toString());
                editor.putString("printport", port.getText().toString());
                editor.commit();
                mToast.setText("保存成功");
                mToast.show();
                final Intent intent = new Intent(HotPrintSet.this, HotPrintText.class);
                startActivity(intent);
            }
        });

        test.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                out = new ByteArrayOutputStream();
                final HotPrinterCmd hp = new HotPrinterCmd(out);
                try {
                    hp.doubley("这是一个打印测试，如果您看到这段文字。\n","CENTER");
                    hp.doubley("祝贺你！！！\n\n\n","CENTER");
                    hp.CutPaper();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                final Thread th = new Thread(new Runnable() {
                    public void run() {
                        ((MyApp)getApplication()).printbin(out.toByteArray(), null);
                    }
                });
                th.setDaemon(true);
                th.start();
            }
        });

        scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //检查网络
                ConnectivityManager con = (ConnectivityManager)getSystemService(Activity.CONNECTIVITY_SERVICE);
                boolean wifi = con.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isConnectedOrConnecting();
                boolean internet = con.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isConnectedOrConnecting();
                if( wifi==false && internet==false ){
                    Toast.makeText(HotPrintSet.this, "没有网络，请检查网络", Toast.LENGTH_SHORT).show();
                    return ;
                }

                if( wifi==false && internet==true ){
                    Toast.makeText(HotPrintSet.this, "仅支持对WIFI网络环境进行扫描。", Toast.LENGTH_SHORT).show();
                    return ;
                }

                WifiManager wifimanage=(WifiManager)getSystemService(Context.WIFI_SERVICE);
                WifiInfo wifiinfo= wifimanage.getConnectionInfo();
                String ip=intToIp(wifiinfo.getIpAddress());

                port.setText("9100");
                pro= ProgressDialog.show(HotPrintSet.this, "寻找热敏打印机", "正在寻找热敏打印机 ... ", true);
                scan(ip);
            }
        });

        mToast = Toast.makeText(this, "", Toast.LENGTH_SHORT);
        mToast.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL, 0, 0);

    }

    //将获取的int转为真正的ip地址,参考的网上的，修改了下
    private String intToIp(int i)  {
        return (i & 0xFF)+ "." + ((i >> 8 ) & 0xFF) + "." + ((i >> 16 ) & 0xFF) +"."+((i >> 24 ) & 0xFF );
    }

    //进入后台长时不显示时，这个最好关掉
    public void onStop(){
        super.onStop();
        finish();
    }

    private int count = 0;
    //固定大小的池，设定并发线程数不要超过20个
    private ExecutorService Pool = Executors.newFixedThreadPool(20);
    //自动寻找同网段服务器
    private void scan(String ip){

        if(ip.startsWith("127")) return;
        count = 0 ;

        //从255个主机中寻找服务器，估且认为其子网掩码为255.255.255.0
        int flag=ip.lastIndexOf(".");
        ip=ip.substring(0, flag+1);
        Pool = Executors.newFixedThreadPool(20);

        for(int n=1; n<255; n++){
            final String myip = ip + n ;

            //扫描，每一个IP启动一个线程
            Pool.submit(new Runnable() {
                public void run() {

                    runOnUiThread(new Runnable() {
                        public void run() {
                            pro.setTitle("扫描中... "+myip);
                        }
                    });

                    Socket s=null;
                    try {
                        s = new Socket();
                        SocketAddress add = new InetSocketAddress(myip, 9100);
                        s.connect(add, 5000);	//设定超时时间为5秒

                        /**
                         * shutdown调用后，不可以再submit新的task，已经submit的将继续执行
                         * shutdownNow试图停止当前正执行的task，并返回尚未执行的task的list
                         */
                        synchronized (Pool){
                            if(Pool.isShutdown() || Pool.isTerminated()) return;
                            Pool.shutdownNow();
                            final String curip = myip;
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    pro.dismiss();
                                    address.setText(curip);
                                    Toast.makeText(HotPrintSet.this, "恭喜！当前找到可用IP："+curip, Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }

                    catch (Exception e) {
                        //务必采取同步的方式，否则count计数会有错误
                        synchronized (Pool) {
                            count++;
                            if(count==254){
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        pro.dismiss();
                                        Toast.makeText(HotPrintSet.this, "没有找到可用的IP，扫描结束。", Toast.LENGTH_SHORT).show();
                                    }
                                });
                                /* 另一种方法
                                new Handler(PrintCfgActivity.this.getMainLooper()).post(new Runnable() {
                                    public void run() {
                                        pro.dismiss();
                                        Toast.makeText(this, "没有找到可用的IP，扫描结束。", Toast.LENGTH_SHORT).show();
                                    }
                                }); */
                            }
                        }
                    }

                    finally{
                        try {s.close();} catch (IOException e) {}
                    }

                }
            });
        }
    }
}