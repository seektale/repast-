package com.dmumu.phone.repast.showphoto;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.dmumu.phone.repast.MyApp;
import com.dmumu.phone.repast.R;

import java.util.ArrayList;

/**
 * Created by root on 15-1-7.
 */

public class MenuImgSlip extends Activity {
    private ViewFlipper viewFlipper = null;
    private TextView msgtext;
    private ArrayList<String[]> dish;
    private static int flag = 0;       //声明为静态可以使其下次返回时位置不是又从头开始
    private static int fangxiang = 1 ;  //方向
    private float startX;

    private boolean pase = true ;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //全屏
        //requestWindowFeature(Window.FEATURE_NO_TITLE); //无标题
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.sliplayout);

        //屏幕常亮  (在布局文件里面已实现了)
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        msgtext = (TextView) findViewById(R.id.msg);
        msgtext.setText("手指滑动浏览图片,单击屏幕点单");
        String col[] = { "num", "name"};
        dish = ((MyApp)getApplication()).selSQLite(col, " photo = 0 ");

        ImageView one = new ImageView(this);
        ImageView two = new ImageView(this);
        viewFlipper = (ViewFlipper) findViewById(R.id.viewFlipper);
        viewFlipper.addView(one, new ViewPager.LayoutParams());
        viewFlipper.addView(two, new ViewPager.LayoutParams());
        viewFlipper.setPadding(6,0,6,0);
        viewFlipper.setFlipInterval(3000);  //播放间隔时间

        //初始化第一张图
        initOneTwo(one);

        one.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
                play((ImageView)v);
            }
        });
        two.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
                play((ImageView)v);
            }
        });
    }

    private void initOneTwo(ImageView one){
        if(dish!=null && dish.size()>flag){
            Bitmap bitmap = ((MyApp)getApplication()).readimg(dish.get(flag)[0], dish.get(flag)[1]);
            if(bitmap!=null){
                bitmap = comp(bitmap);  //对图片进行等比缩放
                bitmap = MenuImg.bitmapExec(bitmap);    //圆角
                one.setImageBitmap(bitmap);
            }
            text();
        }
    }

    private void play(ImageView who){
        if(dish==null || dish.size()==0 || pase) return;

        flag = flag + fangxiang ;
        if(flag>=dish.size()) flag = 0;
        if(flag<0) flag=dish.size()-1;

        Bitmap bitmap = ((MyApp)getApplication()).readimg(dish.get(flag)[0], dish.get(flag)[1]);
        if(bitmap == null){
            Toast.makeText(MenuImgSlip.this, "未能从本地缓存中读取到图片", Toast.LENGTH_SHORT).show();
            // 得到一个空图片
            bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }

        bitmap = comp(bitmap);  //对图片进行等比缩放
        bitmap = MenuImg.bitmapExec(bitmap);    //圆角

        who.setImageBitmap(bitmap);
        text();
    }

    private void screen(){
        //获取屏幕的亮度
        int value = 0;
        ContentResolver cr = getContentResolver();
        try {
            value = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS);
        } catch (Settings.SettingNotFoundException e) {}
        //设置屏幕亮度
        if(value>0){
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.screenBrightness = 250 / 255f;
            getWindow().setAttributes(params);
        }
    }

    public void onConfigurationChanged(Configuration newConfig){
        super.onConfigurationChanged(newConfig);
        //横竖屏切换时调用
        //AndroidManifest.xml 中配置：android:configChanges"
        if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE){

        }
        else if(newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){

        }

        //如果是在暂停状态下屏幕旋转,则不要更新图片
        if(viewFlipper.isAutoStart() && viewFlipper.isFlipping()){
            return ;
        }
        pase = true;
    }
    //进入后台长时不显示时，这个最好关掉
    public void onStop(){
        super.onStop();
        finish();
    }

    public boolean onKeyDown(int keyCode,KeyEvent event){
        if(keyCode== KeyEvent.KEYCODE_MENU && dish!=null && flag>=0 && flag<dish.size()){
            if(viewFlipper.isAutoStart() && viewFlipper.isFlipping()){
                viewFlipper.setAutoStart(false);
                viewFlipper.stopFlipping();
            }
            //先查询商品信息
            String col[] = { "num", "cla", "name", "price", "unit", "lock" };
            String where = "num='"+dish.get(flag)[0]+"' ";
            ArrayList<String[]> arr= ((MyApp)getApplication()).selSQLite(col, where);
            ((MyApp)getApplication()).amount(this, arr.get(0)).show();
        }
        return super.onKeyDown(keyCode,event);
    }

    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = event.getX();
                break;

            case MotionEvent.ACTION_UP:
                if (dish==null || dish.size()==0) {
                    Toast.makeText(this, "没有缓存图，请先同步", Toast.LENGTH_SHORT).show();
                    break;
                }
                if (event.getX()==startX) {     //单击事件
                    if(flag<0) break;
                    if(viewFlipper.isAutoStart() && viewFlipper.isFlipping()){
                        viewFlipper.setAutoStart(false);
                        viewFlipper.stopFlipping();
                    }

                    //先查询商品信息
                    String col[] = { "num", "cla", "name", "price", "unit", "lock" };
                    String where = "num='"+dish.get(flag)[0]+"' ";
                    ArrayList<String[]> arr= ((MyApp)getApplication()).selSQLite(col, where);
                    ((MyApp)getApplication()).amount(this, arr.get(0)).show();
                    break;
                }
                if (event.getX() > startX) {  // 向右滑动
                    if(pase){
                        pase = false ;
                    }

                    viewFlipper.clearAnimation();
                    viewFlipper.setInAnimation(this, R.anim.in_leftright);
                    viewFlipper.setOutAnimation(this, R.anim.out_leftright);

                    fangxiang = -1 ;
                    if(!viewFlipper.isAutoStart() && !viewFlipper.isFlipping()){
                        viewFlipper.showNext(); // 这一句要保留
                        viewFlipper.setAutoStart(true);
                        viewFlipper.startFlipping();
                    }
                }
                if (event.getX() < startX) { // 向左滑动
                    if(pase){
                        pase = false ;
                    }

                    viewFlipper.clearAnimation();
                    viewFlipper.setInAnimation(this, R.anim.in_rightleft);
                    viewFlipper.setOutAnimation(this, R.anim.out_rightleft);

                    fangxiang = 1 ;
                    if(!viewFlipper.isAutoStart() && !viewFlipper.isFlipping()){
                        viewFlipper.showPrevious();  // 这一句要保留
                        viewFlipper.setAutoStart(true);
                        viewFlipper.startFlipping();
                    }
                }
                break;
        }
        return super.onTouchEvent(event);
    }

    private void text(){
        //显示商品信息
        String col[] = { "num", "cla", "name", "price", "unit", "lock" };
        String where = "num='"+dish.get(flag)[0]+"' ";
        ArrayList<String[]> arr= ((MyApp)getApplication()).selSQLite(col, where);
        if(arr==null){
            msgtext.setText("商品信息不存在，请先进行同步。");
            return ;
        }

        Bundle b=new Bundle();
        b.putString("num",arr.get(0)[0]);
        b.putString("class",arr.get(0)[1]);
        b.putString("name",arr.get(0)[2]);
        b.putString("price",arr.get(0)[3]);
        b.putString("unit",arr.get(0)[4]);
        b.putString("lock",arr.get(0)[5]);

        msgtext.setText(b.getString("name")+"   "+b.getString("price")+"/"+b.getString("unit")+
                "\n编号:"+b.getString("num")+"  分类:"+b.getString("class")+"  锁定:"+
                b.getString("lock")+"  当前:"+(flag+1)+"/"+dish.size());

    }

    //对图片进行等比缩放,如果图片太大，会导致滑动很卡顿
    private Bitmap comp(Bitmap icon) {
        int width = icon.getWidth(), height = icon.getHeight();
        float ws = viewFlipper.getWidth(), hs = viewFlipper.getHeight();
        if(ws==0 || hs==0) {
            ws = 1920 ;  hs = 1080 ;        //按高清分辨率为标准
        }

        if(width > ws || height > hs) {
            float scaleRate = ws/width > hs/height ? hs/height : ws/width;

            Matrix matrix = new Matrix();
            matrix.postScale(scaleRate, scaleRate);    // 得到新的图片
            return  Bitmap.createBitmap(icon, 0, 0, width, height, matrix, true);
         }
        return icon;
    }
}