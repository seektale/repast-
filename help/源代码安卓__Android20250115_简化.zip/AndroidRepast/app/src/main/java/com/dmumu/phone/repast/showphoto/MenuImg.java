package com.dmumu.phone.repast.showphoto;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.dmumu.phone.repast.MainActivity;
import com.dmumu.phone.repast.MyApp;
import com.dmumu.phone.repast.R;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by root on 15-1-4.
 */
public class MenuImg extends Activity implements ViewPager.OnPageChangeListener {

    private PopupWindow menu;
    private TextView des;

    //声明为静态变量可以保证在下次进入时显示上次的图片位置
    public static ArrayList<String[]> dishcla = new ArrayList<>();
    public static int flag=0;
    private boolean justone = true ;
    private static int imgzuan=0; //图片旋转角度
    private Animation an ;
    private ViewPager viewPager;

    //private LinkedList books = new LinkedList(); //栈
    public void onConfigurationChanged(Configuration newConfig){
        super.onConfigurationChanged(newConfig);
    }
    //进入后台长时不显示时，这个最好关掉
    public void onStop(){
        super.onStop();
        if (menu!=null && menu.isShowing()) menu.dismiss();
        finish();
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //全屏
        //requestWindowFeature(Window.FEATURE_NO_TITLE); //无标题
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.fragment_photo);

        //屏幕常亮  (在布局文件里面已实现了,结果无效,只好用下面的一句,作用一样. 但SlipImg.java的布局文件里设置后好像有效)
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        //从上到下的滑出的动画
        an = AnimationUtils.loadAnimation(getBaseContext(), R.anim.menushow2);
        an.setDuration(200);

        viewPager =  findViewById(R.id.forvp);
        viewPager.setAdapter(new MyAdapter());
        viewPager.setOnPageChangeListener(this);
        viewPager.setCurrentItem(0);
        // 设置页与页之间的间距
        viewPager.setPageMargin(10);
        viewPager.setAlpha(0.98f); //稍微有一点透明

        des = (TextView)findViewById(R.id.des);
        des.setTextColor(Color.BLUE);

        Button synimg=(Button)findViewById(R.id.synimg);
        synimg.setAlpha(0.8f); //稍微有一点透明
        synimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MenuImg.this.finish();
            }
        });

        Button zuan=(Button)findViewById(R.id.zuan);
        zuan.setAlpha(0.8f); //稍微有一点透明
        zuan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(dishcla==null || dishcla.size()==0){
                    return ;
                }
                final int k = viewPager.getCurrentItem();
                if(viewPager.findViewById(k) instanceof ImageView == false) return; //只有图片才可以进行旋转, gif和视频均忽略

                Animation an1 = AnimationUtils.loadAnimation(getBaseContext(), R.anim.rotate);
                final ScaleAnimation an2 = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                an2.setDuration(600);

                an1.setAnimationListener(new Animation.AnimationListener() {
                    public void onAnimationStart(Animation animation) {}
                    public void onAnimationEnd(Animation animation) {
                        imgzuan = imgzuan + 90;
                        if (imgzuan >= 360) imgzuan = 0;
                        ImageView vv = ((ImageView) viewPager.findViewById(k));
                        Bitmap temp = ((BitmapDrawable)vv.getDrawable()).getBitmap();
                        temp = bitmapxuan90(temp);
                        ((ImageView) viewPager.findViewById(k)).setImageBitmap(temp);
                        viewPager.findViewById(k).startAnimation(an2);
                    }
                    public void onAnimationRepeat(Animation animation) {}
                });
                an2.setAnimationListener(new Animation.AnimationListener() {
                    public void onAnimationStart(Animation animation) {}
                    public void onAnimationEnd(Animation animation) {
                        viewPager.findViewById(k).clearAnimation();
                        viewPager.getAdapter().notifyDataSetChanged();
                    }
                    public void onAnimationRepeat(Animation animation) {}
                });
                viewPager.findViewById(k).startAnimation(an1);
            }
        });

        Button ok=(Button)findViewById(R.id.ok);
        ok.setAlpha(0.8f); //稍微有一点透明
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dishcla==null){
                    toastshow("没有选择分类，请先选择分类");
                    return ;
                }
                if(dishcla.size()==0){
                    toastshow("当前商品分类下的商品没有可用的图片");
                    return ;
                }
                //先查询商品信息
                String col[] = { "num", "cla", "name", "price", "unit", "lock" };
                String where = "num='"+dishcla.get(viewPager.getCurrentItem())[0]+"' ";
                final ArrayList<String[]> arr= ((MyApp)getApplication()).selSQLite(col, where);
                if(arr==null || arr.size()==0) return; //可能用户清了缓存，要判断一下

                ((MyApp)getApplication()).pre(arr.get(0)[0], 1);
                toastshow(arr.get(0)[2]+" 添加成功！");
            }
        });

        ok.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                //振动
                final Vibrator vib = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
                vib.vibrate(100);

                if(dishcla==null){
                    toastshow("没有选择分类，请先选择分类");
                    return false;
                }

                if(dishcla.size()==0){
                    toastshow("当前商品分类下的商品没有可用的图片");
                    return false;
                }

                //先查询商品信息
                String col[] = { "num", "cla", "name", "price", "unit", "lock" };
                String where = "num='"+dishcla.get(viewPager.getCurrentItem())[0]+"' ";
                ArrayList<String[]> arr= ((MyApp)getApplication()).selSQLite(col, where);
                if(arr==null || arr.size()==0) return false; //可能用户清了缓存，要判断一下

                ((MyApp)getApplication()).amount(v.getContext(),arr.get(0)).show();
                return false;
            }
        });


        /******************************************************************************************************************************/

        final ListView menuView =new ListView(this);
        menu = new PopupWindow(menuView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        /* 这四条可以保证点击其它地方会自动消失 */
        //使其聚焦
        menu.setFocusable(true);
        //设置允许在外点击消失
        menu.setOutsideTouchable(true);
        //刷新状态
        menu.update();
        //点back键和其它地方使其消失，设置了这个才能触发OnDismisslistener，设置其它控件变化等操作
        //menu.setBackgroundDrawable(new BitmapDrawable()); 方法已过时，使用下面的方法
        //menu.setBackgroundDrawable(new BitmapDrawable(Resources.getSystem(),"")); 会报目录错误
        //得到一个空图片
        Bitmap nullbit = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        Drawable front = new BitmapDrawable(null,nullbit);
        menu.setBackgroundDrawable(front);
        menu.setAnimationStyle(R.style.popwin_anim_style);

        //final ArrayList<String[]> arr = mysql.selSQLite(handler);
        menuView.setAdapter(new MyAdater(new ArrayList<String[]>()));
        menuView.setBackgroundColor(Color.WHITE);
        menuView.getBackground().setAlpha(230);
        menuView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {

                //定位到第一张
                if(dishcla!=null && dishcla.size()>0) viewPager.setCurrentItem(0);

                String col[] = { "num", "name"};
                //dishcla = mysql.selSQLite(col, " cla = '"+arr.get(position)[0]+"' and photo = 0 ", handler);
                dishcla = ((MyApp)getApplication()).selSQLite(col, " cla = '"+((TextView)view).getHint().toString()+"' and photo = 0 ");
                menu.dismiss();

                //viewPager.removeAllViewsInLayout();
                viewPager.removeAllViews();
                viewPager.getAdapter().notifyDataSetChanged();
                if(dishcla!=null && dishcla.size()>0){
                    onPageSelected(0);
                }
            }
        });

        final Button b=(Button)findViewById(R.id.cho);
        b.setAlpha(0.8f); //稍微有一点透明
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menuView.setAdapter(new MyAdater(((MyApp)getApplication()).selSQLite("select cla,count(*) from menu where photo=0 group by cla order by num")));
                if(menuView.getAdapter().getCount()>0) {
                    if(!isFinishing()) menu.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0); //显示菜单
                    return;
                }
                toastshow("需同步图片 或 暂无数据："+menuView.getAdapter().getCount());
            }
        });

        /******************************************************************************************************************************/

        //显示菜单 还是图片
        if(dishcla!=null && dishcla.size()!=0 && flag<dishcla.size()) {
            viewPager.setCurrentItem(flag);
            onPageSelected(flag);
        }

        //无法显示菜单，部分手机如红米2会报如下异常, 即在activity未初始化完成并显示之前，菜单是不可能弹出的
        //android.view.WindowManager$BadTokenException: Unable to add window -- token null is not valid; is your activity running?
    }

    @Override
    protected void onResume() {
        super.onResume();
        findViewById(R.id.cho).postDelayed(new Runnable() {
            @Override
            public void run() {
                if(isFinishing()) return; //防止极端情况
                if(dishcla==null || dishcla.size()==0) findViewById(R.id.cho).performClick(); //默认自动点击一下分类，方便用户选择浏览哪一类的图片
            }
        }, 1000); //要等Activity界面绘制结束等个1秒钟后才能弹出菜单，因为菜单是以Activity为基础的，否则报错闪退
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    //在中间显示消息
    private void toastshow(final String str) {
        Toast toast = Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER| Gravity.CENTER, 0, 0);
        toast.show();
    }

    //onResume, onCreate都不是真正visible的时间点，真正的visible时间点是onWindowFocusChanged()函数被执行
    //但我又只想在进来时执行一次就够了,用justone标记
    public void onWindowFocusChanged(boolean hasFocus) {
        if (hasFocus && justone && dishcla.size()==0) {
            //menu.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0); 报异常，原因不明
            justone = false ;
        }
    }

    //菜单的适配器
    private class MyAdater extends BaseAdapter {
        private ArrayList<String[]> arr =new ArrayList<>();
        private MyAdater(ArrayList<String[]> arr){
            if(arr!=null) this.arr=arr;
        }
        @Override
        public int getCount() {
            return arr.size();
        }

        @Override
        public Object getItem(int position) {
            return arr.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView text = new TextView(MenuImg.this);
            text.setText(arr.get(position)[0]+"  ["+arr.get(position)[1]+"张图]"+"  -- "+(position+1)+"/"+arr.size());
            text.setTextColor(Color.BLUE);
            text.setTextSize(20);
            text.setGravity(Gravity.CENTER);
            text.setPadding(0,20,0,20);
            text.setHint(arr.get(position)[0]+""); //不能为数字
            return text;
        }
    }

    public class MyAdapter extends PagerAdapter {
        public int getCount() {
            return dishcla.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            if(dishcla.size()==0){
                return ;
            }
            //container.removeView(arrImage.get(position % arrImage.size()));
            container.removeView((View)object);
        }

        /*
        * 通常情况下，调用notifyDataSetChanged方法会让ViewPager通过Adapter的getItemPosition方法查询一遍所有child view，这种情况下，
        * 所有child view位置均为POSITION_NONE，表示所有的child view都不存在，ViewPager会调用destroyItem方法销毁，并且重新生成，加大系统开销，
        * 并在一些复杂情况下导致逻辑问题。特别是对于只是希望更新child view内容的时候，造成了完全不必要的开销。
        * */
        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        /**
         * 载入图片进去，用当前的position 除以 图片数组长度取余数是关键
         */
        @Override
        public Object instantiateItem(ViewGroup container, int position) {

            if(dishcla.size()==0) return null;

            final int ind = position % dishcla.size();
            final String num = dishcla.get(ind)[0];
            final String name = dishcla.get(ind)[1];
            final String path = getExternalFilesDir(null).getPath()+"/repastdir/"+name+"@"+num;
            final String ft = getFileType(new File(path));
            if(ft.equalsIgnoreCase("jpg") || ft.equalsIgnoreCase("png")) {
                final ImageView iv = getimg(ind);
                iv.setId(position); //标记ID
                addchange(iv, num, name, true);
                container.addView(iv, 0);
                return iv;
            }
            else if(ft.equalsIgnoreCase("gif")){
                final WebView wv = getweb(path);
                wv.setId(position); //标记ID
                addchange(wv, num, name, true);
                container.addView(wv, 0);
                return wv;
            }
            else {
                final TextView tv = new TextView(MenuImg.this);
                tv.setText("当前数据无法识别\n\n文件不存在 或 不是有效的 jpg、png、gif 格式\n\n点击或长按可以加载一个网络资源,下次预览时生效");
                tv.setGravity(Gravity.CENTER);
                addchange(tv, num, name, false);
                container.addView(tv, 0);
                return tv;
            }

            //final Intent intent = new Intent(MenuImg.this, VideoActivity.class);
            //intent.putExtra("num", num);
            //intent.putExtra("name", name);
            //startActivity(intent);

            //container.addView(arrImage.get(position % arrImage.size()), 0);
            //return arrImage.get(position % arrImage.size());
        }
        private void addchange(final View v, final String num, final String name, boolean boo){
            v.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    ((MyApp)getApplication()).NetPhoto(num, name, new Object(){
                        public boolean equals(final Object obj){
                            if(obj!=null) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(MenuImg.this, obj.toString(), Toast.LENGTH_SHORT).show(); //显示错误信息
                                    }
                                });
                                return super.equals(obj);
                            }
                            return super.equals(obj);
                        }
                    });
                    return false;
                }
            });
            if(boo) return;
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((MyApp)getApplication()).NetPhoto(num, name, new Object(){
                        public boolean equals(final Object obj){
                            if(obj!=null) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(MenuImg.this, obj.toString(), Toast.LENGTH_SHORT).show(); //显示错误信息
                                    }
                                });
                                return super.equals(obj);
                            }
                            return super.equals(obj);
                        }
                    });
                }
            });
        }

        private ImageView getimg(int ind){

            final String num = dishcla.get(ind)[0];
            final String name = dishcla.get(ind)[1];

            Bitmap b = ((MyApp)getApplication()).readimg(num, name);
            if (b == null) {
                //得到一个空图片
                b = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }
            b = comp(b);
            b = bitmapExec(b);   // 再圆角

            /* //缓存处理  实际测试表明,非常容易出现异常:trying to use a recycled bitmap android.graphics.Bitmap@42d4ddf8
            if(!books.contains(ind)){
                books.offerFirst(ind);  //将字符串元素添加到队列的头(相当于栈的顶部)
                if(books.size()>3) {
                    Integer temp = (Integer)books.pollLast();    //访问、并删除队列的最后一个元素
                }
            }*/

            //缓存之后再旋转
            b = bitmapxuan(b);   // 旋转

            final ImageView iv = new ImageView(MenuImg.this);
            iv.setImageBitmap(b);
            return iv ;
        }

        private WebView getweb(final String path) {

            final WebView web=new WebView(MenuImg.this);

            //声明WebSettings子类
            WebSettings webSettings = web.getSettings();

            //如果访问的页面中要与Javascript交互，则webview必须设置支持Javascript
            webSettings.setJavaScriptEnabled(true);
            // 设置允许JS弹窗
            webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

            //设置自适应屏幕，两者合用
            webSettings.setUseWideViewPort(true); //将图片调整到适合webview的大小
            webSettings.setLoadWithOverviewMode(true); // 缩放至屏幕的大小

            //缩放操作
            webSettings.setSupportZoom(true); //支持缩放，默认为true。是下面那个的前提。
            webSettings.setBuiltInZoomControls(true); //设置内置的缩放控件。若为false，则该WebView不可缩放
            webSettings.setDisplayZoomControls(false); //隐藏原生的缩放控件

            //允许对文件操作
            webSettings.setAllowUniversalAccessFromFileURLs(true);
            webSettings.setAllowFileAccess(true);
            webSettings.setAllowFileAccessFromFileURLs(true);

            //其他细节操作
            webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK); //关闭webview中缓存
            webSettings.setAllowFileAccess(true); //设置可以访问文件
            webSettings.setLoadsImagesAutomatically(true); //支持自动加载图片
            webSettings.setDefaultTextEncodingName("utf-8");//设置编码格式

            webSettings.setAppCacheEnabled(true);//是否使用缓存
            webSettings.setDomStorageEnabled(true);//DOM Storage

            web.setBackgroundColor(Color.TRANSPARENT); //设置WebView背景为透明
            web.loadUrl("file:///android_asset/errpage.html"); //加载本地网页
            web.setWebChromeClient(new WebChromeClient()); //alert的支持
            web.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    web.loadUrl("javascript:showimg('file://"+path+"')"); //触发图片显示, file://作为前辍不加好像也行
                }
            });
            return web;
        }
    }

    public void onPageScrollStateChanged(int arg0) {}
    public void onPageScrolled(int arg0, float arg1, int arg2) {}
    public void onPageSelected(int index) {
        //当前选中页, 显示商品信息
        if(index<0 || index>dishcla.size()-1) return;
        flag = index ;

        final String num = dishcla.get(index)[0];
        final String col[] = { "num", "cla", "name", "price", "unit", "lock" };
        final String where = "num='"+num+"' ";
        final ArrayList<String[]> arr= ((MyApp)getApplication()).selSQLite(col, where);

        if(arr == null || arr.size()==0) {
            des.setText("商品信息不存在，请先同步商品。");
            return ;
        }

        final Bundle b=new Bundle();
        b.putString("num",arr.get(0)[0]);
        b.putString("class",arr.get(0)[1]);
        b.putString("name",arr.get(0)[2]);
        b.putString("price",arr.get(0)[3]);
        b.putString("unit",arr.get(0)[4]);
        b.putString("lock",arr.get(0)[5]);
        des.setText(b.getString("name")+"   "+b.getString("price")+"/"+b.getString("unit")+
                "\n编号:"+b.getString("num")+"  分类:"+b.getString("class")+"  锁定:"+b.getString("lock")+"  当前:"+(index+1)+"/"+dishcla.size());

        if(an != null) des.startAnimation(an);

        if(index>0 && index == dishcla.size()-1){
            Toast.makeText(this, "这是最后一张图片了! The last", Toast.LENGTH_SHORT).show();
        }
    }

    //对图片进行等比缩放,如果图片太大，会导致滑动很卡顿
    private Bitmap comp(Bitmap icon) {
        int width = icon.getWidth(), height = icon.getHeight();
        float ws = viewPager.getWidth(), hs = viewPager.getHeight();
        if(ws==0 || hs==0) {
            ws = 1920 ;  hs = 1080 ;        //按高清分辨率为标准
        }

        if(width > ws || height > hs) {
            float scaleRate = ws/width > hs/height ? hs/height : ws/width;

            Matrix matrix = new Matrix();
            matrix.postScale(scaleRate, scaleRate);    // 得到新的图片

            return  Bitmap.createBitmap(icon, 0, 0, width, height, matrix, true);
        }
        return icon;
    }

    //得到一个圆角图片
    public static Bitmap bitmapExec(Bitmap bitmap){
        try {
            Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(output);
            Paint paint = new Paint();
            Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
            RectF rectF = new RectF(new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight()));
            float roundPx = 14;
            paint.setAntiAlias(true);
            canvas.drawARGB(0, 0, 0, 0);
            paint.setColor(Color.BLACK);
            canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
            canvas.drawBitmap(bitmap, src, rect, paint);
            return output;
        }
        catch (Exception e){
            Log.i("FragmentD","处理圆角图片失败");
            return bitmap;
        }
    }

    //图片旋转 X 度
    private Bitmap bitmapxuan(Bitmap bitmap){
        //不旋转则直接返回
        if (imgzuan == 0) return bitmap;

        Matrix matrix = new Matrix();
        matrix.postRotate(imgzuan);

        Bitmap resizeBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        return resizeBitmap;
    }

    //图片旋转 90 度
    private Bitmap bitmapxuan90(Bitmap bitmap){
        Matrix matrix = new Matrix();
        matrix.postRotate(90);
        Bitmap resizeBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        return resizeBitmap;
    }

    //文件类型判断
    private String getFileType(final File f) {

        String contentType = "";
        try {

            final InputStream is = new FileInputStream(f);
            byte[] buffer = new byte[8];
            is.read(buffer, 0, 8);
            is.close();

            if (buffer[0] == (byte)0xFF && buffer[1] == (byte)0xD8 && buffer[2] == (byte)0xFF) {
                contentType = "image/jpeg";
                return "jpg";
            }
            else if (buffer[0] == (byte)0x89 && buffer[1] == (byte)0x50 && buffer[2] == (byte)0x4E && buffer[3] == (byte)0x47) {
                contentType = "image/png";
                return "png";
            }
            else if (buffer[0] == (byte)0x47 && buffer[1] == (byte)0x49 && buffer[2] == (byte)0x46 && buffer[3] == (byte)0x38) {
                contentType = "image/gif";
                return "gif";
            }

            else if (buffer[0] == (byte)0x25 && buffer[1] == (byte)0x50 && buffer[2] == (byte)0x44 && buffer[3] == (byte)0x46 && buffer[4] == (byte)0x2D && buffer[5] == (byte)0x31 && buffer[6] == (byte)0x2E) {
                return "pdf";
            }

            else if (buffer[0] == (byte)0x57 && buffer[1] == (byte)0x41 && buffer[2] == (byte)0x56 && buffer[3] == (byte)0x45) {
                return "wav";
            }
            else if (buffer[0] == (byte)0x00 && buffer[1] == (byte)0x00 && buffer[2] == (byte)0x01 && buffer[3] == (byte)0xBA) {
                return "mpg";
            }
            else if (buffer[0] == (byte)0x00 && buffer[1] == (byte)0x00 && buffer[2] == (byte)0x01 && buffer[3] == (byte)0xB3) {
                return "mpg";
            }
            else if (buffer[0] == (byte)0x00 && buffer[1] == (byte)0x00 && buffer[2] == (byte)0x00 && buffer[3] == (byte)0x20 && buffer[4] == (byte)0x66 && buffer[5] == (byte)0x74 && buffer[6] == (byte)0x79 && buffer[7] == (byte)0x70) {
                return "mp4"; //0x00, 0x00, 0x00, 0x20, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6F, 0x6D
            }
        }
        catch (IOException ex){ex.printStackTrace();}
        //contentType = URLConnection.guessContentTypeFromStream(is);
        return contentType;
    }
}
