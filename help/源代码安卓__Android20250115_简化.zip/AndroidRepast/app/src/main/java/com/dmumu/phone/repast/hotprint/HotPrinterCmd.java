package com.dmumu.phone.repast.hotprint;

/**
 * Created by Administrator on 2015/7/20.
 */
import java.io.ByteArrayOutputStream;

public class HotPrinterCmd {
    private ByteArrayOutputStream out;
    public HotPrinterCmd(ByteArrayOutputStream out){
        this.out = out;
    }
    protected final String LEFT = "LEFT";
    protected final String CENTER = "CENTER";
    protected final String RIGHT = "RIGHT";
    public static final byte HT = 0x9;
    public static final byte LF = 0x0A;
    public static final byte CR = 0x0D;
    public static final byte ESC = 0x1B;
    public static final byte DLE = 0x10;
    public static final byte GS = 0x1D;
    public static final byte FS = 0x1C;
    public static final byte STX = 0x02;
    public static final byte US = 0x1F;
    public static final byte CAN = 0x18;
    public static final byte CLR = 0x0C;
    public static final byte EOT = 0x04;

    /* 初始化打印机 */
    public static final byte[] ESC_INIT = new byte[] {ESC, '@'};
    /* 设置标准模式 */
    public static final byte[] ESC_STANDARD = new byte[] {ESC, 'S'};
    /* 设置汉字打印模式 */
    public static final byte[] ESC_CN_FONT = new byte[] {FS, '&'};
    /* 选择字符集 */
    public static final byte[] ESC_SELECT_CHARACTER = new byte[] {ESC, 'R', 9};
    /* 设置用户自定义汉字字体 焗7118 */
    public static final byte[] ESC_FS_2 = new byte[] {FS, 0x32, 0x71, 0x18};
    /* 取消用户自定义字体 */
    public static final byte[] ESC_CANCEL_DEFINE_FONT = new byte[]{ESC, '%', 0};
    /* 打开钱箱指令 */
    public static final byte[] ESC_OPEN_DRAWER = new byte[]{ESC, 'p', 0x00, 0x10, (byte) 0xff};
    /* 切纸指令GS V m
    * m  0,48 Executes a full cut(cuts the paper completely)
    *    1,49 Excutes a partilal cut(one point left uncut)
    */
    public static final byte[] POS_CUT_MODE_FULL = new byte[]{GS, 'V', 0x00};
    public static final byte[] POS_CUT_MODE_PARTIAL = new byte[]{GS, 'V', 0x01};

    /* 西文字符 （半宽）字体A (6 ×12)，汉字字符 （全宽）字体A （12×12） */
    public static final byte[] ESC_FONT_A = new byte[]{ESC, '!', 0};
    /* 西文字符 （半宽）字体B (8×16)，汉字字符 （全宽）字体B （16×16） */
    public static final byte[] ESC_FONT_B = new byte[]{ESC, '!', 1};
    /* 12*24   0/48*/
    public static final byte[] ESC_FONTA= new byte[]{ESC, 'M', 0};
    /* 9*17    1/49*/
    public static final byte[] ESC_FONTB= new byte[]{ESC, 'M', 1};

    /* 默认颜色字体指令 */
    public static final byte[] ESC_FONT_COLOR_DEFAULT = new byte[] {ESC, 'r', 0x00};
    /* 标准大小 */
    public static final byte[] FS_FONT_ALIGN = new byte[]{FS, 0x21, 1, ESC, 0x21, 1};
    /* 横向放大一倍 */
    public static final byte[] FS_FONT_ALIGN_DOUBLE = new byte[]{FS, 0x21, 4, ESC, 0x21, 4};
    /* 纵向放大一倍 */
    public static final byte[] FS_FONT_VERTICAL_DOUBLE = new byte[]{FS, 0x21, 8, ESC, 0x21, 8, GS, '!', 0x01};
    /* 横向纵向都放大一倍 */
    public static final byte[] FS_FONT_DOUBLE = new byte[]{FS, 0x21, 12, ESC, 0x21, 48};
    /* 靠左打印命令 */
    public static final byte[] ESC_ALIGN_LEFT = new byte[]{ESC,'a', 0x00};
    /* 居中打印命令 */
    public static final byte[] ESC_ALIGN_CENTER = new byte[]{ESC,'a', 0x01};
    /* 靠右打印命令 */
    public static final byte[] ESC_ALIGN_RIGHT = new byte[]{ESC,'a', 0x02};
    /* 字体加粗 */
    public static final byte[] ESC_SETTING_BOLD = new byte[]{ESC, 0x45, 1};
    /* 取消字体加粗 */
    public static final byte[] ESC_CANCEL_BOLD = new byte[]{ESC, 0x45, 0};

    //DLE EOT n 实时状态传送
    //如果返回结果为22
    /**
     * 、DLE EOT n 实时状态传送
     [格式] ASCII码 DLE EOT n
     十六进制码 10 04 n
     十进制码 16 4 n
     [范围] 1 ≤ n ≤ 4
     [描述] 根据下列参数，实时传送打印机状态，参数 n 用来指定所要传送的打印机状态：
     n = 1：传送打印机状态
     n = 2：传送脱机状态
     n = 3：传送错误状态
     n = 4：传送纸传感器状态
     [注释] 打印机收到该命令后立即返回相关状态
     该命令尽量不要插在2个或更多字节的命令序列中。
     即使打印机被ESC =(选择外设)命令设置为禁止，该命令依然有效。
     打印机传送当前状态，每一状态用1个字节数据表示。
     打印机传送状态时并不确认主机是否收到。
     打印机收到该命令立即执行。
     该命令只对串口打印机有效。打印机在任何状态下收到该命令都立即执行。
     */
    public static final byte[] PRINT_STATE_DLE_EOT = new byte[] {DLE, EOT,0x01};
    /*
	水平制表位设置ESC  D  d1～dn NUL
	格式：ASCII： ESC D  d1 ～dn  NUL
	十进 制： 27  68  d1 ～dn  00
	十六进制：1B  44  d1  ～dn  00

	说明：（ 1）d=1 ～255，n=1～32
	水平制表位设置为从打印区行首起的“d*字符宽度” ；
	在水平制表位设置后更改了字符宽度，已设置的水平制表位不变；
	当用 ESC D d1 ～dn  NUL 设置了水平制表位后，已设置的水平制表位取消；
	水平制表位设置为d=8，执行HT  命令后将下一个打印位置设置为第9 列；
	最多可以设置 32个水平制表位，如果设置多于32 个，在多余制表位的数据被认为是普通数据；
	所有水平制表位可用 ESC D NUL 命令予以取消；
	打印机上电或复位时，水平制表位被设置为 8个字符（初始状态所选的字符）
    */
    /*//制表符，相当于按Tab键,2014-10-09放弃下面的代码，仅用于学习之用，因为mysql数据库能做到下面的功能需求
    public void Tab(String dishname,String price,String num,String unit,String precent,String total) throws Exception{
    	byte k=18;
    	out.write(FS_FONT_VERTICAL_DOUBLE);
    	out.write(dishname.getBytes("gbk"));

    	out.write(new byte[]{ESC,'D',(byte)(k+7-price.length()),0});	//更改水平制表参数，默认为8
    	out.write(new byte[]{HT});				//执行水平制表动作
    	out.write(price.getBytes("gbk"));

    	out.write(new byte[]{ESC,'D',(byte)(k+9+4-num.length()),0});
    	out.write(new byte[]{HT});
    	out.write((num+unit).getBytes("gbk"));

    	out.write(new byte[]{ESC,'D',(byte)(k+17),0});
    	out.write(new byte[]{HT});
    	if(!precent.equals("1")) out.write(precent.getBytes("gbk"));

    	out.write(new byte[]{ESC,'D',(byte)(k+20+7-total.length()),0});
    	out.write(new byte[]{HT});
    	out.write(total.getBytes("gbk"));

    	out.write(new byte[]{ESC,'D',0});		//取消设定的水平制表位
    	out.write(new byte[]{LF});				//打印并走纸一行，相当于"\n"
    }
    */
    /**
     * 双倍大小字体
     * @param str
     */
    public void doubleSizePrinter(String str) throws Exception{
        doubleSizePrinter(str, "LEFT");
    }
    public void doubleSizePrinter(String str, String align) throws Exception{
        if(CENTER.equals(align)){
            out.write(ESC_ALIGN_CENTER);
        }else if(RIGHT.equals(align)){
            out.write(ESC_ALIGN_RIGHT);
        }else{
            out.write(ESC_ALIGN_LEFT);
        }
        out.write(FS_FONT_DOUBLE);
        out.write(str.getBytes("gbk"));
        out.write(new byte[]{LF});
    }
    /**
     * 标准字体打印一行
     * str 需打印的字符串
     * align 打印的位置 LEFT/CENTER/RIGHT 其他为默认居左打印
     */
    public void standardPrinterLine(String str) throws Exception{
        standardPrinterLine(str, "LEFT");
    }
    public void standardPrinterLine(String str, String align) throws Exception{
        if(CENTER.equals(align)){
            out.write(ESC_ALIGN_CENTER);	//居中
        }else if(RIGHT.equals(align)){
            out.write(ESC_ALIGN_RIGHT);
        }else{
            out.write(ESC_ALIGN_LEFT);
        }
        out.write(FS_FONT_ALIGN);		//标准字大小
        out.write(ESC_CN_FONT);			//中文模式

        out.write(str.getBytes("gbk"));	//一定要注意编码，gbk,gb2312均可
        out.write(new byte[]{LF});		//结束标志
    }

    /**
     * 双倍宽字体按行打印
     * @param str
     * @param align
     */
    public void doublex(String str, String align) throws Exception{
        if(CENTER.equals(align)){
            out.write(ESC_ALIGN_CENTER);
        }else if(RIGHT.equals(align)){
            out.write(ESC_ALIGN_RIGHT);
        }else{
            out.write(ESC_ALIGN_LEFT);
        }
        out.write(FS_FONT_ALIGN_DOUBLE);
        out.write(str.getBytes("gbk"));
        out.write(new byte[]{LF});
    }

    /**
     * 双倍高字体按行打印
     * @param str
     * @param align
     */
    public void doubley(String str, String align) throws Exception{
        if(CENTER.equals(align)){
            out.write(ESC_ALIGN_CENTER);
        }else if(RIGHT.equals(align)){
            out.write(ESC_ALIGN_RIGHT);
        }else{
            out.write(ESC_ALIGN_LEFT);
        }
        out.write(FS_FONT_VERTICAL_DOUBLE);
        out.write(str.getBytes("gbk"));
        out.write(new byte[]{LF});
    }
    //打开钱箱
    public void openDrawer() throws Exception{
        out.write(ESC_OPEN_DRAWER);
        out.flush();
    }

    //复位,清除打印缓冲区的数据,清除各项命令设置（加重，双击，下划线，特定大小，相反打印等）不清除接收缓冲区
    public void init() throws Exception{
        out.write(new byte[] {ESC, '@'});
    }

    /**切纸命令*/
    public void CutPaper() throws Exception{
        out.write(new byte[]{ESC,'d',3});		    //打印并走纸n行
        byte [] cut = new byte[]{'\n',27,109};	//ESC , 105|109	全切和半切
        out.write(cut);
        out.flush();

		/*
		//另一个切纸命令
		byte [] buffer = new byte[5];
		buffer[0]='\n';//命令必须是单行
		buffer[1]=29;
		buffer[2]=86;
		buffer[3]=66;
		buffer[4]=1;
		*/
    }

    public String getcode() {    //获取条型码

        byte b[]= new byte[5];
        int count=0;

        //条码打印	GS  k  n  m  d1～dn
        try{
            out.write(new byte[]{ESC,'a', 0x01});
            out.write(new byte[]{GS,'H',0});
            out.write(new byte[]{GS,'h',100});
            out.write(new byte[]{GS,'w',4});
            out.write(new byte[]{GS,'k',69,5});

            //产生五个随机数
            while (count<5){
                boolean flag=true;
                while (flag){
                    int x = (int) (Math.random() * 100) ;
                    if( (x>=48 && x<=57) || (x>=65 && x<=90) || x==32 || x==36 || x==37 || x==43 || x==45 || x==46 || x==47 ){
                        out.write(new byte[]{(byte)x});
                        b[count]=(byte)x;
                        flag = false ;
                    }
                }
                count++;
            }

        }catch (Exception e){}
        return new String(b);
    }
}