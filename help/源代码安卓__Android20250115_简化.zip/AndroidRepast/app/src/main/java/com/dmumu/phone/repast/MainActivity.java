package com.dmumu.phone.repast;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.MifareClassic;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.internal.BottomNavigationMenuView;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListPopupWindow;
import android.widget.Toast;
import com.dmumu.phone.repast.hotprint.HotPrintSet;
import com.dmumu.phone.repast.other.AboutActivity;
import com.dmumu.phone.repast.other.NFCActivity;
import com.dmumu.phone.repast.showphoto.MenuImg;
import com.dmumu.phone.repast.showphoto.MenuImgSlip;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicLong;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import static java.security.AccessController.getContext;

public class MainActivity extends AppCompatActivity {

    private ProgressDialog pro;
    private SharedPreferences share;
    private ViewPager mainActivityViewPager;
    private FragmentA fragment1;
    private FragmentB fragment2;
    private FragmentC fragment3;
    private NfcAdapter mNfcAdapter;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_place:
                    if(mainActivityViewPager.getCurrentItem()==0) { //再次点击显示区域菜单
                        fragment1.getarea(); //显示区域选择菜单
                        return true;
                    }
                    mainActivityViewPager.setCurrentItem(0);
                    fragment1.refreshDesk(); //刷新数据
                    return true;
                case R.id.navigation_history:
                    mainActivityViewPager.setCurrentItem(1);
                    fragment2.handler.sendEmptyMessage(4); //刷新已点商品
                    return true;
                case R.id.navigation_wall:
                    mainActivityViewPager.setCurrentItem(2);
                    menuVerCheck(); //检查菜谱是否有新版本
                    return true;
                case R.id.navigation_mile:
                    //mainActivityViewPager.setCurrentItem(3);
                    final Intent intent = new Intent(MainActivity.this, MenuImg.class);
                    startActivity(intent);
                    return true;
            }
            return false;
        }
    };

    //去除动画效果
    @SuppressLint("RestrictedApi")
    public static void disableShiftMode(BottomNavigationView view) {

        //获取子View BottomNavigationMenuView的对象
        final BottomNavigationMenuView menuView = (BottomNavigationMenuView) view.getChildAt(0);
        try {
            //设置私有成员变量mShiftingMode可以修改
            Field shiftingMode = menuView.getClass().getDeclaredField("mShiftingMode");
            shiftingMode.setAccessible(true);
            shiftingMode.setBoolean(menuView, false);
            shiftingMode.setAccessible(false);
            for (int i = 0; i < menuView.getChildCount(); i++) {
                BottomNavigationItemView item = (BottomNavigationItemView) menuView.getChildAt(i);
                //去除shift效果
                item.setShiftingMode(false);
                item.setChecked(item.getItemData().isChecked());
            }
        }
        catch (NoSuchFieldException e) {
            Log.e("BNVHelper", "没有mShiftingMode这个成员变量", e);
        }
        catch (IllegalAccessException e) {
            Log.e("BNVHelper", "无法修改mShiftingMode的值", e);
        }
    }

    public void onConfigurationChanged(Configuration newConfig){
        super.onConfigurationChanged(newConfig);
        //横竖屏切换时调用
        //AndroidManifest.xml 中配置：android:configChanges"
    }

    //只运行一次
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //actionBar浮动起来，在上一层，这里不要这么做，否则台号在里层，不方便操作
        supportRequestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY);

        //<!-- 防止手机休眠,如在同步更新菜单时间太长，应该阻止休眠发生 -->
        //要加在setContentView(R.layout.main)之前,已证实有效果,但不保证所有手机有效果
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);
        share = getSharedPreferences("val", Context.MODE_PRIVATE);

        int showimg = share.getInt("defaultimg",1);
        if( showimg > 2 ) {
            final Bitmap bitmap = ((MyApp)getApplication()).readimg("99999999", "背景");
            if(bitmap==null) showimg=1; //图片没有了就还原成默认的背景
            else findViewById(android.R.id.content).setBackground(new BitmapDrawable(getResources(), bitmap)); //设置自定义背景
        }
        if(showimg==1) findViewById(android.R.id.content).setBackgroundResource(R.drawable.bg); //设置默认背景
        if(showimg==2) findViewById(android.R.id.content).setBackgroundResource(R.drawable.tudish);

        // 实现始终显示overflow菜单
        try {
            ViewConfiguration config = ViewConfiguration.get(this);
            Field menuKeyField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
            if(menuKeyField != null) {
                menuKeyField.setAccessible(true);
                menuKeyField.setBoolean(config, false);
            }
        } catch (Exception ex) {}

        final BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        disableShiftMode(navigation);

        //软件启动时，初始化登陆参数为本地保存的值，否则为默认值
        final SharedPreferences.Editor editor=share.edit();
        if(share.contains("account")==false) editor.putString("account", "admin"); //不要用root,防止陌生人用root账号搞其它事情
        if(share.contains("password")==false)editor.putString("password", "");
        if(share.contains("address")==false) editor.putString("address", "repast.dmumu.com");
        if(share.contains("port")==false)editor.putString("port", "3306");
        if(share.contains("dbname")==false) editor.putString("dbname", "repast");
        editor.commit();

        //下面的是关键，它让菜单的三个点一直显示，如果不加,则有物理menu按键的手机将不显示
        try{
            ViewConfiguration mconfig = ViewConfiguration.get(this);
            Field menukeyField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
            if(menukeyField != null) {
                menukeyField.setAccessible(true);
                menukeyField.setBoolean(mconfig,false);
            }
        }
        catch (Exception e){}

        try {
            //jar驱动放在项目的bins目录下即可
            Class.forName("com.mysql.jdbc.Driver");
            Log.i("MainActivity", "加载数据库驱动ok");
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
            Log.i("MainActivity", "加载数据库驱动异常");
        }

        //如果程序又被onCreate()说明是因为内存不足导致Activity被回收，但回收也使的很多变量变成了null,继续进行会因为空指针而闪退
        //解决方法就是结束当前的Activity,并重新启动这个Activity
        if(savedInstanceState != null){
            Intent intent = getIntent();
            finish();
            startActivity(intent);
            return ;
        }

        /*
         * 将三个页面加入其中
         */
        final ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        final List<Fragment> listFragment = getSupportFragmentManager().getFragments();
        if(listFragment.isEmpty()) {
            fragment1 = new FragmentA();
            fragment2 = new FragmentB();
            fragment3 = new FragmentC();
            adapter.addFragment(fragment1);
            adapter.addFragment(fragment2);
            adapter.addFragment(fragment3);
        }
        else {
            fragment1 = (FragmentA) listFragment.get(0);
            fragment2 = (FragmentB) listFragment.get(1);
            fragment3 = (FragmentC) listFragment.get(2);
            adapter.addFragment(listFragment.get(0));
            adapter.addFragment(listFragment.get(1));
            adapter.addFragment(listFragment.get(2));
        }
        mainActivityViewPager = findViewById(R.id.pager);
        mainActivityViewPager.setAdapter(adapter);
        mainActivityViewPager.setOffscreenPageLimit(4); //缓存当前界面每一侧的界面数
        mainActivityViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}
            @Override
            public void onPageSelected(int position) {
                invalidateOptionsMenu(); //更新对应fragment的菜单
                if(position==0) updateTitleStatus(true);
                if(position==1 || position==2) updateTitleStatus(false);
            }
            @Override
            public void onPageScrollStateChanged(int state) {}
        });

        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
    }

    //最上面的时间栏的显示和隐藏
    private void updateFullscreenStatus(Boolean bUseFullscreen){
        if(bUseFullscreen){
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        }
        else{
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }
    //最上面的标题栏的显示和隐藏
    private void updateTitleStatus(Boolean boo){
        if(boo){
            //从上到下的动画
            AnimationSet animationSet = new AnimationSet(true);
            TranslateAnimation translateAnimation = new TranslateAnimation
                    (Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,-1f, Animation.RELATIVE_TO_SELF,0f);
            translateAnimation.setDuration(400);
            animationSet.addAnimation(translateAnimation);
            getWindow().findViewById(R.id.action_bar_container).startAnimation(animationSet);
            getWindow().findViewById(R.id.action_bar_container).setVisibility(View.VISIBLE);
            return;
        }
        if(getWindow().findViewById(R.id.action_bar_container).isShown()==false)  return;
        AnimationSet animationSet = new AnimationSet(true);
        TranslateAnimation translateAnimation = new TranslateAnimation
                (Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,-1f);
        translateAnimation.setDuration(400);
        animationSet.addAnimation(translateAnimation);
        getWindow().findViewById(R.id.action_bar_container).startAnimation(animationSet);
        getWindow().findViewById(R.id.action_bar_container).setVisibility(View.GONE);
    }

    //onSaveInstanceState是在OnStop之前执行，这里要标记一下、以便在onCreate()中识别
    public void onSaveInstanceState(Bundle outState){
        outState.putBoolean("flag",true);
        super.onSaveInstanceState(outState);
    }
    //onRestoreInstanceState在OnStart后执行
    public void onRestoreInstanceState(Bundle outState){
        super.onRestoreInstanceState(outState);
    }
    //程序进入后台后，如果内存不足，资源会被回收，再次回到前台时，很多变量会变为null，如:mSectionsPagerAdapter.AA，程序会闪退
    //谷歌有保存状态的方法，但改程序很烦，折中方案是在程序进入后台时直接结束程序，但后果是每次进入程序都要进行登陆操作

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==111) { //读取本地文本商品菜单
            //获取URI
            final Uri uri = data.getData();  //uri.getPath();
            if(uri==null) return;
            SynLocalMenu(uri);
            return;
        }

        if (data==null) return;
        if (resultCode!=1) return;
        String val = data.getStringExtra("username"); //登陆成功后的返回值
        //if (val!=null) setTitle(mysql.account+"@"+val);  //标题栏更新
        //int ver = data.getIntExtra("menuversion",0);
        if(val!=null) setTitle(share.getString("account","")+"@"+val);  //标题栏更新
    }
    private void SynLocalMenu(final Uri uri){
        pro= ProgressDialog.show(this, "消息", "正在进行本地同步 ... ", true);
        final Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                final AtomicLong count = new AtomicLong(0);
                try {
                    //获取输入流
                    final InputStream is = getApplication().getContentResolver().openInputStream(uri);
                    //创建用于字符输入流中读取文本的bufferReader对象
                    final BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String line;
                    ((MyApp)getApplication()).addmenu(null); //先清空
                    while((line = br.readLine()) != null) {
                        line = line.replace("\t"," "); //制表符变空格
                        while(line.contains("  ")){line=line.replace("  "," ");} //多个空格变一个空格
                        final boolean boo = ((MyApp)getApplication()).addmenu(line);
                        if(boo) {
                            count.incrementAndGet();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    pro.setTitle("同步成功计数："+count.get());
                                }
                            });
                        } else break;
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            final AlertDialog.Builder dialog=new AlertDialog.Builder(MainActivity.this);
                            dialog.setTitle("本地同步结果");
                            dialog.setMessage("旧商品已删除，新商品已同步(当有商品同步失败会中止后续同步并显示错误信息)，本次同步成功数："+count.get());
                            dialog.setPositiveButton("好的", null);
                            dialog.show();
                        }
                    });
                    br.close();
                    is.close();
                }
                catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
                pro.dismiss();
            }
        });
        th.setDaemon(true);
        th.start();
    }

    private boolean menuflag=false;
    private void menuVerCheck() {
        if(menuflag) return;
        if(MyApp.conn==null) return; //没有连接过数据库就不要去判断菜单版本，以免频繁访问网络
        final Thread th=new Thread(new Runnable() {
            public void run() {
                //检查菜谱是否有新版本
                final String sql = " select value from general where name='system' and item='menuversion' ";
                final ArrayList<String[]> menuversion = ((MyApp)getApplication()).sel(sql);
                int ver = 0 ;
                if(menuversion != null && menuversion.size()==1){
                    try{
                        ver = Integer.valueOf(menuversion.get(0)[0]) ;
                    }catch (Exception e){};
                }
                if(ver > share.getInt("menuversion",0)) {
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            final AlertDialog.Builder dialog=new AlertDialog.Builder(MainActivity.this);
                            dialog.setTitle("重要通知：");
                            dialog.setMessage("商品已有新版本，请立即同步更新或前往标题栏手动同步更新。");
                            // 设置确认按钮的监听器
                            dialog.setPositiveButton("立即同步更新", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    onOptionsItemSelected(new MenuItem() {
                                        @Override
                                        public int getItemId() {
                                            return R.id.syn;
                                        }

                                        @Override
                                        public int getGroupId() {
                                            return 0;
                                        }

                                        @Override
                                        public int getOrder() {
                                            return 0;
                                        }

                                        @Override
                                        public MenuItem setTitle(CharSequence title) {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setTitle(int title) {
                                            return null;
                                        }

                                        @Override
                                        public CharSequence getTitle() {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setTitleCondensed(CharSequence title) {
                                            return null;
                                        }

                                        @Override
                                        public CharSequence getTitleCondensed() {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setIcon(Drawable icon) {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setIcon(int iconRes) {
                                            return null;
                                        }

                                        @Override
                                        public Drawable getIcon() {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setIntent(Intent intent) {
                                            return null;
                                        }

                                        @Override
                                        public Intent getIntent() {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setShortcut(char numericChar, char alphaChar) {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setNumericShortcut(char numericChar) {
                                            return null;
                                        }

                                        @Override
                                        public char getNumericShortcut() {
                                            return 0;
                                        }

                                        @Override
                                        public MenuItem setAlphabeticShortcut(char alphaChar) {
                                            return null;
                                        }

                                        @Override
                                        public char getAlphabeticShortcut() {
                                            return 0;
                                        }

                                        @Override
                                        public MenuItem setCheckable(boolean checkable) {
                                            return null;
                                        }

                                        @Override
                                        public boolean isCheckable() {
                                            return false;
                                        }

                                        @Override
                                        public MenuItem setChecked(boolean checked) {
                                            return null;
                                        }

                                        @Override
                                        public boolean isChecked() {
                                            return false;
                                        }

                                        @Override
                                        public MenuItem setVisible(boolean visible) {
                                            return null;
                                        }

                                        @Override
                                        public boolean isVisible() {
                                            return false;
                                        }

                                        @Override
                                        public MenuItem setEnabled(boolean enabled) {
                                            return null;
                                        }

                                        @Override
                                        public boolean isEnabled() {
                                            return false;
                                        }

                                        @Override
                                        public boolean hasSubMenu() {
                                            return false;
                                        }

                                        @Override
                                        public SubMenu getSubMenu() {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setOnMenuItemClickListener(OnMenuItemClickListener menuItemClickListener) {
                                            return null;
                                        }

                                        @Override
                                        public ContextMenu.ContextMenuInfo getMenuInfo() {
                                            return null;
                                        }

                                        @Override
                                        public void setShowAsAction(int actionEnum) {

                                        }

                                        @Override
                                        public MenuItem setShowAsActionFlags(int actionEnum) {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setActionView(View view) {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setActionView(int resId) {
                                            return null;
                                        }

                                        @Override
                                        public View getActionView() {
                                            return null;
                                        }

                                        @Override
                                        public MenuItem setActionProvider(ActionProvider actionProvider) {
                                            return null;
                                        }

                                        @Override
                                        public ActionProvider getActionProvider() {
                                            return null;
                                        }

                                        @Override
                                        public boolean expandActionView() {
                                            return false;
                                        }

                                        @Override
                                        public boolean collapseActionView() {
                                            return false;
                                        }

                                        @Override
                                        public boolean isActionViewExpanded() {
                                            return false;
                                        }

                                        @Override
                                        public MenuItem setOnActionExpandListener(OnActionExpandListener listener) {
                                            return null;
                                        }
                                    });
                                }
                            });
                            // 设置取消按钮的监听器
                            dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {}
                            });
                            dialog.setNeutralButton("待会手动同步", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // TODO Auto-generated method stub
                                    menuflag=true; //不可每次点第三个页面都弹出同步消息框
                                }
                            });
                            dialog.show();
                        }
                    });
                }
            }
        });
        th.setDaemon(true);
        th.start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        //MenuItem item = menu.findItem(R.id.syn);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.cho) {
            final Intent intent = new Intent(this, LogonActivity.class);
            intent.putExtra("auto", false);
            //startActivity(intent);
            startActivityForResult(intent, 1);
            return true;
        }

        if (id == R.id.slip) {
            final Intent intent = new Intent(this, MenuImgSlip.class);
            startActivity(intent);
            return true;
        }

        if (id == R.id.exit) {
            try {
                if(MyApp.conn!=null && MyApp.conn.isClosed()==false) MyApp.conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            MyApp.conn=null;
            MyApp.pwd="";
            final Intent intent = new Intent(this, LogonActivity.class);
            startActivity(intent);
            return true;
        }

        if (id == R.id.about) {
            final Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
            return true;
        }

        if (id == R.id.date) {
            final Calendar calendar = Calendar.getInstance();
            final Dialog dialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {
                        public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                            Toast.makeText(MainActivity.this, year+"年 "+month+"月 "+dayOfMonth+"日", Toast.LENGTH_SHORT).show();
                        }
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH));
            dialog.show();
            return true;
        }

        if (id == R.id.nfc) {
            final Intent intent = new Intent(this, NFCActivity.class);
            //intent.putExtra("menu", 1);
            startActivity(intent);
            return true;
        }

        if (id == R.id.print) {
            final Intent intent = new Intent(this, HotPrintSet.class);
            startActivity(intent);
            return true;
        }

        if (id == R.id.bg1) {
            final SharedPreferences.Editor editor=share.edit();
            editor.putInt("defaultimg",1);
            editor.commit();
            findViewById(android.R.id.content).setBackgroundResource(R.drawable.bg);
            return true;
        }
        if (id == R.id.bg2) {
            final SharedPreferences.Editor editor=share.edit();
            editor.putInt("defaultimg",2);
            editor.commit();
            findViewById(android.R.id.content).setBackgroundResource(R.drawable.tudish);
            return true;
        }
        if (id == R.id.bg3) {
            final SharedPreferences.Editor editor=share.edit();
            editor.putInt("defaultimg",3);
            editor.commit();
            final Bitmap bitmap = ((MyApp)getApplication()).readimg("99999999", "背景");
            if(bitmap!=null) findViewById(android.R.id.content).setBackground(new BitmapDrawable(getResources(), bitmap)); //如果有，先恢复自定义背景
            ((MyApp)getApplication()).NetPhoto("99999999", "背景", new Object(){
                public boolean equals(final Object obj){
                    if(obj!=null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, obj.toString(), Toast.LENGTH_SHORT).show(); //显示错误信息
                            }
                        });
                        return super.equals(obj);
                    }
                    final Bitmap bitmap = ((MyApp)getApplication()).readimg("99999999", "背景"); //再次读取图片
                    if(bitmap==null) return super.equals(obj);
                    final Drawable drawable = new BitmapDrawable(getResources(), bitmap);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            findViewById(android.R.id.content).setBackground(drawable);
                        }
                    });
                    return super.equals(obj);
                }
            });
            return true;
        }

        if (id == R.id.syn) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("同步完成后[预点清单]会清空,请重起程序\n\n网络同步将占用数分钟或更长时间及一定存储空间,建意在WIFI下进行同步\n\n本地同步会先清空商品,请选择一个文本文件,每行一个商品,格式参考<添加一个商品>");
            builder.setTitle("商品及图片同步");
            //第一个按扭
            builder.setPositiveButton("网络同步", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    if(checknet()) return; //检查网络
                    pro= ProgressDialog.show(MainActivity.this, "消息", "正在同步 ... ", true);
                    final Thread th = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            ((MyApp)getApplication()).synmenu(handler, share); //同步时会将当前菜单版本通过share写入本地缓存
                            pro.dismiss();
                        }
                    });
                    th.setDaemon(true);
                    th.start();
                }
            });
            //第二个按扭
            builder.setNegativeButton("本地同步", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    final Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("*/*"); //筛选器
                    //intent.addCategory(Intent.CATEGORY_OPENABLE);
                    //startActivityForResult(Intent.createChooser(intent,"选择一个文件"),111);
                    startActivityForResult(intent,111);
                }
            });
            builder.setNeutralButton("添加一个商品", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ((MyApp)getApplication()).showInputDialog("输入 <编码、分类、商品名、价格、单位、助记符> 用空格隔开", "100000 主食 米饭 3.0 份 mf", new Object(){
                        @Override
                        public boolean equals(Object obj) {
                            if(obj!=null && obj.toString().isEmpty()==false) {
                                final boolean boo = ((MyApp)getApplication()).addmenu(obj.toString());
                                if(boo) Toast.makeText(getApplication(), "添加成功："+obj.toString(), Toast.LENGTH_LONG).show();
                            }
                            return super.equals(obj);
                        }
                    });
                }
            });
            builder.create().show();
            return true;
        }

        if (id == R.id.clear) {
            AlertDialog.Builder dialog=new AlertDialog.Builder(this);
            dialog.setTitle("警告");
            dialog.setMessage("确定清除缓存图片吗(包括商品图片和自定义背景图) ？");
            dialog.setPositiveButton("确定清除", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ((MyApp)getApplication()).deletephote();
                    AlertDialog.Builder dia=new AlertDialog.Builder(MainActivity.this);
                    dia.setTitle("清除缓存");
                    dia.setPositiveButton("OK", null);
                    dia.setMessage("缓存数据已清除，请重新同步商品图片");
                    dia.show();
                }
            });
            dialog.setNegativeButton("取消", null);
            dialog.show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //检查网络
    private boolean checknet() {
        ConnectivityManager con = (ConnectivityManager)getSystemService(Activity.CONNECTIVITY_SERVICE);
        boolean wifi = con.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isConnectedOrConnecting();
        boolean internet = con.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isConnectedOrConnecting();
        if( wifi==false && internet==false ){
            Toast.makeText(this, "没有网络连接，请先连接网络。", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }
    public boolean onKeyDown(int keyCode,KeyEvent event){
        if(keyCode== KeyEvent.KEYCODE_BACK){
            int k = mainActivityViewPager.getCurrentItem();
            if(k == 0){
                dialog();
                return true;
            }
            mainActivityViewPager.setCurrentItem(k-1);
            return true;
        }
        //if(keyCode==KeyEvent.KEYCODE_MENU){
            //Intent intent = new Intent(MainActivity.ins, srcAct.class);
        //}
        return super.onKeyDown(keyCode,event);
    }

    public Handler handler=new Handler(){
        public void handleMessage(Message msg){
            switch (msg.what){
                case 1 :
                    mainActivityViewPager.setCurrentItem(1);
                    break;
                case 2 :
                    AlertDialog.Builder dialog=new AlertDialog.Builder(MainActivity.this);
                    dialog.setTitle("网络错误");
                    dialog.setPositiveButton("OK", null);
                    dialog.setMessage("与数据库通信时出现了错误。");
                    dialog.show();
                    break;
                case 3 :
                    mainActivityViewPager.setCurrentItem(2);
                    break;
                case 6 :
                    //图片同步进度显示
                    if (pro!=null){
                        pro.setTitle(((MyApp)getApplication()).ImgMsg);
                    }
                    break;
                case 7 :
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("同步已完成，需要重起程序。\n");
                    builder.setTitle("重起");
                    //第一个按扭
                    builder.setPositiveButton("手动重新起动程序", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            MainActivity.this.finish();
                        }
                    });
                    builder.create().show();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    private void dialog(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("确定退出吗，Exit ？");
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setTitle("退出");
        //第一个按扭
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //dialog.dismiss();
                finish();
                //System.exit(0);
            }
        });
        //第二个按扭
        builder.setNegativeButton("取消", null);
        //第三个按扭
        //builder.setNeutralButton("",null);
        builder.create().show();
    }

    /**********************************************************************************************
    *
    *   NFC 功能的实现,与NFCActivity.java中的代码一样,略有修改
    *
    * ********************************************************************************************/

    public void onResume() {
        super.onResume();
        if (mNfcAdapter == null) {
            //Toast.makeText(this, "不支持NFC功能；NFC is not available", Toast.LENGTH_LONG).show();
            return;
        }
        if (!mNfcAdapter.isEnabled()) {
            Toast.makeText(this, "请在系统设置中先启用NFC功能！", Toast.LENGTH_LONG).show();
            return;
        }
        ((MyApp)getApplication()).beep(500);
        if(NfcAdapter.ACTION_TECH_DISCOVERED.equals(getIntent().getAction())==false) return;

        // 读M1卡代码
        final Tag tagFromIntent = getIntent().getParcelableExtra(NfcAdapter.EXTRA_TAG);
        final MifareClassic mfc = MifareClassic.get(tagFromIntent);
        if(mfc==null) return;
        try {
            mfc.connect();
            final boolean auth = mfc.authenticateSectorWithKeyA(4, BytePassword());// 验证密码,默认MifareClassic.KEY_DEFAULT
            if (auth) {
                final String dishnum = new String(mfc.readBlock(4)).trim();
                if(mainActivityViewPager.getCurrentItem()==1) {   //只有在第二界面下才执行
                    ((MyApp)getApplication()).pre(dishnum, 1); //添加
                    fragment2.handler.sendEmptyMessage(4); //刷新
                }
            }
            else {
                Toast.makeText(this, "认证失败，进入调试窗口...", Toast.LENGTH_SHORT).show();
                final Intent intent = new Intent(this, NFCActivity.class);
                startActivity(intent);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "异常：可能卡片不在磁场范围,"+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        finally {
            try { mfc.close();} catch (IOException e) {e.printStackTrace();}
        }
    }
    private byte[] BytePassword() {
        final String s = share.getString("NFCpassword","FFFFFFFFFFFF");
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }

}