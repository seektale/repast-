package com.dmumu.phone.repast;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.HeaderViewListAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.util.ArrayList;
import java.util.Hashtable;
import static android.graphics.Color.BLACK;
import static android.graphics.Color.WHITE;
import static com.dmumu.phone.repast.R.id.linearThree;
import static com.dmumu.phone.repast.R.style.popwin_anim_style;

public class FragmentC extends Fragment {
    private static final String ARG_SECTION_NUMBER = "section_number";
    private ArrayList<String[]> arrayList=new ArrayList<String[]>();
    public SearchView edit;
    private ListView listView;
    private TextView footer;
    private PopupWindow menu;
    private String menuid ;
    public FragmentC() {
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, 3);
        setArguments(args);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_three, container, false);
        //rootView.setBackgroundColor(Color.LTGRAY);
        //rootView.setBackgroundResource(R.drawable.cao);

        footer = new TextView(rootView.getContext());
        footer.setGravity(Gravity.CENTER);
        footer.setTextSize(14);
        footer.setText("\n长按商品可以查看相应二维码");

        listView = (ListView)rootView.findViewById(linearThree);
        listView.addFooterView(footer);
        listView.setAdapter(new MyAdater());

        edit=(SearchView)rootView.findViewById(R.id.order);
        edit.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                initDB();
                return false;
            }
        });

        /************************************************************************************************************/

        final ListView menuView =new ListView(rootView.getContext());
        menu = new PopupWindow(menuView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        menu.setFocusable(true);
        menu.setOutsideTouchable(true);
        menu.update();
        //得到一个空图片
        final Bitmap nullbit = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        final Drawable front = new BitmapDrawable(null, nullbit);
        menu.setBackgroundDrawable(front); //会报目录错误
        menu.setAnimationStyle(popwin_anim_style);

        //final ArrayList<String[]> arrss = mysql.selSQLitelook(handler);
        menuView.setAdapter(new lookAdater(new ArrayList<String[]>()));
        menuView.setBackgroundColor(WHITE);
        menuView.getBackground().setAlpha(230);
        menuView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                edit.clearFocus();  //失去焦点，这样可以隐藏软键盘,老是弹出很烦人
                menu.dismiss();
                String col[] = { "num", "cla", "name", "price", "unit", "lock", "stock" };
                //String where = "cla='"+arrss.get(position)[0]+"'";
                String where = "cla='"+((TextView)view).getHint().toString()+"'";
                arrayList = ((MyApp)getActivity().getApplication()).selSQLite(col, where);
                if (arrayList != null){
                    //((MyAdater)listView.getAdapter()).notifyDataSetChanged(); //更新数据
                    final HeaderViewListAdapter hAdapter = (HeaderViewListAdapter)listView.getAdapter();
                    final MyAdater myadapter = (MyAdater)hAdapter.getWrappedAdapter();
                    myadapter.notifyDataSetChanged();
                    footer.setText("共计 "+arrayList.size()+" 条记录(最多1000条)");
                }
            }
        });

        final Button lookmenu = rootView.findViewById(R.id.lookmenu);
        lookmenu.setAlpha(0.8f); //稍微有一点透明
        lookmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.clearFocus();  //失去焦点，这样可以隐藏软键盘
                menuView.setAdapter(new lookAdater(((MyApp)getActivity().getApplication()).selSQLite("select cla,count(*) from menu group by cla")));
                if(menuView.getAdapter().getCount()>0) {
                    menu.showAtLocation(FragmentC.this.getView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0); //显示菜单
                    return;
                }
                final Toast toast = Toast.makeText(getView().getContext(), "请先同步商品："+menuView.getAdapter().getCount(), Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER| Gravity.CENTER, 0, 0);
                toast.show();
            }
        });
        return rootView;
    }

    /*---------------------------------------------------------------------------------------------------*/

    private class lookAdater extends BaseAdapter {
        private ArrayList<String[]> arr =new ArrayList<>();
        private lookAdater(ArrayList<String[]> arr){
            if(arr!=null)   this.arr=arr;
        }
        public int getCount() {
            return arr.size();
        }
        public Object getItem(int position) {
            return arr.get(position);
        }
        public long getItemId(int position) {
            return position;
        }
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView text = new TextView(FragmentC.this.getActivity());
            text.setText("["+(position+1)+"] "+arr.get(position)[0]+"  --  数量:"+arr.get(position)[1]);
            text.setTextSize(18);
            text.setGravity(Gravity.CENTER);
            text.setPadding(0,10,0,10);
            text.setHint(arr.get(position)[0]+""); //不能为数字
            return text;
        }
    }

    private void initDB(){
        String co[] = { "count(*)" };
        ArrayList<String[]> temp = ((MyApp)getActivity().getApplication()).selSQLite(co, null);
        if (temp == null){
            Toast toast = Toast.makeText(getView().getContext(), "查询本地缓存表返回空指针，结果有误", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER| Gravity.CENTER, 0, 0);
            toast.show();
            return;
        }
        if (Integer.valueOf(temp.get(0)[0])==0){
            Toast toast = Toast.makeText(getView().getContext(), "没有缓存本地商品，请先同步商品", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER| Gravity.CENTER, 0, 0);
            toast.show();
            return;
        }

        String help=edit.getQuery().toString().trim();
        if (help.isEmpty()) help="<不显示商品信息〉";

        String col[] = { "num", "cla", "name", "price", "unit", "lock", "stock" };
        String where = "help like '%"+help+"%' or name like '%"+help+"%' or num like '%"+help+"%'";
        arrayList = ((MyApp)getActivity().getApplication()).selSQLite(col, where);

        if (arrayList != null){
            //((MyAdater)listView.getAdapter()).notifyDataSetChanged(); //更新数据
            final HeaderViewListAdapter hAdapter = (HeaderViewListAdapter)listView.getAdapter();
            final MyAdater myadapter = (MyAdater)hAdapter.getWrappedAdapter();
            myadapter.notifyDataSetChanged();
            footer.setText("共计 "+arrayList.size()+" 条记录");
        }
    }

    private class MyAdater extends BaseAdapter {
        @Override
        public int getCount() {
            if (arrayList==null) return 0;
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return arrayList.get(position-1);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final String temp[] = arrayList.get(position);

            View v = LayoutInflater.from(FragmentC.this.getView().getContext()).inflate(R.layout.orderlayout, null);
            ImageView button =  v.findViewById(R.id.gofc);
            button.getBackground().setAlpha(180);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit.clearFocus();  //使其失去焦点，以免其自动弹出软键盘
                    ((MyApp)getActivity().getApplication()).pre(temp[0], 1);
                    Toast.makeText(v.getContext(), temp[2]+" 添加成功!", Toast.LENGTH_SHORT).show();
                }
            });

            TextView attr = v.findViewById(R.id.desattr);
            attr.setTextSize(16);
            attr.setTextColor(Color.RED);
            if(temp[5].equalsIgnoreCase("Y")) attr.setText("已锁定 ");

            TextView b = v.findViewById(R.id.desdish);
            b.setGravity(View.TEXT_ALIGNMENT_TEXT_START);    //左对齐
            b.setTextSize(16);
            b.setTextColor(BLACK);
            //b.setBackgroundResource(R.drawable.ying);
            b.setBackgroundResource(R.drawable.fanga);
            //透明度 取值：0－255
            b.getBackground().setAlpha(220);
            //放在这里才有效，注意位置

            b.setText(Html.fromHtml("<font>" +
                    temp[0]+" "+temp[2]+"["+temp[1]+"]"+
                    "</font><br><font color=\'blue\'>" +
                    "￥: "+temp[3]+"   /"+temp[4]+
                    "</font>"));


            v.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    ((MyApp)getActivity().getApplication()).amount(v.getContext(), temp).show();
                }
            });
            v.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    edit.clearFocus();  //使其失去焦点，以免其自动弹出软键盘
                    return false;
                }
            });
            v.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    getqr(temp[0]+"#"+temp[2]);
                    return true;
                }
            });

            //从右到左滑出的动画
            AnimationSet animationSet = new AnimationSet(true);
            TranslateAnimation translateAnimation = new TranslateAnimation
                    (Animation.RELATIVE_TO_SELF,1f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f);
            translateAnimation.setDuration(300);
            animationSet.addAnimation(translateAnimation);
            v.startAnimation(animationSet);

            return v;
        }

        private void getqr(final String val) {
            Bitmap bitmap = null;
            final QRCodeWriter qrCodeWriter = new QRCodeWriter();
            final Hashtable<EncodeHintType, String> hints = new Hashtable<>();
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            BitMatrix bitMatrix=null;
            try {
                bitMatrix = qrCodeWriter.encode(val, BarcodeFormat.QR_CODE, 800, 800, hints);
            }
            catch (WriterException e) {e.printStackTrace();return;}
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            int[] pixels = new int[width * height];
            for (int y = 0; y < height; y++) {
                int offset = y * width;
                for (int x = 0; x < width; x++) {
                    pixels[offset + x] = bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF;
                }
            }
            bitmap = Bitmap.createBitmap(pixels,0, width, width, height, Bitmap.Config.ARGB_8888);

            final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle(val);
            final ImageView imageView = new ImageView(getContext());
            imageView.setImageBitmap(bitmap);
            builder.setView(imageView);
            builder.setPositiveButton("好的", null);
            builder.create().show();
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data==null) return ;
        if (resultCode!=0) return ;

        String val = data.getStringExtra("result");
        final ArrayList<String> arr = new ArrayList<>();
        arr.add(menuid);
        arr.add(val);

        final Thread th = new Thread(new Runnable() {
            public void run() {
                final String res = ((MyApp)getActivity().getApplication()).pro("menu_scan", arr);
                if(res.startsWith("Y") || res.startsWith("N")) return;
                dia(res) ;
            }
        });
        th.start();
    }
    private void dia(final String val) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setIcon(android.R.drawable.ic_dialog_alert);
                builder.setTitle("提示");
                builder.setMessage(val);
                builder.setPositiveButton("好的", null);
                builder.create().show();
            }
        });
    }
}