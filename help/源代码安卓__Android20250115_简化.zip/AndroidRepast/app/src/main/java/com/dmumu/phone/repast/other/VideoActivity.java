package com.dmumu.phone.repast.other;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.RelativeLayout;
import com.dmumu.phone.repast.R;
import java.io.IOException;

/*
*  已废弃，考滤到复杂性和必要性，不再实现视频播放的功能，意义不大，非常耗时间 20241224
* */

public class VideoActivity extends AppCompatActivity implements SurfaceHolder.Callback {

    /*
    当在方法内部创建MediaPlayer对象实例（局部变量）时，一旦方法执行完成，局部变量将不再被引用所持有。而根据Java JVM内存回收机制，不再被引用持有的对象，执行gc的
    时候该对象就会被回收。这意味着，MediaPlayer对象实例在播放完成、释放之前是可以被gc回收的，因此会导致音频/视频播放中断。解决方案是：应当将MediaPlayer对象实例
    声明为class类成员变量，而不是声明为方法的局部变量。
    */
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videoplay);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        SurfaceView surfaceView = findViewById(R.id.surface_view);
        SurfaceHolder surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        mediaPlayer = new MediaPlayer();

        final DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenWidth = displayMetrics.widthPixels;
        int screenHeight = displayMetrics.heightPixels;

        float aspectRatio = 16f / 9f;
        int surfaceViewWidth = screenWidth;
        int surfaceViewHeight = (int) (screenHeight / aspectRatio);

        final String num = getIntent().getExtras().getString("num");
        final String name = getIntent().getExtras().getString("name").replace("/","|");
        final String path = getExternalFilesDir(null).getPath()+"/repastdir/"+name+"@"+num;

        try {
            //mediaPlayer.setDataSource("http://live.hkstv.hk.lxdns.com/live/hks/playlist.m3u8");
            mediaPlayer.setDataSource(path);
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { //加载完后自动播放
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.start();
            }
        });
        mediaPlayer.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
            @Override
            public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {}
        });
        //mediaPlayer.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);

        //FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(surfaceViewWidth, surfaceViewHeight);
        //lp.gravity = Gravity.CENTER;
        //surfaceView.setLayoutParams(lp);

        //FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(200, 100);
        //findViewById(R.id.surface_up).setLayoutParams(lp);

        //注意：必须放面后面执行，否则闪退
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(surfaceViewWidth, surfaceViewHeight);
        surfaceView.setLayoutParams(layoutParams);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home: //标题栏左上角的返回键点击事件
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Surface surface = holder.getSurface();
        mediaPlayer.setSurface(surface);
        mediaPlayer.prepareAsync();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {}


    @Override
    protected void onDestroy() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        super.onDestroy();
    }
}