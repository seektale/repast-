package com.dmumu.phone.repast;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HeaderViewListAdapter;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Dishlist extends ActionBarActivity {
    private ArrayList<String[]> arrayList=new ArrayList<String[]>();
    private ArrayList<String[]> arrtemp=new ArrayList<String[]>();
    private int meal = 0;
    private DrawerLayout mDrawerLayout = null;
    private TextView header,footer,dishname ;
    private SwipeDismissListView dishscroll ;
    private MyAdater dishscrollAdater = new MyAdater();
    private LinearLayout left;
    private Button ba,bb,bc,bd,be,bh;
    private int flag = -1;
    private ProgressDialog pro ;
    private boolean firstcome = false ;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //导航条显示返回键
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        setContentView(R.layout.dishlist);

        //接收传过来的数据
        Intent intent = getIntent();
        Bundle bu = intent.getBundleExtra("val");
        meal = Integer.valueOf(bu.getString("meal"));

        dishname = (TextView)findViewById(R.id.dishname);
        mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        ba = (Button)findViewById(R.id.ba);
        bb = (Button)findViewById(R.id.bb);
        bc = (Button)findViewById(R.id.bc);
        bd = (Button)findViewById(R.id.bd);
        be = (Button)findViewById(R.id.be);
        bh = (Button)findViewById(R.id.bh);

        header = new TextView(this);
        header.setGravity(Gravity.CENTER);
        header.setTextSize(18);
        header.setTextColor(Color.GREEN);
        header.setText(Html.fromHtml(bu.getString("area")+bu.getString("desk")+"  <B><font color=blue>"+bu.getString("alias")+"</font></B>  编号:"+meal+
                "<br>"+bu.getString("emp")+" "+bu.getString("gotime")));

        footer = new TextView(this);
        footer.setGravity(Gravity.CENTER);
        footer.setTextSize(16);

        dishscroll = new SwipeDismissListView(this);
        dishscroll.addHeaderView(header);
        dishscroll.addFooterView(footer);
        dishscroll.setAdapter(dishscrollAdater);
        dishscroll.setDividerHeight(6); //上下间隔
        dishscroll.setPadding(8, 5, 8, 5);
        dishscroll.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));   //布局
        //单击项目事件
        dishscroll.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //不响应 header 和 footer 的选择事件
                if (position > 0 && position < dishscroll.getCount() - 1) {
                    mDrawerLayout.openDrawer(Gravity.LEFT);
                    if (arrayList != null && arrayList.size() > 0) {
                        dishname.setText(arrayList.get(position - 1)[7]);
                        flag = position - 1;
                        dishscrollAdater.notifyDataSetChanged();
                    }
                }
            }
        });

        //滑动删除事件
        dishscroll.setOnDismissCallback(new SwipeDismissListView.OnDismissCallback() {
            @Override
            public void onDismiss(final int dismissPosition) {
                //不响应 header 和 footer 的事件, 注意:dismissPosition 有可能为-1
                if(dismissPosition<=0 || dismissPosition-1>=arrayList.size()) return;

                final String val = delslip(dismissPosition-1);
                Thread th =new Thread(new Runnable() {
                    public void run() {
                        ArrayList<String> arr = new ArrayList<>();
                        arr.add(val);
                        String result = mysql.pro("dish_del",arr,handler);
                        if(result.startsWith("Y") || result.startsWith("N")){
                            return;
                        }
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
            }
        });
        LinearLayout drawerLayout = (LinearLayout)findViewById(R.id.space);
        drawerLayout.addView(dishscroll);

        left = (LinearLayout)findViewById(R.id.left_drawer);
        left.setBackgroundColor(Color.WHITE);
        left.getBackground().setAlpha(220);

        ba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkflag()) return ;
                Thread th =new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ArrayList<String> arr = new ArrayList<>();
                        arr.add(arrayList.get(flag)[0]);
                        mysql.pro("dish_del",arr,handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
            }
        });

        bb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkflag()) return ;
                Thread th =new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ArrayList<String> arr = new ArrayList<>();
                        arr.add(arrayList.get(flag)[0]);
                        arr.add(arrayList.get(flag)[10]);   //通过手机退单时是全退
                        arr.add("通过手机退单");
                        mysql.pro("dish_back_init",arr,handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
            }
        });

        bc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkflag()) return ;
                amount(v.getContext()).show();
            }
        });

        bd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkflag()) return ;
                price().show();
            }
        });

        be.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkflag()) return ;
                remark().show();
            }
        });

        bh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.closeDrawer(left);
            }
        });

        handler.sendEmptyMessage(1);
    }

    //处理删除的数据
    private String delslip(int index){
        //先保留要删除的商品索引, 再删除商品
        Log.i("dsfA:::::::::::::::::::::::",index + "  " + arrayList.size());
        String val = arrayList.get(index)[0];
        arrayList.remove(index);

        double total = 0d;
        int isvail = 0;
        for (String temp[] : arrayList){
            total = total + Double.valueOf(temp[8])* Double.valueOf(temp[10])* Double.valueOf(temp[11]);
            if (temp[1].isEmpty()) isvail++ ;
        }
        DecimalFormat df = new DecimalFormat("###.00");
        if(arrayList.size()>0){
            footer.setText("有效商品数量:" +isvail+" /"+dishscrollAdater.getCount() + "   合计:" + df.format(total));
        }

        HeaderViewListAdapter listAdapter = (HeaderViewListAdapter) dishscroll.getAdapter();
        MyAdater adapter = (MyAdater)listAdapter.getWrappedAdapter();
        adapter.notifyDataSetChanged();

        mDrawerLayout.closeDrawer(left);
        return val ;
    }

    public void onResume(){
        super.onResume();
        if(firstcome){
            handler.sendEmptyMessage(1);
            return;
        }
        firstcome = true;
    }
    private boolean checkflag(){
        if(flag>=0 && flag<arrayList.size()) return false;
        Toast.makeText(getApplicationContext(), "未选择要编辑的 目标商品", Toast.LENGTH_SHORT).show();
        return true;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dish_list, menu);
        return true;
    }

    /* 因为上面还有一个GoOrder,暂不启用
    //进入后台长时不显示时，这个最好关掉,红米上实测证明：按home键一到后台就会执行,再点开时，界面已关闭
    //之所以关闭掉是因为：如果长时间在后台，系统回收了内存资源，再回到这个程序时，很容易闪退，所以干脆关掉
    public void onStop(){
        super.onStop();
        finish();
    }
    */

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //返回到上一个Activity
        if (id == android.R.id.home) {
            finish();
            return true;
        }
        if (id == R.id.refresh) {
            flag = -1;
            handler.sendEmptyMessage(1);
            return true;
        }
        if (id == R.id.pay) {
            paybill();
            return true;
        }
        if (id == R.id.printbill) {
            Thread th = new Thread(new Runnable() {
                public void run() {
                    ArrayList<String[]> site = mysql.sel("select 站点 from print_config",handler);
                    if (site == null) return;
                    placelist = new String[site.size()];
                    for(int k = 0 ; k<site.size() ; k++)    placelist[k]=site.get(k)[0];
                    handler.sendEmptyMessage(3);
                }
            });
            th.start();
            return true;
        }

        if (id == R.id.printhot) {
            Thread th = new Thread(new Runnable() {
                public void run() {
                    new PrintDB(meal, false, handler);
                }
            });
            th.start();
            return true;
        }
        if (id == R.id.printhold) {
            Thread th = new Thread(new Runnable() {
                public void run() {
                    new PrintDB(meal, true, handler);
                }
            });
            th.start();
            return true;
        }
        if (id == R.id.allper) {
            editall("0.9","批量改折扣","dish_percent_all").show();
            return true;
        }
        if (id == R.id.allprice) {
            editall("0","批量修改价格","dish_price_all").show();
            return true;
        }
        if (id == R.id.allamount) {
            editall("1","批量修改数量(仅支持未出单)","dish_amount_all").show();
            return true;
        }
        if (id == R.id.allremark) {
            editall("2备1","批量编辑备注","dish_remark_all").show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //手机现付结算
    private void paybill() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("注意:仅支持现付结算方式");
        builder.setMessage("确定结算吗 ？");
        builder.setPositiveButton("确定结算", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Thread th = new Thread(new Runnable() {
                    public void run() {
                        ArrayList<String> temparr = new ArrayList<>();
                        temparr.add(meal+"");
                        mysql.pro("billphone",temparr,handler);
                    }
                });
                th.start();
            }
        });
        builder.setNegativeButton("取消", null);
        builder.create().show();
    }

    //账单打印参数选择对话框
    private String placelist[];
    private void PrintBillDia(){
        View v = LayoutInflater.from(this).inflate(R.layout.printbilllayout, null);
        final CheckBox back = v.findViewById(R.id.backdish);
        final CheckBox list = v.findViewById(R.id.sublist);
        final RadioButton rb0 = v.findViewById(R.id.printstyle1);
        final RadioButton rb1 = v.findViewById(R.id.printstyle2);
        final RadioButton rb2 = v.findViewById(R.id.printstyle3);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("热敏打印机站点选择");
        builder.setView(v);
        builder.setSingleChoiceItems(placelist, -1, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, final int which) {
                String a="N",b="N";
                if (back.isChecked()) a="Y";
                if (list.isChecked()) b="Y";
                int style=0; //默认选中第一个
                if(rb1.isChecked()) style=1;
                if(rb2.isChecked()) style=2;
                Pbill(a,b,which,style);
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("取消打印", null);

        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);
        Dia.show();
    }
    private void Pbill(final String a, final String b, final int which, final int style){
        Thread th = new Thread(new Runnable() {
            public void run() {
                if(style==0) mysql.getbill(meal, a, b, placelist[which], handler);  //打印账单
                if(style==1) mysql.getlist(meal, placelist[which], handler);        //打印清单
                if(style==2) mysql.getunion(meal, placelist[which], handler);       //打印联单
            }
        });
        th.start();
    }

    //修改数量选择对话框
    private AlertDialog amount(Context context){
        View v = LayoutInflater.from(context).inflate(R.layout.amountlayout, null);

        final EditText val;
        Button up,down;
        val =(EditText) v.findViewById(R.id.amount);
        val.setText(arrayList.get(flag)[10]);
        val.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{
                    Double.valueOf(val.getText().toString());
                    val.setTextColor(Color.BLUE);
                }catch (Exception e){
                    val.setTextColor(Color.RED);
                }
            }
            public void afterTextChanged(Editable s) {}
        });
        up = (Button) v.findViewById(R.id.add);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return ;
                }
                Double k = Double.valueOf(val.getText().toString());
                val.setText(k+1+"");
            }
        });
        down = (Button) v.findViewById(R.id.del);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return ;
                }
                Double k = Double.valueOf(val.getText().toString());
                if (k-1>=0){
                    val.setText(k-1+"");
                }
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("修改数量(仅支持未出单)");
        builder.setView(v);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mDrawerLayout.closeDrawer(left);
                Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ArrayList<String> arr = new ArrayList<String>();
                        arr.add(arrayList.get(flag)[0]);
                        arr.add(val.getText().toString());
                        mysql.pro("dish_amount",arr,handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
            }
        });
        builder.setNegativeButton("取消", null);

        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);

        return Dia;
    }

    //修改价格对话框
    private AlertDialog price(){
        View v = LayoutInflater.from(this).inflate(R.layout.amountlayout, null);

        final EditText val;
        Button up,down;
        val =(EditText) v.findViewById(R.id.amount);
        val.setText(arrayList.get(flag)[8]);
        val.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{
                    Double.valueOf(val.getText().toString());
                    val.setTextColor(Color.BLUE);
                }catch (Exception e){
                    val.setTextColor(Color.RED);
                }
            }
            public void afterTextChanged(Editable s) {}
        });
        up = (Button) v.findViewById(R.id.add);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return ;
                }
                Double k = Double.valueOf(val.getText().toString());
                val.setText(k+1+"");

            }
        });
        down = (Button) v.findViewById(R.id.del);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return ;
                }
                Double k = Double.valueOf(val.getText().toString());
                if (k-1>=0){
                    val.setText(k-1+"");
                }
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("修改价格");
        builder.setView(v);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mDrawerLayout.closeDrawer(left);
                Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ArrayList<String> arr = new ArrayList<String>();
                        arr.add(arrayList.get(flag)[0]);
                        arr.add(val.getText().toString());  //价格
                        mysql.pro("dish_price",arr,handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
            }
        });
        builder.setNegativeButton("取消", null);

        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);

        return Dia;
    }

    //修改备注对话框
    private AlertDialog remark(){
        View v = LayoutInflater.from(this).inflate(R.layout.inputlayout, null);

        final EditText val;
        val =(EditText) v.findViewById(R.id.inputval);
        val.setText(arrayList.get(flag)[15]);

        Button ed = (Button) v.findViewById(R.id.clearval);
        ed.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                val.setText("");
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("编辑备注");
        builder.setView(v);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mDrawerLayout.closeDrawer(left);
                Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ArrayList<String> arr = new ArrayList<String>();
                        arr.add(arrayList.get(flag)[0]);
                        arr.add(val.getText().toString());
                        mysql.pro("dish_remark",arr,handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
            }
        });
        builder.setNegativeButton("取消", null);

        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);

        return Dia;
    }

    //批量改价格，数量，备注，折扣
    private AlertDialog editall(String def, String title, final String pro){
        View v = LayoutInflater.from(this).inflate(R.layout.inputlayout, null);

        final EditText val;
        val =(EditText) v.findViewById(R.id.inputval);
        val.setText(def);

        Button ed = (Button) v.findViewById(R.id.clearval);
        ed.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                val.setText("");
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setView(v);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mDrawerLayout.closeDrawer(left);
                Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ArrayList<String> arr = new ArrayList<String>();
                        arr.add(meal+"");
                        arr.add(val.getText().toString());
                        mysql.pro(pro,arr,handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
            }
        });
        builder.setNegativeButton("取消", null);

        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);

        return Dia;
    }

    private Handler handler=new Handler(){
        public void handleMessage(final Message msg){
            switch (msg.what){
                case 1 :
                    //清空数据
                    footer.setText("");
                    arrayList = new ArrayList<>();
                    HeaderViewListAdapter listAdaptera = (HeaderViewListAdapter) dishscroll.getAdapter();
                    MyAdater adaptera = (MyAdater)listAdaptera.getWrappedAdapter();
                    //dishscroll.requestLayout();
                    adaptera.notifyDataSetChanged();

                    //连接数据库必须以线程的方式，否则不能连接数据库
                    Thread th=new Thread(new Runnable() {
                        @Override
                        public void run() {
                            arrtemp = mysql.sel( "select * from dish where 台次="+meal ,handler);
                            if(arrtemp!=null){
                                handler.sendEmptyMessage(2);
                            }
                        }
                    });
                    th.start();
                    break;
                case 2 :
                    //压力测试时表明，MyAdapter持有的对象arrayList不能在线程中赋值。否则有很大的机率出错并直接闪退
                    //解决方法：从线程获得的新数据先传到主线程，不要直接在子线程中为其赋值
                    arrayList = arrtemp;
                    double total=0d;
                    int isvail=0;
                    for (String temp[] : arrayList){
                        total = total + Double.valueOf(temp[8])* Double.valueOf(temp[10])* Double.valueOf(temp[11]);
                        if (temp[1].isEmpty()) isvail++ ;
                    }
                    DecimalFormat df = new DecimalFormat("###.00");
                    footer.setText("");
                    if(arrayList.size()>0){
                        footer.setText("有效商品数量:" +isvail+" /"+dishscrollAdater.getCount() + "   合计:" + df.format(total));
                    }

                    HeaderViewListAdapter listAdapter = (HeaderViewListAdapter) dishscroll.getAdapter();
                    MyAdater adapter = (MyAdater)listAdapter.getWrappedAdapter();
                    adapter.notifyDataSetChanged();
                    mDrawerLayout.closeDrawer(left);
                    break;
                case 3 :
                    PrintBillDia();
                    break;
                case 98 :
                    //显示当前正在做什么,针对出单打印
                    if(pro==null) break;
                    Bundle who = msg.getData();
                    String abo = who.getString("who");
                    String what = who.getString("what");
                    pro.dismiss();
                    showprint(abo,what);
                    break ;
                case 99 :
                    pro= ProgressDialog.show(Dishlist.this, "稍等", "打印任务正在进行 ... ", true);
                    break;
                case 100 :
                    if(Dishlist.this.isFinishing()) return;
                    mysql.showmsg(msg, Dishlist.this);
                    break;
            }
            super.handleMessage(msg);
        }
    };
    private void showprint(String abo, String who){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(android.R.drawable.ic_dialog_alert);

        String msgv = "" ;
        String temp[] = abo.split("&");
        for(int k = 0 ; k<temp.length ; k++){
            msgv = msgv + temp[k] ;
            if(who.substring(k,k+1).equals("Y")){
                msgv = msgv + "  "+who.substring(k,k+1)+"  成功\n" ;
            }
            else{
                msgv = msgv + "  "+who.substring(k,k+1)+ "  失败\n" ;
            }
        }

        builder.setTitle("打印结果:"+temp.length);
        builder.setMessage(msgv);
        builder.setPositiveButton("确定", null);
        builder.create().show();
    }

    private class MyAdater extends BaseAdapter {
        @Override
        public int getCount() {
            if (arrayList==null) return 0;
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return arrayList.get(position-1);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final String temp[]=arrayList.get(position);

            TextView b = new TextView(Dishlist.this);
            String att = temp[1].isEmpty() ? temp[1] : "["+temp[1]+"]" ;
            String low = temp[11].equals("1") ? "" : " 折扣:"+temp[11] ;
            //左对齐
            b.setGravity(View.TEXT_ALIGNMENT_TEXT_START);
            b.setTextColor(Color.BLACK);
            if (flag == position) b.setTextColor(Color.BLUE);

            if(temp[14].length()>16){
                temp[14] = temp[14].substring(11,16) +"  ["+ howlong(temp[14]) +"]";
            }

            /*
            //已出单
            b.setText(temp[0]+" ["+temp[5]+"]  ￥"+temp[8]+"/"+temp[9]+" 数量:"+temp[10] + low +
                    "\n"+att+temp[7]+" ※ "+temp[15]+"\n"+temp[13]+" "+temp[14]+"  (出单:"+temp[12]+")");
            //未出单
            if (temp[12].equals("0")){
                b.setText(temp[0]+" ["+temp[5]+"]  ￥"+temp[8]+"/"+temp[9]+" 数量:"+temp[10]+ low +
                        "\n"+att+temp[7]+" ※ "+temp[15]+"\n"+temp[13]+" "+temp[14]+"  (未出单)");
            }
            */

            //已出单
            b.setText(Html.fromHtml("<font>" +
                    temp[0]+" ["+temp[5]+"]  ￥"+temp[8]+"/"+temp[9]+" 数量:"+temp[10] + low +
                    "</font><br><font color=\'blue\'><B>" +
                    att+temp[7]+" ※ "+temp[15]+
                    "</B></font><br><font color=\'#f02387\'>"+
                    temp[13]+" "+temp[14]+"  (出单:"+temp[12]+")"+
                    "</font>"));
            //未出单
            if (temp[12].equals("0"))
            b.setText(Html.fromHtml("<font>" +
                    temp[0]+" ["+temp[5]+"]  ￥"+temp[8]+"/"+temp[9]+" 数量:"+temp[10] + low +
                    "</font><br><font color=\'blue\'><B>" +
                    att+temp[7]+" ※ "+temp[15]+
                    "</B></font><br><font color='#f02387'>"+
                    temp[13]+" "+temp[14]+"  (未出单)"+
                    "</font>"));

            if(temp[1].equals("退单")){
                b.setBackgroundResource(R.drawable.fangc);
            }
            else if(temp[1].equals("删除")){
                b.setBackgroundResource(R.drawable.fangb);
            }
            else if(temp[1].length()>0){    //其它失效商品
                b.setBackgroundResource(R.drawable.fangd);
            }
            else{
                b.setBackgroundResource(R.drawable.fanga);
            }
            //透明度 取值：0－255
            b.getBackground().setAlpha(200);

            return b;
        }

        //计算时间差
        private String howlong(String old) {
            String val = ">1day" ;
            try {
                SimpleDateFormat dfs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date begin = dfs.parse(old);
                Date now   = new Date();
                long time = (now.getTime() - begin.getTime()) / 1000;	// 除以1000是为了转换成秒

                long day = time / (24 * 3600);
                long hour = time % (24 * 3600) / 3600;
                long minute = time % 3600 / 60;
                //long second = time % 60 ;

                if(day==0){
                    String m = hour<10 ? "0"+hour : ""+hour ;
                    String n = minute<10 ? "0"+minute : ""+minute ;
                    val = m +":"+ n ;
                }
                //System.out.println("" + day + "天" + hour + "小时" + minute + "分"+ second + "秒");
            } catch (ParseException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return val ;
        }
    }
}