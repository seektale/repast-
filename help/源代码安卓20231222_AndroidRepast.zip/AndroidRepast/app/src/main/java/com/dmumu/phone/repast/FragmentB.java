package com.dmumu.phone.repast;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.dmumu.phone.repast.activity.CaptureActivity;

import java.util.ArrayList;

public class FragmentB extends Fragment {
    private static final String ARG_SECTION_NUMBER = "section_number";
    private ArrayList<String[]> arrayList=new ArrayList<String[]>();
    private TextView header,footer ;
    private ListView dishscroll = null;
    private MyAdater dishscrollAdater = new MyAdater();
    private Button godata, gonewlist, goscan;
    private String dishind,dishMount,dishname ;
    private SwipeRefreshLayout downRefresh = null;
    private boolean placeflag = true ;
    public FragmentB() {
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, 2);
        setArguments(args);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_two, container, false);

        downRefresh = (SwipeRefreshLayout)rootView.findViewById(R.id.swipelayout);
        downRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            public void onRefresh() {
                handler.sendEmptyMessageDelayed(4, 300);
            }
        });

        dishscroll = (ListView)rootView.findViewById(R.id.dishscroll);
        header = new TextView(rootView.getContext());
        header.setGravity(Gravity.CENTER);
        header.setTextSize(20);
        header.setTextColor(Color.BLUE);
        header.setText("待提交商品临时清单");

        footer = new TextView(rootView.getContext());
        footer.setGravity(Gravity.CENTER);
        footer.setTextSize(16);
        //footer.setTextColor(Color.BLUE);

        dishscroll.addHeaderView(header);
        dishscroll.addFooterView(footer);
        dishscroll.setAdapter(dishscrollAdater);
        dishscroll.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                placeflag = true ;
                if(event.getX()/v.getWidth()<0.9){ //太靠右点击不响应
                    placeflag = false ;
                }
                return false;
            }
        });
        dishscroll.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(placeflag) return ;
                if (position>0 && position<dishscroll.getCount()-1){
                    Object ob = dishscrollAdater.getItem(position);
                    dishind = ((String[])ob)[0];
                    dishMount = ((String[])ob)[5];
                    dishname = ((String[])ob)[2];
                    amountb().show();
                }
            }
        });

        goscan = (Button)rootView.findViewById(R.id.goscan);
        goscan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //打开扫描界面扫描条形码或二维码
                Intent openCameraIntent = new Intent(getActivity(),CaptureActivity.class);
                startActivityForResult(openCameraIntent, 0);
            }
        });

        gonewlist = (Button)rootView.findViewById(R.id.gonewlist);
        gonewlist.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                handler.sendEmptyMessage(4);
            }
        });

        godata = (Button)rootView.findViewById(R.id.godata);
        godata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //先刷新数据
                arrayList = mysql.readPreMenu(handler);
                if (arrayList==null || arrayList.size()==0){
                    Toast.makeText(getView().getContext(), "没有可用于提交的商品", Toast.LENGTH_SHORT).show();
                    return ;
                }
                dishscrollAdater.notifyDataSetChanged();
                Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        selDesk();
                    }
                });
                th.start();
            }
        });

        return rootView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data==null) return ;
        if (resultCode!=0) return ;

        String val = data.getStringExtra("result");
        String sp[] = val.split("#");
        if(sp.length==2){
            String col[] = { "num", "cla", "name", "price", "unit", "lock" };
            String where = "num='"+sp[0]+"'and name='"+sp[1]+"'";
            ArrayList<String[]> temparr = mysql.selSQLite(col, where, handler);

            if (temparr == null || temparr.size()==0){
                mysql.sendmsg(handler,true,"该商品信息不存在，可能需要同步菜谱：\n"+val);
                return;
            }

            mysql.pre(temparr.get(0),1,handler);
            //刷新未提交商品列表
            arrayList = mysql.readPreMenu(handler);
            dishscrollAdater.notifyDataSetChanged();
            return ;
        }

        String col[] = { "num", "cla", "name", "price", "unit", "lock" };
        String where = "ma='"+val+"'";
        ArrayList<String[]> temparr = mysql.selSQLite(col, where, handler);
        if (temparr == null || temparr.size()==0){
            mysql.sendmsg(handler,true,"通过 条行码/二维码 未找到商品\n可能需要同步菜谱：\n"+val);
            return;
        }

        mysql.pre(temparr.get(0),1,handler);
        //刷新未提交商品列表
        arrayList = mysql.readPreMenu(handler);
        dishscrollAdater.notifyDataSetChanged();

        // mysql.sendmsg(handler,true,"不能识别的信息格式：\n"+val);
    }

    public Handler handler=new Handler(){
        public void handleMessage(final Message msg){
            switch (msg.what){
                case 1 :
                    builder.create().show();
                    break;
                case 3 :
                    //显示提交商品后返回的错误信息
                    Bundle bundle = msg.getData();
                    AlertDialog.Builder bu = new AlertDialog.Builder(getView().getContext());
                    bu.setTitle("错误");
                    bu.setIcon(android.R.drawable.ic_dialog_info);
                    bu.setMessage(bundle.getString("msg"));
                    bu.setNegativeButton("确定", null);
                    bu.create().show();

                    //刷新未提交商品列表
                    arrayList = mysql.readPreMenu(handler);
                    dishscrollAdater.notifyDataSetChanged();
                    break;
                case 4 :
                    if(downRefresh.isRefreshing()) downRefresh.setRefreshing(false);

                    //刷新未提交商品列表 ,  Fragment显示时 MainActivity 调用
                    arrayList = mysql.readPreMenu(handler);
                    dishscrollAdater.notifyDataSetChanged();

                    break;
                case 100 :
                    mysql.showmsg(msg, getView().getContext());
                    break;
            }
            super.handleMessage(msg);
        }
    };

    private class MyAdater extends BaseAdapter {
        @Override
        public int getCount() {
            if (arrayList==null) return 0;
            return arrayList.size();
        }
        public void notifyDataSetChanged(){
            if (arrayList!=null && arrayList.size()>0){
                Double money=0d;
                for (String temp[] : arrayList){
                    money = money + Double.valueOf(temp[3]) * Double.valueOf(temp[5]);
                }
                footer.setText("商品条目数: "+getCount()+"       总金额: "+money);
            }
            else{
                if(footer!=null) footer.setText("");
            }
            super.notifyDataSetChanged();
        }
        @Override
        public Object getItem(int position) {
            return arrayList.get(position-1);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final String temp[]=arrayList.get(position);

            View v = LayoutInflater.from(FragmentB.this.getView().getContext()).inflate(R.layout.orderover, null);
            TextView b = v.findViewById(R.id.desdishx);
            TextView price = v.findViewById(R.id.desprice);

            //b.setText(temp[0]+" "+temp[2]+"["+temp[1]+"]\n￥: "+temp[3]+"  /"+temp[4]+"       数量:"+temp[5]);
            b.setGravity(View.TEXT_ALIGNMENT_TEXT_START);   //左对齐
            b.setTextColor(Color.BLACK);

            b.setBackgroundResource(R.drawable.fang);
            b.getBackground().setAlpha(180);
            b.setTextSize(15);
            b.setText(Html.fromHtml("<font><B>" +
                    temp[0]+" "+temp[2]+"["+temp[1]+"]" +
                    "</B></font><br><font color=\'blue\'>" +
                    "￥: "+temp[3]+"  /"+temp[4]+"</font>"));

            price.setTextColor(Color.BLACK);
            price.setText(Html.fromHtml("<font>数量："+temp[5]+"</font>"));
            return v;
        }
    }

    //修改预点数量选择对话框
    private AlertDialog amountb(){
        View v = LayoutInflater.from(getView().getContext()).inflate(R.layout.amountlayout, null);

        final EditText val;
        Button up,down;
        val =(EditText) v.findViewById(R.id.amount);
        val.setText(dishMount);
        val.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{
                    Double.valueOf(val.getText().toString());
                    val.setTextColor(Color.BLUE);
                }catch (Exception e){
                    val.setTextColor(Color.RED);
                }
            }
            public void afterTextChanged(Editable s) {}
        });
        up = (Button) v.findViewById(R.id.add);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return;
                }
                Double k = Double.valueOf(val.getText().toString());
                val.setText(k+1+"");
            }
        });
        down = (Button) v.findViewById(R.id.del);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return;
                }
                Double k = Double.valueOf(val.getText().toString());
                if (k-1>=0){
                    val.setText(k-1+"");
                }
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(getView().getContext());
        builder.setTitle(dishname);
        builder.setView(v);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Double k = Double.valueOf(val.getText().toString());
                mysql.updatePreMenu(dishind, k, handler);
                handler.sendEmptyMessage(4);
            }
        });
        builder.setNeutralButton("删除", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mysql.clearPreMenu(dishind,handler);
                handler.sendEmptyMessage(4);
            }
        });
        builder.setNegativeButton("返回", null);

        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);
        return Dia;
    }

    private AlertDialog.Builder builder;
    //台号选择
    private void selDesk(){
        builder = new AlertDialog.Builder(getView().getContext());
        builder.setTitle("已开台列表,请选择");
        builder.setIcon(android.R.drawable.ic_dialog_info);

        final ArrayList<String[]> arr = mysql.sel("select desk.区域,desk.台号,desk.前辍,desk.别名,deskgo.台次 from desk left join deskgo " +
                "on desk.`区域`=deskgo.`区域` and desk.台号=deskgo.台号 and desk.`操作时间`=deskgo.`开台时间` " +
                "where desk.状态='已开台' order by desk.前辍,desk.台号 ;",handler);
        if (arr == null) return;

        String temp[]=new String[arr.size()];
        for (int k=0; k<arr.size(); k++) {
            String desknum = arr.get(k)[1];
            desknum = desknum.length()==1 ? "0"+desknum : desknum;
            desknum = arr.get(k)[2]+desknum;
            temp[k]=arr.get(k)[0]+"  "+desknum;
            if(!arr.get(k)[4].isEmpty()) temp[k]=temp[k]+"  台次:"+arr.get(k)[4];
            temp[k]=temp[k]+"  "+arr.get(k)[3];
        }
        builder.setItems(temp, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, final int which) {
                final String meal = arr.get(which)[4];
                Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        submitDish(meal);
                    }
                });
                th.start();
            }
        });
        //第一个按扭
        builder.setPositiveButton("吧台提交", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Thread th = new Thread(new Runnable() {
                    public void run() {
                       submitDishbar();  //提交到吧台的商品其台次为 0
                    }
                });
                th.start();
            }
        });
        builder.setNegativeButton("取消返回", null);
        handler.sendEmptyMessage(1);
    }

    //提交商品
    private void submitDish(String meal){
        ArrayList<String[]> arr = mysql.readPreMenu(handler);
        for (String temp[] : arr){
            //初始化参数
            ArrayList<String> val=new ArrayList<String>();
            val.add(meal);	        //餐次
            val.add(temp[0]);		//菜品编号
            val.add(temp[5]);	    //数量
            val.add(temp[3]);		//价格
            String res = mysql.pro("dish_order_init",val,handler);

            if (res.contains("点单成功")){
                //删除数据
                mysql.clearPreMenu(temp[0], handler);
                //存储过程会显示结果，这里同步刷新一下
                handler.sendEmptyMessage(4);
                continue;
            }

            //以对话框方式显示返回的错误消息
            Message m=new Message();
            Bundle bundle=new Bundle();
            bundle.putString("msg",res);
            m.setData(bundle);
            m.what=3;
            handler.sendMessage(m);
            //提交失败则结束
            break;
        }
    }

    //提交商品, 专门用于提交到吧台, 和上面的略有区别
    private void submitDishbar(){
        ArrayList<String[]> arr = mysql.readPreMenu(handler);
        for (String temp[] : arr){
            //初始化参数
            ArrayList<String> val=new ArrayList<String>();
            val.add("0");	        //餐次
            val.add(temp[0]);		//菜品编号
            val.add(temp[5]);	    //数量
            val.add(temp[3]);		//价格
            val.add("Android终端提交");
            String res = mysql.pro("dish_order", val, handler);

            if (res.contains("点单成功")){
                //删除数据
                mysql.clearPreMenu(temp[0], handler);
                //存储过程会显示结果，这里同步刷新一下
                handler.sendEmptyMessage(4);
                continue;
            }

            //以对话框方式显示返回的错误消息
            Message m=new Message();
            Bundle bundle=new Bundle();
            bundle.putString("msg",res);
            m.setData(bundle);
            m.what=3;
            handler.sendMessage(m);
            //提交失败则结束
            break;
        }
    }
}