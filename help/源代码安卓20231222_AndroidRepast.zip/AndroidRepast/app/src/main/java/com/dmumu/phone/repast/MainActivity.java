package com.dmumu.phone.repast;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.Toast;
import java.io.File;
import java.lang.reflect.Field;
import java.util.Locale;

public class MainActivity extends ActionBarActivity {
    private SectionsPagerAdapter mSectionsPagerAdapter;
    private ProgressDialog pro ;
    private SharedPreferences share ;
    public static ViewPager mViewPager;
    public static String macaddress;
    private Button downa,downb,downc,downd;
    public void onConfigurationChanged(Configuration newConfig){
        super.onConfigurationChanged(newConfig);
        //横竖屏切换时调用
        //AndroidManifest.xml 中配置：android:configChanges"
    }

    //只运行一次
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //actionBar浮动起来，在上一层，这里不要这么做，否则台号在里层，不方便操作
        supportRequestWindowFeature(Window.FEATURE_ACTION_BAR_OVERLAY);

        //<!-- 防止手机休眠,如在同步更新菜单时间太长，应该阻止休眠发生 -->
        //要加在setContentView(R.layout.main)之前,已证实有效果,但不保证所有手机有效果
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);
        share = getSharedPreferences("val", Context.MODE_PRIVATE);

        //下面的是关键，它让菜单的三个点一直显示，如果不加,则有物理menu按键的手机将不显示
        try{
            ViewConfiguration mconfig = ViewConfiguration.get(this);
            Field menukeyField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
            if(menukeyField != null) {
                menukeyField.setAccessible(true);
                menukeyField.setBoolean(mconfig,false);
            }
        }
        catch (Exception e){}

        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        mViewPager = findViewById(R.id.pager);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}
            public void onPageSelected(int position) {
                if(position==0){
                    downa.setTextColor(Color.BLUE);
                    downc.setTextColor(Color.BLACK);
                    downd.setTextColor(Color.BLACK);
                }
                else if(position==1){
                    downd.setTextColor(Color.BLUE);
                    downa.setTextColor(Color.BLACK);
                    downc.setTextColor(Color.BLACK);
                }
                else if(position==2){
                    downc.setTextColor(Color.BLUE);
                    downa.setTextColor(Color.BLACK);
                    downd.setTextColor(Color.BLACK);
                }

                if(position==1){
                    mSectionsPagerAdapter.BB.handler.sendEmptyMessage(4);
                }

                if(position==0){
                    //从上到下的动画
                    AnimationSet animationSet = new AnimationSet(true);
                    TranslateAnimation translateAnimation = new TranslateAnimation
                            (Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,-1f, Animation.RELATIVE_TO_SELF,0f);
                    translateAnimation.setDuration(400);
                    animationSet.addAnimation(translateAnimation);
                    ((ViewGroup)getWindow().findViewById(R.id.action_bar_container)).startAnimation(animationSet);

                    ((ViewGroup)getWindow().findViewById(R.id.action_bar_container)).setVisibility(View.VISIBLE);
                    return;
                }

                if(((ViewGroup)getWindow().findViewById(R.id.action_bar_container)).isShown()==false)  return ;

                AnimationSet animationSet = new AnimationSet(true);
                TranslateAnimation translateAnimation = new TranslateAnimation
                        (Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,-1f);
                translateAnimation.setDuration(400);
                animationSet.addAnimation(translateAnimation);
                ((ViewGroup)getWindow().findViewById(R.id.action_bar_container)).startAnimation(animationSet);

                ((ViewGroup)getWindow().findViewById(R.id.action_bar_container)).setVisibility(View.GONE);
            }
            public void onPageScrollStateChanged(int state) {}
        });

        try {
            //jar驱动放在项目的bins目录下即可
            Class.forName("com.mysql.jdbc.Driver");
            Log.i("MainActivity", "加载数据库驱动ok");
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
            Log.i("MainActivity", "加载数据库驱动异常");
        }

        mysql.path = getExternalFilesDir(null).getPath();
        Log.i("存储目录:",mysql.path);
        // getFilesDir()：它返回你app所在的内部存储器的目录结构 。
        // getCacheDir()：它返回你app临时缓存文件的内部存储器的目录结构

        //如果程序又被onCreate()说明是因为内存不足导致Activity被回收，但回收也使的很多变量变成了null,继续进行会因为空指针而闪退
        //解决方法就是结束当前的Activity,并重新启动这个Activity
        if(savedInstanceState != null){
            Intent intent = getIntent();
            finish();
            startActivity(intent);
            return ;
        }

        downa =  (Button)findViewById(R.id.downa);
        downa.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(mViewPager.getCurrentItem()==0) {
                    //弹出菜单前回到第一页面，否则如果不在第一页面登陆时会闪退
                    mSectionsPagerAdapter.AA.getarea(); //显示区域选择菜单
                    return;
                }
                mViewPager.setCurrentItem(0);
                if(mysql.account.isEmpty() || mysql.password.isEmpty()) return;
                Toast.makeText(MainActivity.this, "自动刷新卡台", Toast.LENGTH_SHORT).show();
                mSectionsPagerAdapter.AA.handler.sendEmptyMessage(1);   //刷新
            }
        });
        downb =  (Button)findViewById(R.id.downb);
        downb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MenuImg.class);
                startActivity(intent);
            }
        });
        downc =  (Button)findViewById(R.id.downc);
        downc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mViewPager.setCurrentItem(2);
            }
        });
        downd =  (Button)findViewById(R.id.downd);
        downd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mViewPager.setCurrentItem(1);
            }
        });

        final Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, LogonActivity.class);
                //startActivity(intent);
                startActivityForResult(intent, 1);
            }
        });
        th.start();
        macaddress = getMacAddress();
    }

    //最上面的时间栏的显示和隐藏
    private void updateFullscreenStatus(Boolean bUseFullscreen){
        if(bUseFullscreen){
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        }
        else{
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    //onSaveInstanceState是在OnStop之前执行，这里要标记一下、以便在onCreate()中识别
    public void onSaveInstanceState(Bundle outState){
        outState.putBoolean("flag",true);
        super.onSaveInstanceState(outState);
    }
    //onRestoreInstanceState在OnStart后执行
    public void onRestoreInstanceState(Bundle outState){
        super.onRestoreInstanceState(outState);
    }
    //程序进入后台后，如果内存不足，资源会被回收，再次回到前台时，很多变量会变为null，如:mSectionsPagerAdapter.AA，程序会闪退
    //谷歌有保存状态的方法，但改程序很烦，折中方案是在程序进入后台时直接结束程序，但后果是每次进入程序都要进行登陆操作

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data==null) return ;
        if (resultCode!=1) return ;

        String val = data.getStringExtra("username");
        if (val!=null) setTitle(mysql.account+"@"+val);

        int ver = data.getIntExtra("menuversion",0);
        int verlocal = share.getInt("menuversion",0);
        if(ver > verlocal){
            AlertDialog.Builder dialog=new AlertDialog.Builder(this);
            dialog.setTitle("重要通知：");
            dialog.setMessage("菜谱已有新内容,需要更新菜谱\n请及时更新\n");
            dialog.setPositiveButton("唉！知道了",null);
            dialog.show();
            return;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.cho) {
            Intent intent = new Intent(this, LogonActivity.class);
            intent.putExtra("auto", false);
            //startActivity(intent);
            startActivityForResult(intent, 1);
            return true;
        }

        if (id == R.id.slip) {
            Intent intent = new Intent(this, MenuImgSlip.class);
            startActivity(intent);
            return true;
        }

        if (id == R.id.syn) {
            if(checknet()) return true; //检查网络
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("同步完成后[临时清单]会清空,请重起程序\n\n将占用数分钟或更长时间及一定存储空间\n\n我们建意您在WIFI网络下进行同步\n");
            builder.setTitle("商品及图片同步");
            //第一个按扭
            builder.setPositiveButton("确定同步", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    pro= ProgressDialog.show(MainActivity.this, "消息", "正在同步 ... ", true);
                    Thread th = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            mysql.synmenu(handler, share);
                            pro.dismiss();
                        }
                    });
                    th.start();
                }
            });
            //第二个按扭
            builder.setNegativeButton("取消返回", null);
            builder.create().show();
            return true;
        }

        if (id == R.id.clear) {
            AlertDialog.Builder dialog=new AlertDialog.Builder(this);
            dialog.setTitle("警告");
            dialog.setMessage("确定清除缓存吗 ？");
            dialog.setPositiveButton("确定清除", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    File f = new File(mysql.path+"/repastdir");
                    if (f.isDirectory()){
                        File[] childFiles = f.listFiles();
                        if(childFiles!=null && childFiles.length>0){
                            for(File temp : childFiles){
                                temp.delete();
                            }
                        }
                    }
                    AlertDialog.Builder dia=new AlertDialog.Builder(MainActivity.this);
                    dia.setTitle("清除缓存");
                    dia.setPositiveButton("OK", null);
                    dia.setMessage("缓存数据已清除，请重新同步菜谱或同步图片");
                    dia.show();
                }
            });
            dialog.setNegativeButton("取消", null);
            dialog.show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //检查网络
    private boolean checknet(){
        ConnectivityManager con = (ConnectivityManager)getSystemService(Activity.CONNECTIVITY_SERVICE);
        boolean wifi = con.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isConnectedOrConnecting();
        boolean internet = con.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isConnectedOrConnecting();
        if( wifi==false && internet==false ){
            Toast.makeText(this, "没有网络连接，请先连接网络。", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }
    public boolean onKeyDown(int keyCode,KeyEvent event){
        if(keyCode== KeyEvent.KEYCODE_BACK){
            int k = mViewPager.getCurrentItem();
            if(k == 0){
                dialog();
                return true;
            }
            mViewPager.setCurrentItem(k-1);
            return true;
        }
        //if(keyCode==KeyEvent.KEYCODE_MENU){
            //Intent intent = new Intent(MainActivity.ins, srcAct.class);
        //}
        return super.onKeyDown(keyCode,event);
    }

    public Handler handler=new Handler(){
        public void handleMessage(Message msg){
            switch (msg.what){
                case 1 :
                    mViewPager.setCurrentItem(1);
                    break;
                case 2 :

                    AlertDialog.Builder dialog=new AlertDialog.Builder(MainActivity.this);
                    dialog.setTitle("网络错误");
                    dialog.setPositiveButton("OK", null);
                    dialog.setMessage("与数据库通信时出现了错误。");
                    dialog.show();

                    break;
                case 3 :
                    mViewPager.setCurrentItem(2);
                    break;
                case 6 :
                    //图片同步进度显示
                    if (pro!=null){
                        pro.setTitle(mysql.ImgMsg);
                    }
                    break;
                case 7 :
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("同步已完成，需要重起程序。\n");
                    builder.setTitle("重起");
                    //第一个按扭
                    builder.setPositiveButton("手动重新起动程序", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            MainActivity.this.finish();
                        }
                    });
                    builder.create().show();
                    break;
                case 100 :
                    mysql.showmsg(msg, MainActivity.this);
                    break;
            }
            super.handleMessage(msg);
        }
    };

    private void dialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("确定退出吗？");
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setTitle("退出");
        //第一个按扭
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //dialog.dismiss();
                //finish();
                System.exit(0);
            }
        });
        //第二个按扭
        builder.setNegativeButton("取消", null);
        //第三个按扭
        //builder.setNeutralButton("",null);
        builder.create().show();
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {
        private FragmentManager fm;
        FragmentA AA = new FragmentA() ;
        FragmentB BB = new FragmentB() ;
        FragmentC CC = new FragmentC() ;
        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
            this.fm=fm;
        }
        public Fragment getItem(int position) {
            if(position==0){
                return AA;
            }
            if(position==1){
                return BB;
            }
            if(position==2){
                return CC;
            }
            return null;
        }
        public int getCount() {
            return 3;
        }
        public CharSequence getPageTitle(int position) {
            Locale l = Locale.getDefault();
            switch (position) {
                case 0:
                    return getString(R.string.title_section1).toUpperCase(l);
                case 1:
                    return getString(R.string.title_section2).toUpperCase(l);
                case 2:
                    return getString(R.string.title_section3).toUpperCase(l);
            }
            return null;
        }

        //显示目标 Fragment
        public Fragment instantiateItem(ViewGroup container, int position){
            Fragment fragment=(Fragment)super.instantiateItem(container, position);
            fm.beginTransaction().show(fragment).commit();
            return fragment;
        }

        //关闭 Fragment
        public void destroyItem(ViewGroup container, int position, Object object){
            //super.destroyItem(container, position, object);
            //使用下面的方法可以保存后台Fragment的状态
            Fragment fragment=getItem(position);
            fm.beginTransaction().hide(fragment).commit();
        }
    }

    /*************************************************************************************************************/

    /**
     * .获取手机MAC地址
     *  只有手机开启wifi才能获取到mac地址
     */
    private String getMacAddress(){
        String result = "";
        WifiManager wifiManager = (WifiManager)getSystemService(Context.WIFI_SERVICE);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        result = wifiInfo.getMacAddress();
        Log.i("text", " 手机macAdd:" + result);
        return  " 手机macAdd:" + result;
    }
}


/*
1、将jar包放入项目里的libs文件夹中。
2、在project选中jar包点击右键"Add as library"。
3、这两步是网上比较容易找到的，但此时项目仍然是无法正常编译的，这时需要在项目的build.gradle文件里的dependencies节加入 dependencies
{
        compile files('libs/android-support-v4.jar')
       compile files('libs/xxxx.jar')
}
4、此时项目正常编译并运行了，但当你的代码中真正创建了引用jar里的类实例时，有可能系统会抛出异常NoClassDefFoundError，这个时候可以按以下步骤操作：

 进入命令提示符窗口。
 定位到项目的根目录，即build.gradle所在的目录。
 运行 "{android studio 安装目录}\sdk\tools\templates\gradle\wrapper\gradlew.bat" clean
  重新编译运行项目

通过以上操作，应该可以解决问题。
 */