package com.dmumu.phone.repast;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.dmumu.phone.repast.R.id.linearThree;

public class MenuList extends Activity {
    private ArrayList<String[]> arrayList=new ArrayList<String[]>();
    public SearchView edit;
    private ListView listView;
    private PopupWindow menu;
    private int meal = 0;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_three);
        getWindow().setBackgroundDrawableResource(R.drawable.bg);

        //接收传过来的数据
        Intent intent = getIntent();
        meal = intent.getIntExtra("mealnum",0);

        listView = (ListView)findViewById(linearThree);
        listView.setAdapter(new MyAdater());
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //edit.clearFocus();  //使其失去焦点，以免其自动弹出软键盘
                //mysql.amount(view.getContext(), arrayList.get(position), handler).show();
                amount(arrayList.get(position)).show();
            }
        });
        listView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                edit.clearFocus();  //使其失去焦点，以免其自动弹出软键盘
                return false;
            }
        });

        edit=(SearchView)findViewById(R.id.order);
        edit.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                initDB();
                return false;
            }
        });

        Button lookmenu = (Button)findViewById(R.id.lookmenu);
        lookmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.clearFocus();  //失去焦点，这样可以隐藏软键盘
                menu.showAtLocation(v, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0);
            }
        });

        /************************************************************************************************************/

        ListView menuView =new ListView(this);
        menu = new PopupWindow(menuView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        menu.setFocusable(true);
        menu.setOutsideTouchable(true);
        menu.update();
        menu.setBackgroundDrawable(new AnimationDrawable());   //没有这一句会使菜单外点击时菜单不消失
        menu.setAnimationStyle(R.style.popwin_anim_style2);
        //menu.setAnimationStyle(R.anim.menushow2);

        final ArrayList<String[]> arrss = mysql.selSQLitelook(handler);
        menuView.setAdapter(new lookAdater(arrss));
        menuView.setBackgroundColor(Color.WHITE);
        menuView.getBackground().setAlpha(230);
        menuView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                edit.clearFocus();  //失去焦点，这样可以隐藏软键盘,老是弹出很烦人
                menu.dismiss();
                String col[] = { "num", "cla", "name", "price", "unit", "lock" };
                String where = "cla='"+arrss.get(position)[0]+"'";
                arrayList = mysql.selSQLite(col, where, handler);
                if (arrayList != null){
                    ((MyAdater)listView.getAdapter()).notifyDataSetChanged(); //更新数据
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //返回到上一个Activity
        if (id == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //进入后台长时不显示时，这个最好关掉,红米上实测证明：按home键一到后台就会执行,再点开时，界面已关闭
    //之所以关闭掉是因为：如果长时间在后台，系统回收了内存资源，再回到这个程序时，很容易闪退，所以干脆关掉
    public void onStop(){
        super.onStop();
        finish();
    }

    private class lookAdater extends BaseAdapter {
        private ArrayList<String[]> arr =new ArrayList<>();
        private lookAdater(ArrayList<String[]> arr){
            if(arr!=null)   this.arr=arr;
        }
        public int getCount() {
            return arr.size();
        }
        public Object getItem(int position) {
            return arr.get(position);
        }
        public long getItemId(int position) {
            return position;
        }
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView text = new TextView(MenuList.this);
            text.setText("["+(position+1)+"]"+arr.get(position)[0]+"  --  数量:"+arr.get(position)[1]);
            text.setTextSize(18);
            text.setGravity(Gravity.CENTER);
            text.setPadding(0,10,0,10);
            return text;
        }
    }
    /************************************************************************************************************/


    public Handler handler=new Handler(){
        public void handleMessage(Message msg){
            switch (msg.what){
                //显示点单错误信息
                case 3 :
                    Bundle bundle=msg.getData();
                    String temp=bundle.getString("msg");
                    Toast.makeText(MenuList.this, temp, Toast.LENGTH_SHORT).show();
                    break;
                //以对话框的形式显示点单错误信息
                case 4 :
                    Bundle bundles = msg.getData();
                    AlertDialog.Builder bu = new AlertDialog.Builder(MenuList.this);
                    bu.setTitle("错误");
                    bu.setIcon(android.R.drawable.ic_dialog_info);
                    bu.setMessage(bundles.getString("msg"));
                    bu.setNegativeButton("确定", null);
                    bu.create().show();
                    break;
                case 100 :
                    mysql.showmsg(msg, MenuList.this);
                    break;
            }
            super.handleMessage(msg);
        }
    };

    private void initDB(){
        String co[] = { "count(*)" };
        ArrayList<String[]> temp = mysql.selSQLite(co, null, handler);
        if (temp == null){
            Toast toast = Toast.makeText(MenuList.this, "查询本地缓存表返回空指针，结果有误", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER| Gravity.CENTER, 0, 0);
            toast.show();
            return;
        }
        if (Integer.valueOf(temp.get(0)[0])==0){
            Toast toast = Toast.makeText(MenuList.this, "没有缓存本地菜谱，请先同步菜谱", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER| Gravity.CENTER, 0, 0);
            toast.show();
            return;
        }

        String help=edit.getQuery().toString().trim();
        if (help.isEmpty()) help="<不显示商品信息〉";

        String col[] = { "num", "cla", "name", "price", "unit", "lock" };
        String where = "help like '%"+help+"%' or name like '%"+help+"%' or num like '%"+help+"%'";
        arrayList = mysql.selSQLite(col, where, handler);

        if (arrayList != null){
            ((MyAdater)listView.getAdapter()).notifyDataSetChanged(); //更新数据
        }
    }

    //点单时，数量选择对话框
    private AlertDialog amount(final String temp[]){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(temp[2]);
        String dishnum[] = new String[5];
        for (int k = 0 ; k<5; k++){
            dishnum[k]="点单数量   "+(k+1)+" "+temp[4] + "     ￥" + Double.valueOf(temp[3])*(k+1);
        }
        builder.setItems(dishnum, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, final int which) {
                //mysql.pre(temp,which+1,handler);
                Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        submitdish(which+1,temp);
                    }
                });
                th.start();
            }
        });
        builder.setNegativeButton("取消", null);

        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);

        return Dia;
    }
    //连接数据库存必须以线程方式操作
    private void submitdish(int amount, String temp[]){
        //初始化参数
        ArrayList<String> val=new ArrayList<String>();
        val.add(meal+"");	     //餐次
        val.add(temp[0]);		//菜品编号
        val.add(amount+"");	    //数量
        val.add(temp[3]);		//价格

        String res = mysql.pro("dish_order_init", val, handler);

        if (res.contains("点单成功")){
            //存储过程会显示结果
            return ;
        }

        //以对话框方式显示返回的错误消息
        Message m=new Message();
        Bundle bundle=new Bundle();
        bundle.putString("msg",res);
        m.setData(bundle);
        m.what=4;
        handler.sendMessage(m);
    }

    private class MyAdater extends BaseAdapter {
        @Override
        public int getCount() {
            if (arrayList==null) return 0;
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return arrayList.get(position-1);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final String temp[] = arrayList.get(position);

            TextView b=new TextView(MenuList.this.getBaseContext());
            b.setText(temp[0]+" "+temp[2]+"["+temp[1]+"]\n￥: "+temp[3]+"   /"+temp[4]);
            b.setGravity(View.TEXT_ALIGNMENT_TEXT_START);    //左对齐
            b.setTextSize(18);
            b.setTextColor(Color.BLACK);
            b.setBackgroundResource(R.drawable.ying);
            //透明度 取值：0－255
            b.getBackground().setAlpha(220);
            //放在这里才有效，注意位置

            //从右到左滑出的动画
            AnimationSet animationSet = new AnimationSet(true);
            TranslateAnimation translateAnimation = new TranslateAnimation
                    (Animation.RELATIVE_TO_SELF,1f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f);
            translateAnimation.setDuration(300);
            animationSet.addAnimation(translateAnimation);
            b.startAnimation(animationSet);

            return b;
        }
    }
}