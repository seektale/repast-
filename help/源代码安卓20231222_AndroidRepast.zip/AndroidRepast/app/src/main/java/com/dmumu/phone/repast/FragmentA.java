package com.dmumu.phone.repast;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.dmumu.phone.repast.R.id.linearOne;

public class FragmentA extends Fragment {
    private ArrayList<String[]> arrayList=new ArrayList<>();
    private GridView listView ;
    private MyAdater listAdater = new MyAdater();
    private SwipeRefreshLayout downRefresh = null;
    public static String area="";
    private int flaglong = 0 ;

    public PopupWindow menu;
    private ArrayList<String> vallist = new ArrayList<>();
    private ArrayList<String> vallisttemp = new ArrayList<>();
    private ArrayList<String> booking = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater,container,savedInstanceState);

        View rootView = inflater.inflate(R.layout.fragment_one, container, false);
        //rootView.setBackgroundResource(R.drawable.bg);

        downRefresh = (SwipeRefreshLayout)rootView.findViewById(R.id.swipelayout);
        downRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                handler.sendEmptyMessageDelayed(1, 500);
            }
        });

        listView = (GridView)rootView.findViewById(linearOne);

        listView.setAdapter(listAdater);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(flaglong==1){
                    flaglong = 0 ;
                    return ;
                }

                String temp[] = arrayList.get(position);
                if (temp[5].isEmpty() || temp[5].equals("0")){
                    deskStart(view, temp[1], temp[2], temp[3], temp[4]);
                    return ;
                }

                //显示另一个Activity
                Bundle bundle = new Bundle();
                bundle.putString("meal", temp[5]);
                bundle.putString("area",temp[1]);
                bundle.putString("desk",temp[2]);
                bundle.putString("alias",temp[4]);
                bundle.putString("emp",temp[7]);
                bundle.putString("gotime",temp[8]);

                Intent intent = new Intent(getActivity(), Dishlist.class);
                intent.putExtra("val", bundle);
                startActivity(intent);
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                flaglong = 1 ;

                //只响应已开台
                String temp[] = arrayList.get(position);
                if (temp[5].isEmpty() || temp[5].equals("0")){
                    return false;
                }

                //振动
                Vibrator vib = (Vibrator)FragmentA.this.getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                //long [] pattern = {100,400,100,400};   // 停止 开启 停止 开启
                vib.vibrate(100);

                deskoper(view,temp[5]);
                return false;
            }
        });

        /********************************************************************************************************/

        //初始化区域选择菜单
        //LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //View menuView = (View) inflater.inflate(R.layout.menulayout, null, true);//弹出窗口包含的视图
        //menu = new PopupWindow(menuView, LayoutParams.FILL_PARENT,238, true);//创建弹出窗口，指定大小

        ListView menuView =new ListView(getActivity());
        //menu = new PopupWindow(menuView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        menu = new PopupWindow(menuView, 360, WindowManager.LayoutParams.WRAP_CONTENT);
        menu.setAnimationStyle(R.style.popwin_anim_style);      //设置窗口显示的动画效果
        //menu.showAsDropDown(menuView);
        //menu.showAsDropDown(null,0,menuView.getHeight());

        /* 这四条可以保证点击其它地方会自动消失 */
        //使其聚焦
        menu.setFocusable(true);
        //设置允许在外点击消息
        menu.setOutsideTouchable(true);
        //刷新状态
        menu.update();
        //必须设置背景，这样点back键和其它地方使其消失，设置了这个才能触发OnDismisslistener，设置其它控件变化等操作
        //menu.setBackgroundDrawable(new BitmapDrawable()); 方法已过时，使用下面的方法
        //menu.setBackgroundDrawable(new BitmapDrawable(Resources.getSystem(),"")); 会报目录错误
        //得到一个空图片
        Bitmap nullbit = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        Drawable front = new BitmapDrawable(null,nullbit);
        menu.setBackgroundDrawable(front);

        menuView.setAdapter(new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,vallist));
        menuView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                menu.dismiss();
                area = vallist.get(position);
                handler.sendEmptyMessage(1);
            }
        });
        menuView.setBackgroundColor(Color.WHITE);
        menuView.getBackground().setAlpha(230);

        //menu.setAnimationStyle(R.style.popwin_anim_style);        //设置窗口显示的动画效果
        //menu.showAtLocation(mViewPager, Gravity.BOTTOM, 0, 0);    //设置窗口显示的位置
        //menu.update();
        //WebView s=new WebView(null);

        /********************************************************************************************************/

        return rootView;
    }

    public void getarea(){
        if (vallisttemp.size()>0){
            handler.sendEmptyMessage(3);
            return;
        }

        //查询区域信息
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<String[]> arr = mysql.sel("select distinct 区域 from desk order by 前辍;",handler);
                //如果连接数据库失败，则arr为null
                if (arr == null)    return;

                //vallist的更新必须在主线程中进行
                for (String temp[] : arr){
                    vallisttemp.add(temp[0]);
                }
                vallisttemp.add("★ 全部区域");
                vallisttemp.add("★ 所有已开");
                vallisttemp.add("★ 临时挂起");
                handler.sendEmptyMessage(3);
            }
        });
        th.start();
    }

    //卡台操作
    private void deskoper(final View view, final String mealnum){
        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
        String stat[] = new String[]{"并 台","并 台 取 消","换 台","挂 起","复 台"};
        builder.setSingleChoiceItems(stat, -1, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int which) {
                if (which==0){
                    Thread th =new Thread(new Runnable() {
                        public void run() {
                            String sql="SELECT 台次,deskgo.区域,concat(desk.`前辍`,LPAD(deskgo.台号,2,'0')) as 台号,desk.`别名` " +
                                    "FROM deskgo JOIN desk ON deskgo.`开台时间`=desk.`操作时间` ORDER BY desk.`前辍`,desk.`台号`";
                            final ArrayList<String[]> arr = mysql.sel(sql,handler);
                            if(arr==null) return ;
                            //跳入UI线程中
                            ((Activity) view.getContext()).runOnUiThread(new Runnable() {
                                public void run() {
                                    uniondesk(mealnum, arr);
                                }
                            });
                        }
                    });
                    th.start();
                }
                if (which==1){
                    Thread th =new Thread(new Runnable() {
                        public void run() {
                            String sql = " select DISTINCT 台次 from dishlog WHERE 动作='并台' AND locate('台次:"+mealnum+"',`说明`)>0 ";
                            ArrayList<String[]> arr = mysql.sel(sql, handler);
                            if(arr==null) return ;
                            if(arr.size()==0){
                                //跳入UI线程中
                                ((Activity) view.getContext()).runOnUiThread(new Runnable() {
                                    public void run() {
                                        Toast.makeText(FragmentA.this.getView().getContext(), "没有并台记录,操作无效", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                            if(arr.size()==1){
                                ArrayList<String> v=new ArrayList<>();
                                v.add(mealnum);
                                v.add(arr.get(0)[0]);
                                mysql.pro("desk_union_cancel", v, handler);
                                handler.sendEmptyMessage(1);
                            }
                            if(arr.size()>1){
                                //跳入UI线程中
                                ((Activity) view.getContext()).runOnUiThread(new Runnable() {
                                    public void run() {
                                        Toast.makeText(FragmentA.this.getView().getContext(), "并台记录过多,请在电脑终端操作", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                    });
                    th.start();
                }
                if (which==2){
                    Thread th =new Thread(new Runnable() {
                        public void run() {
                            String sql="select 区域,concat(前辍,LPAD(台号,2,'0')) as 台号,别名,状态 from desk where 状态='空台' order by 前辍,台号;" ;
                            final ArrayList<String[]> arr = mysql.sel(sql,handler);
                            if(arr==null) return ;
                            //跳入UI线程中
                            ((Activity) view.getContext()).runOnUiThread(new Runnable() {
                                public void run() {
                                    chdesk(mealnum, arr);
                                }
                            });
                        }
                    });
                    th.start();
                }
                if (which == 3){
                    Thread th =new Thread(new Runnable() {
                        public void run() {
                            ArrayList<String> list=new ArrayList<>();
                            list.add(mealnum);
                            mysql.pro("bill_updesk", list, handler);
                            handler.sendEmptyMessage(1);
                        }
                    });
                    th.start();
                }
                if (which == 4){
                    Thread th =new Thread(new Runnable() {
                        public void run() {
                            ArrayList<String> list=new ArrayList<>();
                            list.add(mealnum);
                            mysql.pro("bill_redesk", list, handler);
                            handler.sendEmptyMessage(1);
                        }
                    });
                    th.start();
                }
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("取消", null);
        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);
        Dia.show();
    }

    //并台
    private void uniondesk(final String mealnum, final ArrayList<String[]> arr){
        AlertDialog.Builder builder = new AlertDialog.Builder(this.getView().getContext());
        builder.setTitle("并台 请选择目标卡台");
        String stat[] = new String[arr.size()];
        for(int m=0; m<arr.size(); m++){
            stat[m] = new String();
            for(int n=0; n<arr.get(m).length; n++){
                stat[m]=stat[m]+arr.get(m)[n]+" ";
            }
        }
        builder.setSingleChoiceItems(stat, -1, new DialogInterface.OnClickListener(){
            public void onClick(final DialogInterface dialog, final int which) {
                Thread th =new Thread(new Runnable() {
                    public void run() {
                        dialog.dismiss();
                        ArrayList<String> v=new ArrayList<>();
                        v.add(arr.get(which)[0]);		//目标台次
                        v.add(mealnum);					//源台次
                        mysql.pro("desk_union", v, handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
            }
        });

        builder.setNegativeButton("取消", null);
        AlertDialog Dia=builder.create();
        Dia.show();
    }

    //换台
    private void chdesk(final String mealnum, final ArrayList<String[]> arr){
        AlertDialog.Builder builder = new AlertDialog.Builder(this.getView().getContext());
        builder.setTitle("换台 请先选择空台");
        String stat[] = new String[arr.size()];
        for(int m=0; m<arr.size(); m++){
            stat[m] = new String();
            for(int n=0; n<arr.get(m).length; n++){
                if(n==2 && !arr.get(m)[n].isEmpty()) stat[m]=stat[m]+" # ";
                stat[m]=stat[m]+arr.get(m)[n]+" ";
            }
        }
        builder.setSingleChoiceItems(stat, -1, new DialogInterface.OnClickListener(){
            public void onClick(final DialogInterface dialog, final int which) {
                Thread th =new Thread(new Runnable() {
                    public void run() {
                        dialog.dismiss();
                        ArrayList<String> v=new ArrayList<>();
                        v.add(mealnum);
                        v.add(arr.get(which)[0]);
                        v.add(arr.get(which)[1]);
                        mysql.pro("desk_change", v, handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
            }
        });

        builder.setNegativeButton("取消", null);
        AlertDialog Dia=builder.create();
        Dia.show();
    }

    //开台
    private void deskStart(View view, final String area, final String desknum, final String head, final String alias){
        View v = LayoutInflater.from(view.getContext()).inflate(R.layout.amountlayout, null);
        final EditText val;
        Button up,down;
        val =(EditText) v.findViewById(R.id.amount);
        val.setText("1");
        //val.setEnabled(false); 最好允许输入
        val.setInputType(EditorInfo.TYPE_CLASS_NUMBER); //限制只能输入数字
        val.setTextColor(Color.BLUE);
        up = (Button) v.findViewById(R.id.add);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return ;
                }
                Integer k = Integer.valueOf(val.getText().toString());
                val.setText(k+1+"");

            }
        });
        down = (Button) v.findViewById(R.id.del);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return ;
                }
                Integer k = Integer.valueOf(val.getText().toString());
                if (k-1>=0){
                    val.setText(k-1+"");
                }
            }
        });
        up.setText("人数加");
        down.setText("人数减");

        //开始打开对话框
        final AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
        builder.setTitle(area+"  "+head+desknum+" # "+alias);
        final String stat[] = new String[]{"切换状态为:   空台","切换状态为:   脏台","切换状态为:   维修"};
        builder.setView(v);
        builder.setSingleChoiceItems(stat, -1, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int which) {
                //初始化参数
                final ArrayList<String> val=new ArrayList<String>();
                val.add(area);
                val.add(desknum);
                if (which==0) val.add("空台");
                if (which==1) val.add("脏台");
                if (which==2) val.add("维修");
                val.add("通过手机切换台号状态");
                Thread th =new Thread(new Runnable() {
                    @Override
                    public void run() {
                        mysql.pro("desk_station_shift",val,handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("取消", null);
        builder.setPositiveButton("开台", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                final ArrayList<String> arr=new ArrayList<String>();
                arr.add("0"); //开台餐次为0
                arr.add("");
                arr.add("");
                arr.add("0");
                arr.add(val.getText().toString());
                arr.add(""); //时段由存储过程自动判断
                arr.add("");
                arr.add("否");
                arr.add("");
                arr.add("");
                arr.add("通过手机APP开台");
                arr.add(area);
                arr.add(desknum);
                Thread th =new Thread(new Runnable() {
                    @Override
                    public void run() {
                        mysql.pro("desk_start",arr,handler);
                        handler.sendEmptyMessage(1);
                    }
                });
                th.start();
                dialog.dismiss();
            }
        });
        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);
        Dia.show();
    }

    public Handler handler=new Handler(){
        public void handleMessage(Message msg){
            switch (msg.what){
                case 1 :
                    //清空数据
                    arrayList = new ArrayList<>();
                    listAdater.notifyDataSetChanged();

                    Thread th=new Thread(new Runnable() {
                        @Override
                        public void run() {
                            initDB();
                        }
                    });
                    th.start();
                    break;
                case 2 :
                    if(downRefresh.isRefreshing()) downRefresh.setRefreshing(false);
                    if (arrayList==null) break;

                    if (arrayList!=null){
                        listAdater.notifyDataSetChanged(); //更新数据
                    }
                    break;
                case 3 :
                    //更新值
                    if(vallist.size()==0 && vallisttemp.size()>0){
                        for(String temp : vallisttemp)  vallist.add(temp);
                    }
                    //menu.showAtLocation(getView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
                    menu.showAtLocation(getView(), Gravity.BOTTOM | Gravity.LEFT, 0, 0);
                    break;
                case 100 :
                    mysql.showmsg(msg,getView().getContext());
                    break;
            }
            super.handleMessage(msg);
        }
    };

    //连接数据库必须以线程的方式，否则不能连接数据库
    private void initDB(){
        //排序中'前辍'可以保证餐区排序不会发生变动（只要前辍参数不变），deskgo.`开台工号` 目前这一列没有意义，备用吧
        String headsql = "select desk.状态,desk.区域,desk.台号,desk.`前辍`,desk.`别名`," +
                         "deskgo.`台次`,deskgo.`选择时段`,deskgo.`开台工号`,deskgo.`开台时间`,deskgo.锁台,deskgo.宾客人数,desk.状态说明 " +
                         "from desk LEFT JOIN deskgo on desk.`区域`=deskgo.`区域` and desk.台号=deskgo.台号 and desk.`操作时间`=deskgo.`开台时间` ";
        String sql = headsql + "where desk.区域='"+area+"' order by 前辍,台号;";

        if(area.contains("全部区域")){
            sql=headsql + "order by 前辍,台号;";
        }
        if(area.contains("所有已开")){
            sql=headsql + "where desk.状态='已开台' ";
            sql=sql+"order by 前辍,台号;";
        }
        if(area.contains("临时挂起")){
            sql = "select '挂起', 区域, 台号, '', 别名, 台次, 选择时段, 开台工号, 开台时间, 锁台, 宾客人数,'' " +
                   "from deskgo where isnull(结账时间) and `开台时间` not in (select 操作时间 from desk) ";
        }

        arrayList = mysql.sel(sql,handler);

        //得到三天内的所有预定信息
        if(arrayList!=null && !area.equals("ing") && !area.equals("uping")){
            sql = "select 区域,台号,时段,抵达日期-date(now()) from booking where 抵达日期-date(now())>=0 and 抵达日期-date(now())<3";
            ArrayList<String[]> tempval =mysql.sel(sql, handler);
            if(tempval!=null){
                for(String val[] : tempval){
                    booking.add(val[0]+val[1]+val[2]+val[3]);
                }
            }
        }

        handler.sendEmptyMessage(2);
    }

    //最近三天的预定情况编排
    private String getbooking(String area, String desknum){
        String res = "" ;
        String s = area + desknum;

        for(int k=0; k<3; k++){
            String dd = "" ;
            dd = booking.indexOf(s+"早餐"+k)>=0 ? dd+"●" : dd+"○" ;
            dd = booking.indexOf(s+"中餐"+k)>=0 ? dd+"●" : dd+"○" ;
            dd = booking.indexOf(s+"晚餐"+k)>=0 ? dd+"●" : dd+"○" ;
            dd = booking.indexOf(s+"夜宵"+k)>=0 ? dd+"●" : dd+"○" ;
            res = res + "("+dd+")" ;
        }
        if(res.replace("(○○○○)", "").isEmpty()) return "";
        return res;
    }

    private class MyAdater extends BaseAdapter {
        @Override
        public int getCount() {
            if (arrayList==null) return 0;
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return arrayList.get(position-1);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            String temp[]=arrayList.get(position);
            TextView b=new TextView(FragmentA.this.getView().getContext());

            if(!temp[9].equals("") && !temp[9].equals("N")) temp[0]="被锁定";
            temp[8]=temp[8].replace("-","/");
            temp[2] = temp[2].length()==1 ? "0"+temp[2] : temp[2];

            String startmsg = "";
            if(!temp[5].isEmpty() && !temp[5].equals("0")){
                temp[0]="";
                startmsg = temp[6]+" "+temp[10]+"人" ;
            }
            b.setText("<B>"+temp[1]+" "+temp[3]+temp[2]+" <font color=red>"+temp[4]+"</font></B><br><font color=green>" + startmsg + temp[0]+"</font>" );


            if(temp[0].equals("已开台") || temp[0].equals("被锁定")){
                b.setBackgroundResource(R.drawable.kuaia);
                b.setText(b.getText()+"<br>"+getbooking(temp[1],temp[2]));
            }
            else if(temp[0].equals("挂起")){
                b.setBackgroundResource(R.drawable.kuaid);
                b.setText(b.getText()+"<br>"+getbooking(temp[1],temp[2]));
            }
            else if(temp[0].equals("空台")){
                b.setBackgroundResource(R.drawable.kuaib);
                b.setText(b.getText()+"<br>"+getbooking(temp[1],temp[2]));
            }
            else if(temp[0].equals("脏台")){
                b.setBackgroundResource(R.drawable.kuaic);
                b.setText(b.getText()+"<br>"+getbooking(temp[1],temp[2]));
            }
            else if(temp[0].equals("维修")){
                b.setBackgroundResource(R.drawable.kuairepair);
                b.setText(b.getText()+"<br>"+getbooking(temp[1],temp[2]));
            }
            else if(temp[0].equals("联台")){
                b.setBackgroundResource(R.drawable.kuaid);
                b.setText(b.getText()+"  "+temp[11]+"<br>"+getbooking(temp[1],temp[2]));
            }
            else{
                b.setBackgroundResource(R.drawable.kuaid);
                b.setText(b.getText()+"<br>"+getbooking(temp[1],temp[2]));
            }

            //透明度 取值：0－255
            b.getBackground().setAlpha(180);
            //b.setGravity(View.TEXT_ALIGNMENT_TEXT_START);   //左对齐
            b.setTextColor(Color.BLACK);
            b.setTextSize(16);
            b.setText(Html.fromHtml(b.getText().toString()));

            // 创建一个AnimationSet对象（AnimationSet是存放多个Animations的集合）
            AnimationSet animationSet = new AnimationSet(true);
            // 创建一个ScaleAnimation对象（以某个点为中心缩放）
            ScaleAnimation scaleAnimation = new ScaleAnimation(0.0f, 1f, 0.0f, 1f, Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF, 0.0f);
            // 设置动画执行之前等待的时间（单位：毫秒）
            //scaleAnimation.setStartOffset(500);
            // 设置动画执行的时间（单位：毫秒）
            scaleAnimation.setDuration(400);
            // 如果fillAfter设为true，则动画执行后，控件将停留在动画结束的状态
            // 运行了一下发现以下奇怪的现象
            // scaleAnimation.setFillAfter(true);不会停留在动画结束的状态
            // animationSet.setFillAfter(true);则会停留在动画结束的状态
            animationSet.setFillAfter(true);
            // 将ScaleAnimation对象添加到AnimationSet当中
            animationSet.addAnimation(scaleAnimation);
            // 使用ImageView的startAnimation方法开始执行动画
            b.setAnimation(animationSet);

            return b;
        }
    }
}