package com.dmumu.phone.repast;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Created by root on 14-12-25.
 * 结论:
 1.使用Environment.getExternalStorageDirectory可以得到系统的sdcard路径，不过这个一般在各个手机上都是一样的。
 2.使用context.getExternalFilesDir可以得到系统为程序在sdcard上分配的存储路径，据说放在这里卸载程序时目录也会被删除;
 3.使用context.getFileDir可以获得程序的data目录的files子目录，如果有小文件，sdcard又不存在时可以选择放这里。

 android的官方文档上说，采用Enviroment.getExternalStorageDirectory()方法可以得到android设备的外置存储(即外插SDCARD)，
 如果android设备有外插SDCARD的话就返回外插SDCARD的根目录路径，如果android设备没有外插SDCARD的话就返回android设备的内置SDCARD的路径。
 这套方案很快就被否决了，因为Enviroment类的这个方法里面的路径也是写死的，只有原生的android系统才使用这套方案，被更改过的anroid体统很多设备的路径都改了。
 */

public class mysql {

    public static String address="";
    public static String port="3306";
    public static String account="";
    public static String password="";
    public static Connection conn ;
    public static String path ;
    public static int contimeout = 5 ;

    //发送消息
    public static void sendmsg(Handler handler, boolean flag, String val){
        //弹出错误消息框
        Message m=new Message();
        Bundle b=new Bundle();
        b.putBoolean("flag",flag);
        b.putString("val", val);
        m.setData(b);
        m.what=100;
        handler.sendMessage(m);
    }
    //显示消息
    public static void showmsg(Message msg, Context context){
        Bundle bb = msg.getData();
        if (bb.getBoolean("flag")){
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setIcon(android.R.drawable.ic_dialog_alert);
            builder.setTitle("消息");
            builder.setMessage(bb.getString("val"));
            builder.setPositiveButton("确定", null);
            builder.create().show();
            return ;
        }
        Toast.makeText(context, bb.getString("val"), Toast.LENGTH_SHORT).show();
    }

    //对网络进行预先检查是否依然有效
    private static boolean checkconn(Handler handler){
        if(account.isEmpty() || password.isEmpty()){
            sendmsg(handler,true,"请先登陆");
            return false;
        }
        if(conn == null) return getcon(handler); //重新登陆

        //检查是否超时
        boolean flag = false;
        try {
            flag = conn.isValid(3) ;
        } catch (SQLException e) {
            e.printStackTrace();
            flag = false;
        }
        if(flag == false){
            sendmsg(handler,false,"连接超时，自动恢复连接");
            flag = getcon(handler); //重新登陆
        }
        return flag ;
    }

    //连接数据库
    public static boolean getcon(Handler handler){
        conn = null;
        ExecutorService executor = Executors.newSingleThreadExecutor();
        FutureTask<String> future = new FutureTask<>(new Callable<String>() {
                //使用Callable接口作为构造参数
                public String call() {
                    try {
                        conn = DriverManager.getConnection("jdbc:mysql://"+address+":"+port+"/repast", account, password);
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                        return e.getMessage();
                    }
                    return null;
                }
        });
        executor.execute(future);

        try {
            //取得结果，同时设置超时执行时间为5秒。同样可以用future.get()，不设置执行超时时间取得结果
            //但后续联通3G网络测试表明，这个连接过程至少都在10秒以上 (注意使用3Gnet 而非3Gwap),一但登陆成功，后面的需要连网的操作又很顺畅了
            String err = future.get(contimeout*1000, TimeUnit.MILLISECONDS);
            if(err!=null) {
                if(err.startsWith("Communications link failure")){
                    sendmsg(handler,true,"网络错误,请保证网络可用\n"+err);
                }
                else{
                    sendmsg(handler,true,"账号 或 密码错误\n"+err);
                }
                conn = null ;
                return false;
            }

            //必须初始化登陆
            try{
                CallableStatement cs = conn.prepareCall("{call logon(?,?,?)}");
                cs.registerOutParameter(1, Types.VARCHAR);	//输出型参数
                cs.setString(2, "Android"); //输入型参数
                cs.setString(3, "MAC Address " + MainActivity.macaddress);
                cs.execute();
                return true ;
            }
            catch (Exception e) {
                Log.i("执行存储过程", "登陆初始化失败");
                e.printStackTrace();
                sendmsg(handler,true,e.getMessage());
                conn = null ;
                return false;
            }
        } catch (InterruptedException e) {
            future.cancel(true);
        } catch (ExecutionException e) {
            future.cancel(true);
        } catch (TimeoutException e) {
            future.cancel(true);
            sendmsg(handler,true,"连接数据库超时 "+contimeout+" 秒");
            conn = null ;
        } finally {
            executor.shutdown();
        }
        return false;
    }

    //查询
    public static synchronized ArrayList<String[]> sel(String sql, Handler handler){
        if(!checkconn(handler)) return null ;
        ArrayList<String[]> arrayList=new ArrayList<String[]>();
        try {
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //Statement st=conn.createStatement();
            //ResultSet rs=st.executeQuery(sql);

            ResultSetMetaData md=rs.getMetaData();
            int col=md.getColumnCount();

            while (rs.next()){
                String temp[]=new String[col];
                for(int k=0;k<temp.length;k++){
                    temp[k]=rs.getString(k+1);
                    if (temp[k]==null) temp[k]="";
                    else if(temp[k].equals("null")) temp[k]="";
                }
                arrayList.add(temp);
            }

            rs.close();
            st.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
            Log.i("查询数据库", "连接数据库异常");
            sendmsg(handler,true,e.getMessage());
            return null;
        }

        return arrayList;
    }

    //执行存储过程
    public static synchronized String pro(String name, ArrayList<String> arr, Handler handler){
        if(!checkconn(handler)) return "执行存储过程前网络检查不可用" ;

        String val="?";
        for(String temp : arr)	{val=val+",?";}
        val = "{call "+name+"("+val+")}";
        CallableStatement cs=null;
        try{
            cs = conn.prepareCall(val);
            cs.registerOutParameter(1, Types.VARCHAR);	//输出型参数
            for(int k=0;k<arr.size();k++){
                cs.setString(k+2, arr.get(k));          //输入型参数
            }
            cs.execute();	//总是返回boolean型的值false
            //如果要得到结果集应使用rs = cs.executeQuery();
        }
        catch (Exception e) {
            Log.i("执行存储过程", "执行存储过程异常");
            e.printStackTrace();
            String head="";
            if(e.getMessage().contains("execute command denied")){
                head = "没有权限，请向管理员申请！";
            }
            sendmsg(handler,true, head+"\n"+e.getMessage());
            return "执行存储过程异常";
        }

        String sqlout = "";
        try {
            if(cs.getWarnings()!=null){
                Log.i("执行存储过程", "执行存储过程发出警告:"+cs.getWarnings());
                return "执行存储过程发出警告:\n"+cs.getWarnings();
            }
            sqlout = cs.getString(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        //事务中输出的提示信息，即得到第一个输出型参数的值
        if(sqlout==null){
            String s="存储过程 "+name+" 的输出变量 sqlout 为 null!\n";
            s=s+"这种情况一般是存储过程代码有误或传参错误导致异常，为使存储过程能够回滚，加有如下代码：\n";
            s=s+"DECLARE EXIT HANDLER FOR sqlexception ROLLBACK;\n";
            s=s+"但该代码导致存储过程不返回任何消息。请行先将该代码注释掉 或 检查传入参数 后再调试！";
            Log.i("执行存储过程", s);
            return s;
        }
        if(sqlout.isEmpty()){
            sqlout="结果为空字符串";
            Log.i("执行存储过程", "执行存储过程结果:结果为空字符串");
            return "执行存储过程结果:结果为空字符串";
            //人为规定存储过程输出变量sqlout为空字符串时不作响应，说明一切正常,但返回false
            //注意的是，存储过程中的输出变量sqlout默认是null。如果存储过程正确，需要记得给其赋值空字符串
        }

        //显示执行存储过程得到的结果
        sendmsg(handler,false,sqlout);
        Log.i("执行存储过程", "执行存储过程结果:"+sqlout);
        return sqlout;
    }

    //供程序调用，读取本地图片
    public static Bitmap readimg(String num, String dishname){
        dishname = dishname.replace("/","|");
        String file = dishname+"@"+num+".jpg";
        Bitmap bitmap= BitmapFactory.decodeFile(path+"/repastdir/"+file);

        /*//读取网络图片
        try {
            //URL u = new URL("");
            //InputStream i = (InputStream) u.getContent();
            //Bitmap b = BitmapFactory.decodeStream(i);
        }
        catch (Exception e) {
            e.printStackTrace();
        }*/

        return bitmap;
    }

    // 专用于同步，所有的图片读取均间接从这里得到
    private static synchronized void readIcon(String dishnum, Handler handler) {
        if(!checkconn(handler)) return ;

        InputStream is = null;
        ResultSet rs = null;
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement("select num,name,img from photo where num="+dishnum);
            rs = pstmt.executeQuery();

            rs.first();
            is = rs.getBinaryStream("img");
            if(is==null) return ;

            String num = rs.getString("num");
            String name = rs.getString("name");
            Bitmap bitmap = BitmapFactory.decodeStream(is);

            //保存到本地,注意，大图img列可能存在值，但实际上有时会没有图片，或二进制数据不是图片
            if(bitmap==null){
                sendmsg(handler,true,"商品名:"+name+" 编号:"+num+" \n大图片有误,请检查数据库photo表");
            }
            else{
                saveimg(bitmap,num,name);
                bitmap.recycle();
            }
        } catch (Exception e) {
            Log.i("读取图片", "获得大图片失败");
            e.printStackTrace();
            sendmsg(handler,true,"获得图片失败\n"+e.getMessage());
        } finally {
            try {
                is.close();
                rs.close();
                pstmt.close();
            } catch (Exception e) {}
        }
    }

    //保存图片
    private static void saveimg(Bitmap bm, String num, String name) throws Exception {
        File dirFile = new File(path+"/repastdir");
        if (!dirFile.exists()){
            dirFile.mkdirs();
        }

        //File myCaptureFile=new File(sdcardDir+"/repastdir/test.jpg");
        //if (myCaptureFile.exists()) myCaptureFile.mkdir();
        name = name.replace("/","|");
        File f=new File(path+"/repastdir/"+name+"@"+num+".jpg");
        FileOutputStream fo=new FileOutputStream(f);
        BufferedOutputStream bos=new BufferedOutputStream(fo);

        //质量压缩方法，这里100表示不压缩，把压缩后的数据存放到baos中
        bm.compress(Bitmap.CompressFormat.JPEG, 100, bos);

        bos.close();
        fo.close();
    }

    //同步图片
    public static String ImgMsg="";
    public static void synmenu(final Handler handler, SharedPreferences share){
        if(!checkconn(handler)) return ;

        ImgMsg="正在清空repastdir目录。";
        handler.sendEmptyMessage(6);

        File f = new File(path+"/repastdir");
        if (f.isDirectory()){
            File[] childFiles = f.listFiles();
            if(childFiles!=null && childFiles.length>0){
                for(File temp : childFiles){
                    temp.delete();
                }
            }
        }

        boolean b = syngoods(handler, share);       //先同步菜谱
        if(b==false) return;

        String sql="select `编号` FROM menu INNER JOIN photo ON `编号`=num WHERE !ISNULL(img) ";
        final ArrayList<String[]> arr = mysql.sel(sql,handler);
        if(arr==null) return ;

        for(final String val[] : arr){
            readIcon(val[0],handler);

            //图片同步进度显示
            ImgMsg="当前完成第:" + arr.indexOf(val) + "/" + arr.size() + " 张图。";
            handler.sendEmptyMessage(6);
        }
    }

    //同步菜谱
    private static boolean syngoods(Handler handler, SharedPreferences share){
        if(!checkconn(handler)) return false;

        SQLiteDatabase db = initFirst(handler);
        if (db==null) return false;

        //先查询数据库
        String sql=" select 编号,分类,商品名,价格,单位,锁定,助记符,isnull(img),库存 from menu left join photo on `编号`=num ";
        ArrayList<String[]> arr = sel(sql, handler);
        if (arr==null) return false;

        //再删除本地数据
        try{
            //第二个参等效于where
            //db.delete("menu", " a = '20023' ", null);
            //drop table menu
            db.execSQL("drop table if exists menu");
            db.execSQL("drop table if exists premenu");
        }catch (Exception e){
            Log.i("同步菜谱","删除表出錯");
        }

        //初始化本地数据
        try{
            sql="create table menu (num varchar, cla varchar, name varchar, price varchar, unit varchar, lock varhcar, help varchar, photo long, stock double);";
            db.execSQL(sql);
            sql="create table premenu (num varchar, cla varchar, name varchar, price varchar, unit varchar, amount double);";
            db.execSQL(sql);
        }catch (Exception e){
            Log.i("同步菜谱","建立表出錯");
        }

        //写入本地数据
        int k=0;
        for (String val[] : arr){
            db.execSQL(" insert into menu values (?,?,?,?,?,?,?,?,?) ", val);
            k++;
            //图片同步进度显示
            ImgMsg="写入商品: "+k+"/"+arr.size() ;
            handler.sendEmptyMessage(6);
        }
        db.close();

        //同步菜谱版本
        sql = " select value from general where name='system' and item='menuversion' ";
        ArrayList<String[]> menuversion = mysql.sel(sql, handler);
        int ver = 0 ;
        if(menuversion != null && menuversion.size()==1){
            try{
                ver = Integer.valueOf(menuversion.get(0)[0]) ;
                SharedPreferences.Editor editor=share.edit();
                editor.putInt("menuversion",ver);
                editor.commit();
            }catch (Exception e){};
        }
        return true;
    }

    public static ArrayList<String[]> selSQLite(String col[], String where, Handler handler){
        SQLiteDatabase db = initFirst(handler);
        if (db==null) return null;

        Cursor cur = db.query("menu", col, where, null, null, null, null);
        if (where!=null && where.contains("help like")){
            //商品查询时，为节约内存，只显示前60行数据
            cur = db.query("menu", col, where, null, null, null, null, "60");
        }

        ArrayList<String[]> arrayList=new ArrayList<String[]>();
        cur.moveToFirst();
        while (!cur.isAfterLast()){
            String temp[]=new String[col.length];
            for (int k=0; k<col.length; k++){
                temp[k] = cur.getString(k);
            }
            arrayList.add(temp);
            cur.moveToNext();
        };
        if(!cur.isClosed()) cur.close();
        db.close();

        return arrayList;
    }

    //图片预览时分类选择菜单初始化时调用
    public static ArrayList<String[]> selSQLite(Handler handler){
        SQLiteDatabase db = initFirst(handler);
        if (db==null) return null;

        String col[] = { "cla", "count(*)"};
        Cursor cur = db.query("menu", col, "photo=0", null, "cla", null, "num");

        ArrayList<String[]> arrayList=new ArrayList<>();
        cur.moveToFirst();
        while (!cur.isAfterLast()){
            String temp[]=new String[col.length];
            for (int k=0; k<col.length; k++){
                temp[k] = cur.getString(k);
            }
            arrayList.add(temp);
            cur.moveToNext();
        };
        if(!cur.isClosed()) cur.close();
        db.close();

        //注意尽可能防止arrayList为null，减少出闪退现像发生
        return arrayList;
    }

    //专供于分类浏览商品时调用
    public static ArrayList<String[]> selSQLitelook(Handler handler){
        SQLiteDatabase db = initFirst(handler);
        if (db==null) return null;

        String col[] = { "cla", "count(*)"};
        Cursor cur = db.query("menu", col, null, null, "cla", null, null);

        ArrayList<String[]> arrayList=new ArrayList<>();
        cur.moveToFirst();
        while (!cur.isAfterLast()){
            String temp[]=new String[col.length];
            for (int k=0; k<col.length; k++){
                temp[k] = cur.getString(k);
            }
            arrayList.add(temp);
            cur.moveToNext();
        };
        if(!cur.isClosed()) cur.close();
        db.close();

        //注意尽可能防止arrayList为null，减少出闪退现像发生
        return arrayList;
    }

    public static void pre(String val[], double num, Handler handler){
        SQLiteDatabase db = initFirst(handler);
        if (db==null) return;
        val = new String[]{ val[0], val[1], val[2], val[3], val[4], num+"" };
        db.execSQL(" insert into premenu values (?,?,?,?,?,?) ", val);
    }

    //查询预点商品
    public static ArrayList<String[]> readPreMenu(Handler handler){
        SQLiteDatabase db = initFirst(handler);
        if (db==null) return null;

        String col[] = { "num", "cla", "name", "price", "unit", "amount"};
        Cursor cur = db.query("premenu", null, null, null, null, null, null);

        ArrayList<String[]> arrayList=new ArrayList<String[]>();
        cur.moveToFirst();
        while (!cur.isAfterLast()){
            String temp[]=new String[col.length];
            for (int k=0; k<col.length; k++){
                temp[k] = cur.getString(k);
            }
            arrayList.add(temp);
            cur.moveToNext();
        };
        if(!cur.isClosed()) cur.close();
        db.close();

        return arrayList;
    }
    public static void clearPreMenu(String dishnum, Handler handler){
        SQLiteDatabase db = initFirst(handler);
        if (db==null) return ;

        db.delete("premenu"," num=?", new String[]{dishnum});
    }
    public static void updatePreMenu(String dishnum, Double amount, Handler handler){
        SQLiteDatabase db = initFirst(handler);
        if (db==null) return ;

        ContentValues values = new ContentValues();
        values.put("amount",amount);
        db.update("premenu", values, " num=? ", new String[]{dishnum});
    }

    //点单时，数量选择对话框，有三个地方要调用这里
    public static AlertDialog amount(Context context, final String temp[], final Handler handler){
        View v = LayoutInflater.from(context).inflate(R.layout.amountlayout, null);
        final EditText val;
        Button up,down;
        val =(EditText) v.findViewById(R.id.amount);
        val.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    Double.valueOf(val.getText().toString());
                    val.setTextColor(Color.BLUE);
                }catch (Exception e){
                    val.setTextColor(Color.RED);
                }
            }
            public void afterTextChanged(Editable s) {}
        });
        up = (Button) v.findViewById(R.id.add);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return;
                }
                Double k = Double.valueOf(val.getText().toString());
                val.setText(k+1+"");
            }
        });
        down = (Button) v.findViewById(R.id.del);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (val.getText().toString().isEmpty()){
                    val.setText("1");
                    return;
                }
                Double k = Double.valueOf(val.getText().toString());
                if (k-1>=0){
                    val.setText(k-1+"");
                }
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(temp[2]);
        String dishnum[] = new String[3];
        for (int k = 0 ; k<3; k++){
            dishnum[k]="点单数量   "+(k+1)+" "+temp[4] + "     ￥" + Double.valueOf(temp[3])*(k+1);
        }
        builder.setItems(dishnum, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int which) {
                mysql.pre(temp,which+1,handler);
            }
        });
        builder.setView(v);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Double k = val.getText().toString().isEmpty() ? 0 : Double.valueOf(val.getText().toString());
                mysql.pre(temp, k, handler);
            }
        });
        builder.setNegativeButton("取消", null);

        AlertDialog Dia=builder.create();
        //动画效果
        Window logonwidow = Dia.getWindow();
        logonwidow.setWindowAnimations(R.style.popwin_anim_style);

        return Dia;
    }


    /****************************************************************************************************************************/

    //首次登陆数据库应做初始化
    public static SQLiteDatabase initFirst(Handler handler){
        //创建目录
        File dirFile = new File(path+"/repastdir");
        if (!dirFile.exists()){
            boolean temp = dirFile.mkdirs();
            if(!temp) {
                sendmsg(handler, true, "文件夹创建失败,无法在存储卡上新建目录文件夹\n"+path);
                return null;
            }
        }

        //创建数据库文件
        File dbfile = new File(path+"/repastdir/menu.db");
        if (!dbfile.exists()) {
            try {
                boolean temp = dbfile.createNewFile();
                if(!temp) {
                    sendmsg(handler, true, "数据库创建失败,无法在存储卡上创建数据库文件\n"+path);
                    return null;
                }
            } catch (IOException e) {
                e.printStackTrace();
                sendmsg(handler, true, "数据库创建异常,无法在存储卡上u新建数据库文件\n"+e.getMessage());
                return null;
            }
        }

        SQLiteDatabase db = null;
        try{
            db = SQLiteDatabase.openOrCreateDatabase(path+"/repastdir/menu.db", null, null);
        }
        catch (Exception e){
            e.printStackTrace();
            sendmsg(handler, true, "操作数据库文件出错，SQLiteDatabase对象初始化失败\n"+e.getMessage());
            return null;
        }

        //初始化数据库
        try{
            String sql="create table menu (num varchar, cla varchar, name varchar, price varchar, unit varchar, lock varhcar, help varchar, photo long, stock double);";
            if (!tabIsExist("menu",db))  db.execSQL(sql);

            sql="create table premenu (num varchar, cla varchar, name varchar, price varchar, unit varchar, amount double);";
            if (!tabIsExist("premenu",db)) db.execSQL(sql);
        }
        catch (Exception e) {
            e.printStackTrace();
            sendmsg(handler, true, "新建数据库表出错，无法创建菜单表 或 预点菜单表\n"+e.getMessage());
            return null;
        }

        return db;
    }

    //判断某张表是否存在
    public static boolean tabIsExist(String tabName, SQLiteDatabase db){
        boolean result = false;
        Cursor cursor = null;
        try {
            //db = this.getReadableDatabase();
            String sql = "select count(*) as c from sqlite_master where type ='table' and name ='"+tabName.trim()+"' ";
            cursor = db.rawQuery(sql, null);
            if(cursor.moveToNext()){
                int count = cursor.getInt(0);
                if(count>0){
                    result = true;
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
        }
        return result;
    }

    /******************************************************************************************************************************************/
    //读取字节,数据流  打印账单
    public static void getbill(int mealnum, String showback, String showlist, String site, Handler handler){
        //是否显示退单和套餐明细
        //byte bb[] = getbin("select convert(binary_bill("+mealnum+",'"+showback+"','"+showlist+"') using gbk)", handler);
        byte bb[] = getbin("select binary_bill("+mealnum+",'"+showback+"','"+showlist+"')", handler);
        if(bb!=null) {
            boolean result = printbin(bb, site, handler);
            if(result) sendmsg(handler, true, "恭喜，账单打印成功。\n站点：" + site);
        }
    }
    //读取字节,数据流  打印清单
    public static void getlist(int mealnum, String site, Handler handler){
        byte bb[] = getbin("select binary_list("+mealnum+",'"+site+"')", handler);
        if(bb!=null){
            boolean result = printbin(bb, site, handler);
            if(result) sendmsg(handler, true, "恭喜，清单打印成功。\n站点：" + site);
        }
    }
    //读取字节,数据流  打印联单
    public static void getunion(int mealnum, String site, Handler handler){
        byte bb[] = getbin("select binary_union("+mealnum+",'"+site+"')", handler);
        if(bb!=null){
            boolean result = printbin(bb, site, handler);
            if(result) sendmsg(handler, true, "恭喜，联单打印成功。\n站点：" + site);
        }
    }

     //读取字节,数据流
    private synchronized static byte[] getbin(String sql, Handler handler){
        if(!checkconn(handler)) return null ;
        ResultSet rs = null;
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            rs.first();

            /* //改用下面的方法一切正常
            String val=rs.getString(1);
            byte[] A = new byte[]{};
            try{A=val.getBytes("GBK");}catch (Exception e) {}
            return A ;
            */
            return rs.getBytes(1);
        }
        catch (Exception e) {
            String errmsg = "";
            if (e.getMessage().contains("execute command denied")){
                errmsg = "没有权限,请向管理员申请\n";
            }
            sendmsg(handler, true, errmsg+"[mysql.getbin()读取字节流异常]\n" + e.getMessage());
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null) rs.close();
                if(pstmt!=null) pstmt.close();
            } catch (Exception e) {}
        }
        return null;
    }

    //读取字节,后来加的，从存储过程中得到binary_go
    public synchronized static HashMap<String[], byte[]> getBinDB(int mealnum, String hold, Handler handler){
        CallableStatement cs = null ;
        HashMap<String[], byte[]> hm = new HashMap<>();
        try{
            cs = (CallableStatement)conn.prepareCall("{call binary_go(?,?,?)}");
            cs.registerOutParameter(1, Types.VARCHAR);	//输出型参数
            cs.setString(2, mealnum+"");			//输入型参数
            cs.setString(3, hold);
            cs.execute();

            if(cs.getWarnings()!=null){
                sendmsg(handler, true, "[mysql.getBinDB()警告信息]\n" + cs.getWarnings().toString());
            }

            // 事务中输出的提示信息，即得到第一个输出型参数的值
            String sqlout = cs.getString(1);
            if(sqlout!=null && !sqlout.isEmpty()){
                sendmsg(handler, true, "[mysql.getBinDB()返回消息]\n" + sqlout);
            }

            // 没有错误的情况下处理结果集
            if(cs.getWarnings()==null && sqlout==null){
                boolean hadResults = false;
                int flag = 0;	//如果打印两份，则会出现重复，但HashMap不充许重复键值对，所以加一个序号标识。
                do{
                    ResultSet rs = cs.getResultSet();
                    while(rs != null && rs.next()){
                        String temp[] = new String[7];
                        temp[0] = rs.getString(1);  //ip
                        temp[1] = rs.getString(2);  //port
                        temp[2] = rs.getString(3);  //site
                        temp[3] = "" + flag++;
                        hm.put(temp, rs.getBytes(4));   //binary
                    }
                    rs.close();
                    hadResults = cs.getMoreResults(); 	//检查是否存在更多结果集
                }while(hadResults);
            }
        }
        catch(Exception e){
            String s = e.getMessage();
            if (s == null) {
                // 比如，cat连接到了数据库，然后root删除了cat账号，当cat调用存储过程时e.getMessage就为空。
                s = "异常消息为空，可能帐号不存在，或其它不明原因。";
            }
            else if (s.startsWith("execute command denied to user")) {
                s = "没有权限，请向管理员申请。\n" + s;
            }
            sendmsg(handler, true, "[mysql.getBinDB()調用异常]\n" + s);
        }
        finally{
            //不再使用就关闭
            try{cs.close();}catch (Exception e) {};
        }
        return hm ;
    }


    //不指定站点IP和端口时，自己根据站点名称找到IP和端口
    public static boolean printbin(byte temp[], String site, Handler handler){
        ArrayList<String[]> config = sel("select 站点,IP,端口 from print_config where 站点='"+site+"';", handler);
        if(config.size()==0 || config.get(0).length==0){
            sendmsg(handler, true,"站点："+site+" 不存在，请正确配置打印机站点。");
            return false;
        }
        String ip=config.get(0)[1];					    //IP地址
        int port= Integer.valueOf(config.get(0)[2]);	//端口
        return printbin(temp, site, ip, port, handler);
    }

    //打印数据
    public static synchronized boolean printbin(byte temp[], String site, String ip, int port, Handler handler){
        boolean result = true;

        Socket socket = new Socket() ;
        ObjectOutputStream output = null ;
        SocketAddress add = new InetSocketAddress(ip, port) ;
        try{
            socket.connect(add,3000);
            output=new ObjectOutputStream(socket.getOutputStream());

            byte LF = 0x0A;	//打印并走纸的标记
            byte ESC = 0x1B;
            int flag=0;

            //复位两次,有些热敏打印机复位一次不够
            output.write(new byte[] {ESC, '@'});
            output.write(new byte[] {ESC, '@'});

            for(int k=0;k<temp.length;k++){
                output.write(temp[k]);
                flag++;

                //如果热敏打印机缓存为1024字节，应在快达到这个数之前将数据发送出去
                if((temp[k]==LF)&&(flag>900)){
                    output.flush();
                    flag=0;

                    //复位两次
                    output.write(new byte[] {ESC, '@'});
                    output.write(new byte[] {ESC, '@'});
                }
            }
            output.flush();
        }
        catch (Exception e) {
            sendmsg(handler, true,"打印机站点:"+site+" "+ip+":"+port+" 连接超时3秒,打印失败\n"+e.getMessage());
            e.printStackTrace();
            result = false ;	//不要return false, 因为要下面的代码为关闭端口
        }
        finally{
            try {
                if(output!=null) output.close();
                if(socket!=null && !socket.isClosed()) socket.close();
            } catch (IOException e) {}
        }
        return result;
    }
}