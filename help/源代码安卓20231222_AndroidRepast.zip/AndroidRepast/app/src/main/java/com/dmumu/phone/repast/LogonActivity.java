package com.dmumu.phone.repast;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Administrator on 2015/1/13.
 */
public class LogonActivity extends Activity {
    private AutoCompleteTextView account ;
    private CheckBox save, auto;
    private EditText password, address, port ;
    private SharedPreferences share ;
    private Toast mToast;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logonlayout);
        //getWindow().setWindowAnimations(R.style.popwin_anim_style); //动画效果
        //requestWindowFeature(Window.FEATURE_NO_TITLE);  //不要标题
        share = getSharedPreferences("val", Context.MODE_PRIVATE);

        Intent intent = getIntent();
        boolean autoLogon = intent.getBooleanExtra("auto",true);

        account=(AutoCompleteTextView)findViewById(R.id.foraccount);
        password = (EditText)findViewById(R.id.forpassword);
        save = (CheckBox)findViewById(R.id.forsave);
        auto = (CheckBox)findViewById(R.id.forauto);
        address = (EditText)findViewById(R.id.foraddress);
        port = (EditText)findViewById(R.id.forport);

        save.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //保存登陆参数
                SharedPreferences.Editor editor=share.edit();
                editor.putBoolean("save", isChecked);
                if(!isChecked) editor.putString("password","");    //清空密码
                editor.commit();
            }
        });
        auto.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //保存登陆参数
                SharedPreferences.Editor editor=share.edit();
                editor.putBoolean("auto", isChecked);
                editor.commit();
            }
        });

        //初始化参数
        account.setText(share.getString("accounts", "admin"));
        password.setText(share.getString("password","123456"));
        address.setText(share.getString("address","repast.dmumu.com"));
        port.setText(share.getString("port","3306"));
        save.setChecked(share.getBoolean("save", true));
        auto.setChecked(share.getBoolean("auto", false));
        final Set<String> set=share.getStringSet("account",null);
        if (set!=null && set.size()>0) {
            String str[]=new String[set.size()];
            set.toArray(str);
            //account.setText(str[str.length-1]); 不要显示
            ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,str);
            account.setAdapter(adapter);
            //account.setDropDownBackgroundResource(R.drawable.bg);
        }

        Button logon=(Button)findViewById(R.id.forlogon);
        logon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logonOK();
            }
        });

        Button back=(Button)findViewById(R.id.forback);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        mToast = Toast.makeText(this, "", Toast.LENGTH_SHORT);
        mToast.setGravity(Gravity.BOTTOM| Gravity.CENTER_HORIZONTAL, 0, 0);

        //是否自动登陆
        if (auto.isChecked() && autoLogon) {
            handler.sendEmptyMessage(4);
        }
    }

    //进入后台长时不显示时，这个最好关掉
    public void onStop(){
        super.onStop();
        finish();
    }

    private void logonOK(){
        if(account.getText().toString().toLowerCase().equals("log")){
            logonErr("log 是系统辅助账号，限制登陆");
            return ;
        }

        if (password.getText().toString().isEmpty()){
            logonErr("密码不能为空？");
            return;
        }

        if(address.getText().toString().isEmpty()){
            logonErr("服务器地址不能为空？");
            return;
        }

        if(port.getText().toString().isEmpty()){
            logonErr("服务器端口不能为空？");
            return;
        }

        if(checknet()){
            logonErr("唉哟 亲，没有网络耶？");
            return;
        }

        //注意转成小写，以方便登陆
        mysql.account=account.getText().toString().toLowerCase().trim();
        mysql.password=password.getText().toString().toLowerCase().trim();
        mysql.address=address.getText().toString().trim();
        mysql.port=port.getText().toString();

        //在登陆之前保存登陆参数
        final SharedPreferences share = getSharedPreferences("val", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = share.edit();
        Set<String> set=share.getStringSet("account",null);
        if (set==null){
            set = new HashSet<>();
        }
        set.add(mysql.account);
        editor.putStringSet("account", set);
        editor.putString("accounts", mysql.account);
        editor.putString("address", mysql.address);
        editor.putString("port",mysql.port);
        if (save.isChecked()) editor.putString("password",mysql.password);
        editor.commit();

        //尝试激活端口，如果不这么做，登陆经常出现超时现象,但这也不能保证什么。只是提高了登陆成功的效率
        Thread th1=new Thread(new Runnable() {
            public void run() {
                Socket socket = new Socket() ;
                SocketAddress add = new InetSocketAddress(mysql.address, Integer.valueOf(mysql.port)) ;
                try {
                    //socket.setSoTimeout(3000);  //这个也是超时设置，但也不是很好的起作用
                    socket.connect(add, 3000);  //限时3秒好像到了Android里面就不起作用了
                    socket.close();
                    handler.sendEmptyMessage(3);
                }catch (Exception e){
                    handler.sendEmptyMessage(2);
                }
            }
        });
        th1.start();

        //连接数据库必须以线程的方式，否则不能连接数据库
        Thread th2=new Thread(new Runnable() {
            public void run() {
                boolean boo = mysql.getcon(handler);
                if(!boo) return ;

                //检查用户相关信息
                String sql = "select name_chinese,islock from account where name_english='"+mysql.account+"';";
                ArrayList<String[]> usercfg=mysql.sel(sql, handler);

                if(usercfg == null || usercfg.size()==0){
                    return ;
                }
                if(usercfg.get(0)[1].equals("Y")){
                    mysql.account = "";
                    mysql.password = "";
                    handler.sendEmptyMessage(1);
                    return ;
                }

                //检查菜谱是否有新版本
                sql = " select value from general where name='system' and item='menuversion' ";
                ArrayList<String[]> menuversion = mysql.sel(sql, handler);
                int ver = 0 ;
                if(menuversion != null && menuversion.size()==1){
                    try{
                        ver = Integer.valueOf(menuversion.get(0)[0]) ;
                    }catch (Exception e){};
                }

                Intent intent = new Intent();
                intent.putExtra("username", usercfg.get(0)[0]);   // 放入返回值
                intent.putExtra("menuversion",ver);
                setResult(1, intent);     // 放入回传的值,并添加一个Code,方便区分返回的数据
                finish();

                //登陆成功的情况下 记录/更新 密码，用于声纹登陆
                SharedPreferences.Editor editor=share.edit();
                editor.putString(mysql.account + "voice", mysql.password);
                editor.commit();
            }
        });
        th2.start();
    }

    private Handler handler=new Handler(){
        public void handleMessage(final Message msg){
            switch (msg.what){
                case 1 :
                    AlertDialog.Builder builder = new AlertDialog.Builder(LogonActivity.this);
                    builder.setMessage("当前用户被锁定，请联系管理员先解锁。\n");
                    builder.setTitle("禁止登陆");
                    builder.setPositiveButton("知道了",null);
                    builder.create().show();
                    break;
                case 2 :
                    Toast.makeText(LogonActivity.this, "服务器端口检测失败", Toast.LENGTH_SHORT).show();
                    break;
                case 3 :
                    Toast.makeText(LogonActivity.this, "port check success", Toast.LENGTH_SHORT).show();
                    break;
                case 4 :
                    logonOK();
                    break;
                case 100 :
                    //如果activity已经关闭，则不能再显示对话框，否则会异常并闪退
                    if(LogonActivity.this.isFinishing())   return;
                    mysql.showmsg(msg, LogonActivity.this);
                    break;
            }
            super.handleMessage(msg);
        }
    };

    private void logonErr(String err){
        Toast.makeText(this, err, Toast.LENGTH_SHORT).show();
    }
    private boolean checknet(){
        ConnectivityManager con = (ConnectivityManager)getSystemService(Activity.CONNECTIVITY_SERVICE);
        boolean wifi = con.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isConnectedOrConnecting();
        boolean internet = con.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isConnectedOrConnecting();

        if(internet){
            mysql.contimeout = 20 ; //由于3G网络太慢，登陆超时定为20秒
            Toast.makeText(LogonActivity.this, "注意：当前网络为 移动数据网络\n登陆过程可能需要较长时间，最长限制 20 秒", Toast.LENGTH_SHORT).show();
        }
        else{
            mysql.contimeout = 5 ;  //确保网络切换是能恢复到默认超时的5秒
        }

        if( wifi | internet )   return false ;
        return true ;

        /*
        另外需要权限
        <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
        */
    }

    private void showTip(final String str){
        mToast.setText(str);
        mToast.show();
    }
}