package com.dmumu.phone.repast;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class PrintDB{
    private int mealnum;
    private int thnum = 0;
    private HashMap<String[], byte[]> hm ;
    private ArrayList<String[]> over = new ArrayList<>();
    private Handler handler;

    // 传入的值为台次,商品索引数组; hold 标示出单是否叫起
    public PrintDB(int mealnum, boolean hold, Handler handler){
        this.mealnum = mealnum ;
        this.handler = handler ;

        String flag = hold ? "Y" : "N" ;
        hm = mysql.getBinDB(mealnum, flag, handler);
        if(hm.isEmpty()) return ;

        Iterator<?> iter = hm.entrySet().iterator();
        ArrayList<String> site = new ArrayList<>();

        while (iter.hasNext()){
            Map.Entry entry = (Map.Entry)iter.next();
            String[] key = (String[])entry.getKey();
            if(!site.contains(key[2])){
                site.add(key[2]);
            }
        }

        //开台整理数据并打印
        thnum = site.size() ;

        //通知将在哪些站点上出单
        if (thnum<=0) return;
        handler.sendEmptyMessage(99);

        for(String val : site){
            if(val.toUpperCase().startsWith("COM")){
                thnum-- ;
                continue ;
            }
            print(val);
        }
    }

    //根据站点得到打印数据流
    private byte[] getbin(String site){
        Iterator<?> iter = hm.entrySet().iterator();
        byte[] temp = new byte[0];
        while (iter.hasNext()){
            Map.Entry entry = (Map.Entry)iter.next();
            String[] key = (String[])entry.getKey();
            byte val[] = (byte[])entry.getValue();
            if(site.equals(key[2])){
                //java 合并两个byte数组
                byte[] C = new byte[temp.length + val.length];
                System.arraycopy(temp, 0, C, 0, temp.length);
                System.arraycopy(val, 0, C, temp.length, val.length);
                temp = C ;
            }
        }
        return temp ;
    }
    //根据站点得到热敏打印机的地址和端口
    private String[] getadd(String site){
        Iterator<?> iter = hm.entrySet().iterator();
        while (iter.hasNext()){
            Map.Entry entry = (Map.Entry)iter.next();
            String[] key = (String[])entry.getKey();
            if(site.equalsIgnoreCase(key[2])){
                return new String[]{key[0],key[1]};
            }
        }
        return new String[]{"", "9100"};
    }

    //以线程的方式起动，以免打印机连接不上被主线程被卡住，好像死机了一样
    private void print(final String site){
        final Thread th = new Thread(new Runnable() {
            public void run() {
                byte b[] = getbin(site);
                String add[] = getadd(site);
                boolean result = mysql.printbin(b, site, add[0], Integer.valueOf(add[1]), handler);
                over.add(new String[]{site, result ? "Y":"N"});
                thnum--;
                if(thnum==0) ending();
            }
        });
        th.start();
    }

    // 全部打印方式下待所有进程结束后, 还需要写入打印结果
    private void ending(){
        String AA="", BB="" ;
        for(String temp[] : over){
            AA = AA + temp[0] + "&" ;
            BB = BB + temp[1] ;
        }

        // 反馈打印结果
        String sql = "select binary_result_go("+mealnum+",'"+AA+"','"+BB+"')";
        ArrayList<String[]> submit_result = mysql.sel(sql, handler);

        //通知打印结果
        if(submit_result.size()==1){
            Message m=new Message();
            Bundle b=new Bundle();
            b.putString("who", AA);
            b.putString("what", BB);
            m.setData(b);
            m.what=98;
            handler.sendMessage(m);
        }
    }
}
