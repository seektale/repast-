package com.dmumu.phone.repast;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.dmumu.phone.repast.activity.CaptureActivity;

import java.util.ArrayList;

import static com.dmumu.phone.repast.R.id.linearThree;
import static com.dmumu.phone.repast.R.style.popwin_anim_style;

public class FragmentC extends Fragment {
    private static final String ARG_SECTION_NUMBER = "section_number";
    private ArrayList<String[]> arrayList=new ArrayList<String[]>();
    public SearchView edit;
    private ListView listView;
    private PopupWindow menu;

    private String menuid ;
    public FragmentC() {
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, 3);
        setArguments(args);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_three, container, false);
        //rootView.setBackgroundColor(Color.LTGRAY);
        //rootView.setBackgroundResource(R.drawable.cao);
        listView = (ListView)rootView.findViewById(linearThree);
        listView.setAdapter(new MyAdater());

        edit=(SearchView)rootView.findViewById(R.id.order);
        edit.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                initDB();
                return false;
            }
        });

        Button lookmenu = rootView.findViewById(R.id.lookmenu);
        lookmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.clearFocus();  //失去焦点，这样可以隐藏软键盘
                menu.showAtLocation(FragmentC.this.getView(), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
            }
        });

        /************************************************************************************************************/

        ListView menuView =new ListView(rootView.getContext());
        menu = new PopupWindow(menuView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        menu.setFocusable(true);
        menu.setOutsideTouchable(true);
        menu.update();
        //得到一个空图片
        Bitmap nullbit = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        Drawable front = new BitmapDrawable(null,nullbit);
        menu.setBackgroundDrawable(front); //会报目录错误
        menu.setAnimationStyle(popwin_anim_style);

        final ArrayList<String[]> arrss = mysql.selSQLitelook(handler);
        menuView.setAdapter(new lookAdater(arrss));
        menuView.setBackgroundColor(Color.WHITE);
        menuView.getBackground().setAlpha(230);
        menuView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                edit.clearFocus();  //失去焦点，这样可以隐藏软键盘,老是弹出很烦人
                menu.dismiss();
                String col[] = { "num", "cla", "name", "price", "unit", "lock", "stock" };
                String where = "cla='"+arrss.get(position)[0]+"'";
                arrayList = mysql.selSQLite(col, where, handler);
                if (arrayList != null){
                    ((MyAdater)listView.getAdapter()).notifyDataSetChanged(); //更新数据
                }
            }
        });

        return rootView;
    }

    /*---------------------------------------------------------------------------------------------------*/

    private class lookAdater extends BaseAdapter {
        private ArrayList<String[]> arr =new ArrayList<>();
        private lookAdater(ArrayList<String[]> arr){
            if(arr!=null)   this.arr=arr;
        }
        public int getCount() {
            return arr.size();
        }
        public Object getItem(int position) {
            return arr.get(position);
        }
        public long getItemId(int position) {
            return position;
        }
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView text = new TextView(FragmentC.this.getActivity());
            text.setText("["+(position+1)+"]"+arr.get(position)[0]+"  --  数量:"+arr.get(position)[1]);
            text.setTextSize(18);
            text.setGravity(Gravity.CENTER);
            text.setPadding(0,10,0,10);
            return text;
        }
    }
    /************************************************************************************************************/


    public Handler handler=new Handler(){
        public void handleMessage(Message msg){
            switch (msg.what){
                //显示点单错误信息
                case 3 :
                    Bundle bundle=msg.getData();
                    String temp=bundle.getString("msg");
                    Toast.makeText(getView().getContext(), temp, Toast.LENGTH_SHORT).show();
                    break;
                case 100 :
                    mysql.showmsg(msg, getView().getContext());
                    break;
            }
            super.handleMessage(msg);
        }
    };

    private void initDB(){
        String co[] = { "count(*)" };
        ArrayList<String[]> temp = mysql.selSQLite(co, null, handler);
        if (temp == null){
            Toast toast = Toast.makeText(getView().getContext(), "查询本地缓存表返回空指针，结果有误", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER| Gravity.CENTER, 0, 0);
            toast.show();
            return;
        }
        if (Integer.valueOf(temp.get(0)[0])==0){
            Toast toast = Toast.makeText(getView().getContext(), "没有缓存本地菜谱，请先同步菜谱", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER| Gravity.CENTER, 0, 0);
            toast.show();
            return;
        }

        String help=edit.getQuery().toString().trim();
        if (help.isEmpty()) help="<不显示商品信息〉";

        String col[] = { "num", "cla", "name", "price", "unit", "lock", "stock" };
        String where = "help like '%"+help+"%' or name like '%"+help+"%' or num like '%"+help+"%'";
        arrayList = mysql.selSQLite(col, where, handler);

        if (arrayList != null){
            ((MyAdater)listView.getAdapter()).notifyDataSetChanged(); //更新数据
        }
    }

    private class MyAdater extends BaseAdapter {
        @Override
        public int getCount() {
            if (arrayList==null) return 0;
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return arrayList.get(position-1);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final String temp[] = arrayList.get(position);

            View v = LayoutInflater.from(FragmentC.this.getView().getContext()).inflate(R.layout.orderlayout, null);
            ImageView button =  v.findViewById(R.id.gofc);
            button.getBackground().setAlpha(180);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edit.clearFocus();  //使其失去焦点，以免其自动弹出软键盘
                    mysql.pre(temp, 1, handler);
                    Toast.makeText(v.getContext(), temp[2]+" 添加成功!", Toast.LENGTH_SHORT).show();
                }
            });

            TextView attr = v.findViewById(R.id.desattr);
            attr.setTextSize(16);
            attr.setTextColor(Color.RED);
            if(temp[5].equalsIgnoreCase("Y")) attr.setText("已锁定 ");

            TextView b = v.findViewById(R.id.desdish);
            b.setGravity(View.TEXT_ALIGNMENT_TEXT_START);    //左对齐
            b.setTextSize(16);
            b.setTextColor(Color.BLACK);
            //b.setBackgroundResource(R.drawable.ying);
            b.setBackgroundResource(R.drawable.fanga);
            //透明度 取值：0－255
            b.getBackground().setAlpha(220);
            //放在这里才有效，注意位置

            b.setText(Html.fromHtml("<font>" +
                    temp[0]+" "+temp[2]+"["+temp[1]+"]"+
                    "</font><br><font color=\'blue\'>" +
                    "￥: "+temp[3]+"   /"+temp[4]+
                    "</font>"));


            v.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    mysql.amount(v.getContext(), temp, handler).show();
                }
            });
            v.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    edit.clearFocus();  //使其失去焦点，以免其自动弹出软键盘
                    return false;
                }
            });
            v.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    menuid = temp[0];
                    //打开扫描界面扫描条形码或二维码
                    Intent openCameraIntent = new Intent(getActivity(), CaptureActivity.class);
                    startActivityForResult(openCameraIntent, 0);
                    return true;
                }
            });

            //从右到左滑出的动画
            AnimationSet animationSet = new AnimationSet(true);
            TranslateAnimation translateAnimation = new TranslateAnimation
                    (Animation.RELATIVE_TO_SELF,1f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f, Animation.RELATIVE_TO_SELF,0f);
            translateAnimation.setDuration(300);
            animationSet.addAnimation(translateAnimation);
            v.startAnimation(animationSet);

            return v;
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data==null) return ;
        if (resultCode!=0) return ;

        String val = data.getStringExtra("result");
        final ArrayList<String> arr = new ArrayList<>();
        arr.add(menuid);
        arr.add(val);

        Thread th = new Thread(new Runnable() {
            public void run() {
                String res = mysql.pro("menu_scan", arr, handler);
                if(res.startsWith("Y") || res.startsWith("N")) return;
                mysql.sendmsg(handler, true, res) ;
            }
        });
        th.start();
    }
}