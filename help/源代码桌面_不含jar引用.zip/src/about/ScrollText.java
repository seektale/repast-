package about;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import sidePanel.SouthPan;
public class ScrollText extends JLayeredPane implements MouseListener,MouseWheelListener{
	private static final long serialVersionUID = 21245682231L;
	private int start=20,index=0;     //start为字幕初始位置
	private ArrayList<String> list=new ArrayList<String>();  //数组序列类中的元素为String

	private Thread thread=null;
	public boolean flag=true;		//用于结束线程的变量
	private boolean b=false;
	public ScrollText(){
		
		nextString();    //向Arraylist中写入文字
		addMouseListener(this);
		addMouseWheelListener(this);
		
		//文字移动速度控制线程
		thread=new Thread(new Runnable() {
		public void run(){
			while(flag){
			    try {Thread.sleep(30);}catch (InterruptedException e){}
			    repaint();  //即便没有这一句文字也会滚动,说明paint每隔一定时间自动调用
			    start--;
			    if(start<=0){
			    	index++;
			    	if(index>list.size()-10) index=0;
			    	start=20;
			    }
			    
			    //暂停线程,必须在run()里面
			    if(b)
			    synchronized (thread) {
		    		try{
		    			thread.wait();
		        	}catch(Exception es){System.out.println(es.toString());}
				}
			}
		}});
		thread.start();
	}
    public void paint(Graphics g){
    	g.setColor(Color.blue);
    	int temp=start;
    	for(int i=0;i<10;i++){
        	g.drawString(list.get(i+index),1,temp);
        	temp=temp+20;
    	}
    }
    
	private void nextString() {
		try {
			// 下面的方法不支持打包成jar文件后仍能运行
			// URL lic = this.getClass().getClassLoader().getResource("about/License.txt");
			// URL lic = ClassLoader.getSystemResource("about/License.txt");
			// RandomAccessFile rf=new RandomAccessFile(new File(lic.toURI()),"rw");
			// rf.seek(0);

			// 换用下面的方法打包成jar文件后仍可运行
			final InputStream in = this.getClass().getResourceAsStream("License.txt");
			final BufferedReader rea = new BufferedReader(new InputStreamReader(in, "utf8"));
			
			// 每次读取文件指针自动后移
			int b = 0;
			final StringBuffer str = new StringBuffer();
			do {
				b = rea.read();
				str.append((char) b);
				//if(b == 13)读取到换行符,if(b == -1)读取到未尾
				if(check(str.toString())||(b==-1)||(b==13)){
					list.add(str.toString());
					// 复位
					str.delete(0, str.length());
				}
			} while (b != -1);

			rea.close();
			in.close();
		} catch (Exception i) {
			SouthPan.warn("读取文件异常\n" + i.toString(), true);
		}
	}
	
	//声明为全局变量可加快速度
	private JLabel la=new JLabel();
	private boolean check(String s){
		la.setText(s);
		if(la.getPreferredSize().width>320) return true;	//调整文字宽度
	    return false;
	}
    
    public void mouseWheelMoved(MouseWheelEvent e){
    	int n=e.getWheelRotation();  //上滚为1，下滚为了-1
    	for(byte i=0;i<15;i++){
    		start=start-n;
    		if(start<=0){
    	    	index++;
    	    	if(index>=list.size()-10) index=0;
    	    	start=20;
    	    }
        	if(start>20){
    	    	index--;
    	    	if(index<=0) index=0;
    	    	start=0;
    	    }
        	repaint();	//同步显示
    	}
    }
    public void mouseClicked (MouseEvent e){}
    public void mouseEntered (MouseEvent e){
    	b=true;
    }
    public void mouseExited  (MouseEvent e){
    	//唤醒线程
    	b=false;
    	synchronized (thread) {
			thread.notify();
		}
    }
    public void mousePressed (MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
}
