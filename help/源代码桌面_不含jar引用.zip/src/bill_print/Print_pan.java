package bill_print;
//与帐单打印有关的所有内容
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import javax.print.DocFlavor;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import pub.ConfigFile;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class Print_pan extends JPanel implements ActionListener,Printable{
	private static final long serialVersionUID = -5315034157423757153L;
	//打印模板
	private String sql="select distinct templet from billview";
	private JComboBox<String> templet = new JComboBox<String>(Sql.getString(sql, this));
	private JComboBox<PrintService> printcho;		//打印机选择
	private JComboBox<String> pagesize=new JComboBox<String>(new String[]{"A5","A4","与系统默认打印机一致"});//账单纸张大小
	private int page=1;	//存储当前是第几页帐单
	private JLabel pagetip=new JLabel(" 第 1 页 ");
	
	private JRadioButton newPrint   = new JRadioButton("新账单", false);
    private JRadioButton oldPrint   = new JRadioButton("原账单", false);
	private JRadioButton menu_print = new JRadioButton("商品打印");
	private JRadioButton pay_print 	= new JRadioButton("结账打印");
	private JCheckBox showback=new JCheckBox("显示退单");
	private JCheckBox showlist=new JCheckBox("显示套餐明细");
	
	private JButton print 	= new JButton("打印 P");
	private JButton view	= new JButton("预览 V");
	
	private View_Panel viewbill=new View_Panel();

	//账单预览对话框，如果对话框采用dispose()的方法，每次预览将占用两兆内存
	private View_Dialog vd=new View_Dialog();
	
	private int mealnum;
	public Print_pan(int mealnum){
		this.mealnum=mealnum;
		BoxLayout layout=new BoxLayout(this, BoxLayout.Y_AXIS); //垂直布局
		setLayout(layout);

		String sql="select 索引,商品名 from dish where 索引 IN " +
				"(select 内容 from dishlog where 动作='打印位置标记' and 台次="+mealnum+") order by 索引 desc limit 0,1;";
		String lastdish[]=Sql.getString(sql, this);
		if(lastdish.length==2){
			oldPrint.setToolTipText("旧账单打印的最后一个商品是："+lastdish[1]+" ("+lastdish[0]+")");
		}
		menu_print.setToolTipText("<商品打印>选择后将对打印位置进行标记");
		
		 //打印操作
		JPanel pri=new JPanel(new FlowLayout(FlowLayout.LEFT,6,0));
		pri.add(new JLabel("打印机选择："));
		PrintRequestAttributeSet pras =new HashPrintRequestAttributeSet();//获得打印属性
		pras.add(new Copies(1));
		PrintService pss[] =PrintServiceLookup.lookupPrintServices(DocFlavor.INPUT_STREAM.GIF,pras);//获得打印设备
		printcho=new JComboBox<PrintService>(pss);
		printcho.addActionListener(this);
		String config=ConfigFile.getProperty("PrintMachine");
		int indv=0;
		try{
			indv=Integer.valueOf(config);
		}catch (Exception e) {}
		if(indv<printcho.getItemCount()){
			printcho.setSelectedIndex(indv);
		}
		if(pss.length>0) pri.add(printcho);
		else pri.add(new JLabel("   本地主机没有安装任何可用的打印输出设备。"));
		add(pri);
		add(Box.createVerticalStrut((10))); 	//垂直方向间距
		
		JPanel oper=new JPanel(new FlowLayout(FlowLayout.LEFT,6,0));
		JButton up  =new JButton("上一页");
		JButton next=new JButton("下一页");
		up.addActionListener(this);
		next.addActionListener(this);
		templet.addActionListener(this);
		templet.setSelectedItem(ConfigFile.getProperty("Templet"));
		pagetip.setBackground(Color.LIGHT_GRAY);
		pagetip.setOpaque(true);
		
		oper.add(templet);
		oper.add(up);
		oper.add(pagetip);
		oper.add(next);
		oper.add(new JLabel(" 账单纸张规格:"));
		oper.add(pagesize);
		add(oper);
		add(Box.createVerticalStrut((10)));

		JPanel printstyle=new JPanel(new FlowLayout(FlowLayout.LEFT,6,0));
		ButtonGroup a_group = new ButtonGroup();
	    a_group.add(newPrint);
	    a_group.add(oldPrint);
	    ButtonGroup b_group = new ButtonGroup();
	    b_group.add(menu_print);
	    b_group.add(pay_print);
	    
	    JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
	    temp.setBorder(Sql.getBorder(2, null));
	    temp.add(newPrint);
	    temp.add(oldPrint);
	    printstyle.add(temp);
	    
	    temp=new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
	    temp.setBorder(Sql.getBorder(2, null));
	    temp.add(menu_print);
	    temp.add(pay_print);
	    printstyle.add(temp);
	    printstyle.add(showback);
	    printstyle.add(showlist);
	    
	    config=ConfigFile.getProperty("Show_Back");
	    if(config.equals("Y")) showback.setSelected(true);
	    config=ConfigFile.getProperty("Show_List");
	    if(config.equals("Y")) showlist.setSelected(true);
	    add(printstyle);
	    
	    add(Box.createVerticalStrut((10)));
		add(new JSeparator());
		temp=new JPanel(new FlowLayout());
	    temp.add(print);
	    temp.add(view);
	    add(temp);
	    
	    print.setMnemonic(KeyEvent.VK_P);
	    view.setMnemonic(KeyEvent.VK_V);

		newPrint.setSelected(true);
		pay_print.setSelected(true);
		
		newPrint.	addActionListener(this);
		oldPrint.	addActionListener(this);
		menu_print.	addActionListener(this);
		pay_print.	addActionListener(this);
		print.		addActionListener(this);
		view.		addActionListener(this);
		showback.	addActionListener(this);
		showlist.	addActionListener(this);
		
		add(Box.createVerticalStrut((6)));
		add(new JSeparator());
		add(Box.createVerticalStrut((6)));
		add(new Hotprint(mealnum));			//热敏机打印
	}
	private void printok(){
		String a="N",b="N",c="N",d="N",se="";
		if(newPrint.isSelected()) 		a="Y";
		if(pay_print.isSelected())		b="Y";
		if(showback.isSelected())		c="Y";
		if(showlist.isSelected())		d="Y";
		se=templet.getSelectedItem().toString();
		
		//后两个参数为：新旧账单判断，是否打印结账
		viewbill.initval(mealnum, page, se,a,b,c,d);
	}
	public int print(Graphics graphics, PageFormat pageFormat, int pageIndex)throws PrinterException{
		//将面板上的内容打印出来，与print按扭响应
		viewbill.paint(graphics);
		return PAGE_EXISTS;
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==view){
			printok(); //先刷新
			vd.to(viewbill);
		}
		else if(e.getSource()==templet){
			//更新默认打印模板
			ConfigFile.setProperty("Templet", templet.getSelectedItem().toString());
		}
		else if(e.getSource()==showback){
			//更新默认打印模板
			ConfigFile.setProperty("Show_Back", showback.isSelected());
		}
		else if(e.getSource()==showlist){
			//更新默认打印模板
			ConfigFile.setProperty("Show_List", showlist.isSelected());
		}
		else if(e.getSource()==printcho){
			//更新默认打印机
			ConfigFile.setProperty("PrintMachine", printcho.getSelectedIndex()+"");
		}
		else if(e.getActionCommand()=="上一页"||e.getActionCommand()=="下一页"){
			int temp=page;
			if(e.getActionCommand()=="上一页"){
				if(page>1) page--;
			}
			else if(e.getActionCommand()=="下一页"){
				page++;
			}
			//相应的显示当前定位在第几页
			if(temp!=page){
				pagetip.setText(" 第 "+page+" 页 ");
			}
			else{
				SouthPan.warn("已经是账单的最后一页或第一页！",true);
			}
		}
		else if(e.getSource()==print){
			if(menu_print.isSelected() && (!showback.isSelected() || !showlist.isSelected())){
				JOptionPane.showMessageDialog(Front.front, "使用<商品打印>选项时，[显示退单] 和 [显示套餐明细] 必须被选择","消息",2);
				return ;
			}
			if(printcho.getSelectedItem()==null){
				JOptionPane.showMessageDialog(Front.front, "当前主机系统未安装任何打印机设备，打印无法继续","消息",2);
				return ;
			}
			
			//确定纸张大小
			viewbill.pagesize = pagesize.getSelectedItem().toString();
			printok();	//生成数据，这一句必须要有
		    //设置成竖打
		    PageFormat pf = new PageFormat();
		    pf.setOrientation(PageFormat.PORTRAIT);
		    //通过Paper设置页面的空白边距和可打印区域。必须与实际打印纸张大小相符。
		    Paper p = new Paper();
		    int x=595,y=842;		//A4(595 X 842)，以像素为单位
		    p.setSize(x,y);			//纸张大小 ,
		    p.setImageableArea(0,0, x,y);//设置打印区域,即这一区域内可以有文字出现
		    pf.setPaper(p);
		    
		    //获取页面格式,来自操作系统的默认打印机选用的纸张,因此依赖操作系统
			//PageFormat pf = PrinterJob.getPrinterJob().defaultPage();
		    
		    //通俗理解就是书、文档
		    Book book = new Book();
		    //把 PageFormat 和 Printable 添加到书中，组成一个页面,其中this指定了本类中实现的print()方法
		    book.append(this, pf);
		    
			// 如果打印机不存在，上面已作了判断
			PrintService Pserver = (PrintService) printcho.getSelectedItem();
			// 获取打印服务对象
			PrinterJob job = PrinterJob.getPrinterJob();
			// 设置打印类
			job.setPageable(book);
			try {
				job.setPrintService(Pserver);
				// if(job.printDialog()) job.print(); //对话框确定打印
				job.print();
				// 标记菜品打印位置
				if (menu_print.isSelected()) {
					Sql.mysqlprocedure("print_flag", mealnum + "");
				}
			} catch (Exception ea) {
				ea.printStackTrace();
				JOptionPane.showMessageDialog(Front.front,"打印失败，请检查打印服务是否可用？\n" + ea.toString(),"错误",0);
			}
			
			viewbill.pagesize="";	//一定要在这里复位
		}
	}
}
