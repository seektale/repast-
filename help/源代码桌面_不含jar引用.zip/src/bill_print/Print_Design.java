package bill_print;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import pub.Var;
import root.Front;
import root.Sql;
import sidePanel.SouthPan;
public class Print_Design extends JInternalFrame implements ActionListener,DocumentListener,MouseListener{
	private static final long serialVersionUID = 2955920470363246923L;
	private final JComboBox<String> templet = new JComboBox<String>(Sql.getString("select distinct templet from billview", this));
	private final JLabel sqltip=new JLabel(" SQL Language：");
	
	private final JPanel left =new JPanel(new BorderLayout());
	private final JTable right=Sql.getTable();
	private final View_Panel viewbill=new View_Panel();
	
	private final JTextField sql	=new JTextField();
	private final JTextField leftfar=new JTextField();
	private final JTextField upfar	=new JTextField();
	private final JTextField fontsize	=new JTextField();
	private JComboBox<String>  fontstyle=new JComboBox<String>();
	private final JComboBox<String>  area 	=new JComboBox<String>(new String[]{"页眉","商品区","分页区","结账区","页尾"});
	private final JTextField rowfar	=new JTextField();
	private final JTextField rowshow	=new JTextField();
	private final JButton    color	=but("Text_Color 颜色");
	private final JCheckBox  use	=new JCheckBox("启用当前条目");
	private final JCheckBox  logo	=new JCheckBox("打印 Logo");
	
	private final JComboBox<String> div,ind;
    private final JButton save=new JButton("保存参数");
    private final JButton view=new JButton("预览效果");
    private final JButton up=new JButton("上一页");
    private final JButton next=new JButton("下一页");
    private int page=1;
    
    //账单预览对话框，如果对话框采用dispose()的方法，第次预览将占用两兆内存
	private View_Dialog vd=new View_Dialog();
	
	public Print_Design(){
		
		super("账单设计",true,true,true,true);
		JPanel Pan  =new JPanel(new GridLayout(1,2,6,2));
		setContentPane(Pan);
	    setResizable(true);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
	    left.setBorder(BorderFactory.createTitledBorder("参数设置"));
	    
	    //根面板北面
	    JPanel grid=new JPanel(new GridLayout(11,1,6,3));
	    templet.addActionListener(this);
	    templet.actionPerformed(null);
	    
	    JPanel p=new JPanel(new GridLayout(1,5,6,3));	//边距
	    p.add(templet);
	    p.add(lab(" 测试区域："));
	    div = new JComboBox<String>(Var.area());
	    div.addActionListener(this);
	    p.add(div);
	    p.add(lab(" 测试台号："));
	    //下面一句起到初始化全局变量ind并赋值的作用。
	    ind=new JComboBox<String>();
	    actionPerformed(new ActionEvent(div,0,"")) ;
	    p.add(ind);
	    grid.add(p);
	    
	    grid.add(new JLabel());
	    JLabel la=new JLabel(" 相 关 参 数",JLabel.CENTER);
	    la.setBackground(Color.gray);
	    la.setOpaque(true);
	    grid.add(la);
	    grid.add(sqltip);
	    grid.add(sql);
	    sql.getDocument().addDocumentListener(this);
	    
	    p=new JPanel(new GridLayout(1,4,6,3));	//边距
	    p.add(lab("左边距："));
	    p.add(leftfar);
	    p.add(lab("上边距："));
	    p.add(upfar);
	    grid.add(p);
	    
	    p=new JPanel(new GridLayout(1,4,6,3));	//字体
	    p.add(lab("字体大小："));
	    p.add(fontsize);
	    p.add(lab("字体样式："));
	    GraphicsEnvironment g = GraphicsEnvironment.getLocalGraphicsEnvironment();
		String fontName[] = g.getAvailableFontFamilyNames();
		fontstyle = new JComboBox<String>(fontName);
	    p.add(fontstyle);
	    grid.add(p);

	    p=new JPanel(new GridLayout(1,4,6,3));	//行距
	    p.add(lab("区域："));
	    p.add(area);
	    p.add(color);
	    p.add(use);
	    grid.add(p);
	    
	    p=new JPanel(new GridLayout(1,4,6,3));
	    p.add(new JLabel());
	    p.add(new JLabel());
	    p.add(new JLabel());
	    p.add(new JLabel());
	    grid.add(p);
	    
	    grid.add(new JLabel("商品列表参数及Logo："));
	    
	    p=new JPanel(new GridLayout(1,5,6,3));	//行距
	    p.add(lab("行间距："));
	    p.add(rowfar);
	    p.add(lab("每页显示行数："));
	    p.add(rowshow);
	    p.add(logo);
	    grid.add(p);
	    
	    left.add("North",grid);

	    //根面板中间
	    JLabel dsc=new JLabel();
	    String d1="①、当对象的区域在'结账区'时，其上边距在实际应用中会跟随上一行数据的高度！";
	    String d2="②、会调用的函数：strprocess(),bill_show(),total_money(),strlength()，这些是自定义的函数";
	    String d4="③、如果语句中含字符串‘mealtimes’，‘current_page’，page_start，page_row，它将被存储过程替代为相应值。";
	    String d5="④、对于系统中提供的对象不能满足实际需求时，可到数据库中的billview表中添加数据行。";
	    dsc.setText("<html><p>参数调整说明：</p><p>"+d1+"</p><p>"+d2+"</p><p>"+d4+"</p><p>"+d5+"</p></html>");
	    left.add("Center",dsc);
	    
	    //根面板南面
	    JPanel pp=new JPanel(new FlowLayout(FlowLayout.RIGHT,8,2));
	    save.addActionListener(this);
	    view.addActionListener(this);
	    up.addActionListener(this);
	    next.addActionListener(this);
	    pp.add(save);
	    pp.add(view);
	    pp.add(up);
	    pp.add(next);
	    left.add("South",pp);
	    Pan.add(left);
	    
	    right.addMouseListener(this);
	    Pan.add(new JScrollPane(right));
	    
	    templet.setSelectedIndex(0); //默认展示第一个
	}
	
    //有亮黑色背景自定义的标签
    private JLabel lab(String s){
    	JLabel l=new JLabel("  "+s);
		l.setOpaque(true);
		l.setBackground(Color.LIGHT_GRAY);
		return l;
    }
    //有亮黑色背景自定义的按扭
    private JButton but(String s){
    	JButton b=new JButton(s);
    	b.addActionListener(this);
	    b.setContentAreaFilled(false);
	    b.setBackground(Color.LIGHT_GRAY);
	    b.setOpaque(true);
		return b;
    }
    
	//得到当前餐次
	private int getMeal(){
		String a=div.getSelectedItem().toString();
		String b=ind.getSelectedItem().toString();
		String s[]=Sql.getString("select 台次 from deskgo where 开台时间=(select 操作时间 from desk where 区域='"+a+"' and 台号="+b+");",this);
		if(s.length==0){
			SouthPan.warn("当前区域："+a+" 台号："+b+" 在deskgo表中未查询到记录。请换一个餐台试试！", true);
		}
		else{
			try {
				return Integer.valueOf(s[0]);
			} catch (Exception e){
				// TODO: handle exception
				SouthPan.warn("查询到台次:"+s[0]+" 转int出现异常，位置："+getClass().getName(), true);
			}
		}
		return 0;
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==templet){
			String rsql = "select ind,templet,name,area,used from billview where templet='"+templet.getSelectedItem().toString()+"';" ;
			Sql.getArrayToTable(rsql, this, right);
		}
		else if(e.getSource()==color){
			Color c =JColorChooser.showDialog(this,"色彩选择",color.getForeground());
			if(c!=null)	color.setForeground(c);
		}
		else if(e.getSource()==div){
			String divval = div.getSelectedItem().toString() ;
			String ss[]=Sql.getString("select 台号 from desk where 区域='"+divval+"' and 状态='已开台' order by 台号;",this);
			DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(ss);
			ind.setModel(model);
		}
		else if(e.getSource()==up){
			if(page>1){
				page--;
				view.doClick();
			}
			else{
				SouthPan.warn("已经是账单的第一页！",true);
			}
		}
		else if(e.getSource()==next){
			viewbill.mealnum=getMeal();		//先指定餐次
			page++;
			view.doClick();
		}
		//预览效果
		else if(e.getSource()==view){
			//先清除缓存
			Var.hprint.remove(templet.getSelectedItem().toString());
			viewbill.initval(getMeal(),page, templet.getSelectedItem().toString(),"Y","Y","Y","Y"); //先刷新
			vd.to(viewbill);	//显示对话框
		}
		else if(e.getSource()==save){
			int row=right.getSelectedRow();
			if(row==-1){
				SouthPan.warn("没有在右边表格中选择编辑对象,无法保存.", true);
				return ;
			}
			ArrayList<String> v=new ArrayList<String>();
			v.add(Sql.getval(right, "ind", row));	//索引
			v.add(area.getSelectedItem()+"");		//位置
			v.add(sql.getText());
			v.add(leftfar.getText());
			v.add(upfar.getText());
			v.add(fontsize.getText());
			v.add((String)fontstyle.getSelectedItem());
			
			Color c=color.getBackground();
			v.add(String.valueOf(c.getRGB()));
			if(use.isSelected())	v.add("Y");
			else v.add("N");
			
			v.add(rowfar.getText());
			v.add(rowshow.getText());
			if(logo.isSelected())	v.add("Y");
			else v.add("N");
		
			boolean b=Sql.mysqlprocedure("BillDesign",v);
			if(b){		//刷新
				String s=templet.getSelectedItem().toString();
				String rsql = "select ind,templet,name,area,used from billview where templet='"+s+"';" ;
				Sql.getArrayToTable(rsql, this, right);
			}
		}
	}
	
	@Override
	public void insertUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		int k=sql.getText().length();
		if(k<=255){
			sqltip.setText(" SQL Language：Char length "+k+"<=255");
		}
		else{
			sqltip.setText(" SQL Language：Char length "+k+">255");
		}
	}
	@Override
	public void removeUpdate(DocumentEvent e) {
		insertUpdate(e);
		
	}
	@Override
	public void changedUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		String num=Sql.getval(right, "ind", right.getSelectedRow());
		String s[]=Sql.getString("select * from billview where ind="+num, this);
		if(s.length==0){
			SouthPan.warn("从数据库中读取编号："+num+" 的相关数据失败，数组长度："+s.length, true);
			return ;
		}
		area.setSelectedItem(s[3]);
		sql.setText(s[4]);
		leftfar.setText(s[5]);
		upfar.setText(s[6]);
		fontsize.setText(s[7]);
		fontstyle.setSelectedItem(s[8]);
		rowfar.setText(s[9]);
		rowshow.setText(s[10]);
		if(s[11].isEmpty()) s[11]="0";
		color.setBackground(new Color(Integer.valueOf(s[11])));
		
		use.setSelected(false);
		if(s[12].equals("Y"))	use.setSelected(true);
		
		logo.setSelected(false);
		if(s[13].equals("Y"))	logo.setSelected(true);
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
