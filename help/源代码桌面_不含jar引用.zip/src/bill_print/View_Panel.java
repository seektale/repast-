package bill_print;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Rectangle2D;
import java.awt.print.PageFormat;
import java.awt.print.PrinterJob;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import pub.Var;
import root.Sql;
import sidePanel.SouthPan;
public class View_Panel extends JPanel{
	private static final long serialVersionUID = 4225400121253708889L;
	//参数为餐次和帐单的第几页,以及所选用的模板
	public int mealnum;
	private int billpage;			//帐单当前页数，从1开始编号
	private String templet;			//模板
	private String isnew="Y",isend="Y";		//新账单，结账打印
	public String pagesize="";		//纸张大小
	private ArrayList<String[]> arr;//决定参数的属性
	private ArrayList<ArrayList<String>> v;		//存储参数
	public View_Panel(){}
	//本方法用于初始化参数
	public void initval(int a, int b, String c, String isnew, String isend, String showback, String showtao){
		mealnum=a;
		billpage=b;
		templet=c;
		this.isnew=isnew;
		this.isend=isend;
		
		//查找所有参数,注意排序与存储过程bill_view中的要一致
		arr = Var.billview(templet);
		
		//执行存储过程得到参数，参数为台次，页码，模板，是否是新账单
		v=Sql.procedure_bill(mealnum+"", billpage+"", templet, isnew, showback, showtao);
		
		repaint();
	}

	//参考：String sql = "select area,font_size,font_style,left_far,up_far,color,row_far,row_count,logo from billview "
	private String val(String col,int row){
		String temp[] = arr.get(row);
		if(col.equals("area")) 		return temp[0];
		if(col.equals("font_size")) return temp[1];
		if(col.equals("font_style"))return temp[2];
		if(col.equals("left_far")) 	return temp[3];
		if(col.equals("up_far")) 	return temp[4];
		if(col.equals("color")) 	return temp[5];
		if(col.equals("row_far")) 	return temp[6];
		if(col.equals("row_count")) return temp[7];
		if(col.equals("logo")) 		return temp[8];
		
		return "";
	}
	
	public void paint(Graphics g){
		//这一句必须有，如果没有，刷新账单时，因比列账单右边空出部分背景不能更新
		super.paint(g);
		
		Graphics2D g2 = (Graphics2D)g;	//转换成Graphics2D,必须转换,否则不能打印出面板JPanel上的内容
	    g2.setColor(Color.black);		//设置打印颜色为黑色
	    
	    //1.线宽 2、3、不知道，4、空白的宽度，5、虚线的宽度，6、偏移量
	    float[] dash1 = { 4.0f };
		g2.setStroke(new BasicStroke(0.5f, BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER, 4.0f, dash1, 0.0f));
		
		double sx,sy;
		if(pagesize.isEmpty()){
			sx = getWidth() - 1;	//预览账单时对话框面板的宽度和高度
		    sy = getHeight() - 1;
		}
		else if(pagesize.equals("A5")){
			sx=418-1;
			sy=595-1;
		}
		else if(pagesize.equals("A4")){
			sx = 595-1;
	        sy = 842-1;
		}
		else{
			//获取页面格式,来自操作系统的默认打印机选用的纸张,注意是默认打印机；因此依赖操作系统
			PageFormat pf = PrinterJob.getPrinterJob().defaultPage();
	        sx = pf.getWidth()-1; 				// 默认打印机选用纸张页面宽度
	        sy = pf.getHeight()-1; 				// 默认打印机选用纸张页面高度
	        if(sx<10||sy<10) {sx=418;sy=595;}	//值有问题的情况下按A5大小设定
		}
		
        
		double scale; 		//在屏幕上适合页面的比例
		double px = 595;	//A4纸的宽度，因为账单设计时按A4纸张的大小设计的,所以按A4纸张的大小为参照
		double py = 842;	//A4纸的高度，账单设计时按A4纸张设计，可以保证小账单是缩放，清晰度高
        if (px / py < sx / sy) {
        	scale = sy / py; // 计算比例
        }
        else{
        	scale = sx / px; // 计算比例
        }
        g2.translate(0, 0); 	// 转换坐标,左边距，上边距
        g2.scale(scale, scale);	// 其作用可以按比列缩小或放大页面
        
        Rectangle2D page = new Rectangle2D.Double(0, 0, px, py); // 绘制页面矩形
        g2.setPaint(Color.white); // 设置页面背景为白色
        
        //g2.fill(page); 这一句被下面的换掉了
        //由于page的区域太小，打印时，区域外会打印出灰色背景，所以自己修改了一下区域大小，使的背景均为白色
        Rectangle2D pagearea = new Rectangle2D.Double(0, 0, 1000, 1080); // 绘制页面矩形
        g2.fill(pagearea);
        
        g2.setPaint(Color.black);	//设置页面文字为黑色
        g2.draw(page);				//画了一个虚线边界
        
        if((mealnum>0)&&(billpage>0)&&(!templet.isEmpty())){
        	if(arr.size() == v.size()){
        		drawv(g2);
    		}
    		else{
    			SouthPan.warn("账单预览时，由于 '参数' 与 '参数属性' 不能一一对应，预览被中止", false);
    		}
        }
	}
	
	//在面板上画出数据
	private void drawv(Graphics2D g2){
		int rowfar=getint(val("row_far", 0),20);	//行间距
		int upy=0;		//记录上一行的上边距
		
		//logo的设计
		if(val("logo", 0).equals("Y") && isnew.equals("Y")){
			Icon icon=Var.getIcon("logo");
			Image ima=((ImageIcon)icon).getImage();
			g2.drawImage(ima, 36, 20, icon.getIconWidth(), icon.getIconHeight(), null);
		}
		
		//一次从向量中读取一个数据
		for(int n=0;n<v.size();n++){
			int size=getint(val("font_size", n),18);
			Font font = new Font(val("font_style", n), Font.PLAIN, size);
			g2.setFont(font);		//设置字体
			g2.setColor(new Color(getint(val("color", n),0)));
			String str=val("area", n);
			
			int left=getint(val("left_far", n),20);				//左边距
			int up  =getint(val("up_far", n),20);				//上边距
			
			ArrayList<String> sub=v.get(n);		//取数据

			//商品区的高度跟随上一行数据的高度，自身定义高度没有意义
			if(!str.equals("结账区")) upy=up;
			
			//draw数据，两两组合，分四种情况考虑
			for(int x=0;x<sub.size();x++){
				String temp=sub.get(x);
				
				//商品列表区如果不打印退单，那么就是一个空行，这里不要打印出空行
				if(temp.isEmpty()&&sub.size()>1) continue;
				
				upy = upy + rowfar;
				
				//新账单，商品打印。结账区不能显示
				if(isnew.equals("Y") && isend.equals("N") && str.equals("结账区")) continue;
				
				//新账单，结账打印。全部显示
				
				//旧账单，商品打印。仅显示商品
				if(isnew.equals("N") && isend.equals("N") && !str.equals("商品区")) continue;
				
				//旧账单，结账打印。显示商品名和结账区
				if(isnew.equals("N") && isend.equals("Y") && !str.equals("商品区") && !str.equals("结账区") ) continue;
				
				g2.drawString(temp, left, upy);
			}
		}
	}

	//字符串转int
	private int getint(String s,int k){
		try {
			k=Integer.valueOf(s);
		} catch (Exception e) {
			SouthPan.warn("字符串:"+s+" 转int异常，将返回默认值"+k+"代替! 位置："+getClass().getName(), false);
			return k;
		}
		return k;
	}
}
