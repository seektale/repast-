package bill_print;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import pub.ConfigFile;
import pub.Photo;
import root.Front;
import root.Sql;
public class Hotprint extends JPanel implements ActionListener{
	private static final long serialVersionUID = -531533157423757153L;
	//打印机选择
	private JComboBox<String> place ;
	private JButton ok=new JButton("打印帐单");
	private JButton list=new JButton("打印清单");
	private JButton union=new JButton("打印联单");
	private int meal_num ;
	public Hotprint(int meal_num){
		this.meal_num=meal_num;
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		place = new JComboBox<String>(Sql.getString("select 站点 from print_config", this));
		place.addItem("COM1");
		place.addItem("COM2");
		
		add(new JLabel("热敏打印机站点："));
		add(place);
		add(ok);
		add(list);
		add(union);
		add(new JLabel("    "));
		
		String temp=ConfigFile.getProperty("HotPrintStation");
		if(temp.isEmpty()){
			place.actionPerformed(null);
		}
		else{
			place.setSelectedItem(temp);
		}
		
		place.addActionListener(this);
		ok.addActionListener(this);
		list.addActionListener(this);
		union.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==place){
			ConfigFile.setProperty("HotPrintStation", place.getSelectedItem().toString());
			return ;
		}
		
		final String com = place.getSelectedItem().toString();
		if(com.isEmpty()){
			JOptionPane.showMessageDialog(this, "请先选择 热敏打印机 站点 ？");
			return ;
		}
		
		if(e.getSource()==ok){
			byte b[] = Photo.getbill(meal_num);
			print(b);
		}
		if(e.getSource()==list){
			byte b[] = Photo.getlist(meal_num, com);
			print(b);
		}
		if(e.getSource()==union){
			byte b[] = Photo.getunion(meal_num, com);
			print(b);
		}
	}
	
	private void print(byte b[]) {
		if(b==null) return ;
		final String com = place.getSelectedItem().toString();
		if(com.toUpperCase().startsWith("COM")){
			try {
				Photo.Printcom(b, com);
			}
			catch (Exception err) {
				JOptionPane.showMessageDialog(Front.front, err.getMessage(), "错误", 0);
				err.printStackTrace();
			}
			return ;
		}
		Photo.printbin(b, com, true);
	}
}
