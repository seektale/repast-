package print;
import java.util.Enumeration;
import javax.comm.CommPortIdentifier;
import javax.swing.JInternalFrame;
import javax.swing.JTabbedPane;
import root.Front;
public class PrintFrame extends JInternalFrame{
	private static final long serialVersionUID = 6688515361113730386L;
	private JTabbedPane Pan=new JTabbedPane();
	public PrintFrame() {
		super("打印机设置",true,true,true,true);
		setTitle("打印机设置 串口："+Printcom());
		setContentPane(Pan);
	    setResizable(true);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
    	Pan.add("打印机配置",new Print_site());
    	Pan.add("打印机状态",new Print_station());
    	Pan.add("打印日志",new Print_result());
	}
	
	//获取本机的所有串有清单,仅限jdk或jre在32位模式
	private String Printcom() {
		String tem="";
		final Enumeration<?> portList = CommPortIdentifier.getPortIdentifiers();
		while (portList.hasMoreElements()) {
			final CommPortIdentifier portId = (CommPortIdentifier)portList.nextElement();
			//if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
				if(tem.isEmpty()) tem = portId.getName();
				else tem = tem + "," + portId.getName();
			//}
		}
		return tem;
	}
	
}