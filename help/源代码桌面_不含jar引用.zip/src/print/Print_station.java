package print;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

import root.Front;
import root.Sql;
public class Print_station extends JPanel implements ActionListener{
	private static final long serialVersionUID = 2398474243505825574L;
	private JTable t=Sql.getTable();
	private JButton refresh=new JButton("刷新打印机列表");
	private JButton ping=new JButton("PING 检测");
	private JButton soc=new JButton("SOCKET 检测");
	public JButton scan=new JButton("发现站点");
	private JTextArea text = new JTextArea("点击 <发现站点> 扫描同网段是否有热敏打印机(ESC/POS指令集)存在\n\n");
	private JTextArea result = new JTextArea("扫描网段:\n");
	private int port=9100;
	public Print_station(){
		Sql.getArrayToTable("select 站点,IP,端口,'请选择检测方式' from print_config",this,t);
		Sql.TableAtt(t, true, false);
    	JPanel up=new JPanel();
		up.setLayout(new FlowLayout(FlowLayout.LEFT,20,5));
		refresh.addActionListener(this);
		ping.addActionListener(this);
		soc.addActionListener(this);
		scan.addActionListener(this);
		
		up.add(refresh);
		up.add(ping);
		up.add(soc);
		up.add(scan);
		up.add(new JLabel("端口扫描需要 Window7 及以上操作系统, 注意：共享的办公室打印机可能一同被找到"));
		
		JPanel pan=new JPanel(new GridLayout(1, 2));
		pan.add(new JScrollPane(text));
		pan.add(new JScrollPane(result));
		pan.setPreferredSize(new Dimension(0,200));
		text.setEditable(false);
		result.setEditable(false);
		result.setForeground(Color.BLUE);
		
		setLayout(new BorderLayout());
    	add(up, BorderLayout.NORTH);
		add(new JScrollPane(t), BorderLayout.CENTER);
		add(pan, BorderLayout.SOUTH);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==refresh){
			Sql.getArrayToTable("select 站点,IP,端口,'请选择检测方式' from print_config",this,t);
			Sql.TableAtt(t, true, false);
			return ;
		}
		if(e.getSource()==scan){
			Object b = JOptionPane.showInputDialog(Front.front, "默认为：9100", "热敏打印机端口", 1, null, null, "9100");
			if(b!=null){
				try{
					port = Integer.valueOf(b.toString());
					scan();
				}catch (Exception es) {
					JOptionPane.showMessageDialog(Front.front, "输入的端口值不是有效数字");
				}
			}
			return ;
		}
		
		for(int k=0;k<t.getRowCount();k++){
			t.setValueAt("WAIT 等待检测", k, t.getColumnCount()-1);
		}
		if(e.getSource()==ping){
			//这里没有采用线程并发的方式，而是单线程运行，用线程并发时发现结果有不稳定现像
			Thread th=new Thread(new Runnable() {
				public void run(){
					for(int k=0;k<t.getRowCount();k++){
						UDPSacn(k);
					}
					// 取消选中的行
					if(t.getRowCount()>0) t.removeRowSelectionInterval(0, t.getRowCount()-1);
				}
			});
			th.start();
		}
		if(e.getSource()==soc){
			for(int k=0;k<t.getRowCount();k++){
				final int row=k;
				Thread th=new Thread(new Runnable() {
					public void run(){
						soc(row);
					}
				});
				th.start();
			}
		}
	}
	
	private void UDPSacn(int row){
		t.setRowSelectionInterval(row, row);	//当前正在检测的行选中
		String ip=Sql.getval(t, "IP", row);
		try{
			t.setValueAt("PING 正在检测", row, t.getColumnCount()-1);
			int timeOut = 3000;
			boolean status = InetAddress.getByName(ip).isReachable(timeOut);
			if(status){
				t.setValueAt("OK 在线(ping)", row, t.getColumnCount()-1);
			}
			else{
				t.setValueAt("NO 离线(timeout)", row, t.getColumnCount()-1);
			}
		}catch (Exception e) {
			t.setValueAt("NO 离线(ping异常)", row, t.getColumnCount()-1);
		}
	}
	private void soc(int row){
		String ip=Sql.getval(t, "IP", row);
		int port=Integer.valueOf(Sql.getval(t, "端口", row));
		try{
			t.setValueAt("SOCKET 正在检测", row, t.getColumnCount()-1);
			Socket socket = new Socket();
			SocketAddress add = new InetSocketAddress(ip, port);
			socket.connect(add, 3000);	//设定超时时间为3秒
			socket.close();
			t.setValueAt("OK 在线(socket)", row, t.getColumnCount()-1);
		}catch (Exception e) {
			t.setValueAt("NO 离线(socket异常)", row, t.getColumnCount()-1);
		}
	}
	
	private synchronized void msg(String ip, String val, JTextArea who){
		who.append("IP:"+ip+"  Port:"+port+"   "+val+"\n");
		who.setCaretPosition(who.getText().length());
	}
	
	//自动寻找同网段服务器
	private void scan(){
		//固定大小的池，设定并发线程数不要超过50个
		final ExecutorService Pool = Executors.newFixedThreadPool(50);
		ArrayList<String> arrip = getLocalIPList();
		for(int m=0; m<arrip.size(); m++){
			result.append("IP:"+arrip.get(m)+"   Port:"+port+"\n");
		}
		result.append("\n扫描结果:\n");
		result.setCaretPosition(result.getText().length());
		
		for(int m=0; m<arrip.size(); m++){
			
			//从本机IP列表中取出一个IP进行处理，并从255个主机中寻找服务器，估且认为其子网掩码为255.255.255.0
			//如果根据子网掩码找，子网掩码为255.255.240.0 则要找的主机太多了，不现实。
			String ip=arrip.get(m);
			if(ip.startsWith("127")) continue;

			//取IP前三位数字
			int flag=ip.lastIndexOf(".");
			ip=ip.substring(0, flag+1);
			
			for(int n=1; n<255; n++){
				String temp=ip+n;
				final String myip=temp;
				
				//扫描，每一个IP启动一个线程
				Pool.submit(new Runnable() {
					
					public void run() {
						msg(myip,"开始测试",text);
						Socket s=null;
						try {
							s = new Socket();
							SocketAddress add = new InetSocketAddress(myip, port);
							s.connect(add, 2000);	//设定超时时间为2秒
							msg(myip,"恭喜,有效热敏打印机地址",text);
							msg(myip,"恭喜,有效热敏打印机地址",result);
						} 
						catch (Exception e) {
							msg(myip,"不可用 (正在自动寻找服务器)",text);
						}
						finally{
							try {s.close();} catch (IOException e) {}
						}
					}
					
				});
				
				// 可以保证当用户关闭当前内部窗口时能结束进程
				if(!t.isDisplayable()){
					System.out.println("由于窗口关闭，端口扫描提前结束。");
					break ;
				}
			}
		}
	}

	/**
     * IceWee 2013.07.19
     * 获取本地IP列表（针对多网卡情况）
     * 测试表明无线网卡也能读取到，不活动的网卡不会出现在列表中
     * @return
     */
    private ArrayList<String> getLocalIPList() {
        ArrayList<String> ipList = new ArrayList<String>();
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            NetworkInterface networkInterface;
            Enumeration<InetAddress> inetAddresses;
            InetAddress inetAddress;
            String ip;
            while (networkInterfaces.hasMoreElements()) {
                networkInterface = networkInterfaces.nextElement();
                inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    inetAddress = inetAddresses.nextElement();
                    if (inetAddress != null && inetAddress instanceof Inet4Address) { // IPV4
                        ip = inetAddress.getHostAddress();
                        ipList.add(ip);
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return ipList;
    }
}

