package print;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import pub.Photo;
import pub.Var;
import root.Front;
import root.Sql;
public class Print_site extends JPanel implements ActionListener{
	private static final long serialVersionUID = 2398474250582557L;
	private JTable cfg=Sql.getTable("select * from print_config",Sql.getTable(),getClass().getName(),true);
	private JCheckBox cb[];
	private JPanel Menu_Class_Pan=new JPanel();
	private JButton add=new JButton("新增站点");
	private JButton del=new JButton("删除站点");
	private JButton test=new JButton("测试站点");
	private JButton testcom1=new JButton("测试COM1");
	private JButton testcom2=new JButton("测试COM2");
	public Print_site(){
		//最下面的可打印菜品选择
		String str[]=Var.getMenu_class(true);
		cb=new JCheckBox[str.length];
		
		Menu_Class_Pan.setLayout(new GridLayout(str.length/8+1,8,1,1));
		Menu_Class_Pan.setBorder(BorderFactory.createTitledBorder("请选择类别 ==>> 可打印的菜谱分类"));

    	for(int k=0;k<str.length;k++){
    		cb[k]=new JCheckBox(str[k]);
    		cb[k].addActionListener(this);
    		Menu_Class_Pan.add(cb[k]);
    	}
    	
       	//北面
    	JPanel up=new JPanel(new FlowLayout(FlowLayout.LEFT,20,5));
		up.setBackground(new Color(180,200,200));
		up.add(add);
		up.add(del);
		up.add(test);
		up.add(testcom1);
		up.add(testcom2);
		up.add(new JLabel("COM 为系统保留站点,用于带有串口的ESC/POS打印设备,部分参数不可变,且COM口需要在32位JDK或JRE下才能工作"));
		add.addActionListener(this);
		del.addActionListener(this);
		test.addActionListener(this);
		testcom1.addActionListener(this);
		testcom2.addActionListener(this);
		
		//加入滚动面板
		setLayout(new BorderLayout());
		add(new JScrollPane(cfg),BorderLayout.CENTER);
		
		JPanel nortemp = new JPanel(new BorderLayout());
		nortemp.add(up,BorderLayout.NORTH);
		nortemp.add(Menu_Class_Pan,BorderLayout.CENTER);
		add(nortemp,BorderLayout.NORTH);
		
		cfg.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.getClickCount() == 1){
					//设置边界标题
					String s=cfg.getValueAt(cfg.getSelectedRow(), 0)+"";	//获得打印机站点名称
					Menu_Class_Pan.setBorder(BorderFactory.createTitledBorder(s+" ==>> 可打印的菜单"));
					Menu_Class_Pan.setName(s);
					
					//根据数据库中的数据初始化
					String[] str=Sql.getString("select 菜品 from print_config where 站点='"+s+"';", Print_site.this);
					if(str.length==1)	str=str[0].split(",");	//根据双逗号分离成字符串
					
					//首先全部复位，即不选 中状态
					for(int n=0;n<cb.length;n++){
						cb[n].setSelected(false);
					}
					for(int m=0;m<str.length;m++){
						for(int n=0;n<cb.length;n++){
							if(str[m].equals(cb[n].getText())){
								cb[n].setSelected(true);	//变为选中状态
								break;
							}
						}
					}
				}
				if (e.getClickCount() == 2){
					dia(false);
				}
			}
		});
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==add){
			dia(true);
		}
		else if(e.getSource()==del){
			int k = cfg.getSelectedRow();
			if(k==-1||k>=cfg.getRowCount()) {
				JOptionPane.showMessageDialog(Front.front,"请先选中要删除的行！");
				return;
			}
			else {
				int tem = JOptionPane.showConfirmDialog(Front.front, "确定要删除吗？", "注意", 2);
				if(tem==0) {
					Sql.mysqlprocedure("print_site_del",cfg.getValueAt(k, 0)+"");
					Sql.getTable("select * from print_config", cfg, this, true); //即时刷新表格
				}
			}
		}
		else if(e.getSource()==test){
			print();
		}
		else if(e.getSource()==testcom1){
			byte[] C = getbin("COM1");
			try {
				Photo.Printcom(C, "COM1");
			}
			catch (Exception err) {
				JOptionPane.showMessageDialog(Front.front, err.getMessage()+"\n注意：COM只能在32位的JDK或JRE环境中运行，不支持64位环境。", "COM1 错误", 0);
				err.printStackTrace();
			}
		}
		else if(e.getSource()==testcom2){
			byte[] C = getbin("COM2");
			try {
				Photo.Printcom(C, "COM2");
			}
			catch (Exception err) {
				JOptionPane.showMessageDialog(Front.front, err.getMessage()+"\n注意：COM只能在32位的JDK或JRE环境中运行，不支持64位环境。", "COM2 错误", 0);
				err.printStackTrace();
			}
		}
		
		//下面是对可打印菜品分类选择的响应
		else if(Menu_Class_Pan.getName()==null){
			for(int n=0;n<cb.length;n++){
				cb[n].setSelected(false);
			}
			JOptionPane.showMessageDialog(null,"请先选定站点？");
		}
		else{
			String str="";
			//记录所有选中的项
			for(int k=0;k<cb.length;k++){
				if(cb[k].isSelected())	str=str+cb[k].getText()+",";
			}
			//调用存储过程
			final ArrayList<String> v=new ArrayList<String>();
			v.add(Menu_Class_Pan.getName());	 //站点名称
			v.add(str);	 			 //新值
			Sql.mysqlprocedure("print_site_menu",v);
			//即时刷新表格
			Sql.getTable("select * from print_config", cfg, this, true);
		}
	}
	
	//编辑对话框
	private void dia(boolean boo){
		JPanel pan=new JPanel();
		pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));	//一行一行的布局
		final JTextField val[]=new JTextField[4];
		final JSpinner pin=new JSpinner(new SpinnerNumberModel(1,0,100,1));
		JCheckBox ca=new JCheckBox("打印分单");
		JCheckBox cb=new JCheckBox("打印联单");
		
		JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		JLabel la=new JLabel("站点名称 Site_Name：");
		la.setPreferredSize(new Dimension(140,20));
 	    temp.add(la);
 	    temp.add(val[0]=new JTextField(10));
 	    pan.add(temp);
 	    
 	    temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("IP地址 Address：");
		la.setPreferredSize(new Dimension(140,20));
	    temp.add(la);
	    temp.add(val[1]=new JTextField(10));
	    pan.add(temp);
	    
	    temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		la=new JLabel("端口 Port：");
		la.setPreferredSize(new Dimension(140,20));
	    temp.add(la);
	    temp.add(val[2]=new JTextField(10));
	    pan.add(temp);
	    
	    temp=new JPanel(new FlowLayout(FlowLayout.LEFT,8,1));
		la=new JLabel("出单倍数 Print：");
	    temp.add(la);
	    temp.add(pin);
	    temp.add(ca);
	    temp.add(cb);
	    pan.add(temp);
	    
	    pan.add(new JSeparator());	//分割线
		
	    //初始化
	    String title="";
	    if(boo){
	    	title="添加新打印站点";
	    	pan.setName("");
	    	val[2].setText("9100");
	    	ca.setSelected(true);
	    }
	    else {
	    	int row=cfg.getSelectedRow();
	    	val[0].setText(cfg.getValueAt(row, 0).toString());
	    	title="编辑站点: "+val[0].getText();
	    	pan.setName(val[0].getText());
	    	val[1].setText(cfg.getValueAt(row, 1).toString());
	    	val[2].setText(cfg.getValueAt(row, 2).toString());
	    	
	    	pin.setValue(Integer.valueOf(cfg.getValueAt(row, 3).toString()));
	    	
	    	String sv=cfg.getValueAt(row, 4).toString();
	    	ca.setSelected(sv.equalsIgnoreCase("Y"));
	    	sv=cfg.getValueAt(row, 5).toString();
	    	cb.setSelected(sv.equalsIgnoreCase("Y"));
	    }

		int action=JOptionPane.showConfirmDialog(Front.front,pan,title,2,1,new ImageIcon());
		if(action==0){
			
			if(val[0].getText().toUpperCase().startsWith("COM")) {
				JOptionPane.showMessageDialog(Front.front, "为防止与COM打印端口出现混淆,禁止打印机名称使用COM开头");
				return;
			}
			
			//修改帐户信息 或 新增帐户
			final ArrayList<String> v=new ArrayList<String>();
			v.add(pan.getName());	//原来的站点名
			v.add(val[0].getText());
			v.add(val[1].getText());
			v.add(val[2].getText());
			v.add(pin.getValue().toString());
			if(ca.isSelected())	v.add("Y");	else v.add("N");
			if(cb.isSelected())	v.add("Y");	else v.add("N");
			Sql.mysqlprocedure("print_site_edit",v);
			Sql.getTable("select * from print_config", cfg, this, true); //即时刷新表格
		}
	}
	
	private void print(){
		int k=cfg.getSelectedRow();
		if(k==-1 || k>=cfg.getRowCount()){
			JOptionPane.showMessageDialog(Front.front,"请先选中要测试的站点！");
			return ;
		}
		byte[] C = getbin(Sql.getval(cfg, "站点", k));
		Photo.printbin(C, Sql.getval(cfg, "站点", k), true);
	}
	
	private byte[] getbin(String site){
		String val = "站点："+site+"  测试打印：\n" +
					 "如果您看到了这此文字，说明打印机工作正常。\n" +
					 "更多资源：www.dmumu.com\n" +
					 "1015-01-19 武汉工作室，倾力打造。\n\n\n\n";
		
		byte[] A = new byte[]{};
		try{A=val.getBytes("GBK");}catch (Exception e) {}
		byte[] B = new byte[]{'\n',27,109};	//切纸
		
		//java 合并两个byte数组
		byte[] C = new byte[A.length+B.length];
		System.arraycopy(A, 0, C, 0, A.length);
		System.arraycopy(B, 0, C, A.length, B.length);
		
		return C ;
	}
}
