package sidePanel;
import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.Timer;
import pub.ConfigFile;
import pub.Var;
import report.Report_short;
import root.Logon;
import root.Logon_again;
import root.Sql;
public class WestPan extends JPanel implements ActionListener{
	private static final long serialVersionUID = 6360131094418880160L;
	private final Runtime runtime = Runtime.getRuntime();
	private final JButton dayover=new JButton(" 收银班结 ");
	private final JButton billReport=new JButton(" 收银报表 ");
	private final JButton lineUser =new JButton("在线用户"); 
	private final JButton osk  =new JButton("软键盘");
	private final JButton calc =new JButton("计算器");
	
	public final JButton hide =init_buttton("隐藏侧边 Hide = F7","hide2");
	private final JButton lock =init_buttton("切换锁定 Lock","lock");
	private final JButton pass =init_buttton("修改密码 Edit_Password","pass");
	private final JButton exit =init_buttton("退出程序 Shutdown program","exit");
	
	private final JLabel totalm=new JLabel();
	private final JLabel memtip=new JLabel();
	private final JLabel freem =new JLabel();
	private final JLabel maxm  =new JLabel();
	
	public final static JLabel curuser=new JLabel("",JLabel.LEFT);
	private final Timer timer=new Timer(3000,this);             //定时器
	public WestPan() {
		setLayout(new BorderLayout());
		setBorder(BorderFactory.createTitledBorder(""));
		setPreferredSize(new Dimension(200,10));
		/****************北面******************/
	  	JPanel nor=new JPanel();
	  	nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
    	nor.setOpaque(false);
    	
    	JPanel temp=new JPanel(new FlowLayout());
    	temp.setOpaque(false);
    	temp.add(new Clock());
    	nor.add(temp);
	  	
    	JPanel te=new JPanel(new GridLayout(1,4));
    	te.setOpaque(false);
    	te.add(hide);
    	te.add(lock);
    	te.add(pass);
    	te.add(exit);
    	nor.add(te);
    	
    	temp=new JPanel(new FlowLayout());
    	temp.setOpaque(false);
    	temp.add(dayover);
    	nor.add(temp);
    	
    	te=new JPanel(new GridLayout(2,2));
    	te.setOpaque(false);
    	te.add(billReport);te.add(lineUser);te.add(osk);te.add(calc);
    	nor.add(te);
    	add("North",nor);
    	
    	osk.setToolTipText("Operate System Soft Keyboard");
    	calc.setToolTipText("Calculator");
    	dayover.setFont(new Font(null, Font.PLAIN, 15));
    	lock.setMnemonic(KeyEvent.VK_L);	//全局响应Alt+L
    	exit.setMnemonic(KeyEvent.VK_X);
    	dayover.addActionListener(this);
    	billReport.addActionListener(this);
    	osk.addActionListener(this);
    	calc.addActionListener(this);
    	lineUser.addActionListener(this);
    	/**************************************************/
    	
    	//广告,图片不要太大，否则占用过多内存
    	final JLabel img=new JLabel("",JLabel.CENTER);
		final String val = ConfigFile.getProperty("icon32");
		if(!val.isEmpty()) {
			final String path = ConfigFile.confdir + File.separator + "photo" + File.separator + val;
			final File f = new File(path);
			if(f.exists() && f.isFile()){
				img.setIcon(changeImage(path));
			}
		}
    	add("Center",img);
    	
    	/*************南面*************/
    	
    	JPanel logon_msg=new JPanel(new GridLayout(7, 2));
    	logon_msg.setOpaque(false);
    	logon_msg.add(totalm);
    	logon_msg.add(memtip);
    	logon_msg.add(freem);
    	logon_msg.add(maxm);
    	logon_msg.add(new JSeparator());	//分割
    	logon_msg.add(new JSeparator());	//分割
    	logon_msg.add(new JLabel("当前登陆用户"));
    	logon_msg.add(curuser);
    	curuser.setToolTipText(curuser.getText());
    	logon_msg.add(new JLabel("营业站点位置"));
        final Map<String,String> map = System.getenv();  
        final JLabel host = new JLabel(map.get("COMPUTERNAME"),JLabel.LEFT);
        host.setToolTipText(host.getText());
    	logon_msg.add(host);	//主机
    	logon_msg.add(new JLabel("营业登陆日期"));
    	String date[]=Sql.getString("select current_date()", this);
    	if(date==null || date.length==0) date = new String[]{"null"};
    	logon_msg.add(new JLabel(date[0],JLabel.LEFT));
    	logon_msg.add(new JLabel("服务器地址："));
    	logon_msg.add(new JLabel(Logon.myds.getServerName()));
    	add("South",logon_msg);
    	
    	/******************************/
    	
    	setOpaque(false);
		timer.start();
		
		//提示昨天及之前的要班结,在类Meal_node中也有判断
		String sql = "select count(*) from deskgo where date(now())-date(结账时间)>0";
		String cn[] = Sql.getString(sql, this);
		if(cn.length>0 && Integer.valueOf(cn[0])>0){
			dayover.setBackground(Color.YELLOW);
		}
		
		//登陆后根据显示器大小是否显示侧边栏(太小时侧边栏占位置)
		Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int)screensize.getWidth();
		if(width<1280)	setVisible(false);
	}
	
	//对于太大的图片，按比例缩放
	private Icon changeImage(String path) {
		Image img = new ImageIcon(path).getImage();
		Integer wideth = img.getWidth(null); 	// 得到源图宽
		Integer height = img.getHeight(null); 	// 得到源图长
		if(wideth<=200){
			return new ImageIcon(path);			// 不需要缩放
		}
		
		// 缩放
		double n = 200 / wideth.doubleValue();
		BufferedImage tag = new BufferedImage((int) (n * wideth), (int) (n * height), BufferedImage.TYPE_INT_RGB);
		tag.getGraphics().drawImage(img, 0, 0, (int) (n * wideth), (int) (n * height), null);
		Icon returnIcon = new ImageIcon(tag);
		return returnIcon;
	}
	
	private JButton init_buttton(String tip,String pic){
		JButton t=new JButton();
		t.addActionListener(this);
		t.setToolTipText(tip);
		Icon co=new ImageIcon(this.getClass().getClassLoader().getResource("shortico/"+pic+".png"));
		t.setIcon(co);
		t.setContentAreaFilled(false);	//没有背景
		t.setFocusPainted(false);		//没有文字或图片边
		return t;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==hide) {
			if(isVisible())	setVisible(false);
			else 	setVisible(true);
		}
		else if(e.getSource()==dayover) {
			new Meal_node(dayover);
		}
		else if(e.getSource()==billReport) {
			new Report_short() ;
		}
		else if(e.getSource()==osk) {
			handle();
		}
		else if(e.getSource()==calc) {
			try{  //运行Windows下的程序
				Runtime.getRuntime().exec("calc.exe");
		    }catch(IOException io){
		    	JOptionPane.showMessageDialog(null,"启动calc.exe失败，请手动启动");
		    }
		}
		else if(e.getSource()==lineUser) {
			new OnlineUser();
		}
		else if(e.getSource()==exit) {
			String s="确定退出程序吗？ Are you sure shutdown program ?";
			int k=JOptionPane.showConfirmDialog(null,s,"注意",0,1,Var.getIcon("米饭"));
			if(k==0) System.exit(0);
		}
		else if(e.getSource()==lock) {
			new Logon_again();
		}
		else if(e.getSource()==pass) {
			new Password();
		}
		else if(e.getSource()==timer){
			totalm.setText("Total:"+runtime.totalMemory()/1024);
			freem.setText("Free:"+runtime.freeMemory()/1024);
			maxm.setText("Max:"+runtime.maxMemory()/1024);
			if(runtime.maxMemory()/1024/1024-runtime.totalMemory()/1024/1024<5){
				memtip.setForeground(Color.red);
				memtip.setText("剩余内存紧张");
			}
			else{
				memtip.setForeground(Color.black);
				memtip.setText("Used:"+(runtime.totalMemory()-runtime.freeMemory())/1024);
			}
		}
		
		/*代码已过时，供学习之用
		for(int k=0;k<Front.centerpanel.getComponents().length;k++){
			if(Front.centerpanel.getComponents()[k].isVisible()){
				JViewport jv=(JViewport)((JScrollPane)Front.centerpanel.getComponents()[k]).getComponents()[0];
				JPanel jp=(JPanel)jv.getComponents()[0];
				for(int m=0;m<jp.getComponentCount();m++){
					((Desk_info)jp.getComponents()[m]).refresh(null);
				}
			}
		}
		*/
	}
	
	//模拟系统打开运行窗口并启动程序
	public static void handle(){
		try{
			Runtime.getRuntime().exec("osk.exe");
			return ;
	    }catch(IOException io){
	    	System.out.println("启动osk.exe失败，系统将自动手功在运行窗口输入osk命令启动");
	    }
	    
		Robot robot=null;
		try {
			robot = new Robot();
		} catch (AWTException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//Window + R 组合键
	    robot.keyPress(KeyEvent.VK_WINDOWS);
	    robot.keyPress(KeyEvent.VK_R);
	    robot.keyRelease(KeyEvent.VK_WINDOWS);
	    robot.keyRelease(KeyEvent.VK_R);
	    
	    stop();
	    setSystemClipboard("osk");
		past(robot);
	    robot.keyPress(KeyEvent.VK_ENTER);  //回车启动软键盘
	}
	
	// 需要暂停一会，否则程序代码执行太快，系统反应不过来，结果只是打开了运行界面
	private static void stop(){
	    try {
			Thread.sleep(500);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	// 粘贴组合键
	private static void past(Robot robot){
		robot.keyPress(KeyEvent.VK_CONTROL);  
		robot.keyPress(KeyEvent.VK_V);  
		robot.keyRelease(KeyEvent.VK_V);   
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}
	
	// 设置剪切板的内容
	private static void setSystemClipboard(String s) {
		StringSelection ss = new StringSelection(s);
		Clipboard sysClb = Toolkit.getDefaultToolkit().getSystemClipboard();
		sysClb.setContents(ss, null);
	}


	//输入字符,由于用户 输入法 不确定，这种方式在非英文输入法下无法完成任务
	/*
	private void input(Robot robot,String s){
		for (char c : s.toCharArray()) {
			if (c >= '0' && c <= '9') {
				robot.keyPress((int) c);
				robot.keyRelease((int) c);
			} 
			else if (c >= 'a' && c <= 'z') {
				c = (char) ((int) c - 32);
				robot.keyPress((int) c);
				robot.keyRelease((int) c);
			} 
			else if (c >= 'A' && c <= 'Z') {
				robot.keyPress(KeyEvent.VK_SHIFT);
				robot.keyPress(c);
				robot.keyRelease(c);
				robot.keyRelease(KeyEvent.VK_SHIFT);
			}
			else if (c == '>') {
				//robot.keyPress(KeyEvent.);
				//robot.keyRelease((int) c);
			} 
			else{
				robot.keyPress((int) c);
				robot.keyRelease((int) c);
			}
		}
	} */
}

