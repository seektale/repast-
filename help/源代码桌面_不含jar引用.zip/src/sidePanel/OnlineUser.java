package sidePanel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import root.Front;
import root.Sql;
public class OnlineUser extends JDialog implements ActionListener{
	private static final long serialVersionUID = -2175054241828750483L;
	private JTable t = Sql.getTable();
	private JLabel msg=new JLabel("注意：杀死自身连接线程会导致您与数据库的连接被断开，普通用户只能看自己的在线状态。");
	private JButton b=new JButton("强制下线 Kill");
	public OnlineUser(){
		super(Front.front,true);
		setTitle("用户详细");
		setIconImage(Front.logo);
		setSize(700,380);
		setLayout(new BorderLayout());
		
		refresh();
		add("Center",new JScrollPane(t));
		b.setToolTipText("杀死当前连接。");
		b.addActionListener(this);
		
		JPanel sou=new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
		sou.add(b);
		sou.add(msg);
		add("South",sou);
		
		String val[]=Sql.getString("show global status like 'uptime'", this);
		if(val.length>0){
			long ong = Long.valueOf(val[1]);
			long day = ong/(3600*24) ;
			long hour = (ong-day*3600*24)/3600 ;
			long min = (ong-day*3600*24-hour*3600)/60 ;
			String res="数据库已运行时间： [ "+day+"天 "+hour+"小时 "+min+"分 ]";
			msg.setText("<html><body>"+msg.getText()+"<br>"+res+"</body></html>");
		}
		
		setLocationRelativeTo(null);//初始位置在屏幕正中间
		setVisible(true);
	}
	
	//在线用户表的创建
	private void refresh(){
		//show processlist 只显示前100行
		Sql.getArrayToTable("show full processlist;", this, t);
		
		//将第二列加入中文名
		ArrayList<String[]> arr = Sql.getArrayToArrary("select name_english,name_chinese from account;", this);
		HashMap<String, String> hm=new HashMap<String, String>();
		
		for(String temp[] : arr){
			hm.put(temp[0], temp[1]);
		}
		
		for(int m=0;m<t.getRowCount();m++){
			String en=t.getValueAt(m, 1).toString();	//英文名
			String cn=hm.get(en);
			if(cn==null) cn="";
			t.setValueAt(en+" @ "+cn, m, 1);
		}
		
		Sql.TableAtt(t, true, false);
	}
	
	public void actionPerformed(ActionEvent e) {
		int row = t.getSelectedRow();
		if(row<0){
			JOptionPane.showMessageDialog(null,"请先选择要操作的数据行 ？");
			return ;
		}
		
		String id=Sql.getval(t, "Id", row);
		String val="";
		for(int k=0;k<t.getColumnCount();k++){
			val=val+t.getValueAt(row, k)+", ";
		}
		//调用存储过程
		ArrayList<String> v=new ArrayList<String>();
		v.add(id);
		v.add(val);
		Sql.mysqlprocedure("kill_pro",v);
		
		refresh();
	}
}
