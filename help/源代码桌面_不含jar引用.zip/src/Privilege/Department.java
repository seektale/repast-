package Privilege;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.*;

import root.Front;
import root.Sql;
public class Department extends JTree implements TreeSelectionListener {
	private static final long serialVersionUID = 596173890639226995L;
	private JTable t;
	private JTabbedPane TabPan;
	private Add_user ope;
	public Department(JTable t,JTabbedPane TabPan,Add_user ope) {
		super(new DefaultMutableTreeNode("部门分类"));
		this.t=t;
		this.TabPan=TabPan;
		this.ope=ope;
		setEditable(true);
		setOpaque(false);
		addTreeSelectionListener(this);
		setEditable(false);		//这样节点不会出现编辑状态
		refresh(null);
		
		//右键菜单
		Menu_Popup popupmenu = new Menu_Popup();
		setComponentPopupMenu(popupmenu);
	}

	//刷新节点与用户列表
	public void refresh(String dep) {
		//由DefaultTreeModel的getRoot()方法取得根节点.
		DefaultTreeModel treeModel = (DefaultTreeModel) getModel();
		DefaultMutableTreeNode rootNode = (DefaultMutableTreeNode) treeModel.getRoot();
		
		//删除所有子节点.
		rootNode.removeAllChildren();
		
		//根据数据库中的信息，新创立节点
		String s[] = Sql.getString("select item from general where name='部门'", this);
		for (int k = 0; k < s.length; k++) {
			DefaultMutableTreeNode su = new DefaultMutableTreeNode(s[k]);
			rootNode.add(su);
		}
		
		//刷新节点
		treeModel.reload();
		
		//刷新用户表
		if(dep!=null){
			Sql.getArrayToTable("select * from account where department='"+dep+"'", this, t);
			Sql.TableAtt(t, true, false);
		}	
	}
	
	//节点焦点发生变化时
	public void valueChanged(TreeSelectionEvent e) {
		//显示与节点对应的帐户
		String dep=selected();
		TabPan.setSelectedIndex(0);
		if(dep.equals("部门分类")){
			Sql.getArrayToTable("select * from account", this, t);
			Sql.TableAtt(t, true, false);
		}
		else{
			Sql.getArrayToTable("select * from account where department='"+dep+"';", this, t);
			Sql.TableAtt(t, true, false);
		}
	}
	
	//返回当前选中的部门名称
	public String selected(){
		TreePath treepath = getSelectionPath();
		if (treepath != null){
			DefaultMutableTreeNode selectedNode=(DefaultMutableTreeNode)treepath.getLastPathComponent();
			return selectedNode.toString();
		}
		return "";
	}
	
	/*
	 * 内部类,右键菜单
	 * */
	public class Menu_Popup extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -18259645165400196L;
		private JMenuItem a,b,c,add;
		Menu_Popup(){
			add = new JMenuItem("添加用户");
			a = new JMenuItem("新增部门");
			b = new JMenuItem("删除部门");
			c = new JMenuItem("修改部门名称");
			add.addActionListener(this);
			a.addActionListener(this);
			b.addActionListener(this);
			c.addActionListener(this);
			add(add);
			addSeparator();  //加分隔线
			add(a);
			add(b);
			addSeparator();  //加分隔线
			add(c);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==add){
				ope.adduser(null);
			}
			else if(e.getSource()==a){
				String val=JOptionPane.showInputDialog(Front.front,"填写新部门名称...","不能为空",3);
				if(val!=null){
					ArrayList<String> v=new ArrayList<String>();
					v.add(val);
					v.add("add");
					v.add("");
					boolean boo=Sql.mysqlprocedure("department_edit",v);
					if(boo)	refresh(val);
					else	refresh(selected());
				}
			}
			else if(e.getSource()==b){
				String s=selected();
				if(s.isEmpty()){
					JOptionPane.showMessageDialog(Front.front,"请先选择要删除的部门对象！","注意",0);
				}
				else{
					ArrayList<String> v=new ArrayList<String>();
					v.add(s);
					v.add("del");
					v.add("");
					Sql.mysqlprocedure("department_edit",v);
					refresh(s);
				}
			}
			else if(e.getSource()==c){
				String s=selected();
				if(s.isEmpty()){
					JOptionPane.showMessageDialog(null,"请先选择部门编辑对象！","注意",0);
				}
				else{
					String val=JOptionPane.showInputDialog(Front.front,"请输入新名称(不可为空)...",s);
					if(val!=null){
						ArrayList<String> v=new ArrayList<String>();
						v.add(s);
						v.add("edit");
						v.add(val);
						boolean boo=Sql.mysqlprocedure("department_edit",v);
						if(boo)	refresh(val);
						else	refresh(s);
					}
				}
			}
		}
	}
}

