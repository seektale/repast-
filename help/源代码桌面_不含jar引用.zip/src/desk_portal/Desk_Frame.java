package desk_portal;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import bill.Bill_Frame;
import root.Front;
import root.Sql;
public class Desk_Frame extends JInternalFrame implements ActionListener{
	private static final long serialVersionUID = -3266159011449849443L;
	public String area, deskind, alias; 	// 餐区名称,第几桌,别名
	public int Meal_num; 	 		 		// 餐次，即bill表中的主键
	
	private MenuPan myMenu;
	private DishPan myDish;
	public  JPanel Pan=new JPanel(new BorderLayout(10,10));
	private JPanel southPan=new JPanel(new FlowLayout());
	
	private JButton start	 = init_Button("开台信息",KeyEvent.VK_G);
	private JButton food	 = init_Button("已点商品",KeyEvent.VK_U);
	private JButton menu 	 = init_Button("菜单浏览",KeyEvent.VK_S);
	private JButton history	 = init_Button("操作记录",KeyEvent.VK_H);
	private JButton printlog = init_Button("出单记录",KeyEvent.VK_K);
	private JButton billover = init_Button("打印结账",KeyEvent.VK_M);
	private JButton exit	 = init_Button("退出管理",KeyEvent.VK_Q);
	
	public Desk_Frame(int MCount){
		super("",true,true,true,true);
		String temp[]=Sql.getString("select 区域,台号,别名,锁台 from deskgo where 台次="+MCount, this);
		if(temp.length>0){
			area =temp[0];
			deskind=temp[1];
			alias=temp[2];
			Meal_num=MCount;
			if(!temp[3].equals("N")){
				southPan.setBackground(Color.MAGENTA);
			}
			else{
				southPan.setBackground(Color.lightGray);
			}
			init();
		}
		else{
			JOptionPane.showMessageDialog(Front.front,"台次："+MCount+" 在deskgo表中不存在!");
			dispose();
		}
	}
	public void init(){
		setTitle("台号管理：" + area + "  " + deskind + "号台  "+alias);
		setContentPane(Pan);
		setOpaque(false);
		setVisible(true);
		
		Pan.add(new JLabel(),BorderLayout.NORTH);
		Pan.add(new JLabel(),BorderLayout.EAST);
		Pan.add(new JLabel(),BorderLayout.WEST);
		Pan.add(southPan,BorderLayout.SOUTH);
		
		//试过使用层面板，但上一层总是无法完全使下一层组件失效，即两层都可以操作。
    	myDish = new DishPan(Meal_num);
		Pan.add(myDish, BorderLayout.CENTER);
		food.setEnabled(false);
		
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
		    	try {
					setMaximum(true);	//最大化
				} catch (Exception es) {
					es.printStackTrace();
				}
				//myDish.validate();	//使组件得到尺寸大小
				myDish.first();
		    }
		});
		
		//被移除时能监听到，包括dispose()
		addAncestorListener(new AncestorListener() {
			public void ancestorRemoved(AncestorEvent event) {
				Front.front.NorthPanel.setVisible(Front.N);
				Front.front.SouthPanel.setVisible(Front.S);
				Front.front.WestPanel.setVisible(Front.W);
				//Front.front.getJMenuBar().setVisible(Front.N);
			}
			public void ancestorMoved(AncestorEvent event) {}
			public void ancestorAdded(AncestorEvent event) {}
		});
	}
	private JButton init_Button(String s,int c){
		JButton b=new JButton(s+" "+(char)c);
		b.addActionListener(this);
		b.setMnemonic(c);
		southPan.add(b);
		return b;
	}
	public void actionPerformed(ActionEvent e){
		
		requestFocus();	//保持住焦点，这样快捷键才有效
		
		//开台
		if(e.getSource()==start){
			new Desk_start(Meal_num+"",area,deskind);
			start.setEnabled(true);
			return ;
		}
		
		//查看已点菜品
		if(e.getSource()==food){
			showPan(myDish,e);
			myDish.refresh();
			return ;
		}
		
		//点菜或加菜
		if(e.getSource()==menu){
			if(myMenu==null){
				myMenu = new MenuPan(Meal_num);
				showPan(myMenu,e);
			}
			else{
				myMenu.setName("");
				showPan(myMenu,e);
			}
			return ;
		}
		
		//查看操作历史
		if(e.getSource()==history){
			Desk_log temp=new Desk_log(Meal_num);
			showPan(temp,e);
			return ;
		}
		
		//查看出单
		if(e.getSource()==printlog){
			final Desk_print temp=new Desk_print(Meal_num);
			showPan(temp,e);
			return ;
		}
		
		//结账买单
		if(e.getSource()==billover){
			new Bill_Frame(Meal_num);
			start.setEnabled(true);
			return ;
		}
		
		//关闭该桌台对话框
		if(e.getSource()==exit){
			dispose() ;
			if(Front.selected!=null){
				Front.selected.doClick(0);	//刷新台号,点击时间0毫秒，稍微闪一下
			}
		}
	}
	
	//按扭事件本生在UI线程中运行
	private void showPan(final Component com, final ActionEvent e){
		Pan.remove(4);
		Pan.add(com,BorderLayout.CENTER);
		Pan.setVisible(false);
		Pan.setVisible(true);
		
		food.		setEnabled(true);
    	history.	setEnabled(true);
    	menu.		setEnabled(true);
    	printlog.	setEnabled(true);
		((JButton)e.getSource()).setEnabled(false);
		
		//虽然事件本身在EDT线程中运行，这里另起线程插入EDT线程序列当中，doClick()事件会自动在合适的时候运行
		//之所以没有在myMenu的构造方法中运行，是因为构造方法中myMenu还没有加入到Pan面板中，组件大小不确定
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
		    	if(com instanceof MenuPan && myMenu.getName()==null){
					//一定要先自适应大小，这样card组件才有宽度，进而卡片商品能自适应宽度。
					validate();
					myMenu.actiontimes.doClick(0); //点击时间0毫秒
				}
		    }
		});
	}
}

