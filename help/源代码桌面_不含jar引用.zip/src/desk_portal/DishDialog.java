package desk_portal;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.SwingUtilities;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import pub.Var;
import root.Front;
import root.Kbkey;
import root.Numkey;
import root.Sql;
//双击某一菜品进行编辑
public class DishDialog extends JDialog implements ActionListener,FocusListener,ItemListener,ChangeListener{     
	private static final long serialVersionUID = -7634493911002862L;
	private String[] colname,val;	//s1用于存储列名，s2用于存储对应列名的值
	private JButton key	 = new JButton("键盘");
	private JButton roll = new JButton("确认");
	private JButton up = new JButton("<html><body><strong><font color=red >↑↑</font></strong></P></html>");
	private JButton down = new JButton("<html><body><strong><font color=red >↓↓</font></strong></P></html>");
	private JTextField dishname=new JTextField(16);											  //商品名
	private JComboBox<String> unit=new JComboBox<String>(Var.getDish_unit());				  //单位
	private JComboBox<String> remark=new JComboBox<String>(Var.getDish_remark());			  //备注
	private JSpinner num=new JSpinner(new SpinnerNumberModel(1,-100d,Integer.MAX_VALUE,1));	  //数量
	private JSpinner price=new JSpinner(new SpinnerNumberModel(1,-100d,Integer.MAX_VALUE,1)); //价格
	private JSpinner percent=new JSpinner(new SpinnerNumberModel(1,0d,1d,0.1));				  //折扣
	private boolean flag=false;
	private String ind;
	public DishDialog(int dishind){
		super(Front.front,true);
		this.ind=dishind+"";
		setTitle("商品编辑");
		setSize(420,350);
		setLocationRelativeTo(null);//初始位置在屏幕正中间
		setLayout(new BoxLayout(getContentPane(), BoxLayout.PAGE_AXIS)); //一行一行的布局
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//初始化参数
		colname=new String[]{"商品索引","商品属性","所属台次","商品编号","管理科目","分类","小类","","","","","","出单","点单员","点单时间",""};
		val=Sql.getString("select * from dish where 索引="+ind , this);
		refresh(false);	//初始化参数
		
		String info1="";
		String info2="";
		for(int k=0;k<colname.length;k++){
			if(k<5){
				info1=info1+"<font color=blue>"+colname[k]+"：</font>"+val[k]+"<p>";
				continue;
			}
			if(k<7||k==12||k==13||k==14){
				info2=info2+"<font color=blue>"+colname[k]+"：</font>"+val[k]+"<p>";
				continue;
			}
		}
		
		//北面,不可编辑的信息显示在此组件上
		JPanel nor=new JPanel(new BorderLayout());
		nor.setBorder(BorderFactory.createTitledBorder(""));
		JLabel info=new JLabel("<html><body>"+info2+"</body></html>");
		info.setFont(new Font(null,Font.BOLD,14));
		nor.add(BorderLayout.EAST,info);
		info=new JLabel("<html><body>"+info1+"</body></html>");
		info.setFont(new Font(null,Font.BOLD,14));
		nor.add(BorderLayout.WEST,info);
		add(nor);
		add(Box.createVerticalStrut((6)));
		
		remark.addPopupMenuListener(new PopupMenuListener() {
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
				selclass();
				remark.setVisible(false);	//先不可见，再可见，等效于关闭弹出菜单
				remark.setVisible(true);
			}
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {}
			public void popupMenuCanceled(PopupMenuEvent arg0) {}
		});
		
		num.addChangeListener(this);
		price.addChangeListener(this);
		percent.addChangeListener(this);
		dishname.addActionListener(this);
		dishname.addFocusListener(this);
		
		JComponent editor = num.getEditor();
		if(editor instanceof DefaultEditor) {
	        ((DefaultEditor)editor).getTextField().addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					if(e.getClickCount()==2){
						new Numkey(DishDialog.this);
					}
				}
	        });
	    }
		editor = price.getEditor();
		if(editor instanceof DefaultEditor) {
	        ((DefaultEditor)editor).getTextField().addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					if(e.getClickCount()==2){
						new Numkey(DishDialog.this);
					}
				}
	        });
	    }
		editor = percent.getEditor();
		if(editor instanceof DefaultEditor) {
	        ((DefaultEditor)editor).getTextField().addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					if(e.getClickCount()==2){
						new Numkey(DishDialog.this);
					}
				}
	        });
	    }
		
		price.setPreferredSize(new Dimension(90,30));
		num.setPreferredSize(new Dimension(80,30));
		remark.setPreferredSize(new Dimension(160,30));
		unit.setPreferredSize(new Dimension(80,30));
		percent.setPreferredSize(new Dimension(60,30));
		unit.setEditable(true);
		remark.setEditable(true);
		remark.addItemListener(this);
		unit.addItemListener(this);
		up.addActionListener(this);
		down.addActionListener(this);
		up.setFocusable(false);
		down.setFocusable(false);
		
		JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.setBackground(Color.LIGHT_GRAY);
		temp.add(new JLabel("商品名称："));
		temp.add(dishname);
		temp.add(new JLabel("  数量："));
		temp.add(num);
		add(temp);
		add(new JSeparator());	//分割线
		add(Box.createVerticalStrut((6)));
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("商品价格："));
		temp.add(price);
		temp.add(new JLabel("折扣："));
		temp.add(percent);
		temp.add(new JLabel("单位："));
		temp.add(unit);
		add(temp);
		add(new JSeparator());	//分割线
		add(Box.createVerticalStrut((6)));
		
		temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(new JLabel("备注做法："));
		temp.add(remark);
		temp.add(new JLabel("     "));
		temp.add(up);
		temp.add(new JLabel("▲▼"));
		temp.add(down);
		add(temp);
		add(new JSeparator());	//分割线
		up.setToolTipText("当焦点在文本框时，对相应的文本框内的值进行增加");
		down.setToolTipText("当焦点在文本框时，对相应的文本框内的值进行减少");
		
		add(Box.createVerticalStrut((18)));
		key.addActionListener(this);
		roll.addActionListener(this);
		key.setFocusable(false);	// 禁止得到焦点
		JPanel sou=new JPanel(new FlowLayout(FlowLayout.LEFT));
		sou.add(key);
        Box box=Box.createHorizontalBox();  
        box.add(sou);  
        box.add(Box.createHorizontalGlue());  //使的组件一左一右分隔开
        box.add(roll);
		add(box);
		
		// 正确启用UI线程的方法,到EDT线程中执行,这样才能将焦点定们到num组件
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
		    	JComponent editor = num.getEditor();
				((DefaultEditor)editor).getTextField().requestFocus();
		    }
		});
		
		setVisible(true);
	}
	
	private void selclass(){
		int count = remark.getItemCount();
		final JPanel pan=new JPanel(new GridLayout(5, count/6+1));
		final JCheckBox ch[] = new JCheckBox[count];
		for(int k=0; k<count; k++ ){
		    ch[k] = new JCheckBox(remark.getItemAt(k));
		    pan.add(ch[k]);
		}
		int result = JOptionPane.showConfirmDialog(Front.front, pan,"选择商品备注做法...", 2, 1, new ImageIcon());
		if(result!=0) return;
		final StringBuilder val = new StringBuilder();
		for(int k=0; k<count; k++ ){
		    if(ch[k].isSelected()) val.append(ch[k].getText());
		}
		remark.setSelectedItem(val.toString());
	}
	
	//刷新商品信息，即赋值
	private void refresh(boolean boo){
		flag=true; //标记
		if(boo) val=Sql.getString("select * from dish where 索引="+ind, this);
		//初始化参数
		dishname.setText(val[7]);
		dishname.setName(val[7]);
		
		price.setValue(Double.valueOf(val[8]));
		num.setValue(Double.valueOf(val[10]));
		percent.setValue(Double.valueOf(val[11]));
		
		//初始化备注
		for(int m=0;m<remark.getItemCount();m++){
			if(remark.getItemAt(m).toString().equals(val[15])){
				remark.setSelectedIndex(m);
				break;
			}
			if(m+1==remark.getItemCount()){
				remark.addItem(val[15]);
				remark.setSelectedItem(val[15]);
			}
		}
		//初始化单位
		for(int m=0;m<unit.getItemCount();m++){
			if(unit.getItemAt(m).toString().equals(val[9])){
				unit.setSelectedIndex(m);
				break;
			}
			if(m+1==unit.getItemCount()){
				unit.addItem(val[9]);
				unit.setSelectedItem(val[9]);
			}
		}
		flag=false;	//复位
	}
	
	public void actionPerformed(ActionEvent e){
		/*赠送，其实就是将价格改为0，已放弃 20231129
		if(e.getSource()==freedish){
			Sql.mysqlprocedure("dish_free",ind);
			refresh(true);
			dispose();
		}
		*/
		if(e.getSource()==key){
			new Kbkey(this);
		}
		else if(e.getSource()==roll){
			dispose();
		}
		else if(e.getSource()==dishname){
			textEvent();
		}
		
		else if(e.getSource()==up || e.getSource()==down){
			if(price.getEditor().getComponent(0).isFocusOwner()){
				if(e.getSource()==up)   price.setValue(price.getNextValue());
				if(e.getSource()==down) price.setValue(price.getPreviousValue());
			}
			if(num.getEditor().getComponent(0).isFocusOwner()){
				if(e.getSource()==up)   num.setValue(num.getNextValue());
				if(e.getSource()==down) num.setValue(num.getPreviousValue());
			}
			if(percent.getEditor().getComponent(0).isFocusOwner()){
				if(e.getSource()==up)   percent.setValue(percent.getNextValue());
				if(e.getSource()==down) percent.setValue(percent.getPreviousValue());
			}
		}
	}
	private void textEvent(){
		//商品名 相同 则不做响应
		if(dishname.getText().endsWith(dishname.getName())) return ;
		
		ArrayList<String> v=new ArrayList<String>();
		v.add(ind);	 				//商品索引
		v.add(dishname.getText());	//值
		Sql.mysqlprocedure("dish_name",v);
		refresh(true);
	}
	
	public void focusGained(FocusEvent e) {}
	public void focusLost(FocusEvent e) {
		textEvent();
	}

	//失去焦点时也会响应此事件
	public void itemStateChanged(ItemEvent e) {
		if(flag) return ;	//刷新时不响应事件
		//事件会响应两次，所以这里加个判断条件
		if(e.getStateChange()==2){
			ArrayList<String> v=new ArrayList<String>();
			v.add(ind);	 	//菜品索引
			if(e.getSource()==remark){
				v.add(remark.getSelectedItem().toString());
				Sql.mysqlprocedure("dish_remark",v);
			}
			if(e.getSource()==unit){
				v.add(unit.getSelectedItem().toString());
				Sql.mysqlprocedure("dish_unit",v);
			}
		}
		
		//事件响应两次，2先响应，其次是1，如果在响应2时刷新，结果是一次无效、一次有效
		//只有在1时刷新，才会每次都有效。
		if(e.getStateChange()==1){
			refresh(true);
		}
	}
	
	public void stateChanged(ChangeEvent e) {
		if(flag) return ;	//刷新时不响应事件
		ArrayList<String> v=new ArrayList<String>();
		v.add(ind);	 			//菜品索引
		
		if(e.getSource()==num){
			v.add(num.getValue().toString());	//值
			Sql.mysqlprocedure("dish_amount",v);
		}
		if(e.getSource()==price){
			v.add(price.getValue().toString());	//值
			Sql.mysqlprocedure("dish_price",v);
		}
		if(e.getSource()==percent){
			v.add(percent.getValue().toString());	//值
			Sql.mysqlprocedure("dish_percent",v);
		}
		
		refresh(true);
	}
}
