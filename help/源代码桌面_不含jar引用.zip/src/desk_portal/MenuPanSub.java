package desk_portal;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import pub.*;
import root.Kbkey;
import root.Sql;
public class MenuPanSub extends JSplitPane implements ActionListener,DocumentListener{
	private static final long serialVersionUID = -1190923669964168673L;
	private JButton	  linkdish	 = new JButton("套餐商品");
	private JButton	  helpserver = new JButton("辅助商品");
	private JButton	  kb		 = new JButton("键盘");
	private JButton	  pageup	 = new JButton("上翻");
	private JButton	  pagedown	 = new JButton("下翻");
	private JPanel    right  	 = new JPanel(new BorderLayout());	//右边的卡片布局面板
	private JPanel    card		 = new JPanel(new ModifiedFlowlayout(FlowLayout.LEFT,5,3)); //向左对齐

	private JTextField like=new JTextField(12);
	private JTable t = Sql.getTable();
	private JScrollBar bar ;
	private int Meal_num ;
	private MenuEDT MEDT ;
	public MenuPanSub(int Meal_num){
		this.Meal_num=Meal_num;
		
		pageup.addActionListener(this);
		pagedown.addActionListener(this);
		
		like.getDocument().addDocumentListener(this);
   	    like.setForeground(Color.BLUE);
   	    like.setToolTipText("限制最多返回100条数据,如需查询更多,空格与下划线代表匹配任意单个字符");
   	    
		//左边的菜品分类栏
		String[] ss = Var.getMenu_class();
		
		final JPanel left=new JPanel(new ModifiedFlowlayout(FlowLayout.LEFT,0,0));
		for(int k=0;k<ss.length;k++){
			final JButton temp=new JButton(ss[k]);
			temp.addActionListener(this);
			temp.setPreferredSize(new Dimension(110,32));
			temp.setToolTipText(ss[k]);
			temp.setFont(new Font("楷体",Font.BOLD,16));
			left.add(temp);
		}
		
		JScrollPane js=new JScrollPane(card);
		js.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
		bar = js.getVerticalScrollBar();
        
		right.add(js,BorderLayout.CENTER);
		right.add(myPanel(),BorderLayout.NORTH);

		JScrollPane lefts=new JScrollPane(left);
		lefts.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
		lefts.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);	//不要有水平滚动条
		//lefts.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		//lefts.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		//lefts.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		
		setLeftComponent(lefts);
		setRightComponent(right);
		setOrientation(JSplitPane.VERTICAL_SPLIT);
		setDividerSize(6);
		setOneTouchExpandable(true);
	}
	
	private JPanel myPanel(){
		linkdish.addActionListener(this);
		kb.addActionListener(this);
		helpserver.addActionListener(this);
		
		JPanel one = new JPanel(new FlowLayout(FlowLayout.LEFT));
		one.add(like);
		one.add(linkdish);
		one.add(helpserver);
		one.add(kb);
		one.add(new JLabel("拖放或点击商品名"));
		
		JPanel two = new JPanel(new FlowLayout(FlowLayout.LEFT));
		two.add(pageup);
		two.add(pagedown);
		
		JPanel temp =  new JPanel(new BorderLayout());
		temp.add(one, BorderLayout.CENTER);
		temp.add(two, BorderLayout.EAST);
		return temp ;
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==kb){
			like.requestFocus();
			new Kbkey(null);
			return ;
		}
		if(e.getSource()==pageup){
			Thread th = new Thread(new Runnable() {
				public void run() {
					for(int k=0; k<200; k++){
						int val = bar.getValue();
						int min = bar.getMinimum();
						if(val-1<min){
							bar.setValue(min);
							break;
						}
						bar.setValue(val-1);
					}
				}
			});
			th.start();
			return ;
		}
		
		if(e.getSource()==pagedown){
			Thread th = new Thread(new Runnable() {
				public void run() {
					for(int k=0; k<200; k++){
						int val = bar.getValue();
						int max = bar.getMaximum();
						if(val+1>max){
							bar.setValue(max);
							break;
						}
						bar.setValue(val+1);
					}
				}
			});
			th.start();
			return ;
		}
		if(e.getSource()==linkdish){
			showMenu("select * from menu where 分类 like '%套餐%'");
			bar.setValue(bar.getMinimum());
			return ;
		}
		
		if(e.getSource()==helpserver){
			showMenu(" select * from menu where 分类='辅助' ");
			bar.setValue(bar.getMinimum());
			return ;
		}
		
		//对MenuTable表格进行更新
		showMenu("select * from menu where 分类='"+e.getActionCommand()+"'");
		bar.setValue(bar.getMinimum());
	}

	public void insertUpdate(DocumentEvent arg0) {
		if(like.getText().isEmpty()){
			return ;
		}
		
		String val=like.getText().replace(" ", "_");	//空格代表匹配任意单个字符
		val = val.replace("'", "");			//这个字符不能有，因为需要时行转义
		
		//为防止数据表过大，限制最多返回100条数据
		val="select * from menu where 助记符 like '%"+val+"%' or 编号 like '%"+val+"%' or 商品名 like '%"+val+"%' limit 0,100";
		
		showMenu(val);
	}
	public void removeUpdate(DocumentEvent arg0){
		insertUpdate(null);
	}
	public void changedUpdate(DocumentEvent e) {}
	
	public void showMenu(String sql){
		//刷新表格
		if(sql!=null && !sql.isEmpty()){
			Sql.getArrayToTable(sql, this, t);
		}
		
		//处理卡片模式显示
		if(MEDT!=null){
			MEDT.cancel(true);
		}
		
		card.removeAll();	//先清空
		
		final JScrollPane js=(JScrollPane)card.getParent().getParent();
		final List<MenuCard> cmlist = new ArrayList<MenuCard>();
		for(int row=0;row<t.getRowCount();row++){
			//将行数据转成字符串数组
			final ArrayList<String> val = new ArrayList<String>();
			for(int col=0;col<t.getColumnCount();col++){
				Object ob=t.getValueAt(row, col);
				val.add(ob.toString());
			}
			final MenuCard cm=new MenuCard(val, js.getWidth(), false);
			cm.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e){
					//左单击
					if(e.getButton()==1){
						if(e.getX()>cm.getWidth()*0.8){
							new Menu.Weipre(val.get(0)+"#"+val.get(4)); //弹出二维码
						}
						else {
							sub(val); //快速点单
						}
					}
					//右单击
					if(e.getButton()==3){}
				}
			});
			
			card.add(cm);
			cmlist.add(cm);
			if(card.getComponentCount()>=80){
				//为节约内存资源,只显示前80个商品
				break;
			}
			if(!card.isShowing()) break;
		}
		
		card.setVisible(false);	//刷新
		card.setVisible(true);
		
		MEDT = new MenuEDT(cmlist);
		MEDT.execute();
	}
	
	//点单
	private void sub(ArrayList<String> val){
		final ArrayList<String> v=new ArrayList<String>();
		v.add(String.valueOf(Meal_num));		//餐次
		v.add(val.get(MenuCard.menucol.indexOf("编号")));			//菜品编号
		v.add("1");					//数量
		v.add(val.get(MenuCard.menucol.indexOf("价格")));			//价格
		//提交菜品
		boolean boo = Sql.mysqlprocedure("dish_order_init",v);
		if(boo){
			like.selectAll(); //全选，方便下一步继续点单
			//回调结果, 即要求刷新
			if(Callback!=null)	Callback.onRefresh();
		}
	}
	
	/**
     * 设置回调接口
     */
    private GetDate Callback;
    public void setGetCallback(GetDate val) {
        Callback = val;
    }
    
    /**
     * 回调接口
     */
    public interface GetDate {
        public void onRefresh();
    }
}


