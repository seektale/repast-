package desk_portal;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import pub.Var;
import root.Front;
import root.Sql;
class ChangeDesk extends JDialog implements ActionListener,ItemListener{
	private static final long serialVersionUID = -7513552325839358803L;
	private JButton ok=new JButton("换台(S)");
	private JButton cancel=new JButton("退出(Q)");
	private JComboBox<String> desk =new JComboBox<>(Var.area());
	private JComboBox<String> index=new JComboBox<>();
	private JComboBox<String> desk_times=new JComboBox<>();
	private JTable wt=Sql.getTable(),et;		//两个表格
	private JLabel wLab=new JLabel("源台号：");
	private JLabel eLab=new JLabel("目标台号：");
	private int meal_num;
	public ChangeDesk(int meal_num){
		super(Front.front,true);
		this.meal_num=meal_num;
		
		setTitle("换桌，目标台次可以选择为[挂起]的状态");
		setSize(780,500);
		setResizable(false);
		setLayout(new BorderLayout());
		
		/*
		 * 左表格
		 * */
		JPanel p=new JPanel(new FlowLayout());
		String temp[]=Sql.getString("select 区域,台号,别名 from deskgo where 台次="+meal_num, this);
		if(temp.length==0) temp=new String[]{"未知","未知","源台号："};
		wLab.setText(temp[2].isEmpty() ? "源台号：" : temp[2]);
		p.add(wLab);
		p.add(new JComboBox<String>(new String[]{temp[0]}));
		p.add(new JComboBox<String>(new String[]{temp[1]}));
		p.add(new JLabel("台次："));
		
		JTextField sourcetimes=new JTextField(meal_num+"",5);
		sourcetimes.setEditable(false);
		
		//查到有数据说明正在开台中，否则说明已结帐，或是重新结算的餐台；用着色区别开。
		sourcetimes.setBackground(stat(meal_num));	//已结帐
		sourcetimes.setToolTipText("绿色green代表已开台或挂起，cyan代表已结账，红色red代表不存在的台号！");
		p.add(sourcetimes);
		
		//该桌的所有菜品加入表中
		String sql="select 索引,商品名,实价,数量 from dish where 台次="+meal_num+" and 属性='' ;";
		Sql.getArrayToTable(sql, this, wt);
		Sql.TableAtt(wt, true, false);
		// 右对齐
		wt.getColumn("实价").setCellRenderer(new MyTableCellRenderer());
		
		JScrollPane tempsp=new JScrollPane(wt);
		tempsp.setPreferredSize(new Dimension(320,100));
		JPanel leftroot=new JPanel(new BorderLayout());
		leftroot.add("Center",tempsp);
		leftroot.add("North",p);
		add("West",leftroot);
		
		/*
		 * 右表格
		 * */
		//初始化窗体右边的表格
		p=new JPanel(new FlowLayout());
		p.add(eLab);
	    p.add(desk);
	    p.add(index);
	    desk.addItem("");
	    desk.setSelectedItem("");
	    desk.addItemListener(this);
	    index.addItemListener(this);
	    
	    p.add(new JLabel("台次："));
	    p.add(desk_times);
	    /********************/
	    final String etstr[]=new String[]{"索引","商品名","实价","数量","区域","台号"};
	    final DefaultTableModel etdtm=new DefaultTableModel(etstr,0){
    		private static final long serialVersionUID = 3534830845619L;
    		//下面的方法保证了表格是不可编辑的状态
	        public boolean isCellEditable(int row, int column) {
	        	return false;
	        }
		};
	    et=new JTable(etdtm);
		tempsp=new JScrollPane(et);
		tempsp.setPreferredSize(new Dimension(380,100));
		JPanel rightroot=new JPanel(new BorderLayout());
		rightroot.add("Center",tempsp);
		rightroot.add("North",p);
		add("East",rightroot);
		
		p=new JPanel(new GridLayout(4,1,5,90));
		p.add(new JLabel());
		p.add(ok); 
		ok.setMnemonic(KeyEvent.VK_S);
		cancel.setMnemonic(KeyEvent.VK_Q);
		p.add(cancel);
		add("Center",p);
		
		ok.addActionListener(this);
		cancel.addActionListener(this);
		
		//初始化desk,index
		desk.setEnabled(true);
		index.setEnabled(true);
		desk.actionPerformed(null);	//目的为：初始状态下不选择任何对象
		
		setLocationRelativeTo(null);//初始位置在屏幕正中间
		setVisible(true);
	}
	
	//根据台次确定背景色
	private Color stat(int mealtimes) {
		//查到有数据说明正在开台中，否则说明已结帐，或是重新结算的餐台；用着色区别开。
		String tem[] = Sql.getString("select 结账时间 from deskgo where 台次="+mealtimes, this);
		if((tem.length>0)) {
			if(tem[0].isEmpty()) return Color.green; //未结账或挂起
			else return Color.CYAN;	//已结账
		}
		return Color.red;	//不存在
	}
	
	//餐区与餐次被切换时更新
	public void itemStateChanged(ItemEvent e){
		
		if(e.getItem().toString().isEmpty()) return;
		
		//恢复到初始状态
		DefaultComboBoxModel<String> modeltem = new DefaultComboBoxModel<>();
		desk_times.setModel(modeltem);
		desk_times.actionPerformed(null); //默认什么都不选中
		
		//如果没有if条件，则每一次事件会导致这个方法执行两次
		if(e.getItem()==desk.getSelectedItem()) {
			String str = (String)desk.getSelectedItem();
		    String[] tem=Sql.getString("select distinct 台号 from deskgo where isnull(结账时间) and 区域='"+str+"' order by 台号", this);
		    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(tem);
		    index.setModel(model);
		    index.addItem("");
		    index.setSelectedItem("");
		}
		if(e.getItem()==index.getSelectedItem()) ChangedNext();
	}
	private void ChangedNext() {
		final String a=(String)desk.getSelectedItem();	//目标餐区
		final String b=(String)index.getSelectedItem();	//目标餐台
		final String[] tem=Sql.getString("select 台次 from deskgo where isnull(结账时间) and 区域='"+a+"' and 台号="+b+" order by 台号", this);
		if(tem.length>0) {
			final DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(tem);
			desk_times.setModel(model);
		}
		if(tem.length>1) JOptionPane.showMessageDialog(this,"提示：有 "+tem.length+" 个台次，即存在挂起的台次，注意选择正确的台次。");
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==ok){
			if(wt.getSelectedRowCount()!=1){
				JOptionPane.showMessageDialog(Front.front, "请先在左表中选择要换桌的商品？");
				return ;
			}
			//检查目标餐次是否合法
			String desknum = "";
			try {
				desknum = desk_times.getSelectedItem().toString();
				Integer.valueOf(desknum);
			} catch (Exception es) {
				JOptionPane.showMessageDialog(Front.front, "目标台次："+desknum+" 不合法！请重新选择...");
				return ;
			}
			
			//检查是否有选择目标餐台
			String deskval=desk.getSelectedItem().toString();
			if(desk.isEnabled()&&deskval.isEmpty()){
				JOptionPane.showMessageDialog(Front.front, "请先选择目标台号？");
				return ;
			}
			
			//开始换桌
			int row=wt.getSelectedRow();
			String inde=wt.getValueAt(row, 0).toString(); //菜品索引
			
			final ArrayList<String> v=new ArrayList<String>();
			v.add(desknum);	//目标餐次
			final String[] tem=Sql.getString("select 1 from desk where 操作时间=(select 开台时间 from deskgo where 台次="+desknum+")", this);
			if(tem.length>0) v.add("Y"); //是否只在开台状态下换桌
			else v.add("N");
			v.add(inde);	//菜品索引
			boolean boo=Sql.mysqlprocedure("dish_changedesk",v);	//提交菜品
			
			// 左边的表格数据删掉一行
			int se = wt.getSelectedRow();
			if(boo){
				//右边的表格添加一行
				DefaultTableModel dtm=(DefaultTableModel)et.getModel();
				String ss[]=new String[et.getColumnCount()];
				for(int i=0;i<=3;i++){	//前四列相同
					ss[i]=wt.getValueAt(row, i)+"";
				}
				ss[4]=desk.getSelectedItem().toString();
				ss[5]=index.getSelectedItem().toString();
				dtm.addRow(ss);
				Sql.autoWidthC(et);
				// 右对齐
				et.getColumn("实价").setCellRenderer(new MyTableCellRenderer());
				
				dtm = (DefaultTableModel)wt.getModel();
				dtm.removeRow(row);
			}
			
			// 不管菜品换桌是否成功，均更新表wt
			String sql="select 索引,商品名,实价,数量 from dish where 台次="+meal_num+" and 属性='' ;";
			Sql.getArrayToTable(sql, this, wt);
			Sql.TableAtt(wt, true, false);
			
			// 恢复选中行，这样做是为了快速换桌，以免频繁需要先选中表中某一行数据
			if(wt.getRowCount()!=0){
				if(wt.getRowCount()==se) se=wt.getRowCount()-1;
				wt.setRowSelectionInterval(se,se);
				// 右对齐
				wt.getColumn("实价").setCellRenderer(new MyTableCellRenderer());
			}
		}
		else if(e.getSource()==cancel) dispose();
	}
	
	class MyTableCellRenderer extends DefaultTableCellRenderer {
		private static final long serialVersionUID = -4127477074143665006L;
		public MyTableCellRenderer() {
			super();
			setHorizontalAlignment(JLabel.RIGHT);
		}
		public void setValue(Object value) {
			super.setValue(value);
		}
	}
}

