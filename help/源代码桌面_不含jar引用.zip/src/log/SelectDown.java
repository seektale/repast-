package log;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Vector;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;

import pub.DateUI;
import pub.Var;

import root.Front;
import root.Sql;
public class SelectDown extends JPanel implements ActionListener{
	private static final long serialVersionUID = 3793573280713783627L;
	public  JComboBox<String> timecol;
	public  JButton timediv	=new JButton("时间段查询");
	public  JButton todayqu	=new JButton("当日");
	private JButton ye		=new JButton("昨日");
	private JButton week	=new JButton("前一周");
	private JButton dayqu	=new JButton("按日期");
	private JButton monthqu	=new JButton("按月份");
	private JButton ok = new JButton("高级查询");
	
	private JTable t;
	private String subsql;
	private JLabel sqltip;
	private String tablename ;
	public SelectDown(JTable t,String subsql,String tablename,JLabel sqltip){
		this.t=t;
		this.subsql=subsql;
		this.sqltip=sqltip;
		this.tablename=tablename;
		setLayout(new FlowLayout(FlowLayout.LEFT));
		setOpaque(false);
		
		add(new JLabel(Var.getIcon("时间过滤")));
		week.setToolTipText("以当天为参考，7 天历史数据");
		
		ArrayList<String> col = Sql.getcolname(tablename, getClass().getName());
		Vector<String> v=new Vector<String>();
		for(String arrcol : col){
			int x=arrcol.indexOf("时间");
			int y=arrcol.indexOf("日期");
			int z=arrcol.indexOf("time");
			if(x!=-1||y!=-1||z!=-1)	v.add(arrcol);
		}
		timecol=new JComboBox<String>(v);
		//有多个时间定义时才显示出来供用户择取
		if(v.size()>1){
			JLabel warntip=new JLabel("请务必先选择时间对象：");
			warntip.setForeground(Color.blue);
			add(warntip);
			add(timecol);
		}
		
		add(timediv);
		add(todayqu);
		add(ye);
		add(week);
		add(dayqu);
		add(monthqu);
		add(ok);
		
		timediv.addActionListener(this);
		todayqu.addActionListener(this);
		ye.addActionListener(this);
		dayqu.addActionListener(this);
		week.addActionListener(this);
		monthqu.addActionListener(this);
		ok.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e){
		if(timecol.getSelectedItem()==null) return ;
		String s = timecol.getSelectedItem().toString();
		
		if(e.getSource()==todayqu){
			//s="select * from "+tablename+" where date("+s+")=date(now())";
			s=subsql+" date("+s+")=date(now()) limit 0,1000";
			Sql.getArrayToTable(s, this, t);
			Sql.TableAtt(t, false, false);
		}
		else if(e.getSource()==timediv){
			timediv();
		}
		else if(e.getSource()==ye){
			//s="select * from "+tablename+" where to_days(now())-to_days("+s+")=1";
			s=subsql+" to_days(now())-to_days("+s+")=1 ";
			Sql.getArrayToTable(s, this, t);
			Sql.TableAtt(t, false, false);
		}
		else if(e.getSource()==dayqu){
			//如2013-03-14
			DateUI du = new DateUI();
			if(du.toString().isEmpty()) return ;
			
			s = subsql+" "+s+" like '%"+du.toString()+"%'";
			Sql.getArrayToTable(s, this, t);
			Sql.TableAtt(t, false, false);
		}
		else if(e.getSource()==week){
			//s=subsql+" week(now())-week("+s+")=1";	//年首星期周从0开始，会无效
			//to_days(now())函数计算的是公元开始到现在的天数
			s=subsql+" to_days(now())-to_days("+s+")<=7 and to_days(now())-to_days("+s+")>=0 limit 0,2000";
			Sql.getArrayToTable(s, this, t);
			Sql.TableAtt(t, false, false);
		}
		else if(e.getSource()==monthqu){
			Calendar c=Calendar.getInstance();
			int AA = c.get(Calendar.YEAR) ;
			int BB = c.get(Calendar.MONTH)+1 ;
			String val=JOptionPane.showInputDialog(null,"请输入年份与月份，格式：xxxx-xx",AA+"-"+BB);
			if(val==null) return ;
			
			String temp[]=val.split("-");
			if(temp.length!=2){
				JOptionPane.showMessageDialog(null,"格式不正确","Format Error",0);
				return ;
			}
			s=subsql+" month("+s+")="+temp[1]+" and year("+s+")="+temp[0]+" limit 0,2000";
			Sql.getArrayToTable(s, this, t);
			Sql.TableAtt(t, false, false);
		}
		else if(e.getSource()==ok){
			new AdvSelect(tablename, t);
		}
		sqltip.setText("共查询到 "+t.getRowCount()+" 条记录！"); 
	}
	
	//时间段查询
	private void timediv(){
		//初始化
		Calendar c = Calendar.getInstance();
		int Year = c.get(Calendar.YEAR);
		int Month = c.get(Calendar.MONTH) + 1;
		int day = c.get(Calendar.DAY_OF_MONTH);
		
		//日期
		JSpinner yeara=new JSpinner(new SpinnerNumberModel(Year,1900, 2200, 1));
		JSpinner montha = new JSpinner(new SpinnerNumberModel(Month, 1,12, 1));
		JSpinner daya = new JSpinner(new SpinnerNumberModel(day, 0, 31,1));
		JPanel datePanela=DatePanel(yeara,montha,daya);
		
		JSpinner yearb=new JSpinner(new SpinnerNumberModel(Year,1900, 2200, 1));
		JSpinner monthb = new JSpinner(new SpinnerNumberModel(Month, 1,12, 1));
		JSpinner dayb = new JSpinner(new SpinnerNumberModel(day, 0, 31,1));
		JPanel datePanelb=DatePanel(yearb,monthb,dayb);
		
		//时间
		JSpinner houa=new JSpinner(new SpinnerNumberModel(0,0,24,1));
		JSpinner mina = new JSpinner(new SpinnerNumberModel(0, 0,60, 1));
		JSpinner seca = new JSpinner(new SpinnerNumberModel(0, 0, 60,1));
		JPanel timePanela=TimePanel(houa,mina,seca);
		
		JSpinner houb=new JSpinner(new SpinnerNumberModel(23,0,24,1));
		JSpinner minb = new JSpinner(new SpinnerNumberModel(59, 0,60, 1));
		JSpinner secb = new JSpinner(new SpinnerNumberModel(59, 0, 60,1));
		JPanel timePanelb=TimePanel(houb,minb,secb);
		
		JPanel root=new JPanel();
		root.setLayout(new BoxLayout(root, BoxLayout.X_AXIS));
		root.add(getSlipt());
		JPanel p=new JPanel(new GridLayout(3, 1));
		p.add(new JLabel("  开始时间..."));
		p.add(datePanela);
		p.add(timePanela);
		root.add(p);
		
		root.add(getSlipt());
		p=new JPanel(new GridLayout(3, 1));
		p.add(new JLabel("  结束时间..."));
		p.add(datePanelb);
		p.add(timePanelb);
		root.add(p);
		
		int action=JOptionPane.showConfirmDialog(Front.front,root,"时间段查询",2,1,new ImageIcon());
		if(action==0){
			if(timecol.getSelectedItem()!=null){
				String s=timecol.getSelectedItem().toString();
				String s1="'"+yeara.getValue().toString()+"-"+montha.getValue().toString()+"-"+daya.getValue().toString()+" ";
				s1=s1+houa.getValue().toString()+":"+mina.getValue().toString()+":"+seca.getValue().toString()+"'";
				
				String s2="'"+yearb.getValue().toString()+"-"+monthb.getValue().toString()+"-"+dayb.getValue().toString()+" ";
				s2=s2+houb.getValue().toString()+":"+minb.getValue().toString()+":"+secb.getValue().toString()+"'";
				
				String sql=subsql+" "+s+">="+s1+" and "+s+"<="+s2 + " limit 0,2000";
				Sql.getArrayToTable(sql, this, t);
				sqltip.setText("共查询到 "+t.getRowCount()+" 条记录！"); 
			}
		}
	}
	private JSeparator getSlipt(){
		JSeparator separator = new JSeparator();   //创建竖直分隔线  
		separator.setOrientation(JSeparator.VERTICAL);  
		return separator;
	} 
	private JPanel DatePanel(JSpinner yearSpin,JSpinner monthSpin,JSpinner daySpin){
		JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		//年
		yearSpin.setEditor(new JSpinner.NumberEditor(yearSpin, "####"));
		datePanel.add(yearSpin);
		datePanel.add(new JLabel("年"));
		//月
		datePanel.add(monthSpin);
		datePanel.add(new JLabel("月"));
		//日
		datePanel.add(daySpin);
		datePanel.add(new JLabel("日"));
		return datePanel;
	}
	private JPanel TimePanel(JSpinner yearSpin,JSpinner monthSpin,JSpinner daySpin){
		JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		datePanel.add(yearSpin);
		datePanel.add(new JLabel("时"));
		datePanel.add(monthSpin);
		datePanel.add(new JLabel("分"));
		datePanel.add(daySpin);
		datePanel.add(new JLabel("秒"));
		return datePanel;
	}
}

