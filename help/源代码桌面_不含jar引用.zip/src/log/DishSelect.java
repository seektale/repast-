package log;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import root.Front;
import root.Sql;
public class DishSelect extends JInternalFrame{
	private static final long serialVersionUID = -193131311378863350L;
	private JTabbedPane tab=new JTabbedPane();
	public DishSelect(){
		super("日志查询",true,true,true,true);
		setContentPane(tab);
	    setResizable(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
	    Select cho=new Select("select * from dishlog;");
	    JPanel temp=new JPanel(new BorderLayout());
	    temp.add(cho,BorderLayout.NORTH);
	    temp.add(new JScrollPane(cho.t),BorderLayout.CENTER);
	    tab.add("△未班结商品操作日志",temp);
	    
	    cho=new Select("select * from hqdishlog;");
	    temp=new JPanel(new BorderLayout());
	    temp.add(cho,BorderLayout.NORTH);
	    temp.add(new JScrollPane(cho.t),BorderLayout.CENTER);
	    tab.add("▲已班结商品操作日志",temp);
	    
	    JTable ta = Sql.getTable();
	    JLabel tmsga = new JLabel();
	    SelectDown sda = new SelectDown(ta, "select * from dish where ", "hqdish", tmsga);
	    sda.add(new help(ta,"dish",tmsga));
	    sda.add(tmsga);
	    temp=new JPanel(new BorderLayout());
	    temp.add(sda,BorderLayout.NORTH);
	    temp.add(new JScrollPane(ta),BorderLayout.CENTER);
	    tab.add("◇未班结点单记录",temp);
	    
	    JTable tb = Sql.getTable();
	    JLabel tmsgb = new JLabel();
	    SelectDown sdb = new SelectDown(tb, "select * from hqdish where ", "hqdish", tmsgb);
	    sdb.add(new help(tb,"hqdish",tmsgb));
	    sdb.add(tmsgb);
	    temp=new JPanel(new BorderLayout());
	    temp.add(sdb,BorderLayout.NORTH);
	    temp.add(new JScrollPane(tb),BorderLayout.CENTER);
	    tab.add("◆已班结点单记录",temp);
	    
	    setVisible(true);
	}
	
	class help extends JPanel{
		private static final long serialVersionUID = -5366120995956813482L;
		private JTextField text = new JTextField(18);
		public help(final JTable t, final String tablename, final JLabel tip){
			setLayout(new FlowLayout(FlowLayout.RIGHT));
			add(new JLabel("助记符 或 商品名查询:"));
			add(text);
			text.getDocument().addDocumentListener(new DocumentListener() {
				
				@Override
				public void removeUpdate(DocumentEvent e) {
					// TODO Auto-generated method stub
					insertUpdate(e);
				}
				
				@Override
				public void insertUpdate(DocumentEvent e) {
					// TODO Auto-generated method stub
					String sql="select * from "+tablename+" where 商品名 like '%"+text.getText()+"%' or " +
							   "商品名 in (select 商品名 from menu where 助记符 like '%"+text.getText()+"%') " +
							   	"order by 索引 desc limit 0,200 ";
					Sql.getArrayToTable(sql, DishSelect.this, t);
					Sql.TableAtt(t, true, false);
					tip.setText("共查询到:"+t.getRowCount()+" 条记录(限制200条)");
				}
				
				@Override
				public void changedUpdate(DocumentEvent e) {
					// TODO Auto-generated method stub
					
				}
			});
		}
	}
}