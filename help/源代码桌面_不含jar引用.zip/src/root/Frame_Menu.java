package root;
import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import log.Chatlog;
import log.GeneralLog;
import log.DishSelect;
import Menu.Menu;
import Privilege.PriFrame;
import about.Author;
import bar.BarFrame;
import bar.BarLog;
import bill.Interface_Design;
import bill.Sybase;
import bill.ToFront;
import bill_print.Print_Design;
import desk_ago.Querybill;
import desk_creat.Desk_Design;
import desk_creat.Desk_Table;
import desk_creat.Desk_init;
import print.PrintFrame;
import print.Print_result;
import pub.ConfigFile;
import pub.Mycal;
import pub.Photo;
import pub.Var;
import report.Report_short;
import report.Report_frame;
import reserve.BLog;
import reserve.Booking;
import sidePanel.Password;
import vip.AR;
import vip.ARlog;
import vip.ICCard;
public class Frame_Menu extends JMenuBar implements ActionListener{
	private static final long serialVersionUID = 2843695144484398648L;
	private final JCheckBox show_ico=new JCheckBox("快捷图标");
	private final JCheckBox show_inf=new JCheckBox("侧边栏");
	private final JCheckBox show_con=new JCheckBox("终端消息");
	private final JRadioButton cross = new JRadioButton("cross", false);
	private final JRadioButton system = new JRadioButton("system", false);
	private final JRadioButton motif = new JRadioButton("motif", false);
	private final JRadioButton def = new JRadioButton("default", false);
	private final JCheckBox com1 = new JCheckBox("开启COM1串口打印");
	private final JCheckBox com2 = new JCheckBox("开启COM2串口打印");
	public Frame_Menu(){
		String val[]=new String[]{"⌘   欢迎首页","■  方块时态图","▦  表格时态图","   卡台表格","","✎   修改密码","☂  锁定","","✘  退出"};
    	getMenu("大木木Dmumu",val);
    	
    	val = new String[]{"预定系统","菜谱管理","进入吧台","权限管理","系统设置","","删除历史数据","","实时监控"};
    	getMenu("管理Manger",val);
    	//m2.setMnemonic(KeyEvent.VK_M);
    	
    	val = new String[]{"收银快捷报表","财务报表","","AR账管理","IC卡管理","","AR账查询(西软)","房态表(西软)","前台在住宾客(西软)"};
    	getMenu("财务Finance",val);
    	
    	val = new String[]{"账单设计","接口设计","台号属性","","打印机设置",""};
    	getMenu("设计Design",val);
    	
    	val = new String[]{"账单查询","点单及其日志","吧台商品日志","出单日志","","预定操作日志","AR操作日志","系统通用日志","","聊天记录"};
    	getMenu("日志Log",val);

    	JMenu m6=new JMenu("窗体Window");      //窗口
    	m6.add("组件 Comp");
    	m6.add(show_ico);
    	m6.add(show_inf);
    	m6.add(show_con);
    	m6.addSeparator();
	    ButtonGroup feel_group = new ButtonGroup();	   //界面风格
		feel_group.add(cross);
		feel_group.add(system);
		feel_group.add(motif);
		feel_group.add(def);
		m6.add("风格 Style");
		m6.add(cross);
		m6.add(system);
		m6.add(motif);
		m6.add(def);
    	add(m6);
    	
    	val = new String[]{"系统键盘","程序键盘","计算器","数字输入键盘","","万年历","切换输入 Ctrl+Shift","切换输入 Ctrl+Space","","数据库查询器"};
    	getMenu("工具Tools",val);
    	
    	val = new String[]{"快捷键","","法律声明","版本","站点信息","","在线讨论"};
    	getMenu("关于About",val);
    	
    	show_ico.setSelected(true);
    	show_inf.setSelected(true);
    	show_ico.addActionListener(this);
    	show_inf.addActionListener(this);
    	show_con.addActionListener(this);
		cross.addActionListener(new LookAndFeel_Listener());
		system.addActionListener(new LookAndFeel_Listener());
		motif.addActionListener(new LookAndFeel_Listener());
		def.addActionListener(new LookAndFeel_Listener());
	}
	private JMenu getMenu(String s, String val[]){
		final JMenu m=new JMenu(s);      //关于
		for(String temp : val){
			if(temp.isEmpty()){
				m.addSeparator();
				continue ;
			}
			JMenuItem mi=new JMenuItem(temp);
			mi.addActionListener(this);
			m.add(mi);
		}
		add(m);
		
		if(s.equals("设计Design")){
	    	m.add(com1);
	    	m.add(com2);
		    com1.addActionListener(this);
		    com2.addActionListener(this);
		    com1.setToolTipText("当使用com端口打印时,指明是使用1号端口,本地配置文件PrintCom参数同步更新");
		    com2.setToolTipText("当使用com端口打印时,指明是使用2号端口,本地配置文件PrintCom参数同步更新");
		    String temp=ConfigFile.getProperty("PrintCom");
			if(temp.equals("COM1"))	com1.setSelected(true);
			if(temp.equals("COM2"))	com2.setSelected(true);
		}
		
		return m;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		final String s=e.getActionCommand();
		if((e.getSource()==show_ico)||(e.getSource()==show_inf)||(e.getSource()==show_con)){
			Front.front.NorthPanel.setVisible(show_ico.isSelected());
			Front.front.WestPanel. setVisible(show_inf.isSelected());
			Front.front.SouthPanel.setVisible(show_con.isSelected());
		}
		else if(e.getSource()==com1){
			if(com1.isSelected()){
				com2.setSelected(false);
				ConfigFile.setProperty("PrintCom", "COM1");
			}
			else{
				ConfigFile.setProperty("PrintCom", "");
			}
		}
		else if(e.getSource()==com2){
			if(com2.isSelected()){
				com1.setSelected(false);
				ConfigFile.setProperty("PrintCom", "COM2");
			}
			else{
				ConfigFile.setProperty("PrintCom", "");
			}
		}
		
		//window程序
		else if(s.equals("系统键盘")){
			sidePanel.WestPan.handle();
		}
		else if(s.equals("计算器")){
			try{
				Runtime.getRuntime().exec("calc.exe");
		    }catch(IOException io){}
		}
		else if(s.equals("万年历")){
			Mycal cas = new Mycal();
			cas.setBorder(BorderFactory.createTitledBorder(""));
			cas.setPreferredSize(new Dimension(650, 390));
			JOptionPane.showMessageDialog(Front.front, cas, "万年历   → 参考本机时间", 0, new ImageIcon());
		}
		else if(s.endsWith("锁定")){
			new Logon();
		}
		else if(s.endsWith("修改密码")){
			new Password();
		}
		else if(s.endsWith("退出")){
			final int k=JOptionPane.showConfirmDialog(null,"确定退出程序吗？ Are you sure shutdown program ?","注意",0,1,Var.getIcon("米饭"));
			if(k==0) System.exit(0);
		}
		
		//
		else if(s.equals("快捷键")){
	        JOptionPane.showMessageDialog(Front.front, HelpInfo(), "快捷键大全 Hot_Key", 1, new ImageIcon());
		}
		else if(s.equals("法律声明")){
			new Author(500,300);
		}
		else if(s.equals("在线讨论")){
			try{  //运行Windows下的程序
				Runtime.getRuntime().exec("explorer https://webchat.freenode.net/");
		     }catch(IOException io){}
		}
		else if(s.equals("版本")){
			String str[]=Sql.getString("select value from general where name='饭店' and item='名称'", this);
			if(str.length==0) str=new String[]{"Who Are You ?"};
			String temp="Dmumu(R) 餐饮服务行业管理平台\n版本 Version3.0 Build id:20231107-0XXX\n";
			temp=temp+"版权所有 (C) 2023 Dmumu Corp. All rights reserved\n\n";
			temp=temp+"本产品符合 最终用户许可协议，授权给： "+str[0];
			
			JOptionPane.showMessageDialog(Front.front,temp,"版本 Version",1,Photo.readIcon("logo"));
		}
		else if(s.equals("站点信息")){
			final Vector<String> v = Var.getpc();
			String temp="";
			for(int k=0;k<v.size();k++){
				temp=temp+v.get(k);
			}
			JOptionPane.showMessageDialog(Front.front,temp,"站点信息",1, new ImageIcon());
		}
		else if(s.equals("收银快捷报表")){
			new Report_short() ;
		}
		else if(s.contains("Ctrl+Shift")){
			try {
				Robot robot = new Robot();
				//ctrl + shift 组合键
			    robot.keyPress(KeyEvent.VK_CONTROL);
			    robot.keyPress(KeyEvent.VK_SHIFT);
			    robot.keyRelease(KeyEvent.VK_SHIFT);
			    robot.keyRelease(KeyEvent.VK_CONTROL);
			} catch (AWTException e1) {}
		}
		else if(s.contains("Ctrl+Space")){
			try {
				Robot robot = new Robot();
			    robot.keyPress(KeyEvent.VK_CONTROL);
			    robot.keyPress(KeyEvent.VK_SPACE);
			    robot.keyRelease(KeyEvent.VK_SPACE);
			    robot.keyRelease(KeyEvent.VK_CONTROL);
			} catch (AWTException e1) {}
		}
		else if(s.contains("AR账查询")){
			final String sql = "select item,value,remark from general where name='interface' and item='sqld' ";
			final ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
			final JTable dest[] = new JTable[arr.size()];
			
			final JTabbedPane tab = new JTabbedPane();
			for(int x=0; x<arr.size(); x++){
				dest[x] = Sql.getTable();
				dest[x].setName(arr.get(x)[1]);
				tab.addTab(arr.get(x)[2], new JScrollPane(dest[x]));
			}
			
			tab.setPreferredSize(new Dimension(760,380));
			JOptionPane.showConfirmDialog(Front.front, tab,"正在查询 ...",2,1,new ImageIcon());
			new Thread(new Runnable() { //以免卡死
				public void run() {
					new Sybase(dest);
				}
			}).start();
		}
		else if(s.contains("房态表")){
			String sql = "select item,value,remark from general where name='interface' and item='sqle' ";
			final ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
			final JTable dest[] = new JTable[arr.size()];
			
			final JTabbedPane tab = new JTabbedPane();
			for(int x=0; x<arr.size(); x++){
				dest[x] = Sql.getTable();
				dest[x].setName(arr.get(x)[1]);
				tab.addTab(arr.get(x)[2], new JScrollPane(dest[x]));
			}
			
			tab.setPreferredSize(new Dimension(760,380));
			JOptionPane.showConfirmDialog(Front.front, tab,"正在查询 ...",2,1,new ImageIcon());
			new Thread(new Runnable() { //以免卡死
				public void run() {
					new Sybase(dest);
				}
			}).start();
		}
		else if(s.contains("卡台表格")){
			JTable t = Sql.getTable("select * from deskgo", this) ;
			Sql.TableAtt(t, true, false);
			JScrollPane js=new JScrollPane(t);
			js.setPreferredSize(new Dimension(1024, 480));
			JOptionPane.showMessageDialog(Front.front, js, "卡台表格分析", 1, new ImageIcon());
		}
		else if(s.equals("数据库查询器")){
			new SelectTool();
		}
		else if(s.equals("数字输入键盘")){
			new Numkey(null);
		}
		else if(s.equals("程序键盘")){
			new Kbkey(null);
		}
		//内部窗口
		else{
			Front.inFrame.removeAll();
			if(s.contains("前台在住宾客")){
				Front.inFrame.add(new ToFront(""));
			}
			/*************************************************/
			else if(s.equals("账单查询")){
				Front.inFrame.add(new Querybill());
			}
			else if(s.equals("点单及其日志")){
				Front.inFrame.add(new DishSelect());
			}
			else if(s.equals("吧台商品日志")){
				//把吧台商品类别存放在里面
				String mebar="select value from general where name='system' and item='barmenu';";
				String barmenu[]=Sql.getString(mebar, this);
				String temp = "";
				if(barmenu.length>0){
					temp=barmenu[0];
					int len=temp.length();
					if(len>2){
						temp=temp.substring(1, len-1);
					}
				}
				Front.inFrame.add(new IFrame(s,new BarLog(temp)));
			}
			else if(s.equals("出单日志")){
				Front.inFrame.add(new IFrame(s,new Print_result()));
			}
			else if(s.equals("预定操作日志")){
				Front.inFrame.add(new IFrame(s,new BLog()));
			}
			else if(s.equals("AR操作日志")){
				Front.inFrame.add(new IFrame(s,new ARlog()));
			}
			else if(s.equals("系统通用日志")){
				Front.inFrame.add(new IFrame(s,new GeneralLog()));
			}
			else if(s.equals("聊天记录")){
				Front.inFrame.add(new IFrame(s,new Chatlog()));
			}
			/*************************************************/
			else if(s.equals("预定系统")){
				Front.inFrame.add(new Booking());
			}
			else if(s.equals("菜谱管理")){
				Front.inFrame.add(new Menu());
			}
			else if(s.equals("进入吧台")){
				Front.inFrame.add(new BarFrame());
			}
			else if(s.equals("权限管理")){
				Front.inFrame.add(new PriFrame());
			}
			else if(s.equals("系统设置")){
				Front.inFrame.add(new SysOption());
			}
			else if(s.equals("删除历史数据")){
				Front.inFrame.add(new Dislodge());
			}
			else if(s.equals("实时监控")){
				Front.inFrame.add(new Monitor());
			}
			/*********************************************************/
			else if(s.equals("财务报表")){
				Front.inFrame.add(new Report_frame());
			}
			else if(s.equals("AR账管理")){
				Front.inFrame.add(new AR());
			}
			else if(s.equals("IC卡管理")){
				Front.inFrame.add(new ICCard());
			}
			
			
			else if(s.equals("账单设计")){
				Front.inFrame.add(new Print_Design());
			}
			else if(s.equals("接口设计")){
				Front.inFrame.add(new Interface_Design());
			}
			else if(s.equals("台号属性")){
				Front.inFrame.add(new Desk_Design());
			}
			else if(s.equals("打印机设置")){
				Front.inFrame.add(new PrintFrame());
			}
			
			else if(s.endsWith("欢迎首页")){
				Front.inFrame.add(new Welcome());
			}
			else if(s.endsWith("方块时态图")){
				Front.inFrame.add(new Desk_init());
			}
			else if(s.endsWith("表格时态图")){
				Front.inFrame.add(new Desk_Table());
			}
			
			//进行最大化，这样做是为了能自适应inFrame的大小
			try {
		    	if(Front.inFrame.getComponentCount()>0){
		    		if(Front.inFrame.getComponent(0) instanceof JInternalFrame){
		    			((JInternalFrame)Front.inFrame.getComponent(0)).setMaximum(true); 
		    		}
		    	}
			} catch (Exception es) {
				es.printStackTrace();
			}
		}
	}
	
	private JPanel HelpInfo(){
		final JPanel nor=new JPanel();
		nor.setLayout(new BoxLayout(nor, BoxLayout.PAGE_AXIS));	//一行一行的布局
		
		nor.add(new JLabel("F1     帮助文档"));
		nor.add(new JLabel("F2     欢迎首页"));
		nor.add(new JLabel("F3     方块时态图"));
		nor.add(new JLabel("F4     表格时态图"));
		nor.add(new JLabel("F5     预定管理"));
		nor.add(new JLabel("F6     隐藏和显示 快捷图标"));
		nor.add(new JLabel("F7     隐藏和显示 侧面板"));
		nor.add(new JLabel("F8     隐藏和显示 终端面板"));
		nor.add(new JLabel("F10   展开菜单栏"));
		nor.add(Box.createVerticalStrut((12)));
		
		nor.add(new JLabel("方块时态图 视图下："));
		nor.add(new JSeparator());	//分割线
		nor.add(Box.createVerticalStrut((6)));
		nor.add(new JLabel("Alt + 1    以数字编号的对应区域,依此类推"));
		nor.add(Box.createVerticalStrut((12)));
		
		nor.add(new JLabel("台号管理视图下："));
		nor.add(new JSeparator());	//分割线
		nor.add(Box.createVerticalStrut((6)));
		nor.add(new JLabel("Alt + G     开台信息"));
		nor.add(new JLabel("Alt + U     已点商品"));
		nor.add(new JLabel("Alt + S     商品浏览"));
		nor.add(new JLabel("Alt + H     操作记录"));
		nor.add(new JLabel("Alt + K     出单记录"));
		nor.add(new JLabel("Alt + P     打印账单"));
		nor.add(new JLabel("Alt + M     结账买单"));
		nor.add(new JLabel("Alt + Q     退出管理"));
		nor.add(Box.createVerticalStrut((18)));
		
		nor.add(new JLabel("结账视图下："));
		nor.add(new JSeparator());	//分割线
		nor.add(Box.createVerticalStrut((6)));
		nor.add(new JLabel("Alt + S     确定结账"));
		nor.add(new JLabel("Alt + N     取消结账"));
		nor.add(Box.createVerticalStrut((12)));
		
		nor.add(new JLabel("对话框视图下："));
		nor.add(new JSeparator());	//分割线
		nor.add(Box.createVerticalStrut((6)));
		nor.add(new JLabel("Alt + S     确定,提交,保存,存盘 Submit"));
		nor.add(new JLabel("Alt + Q     退出,返回,关闭,撤消 Quit"));
		nor.add(new JLabel("Alt + L     锁定,切换帐号"));
		nor.add(new JLabel("Alt + X     退出系统"));

		return nor;
	}
	
	class IFrame extends JInternalFrame{
		private static final long serialVersionUID = -19551378863350L;
		public IFrame(String title, JPanel com){
			super(title,true,true,true,true);
			setContentPane(com);
		    setResizable(true);
		    setOpaque(false);
		    setSize(Front.inFrame.getSize());
		    setVisible(true);
		}
	}
	
	//更新程序外观样式,应用主题外观效果时某些组件的透明效果没有了
	class LookAndFeel_Listener implements ActionListener { // 选择外观的样式
		public void actionPerformed(ActionEvent ev) {
			final JRadioButton o = (JRadioButton) ev.getSource();
			String str = o.getText();
			try {
				if ("cross" == str) {
					UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
					//UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel") ; 
				} 
				else if ("system" == str) {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					//UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
				}
				else if ("motif" == str) {
					UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
				} 
				else if ("default" == str) {
					UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			for(int k=0;k<Front.getFrames().length;k++){
				SwingUtilities.updateComponentTreeUI(Front.getFrames()[k]);
				//getRootPane().setWindowDecorationStyle(1);
			}
		}
	}
}
