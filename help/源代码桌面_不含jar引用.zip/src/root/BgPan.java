package root;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import pub.ConfigFile;
public class BgPan extends JPanel{
	private static final long serialVersionUID = 416576652L;
	private Image img ;
	public Point p =new Point();
	protected void paintChildrens(Graphics g) {}
	public void paintComponentc(Graphics g) {	//paintComponents也是
		if(img!=null) g.drawImage(img,0,0,this.getWidth()-1,this.getHeight()-1,this);
	    super.paintComponent(g);
	}
	//当Swing中的paint方法被调用时，paintComponent、paintBorder、 paintChildren 
	//这三个方法也会被按顺序调用，之所以要按这个顺序调用是为了保证子组件能正确地显示在目前这个组件之上。
	//总结了一下：Swing中改变组件样式重写paintComponent就可以了，其他paintBorder和paintChildren默认就可以。
	//awt中改变组件样式要重写paint方法，而且如果不需要调用super.paint(g)就可以保留原组件样式，
	//但是不会显示子组件样式，可以调用paintComponents(g)解决这个问题。
	public void paint(Graphics g) {
		if(img!=null) g.drawImage(img,0,0,this.getWidth()-1,this.getHeight()-1,this);
	    super.paintChildren(g);//不知为什么，要用paintChildren才有背景
	}
	public BgPan(String photo, String config){
		img=new ImageIcon(this.getClass().getClassLoader().getResource(photo)).getImage();
		re();
		final String val = ConfigFile.getProperty(config);	//"icon30"
		if(!val.isEmpty()){
			final String path = ConfigFile.confdir+File.separator+"photo"+File.separator+val;
			final File f = new File(path);
			if(f.exists()){
				img = new ImageIcon(path).getImage();
				re();
			}
		}
		p.x = img.getWidth(null);
		p.y = img.getHeight(null);
	}
	private void re(){
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
		    	updateUI();
		    }
		});
	}
}