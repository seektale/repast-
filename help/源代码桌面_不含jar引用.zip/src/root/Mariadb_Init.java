package root;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.swing.JOptionPane;
import ch.vorburger.exec.ManagedProcessException;
import ch.vorburger.mariadb4j.DB;
import ch.vorburger.mariadb4j.DBConfiguration;
import ch.vorburger.mariadb4j.DBConfigurationBuilder;

/*
	数据库官网 https://mariadb.com/kb/zh-cn/mariadb/
	数据库官网 https://mariadb.com/kb/zh-cn/backup-and-restore-overview/
	SET GLOBAL character_set_client=utf8;
	SET GLOBAL character_set_connection=utf8;
	SET GLOBAL character_set_database=utf8;
	SET GLOBAL character_set_results=utf8;
	SET GLOBAL character_set_server=utf8;
	
	--skip-grant-tables=on
	FLUSH PRIVILEGES
	ALTER USER 'root'@'localhost' IDENTIFIED BY '123456'	重置密码,有时候不好使
	FLUSH PRIVILEGES
	
	--skip-grant-tables=off
	FLUSH PRIVILEGES
	GRANT all PRIVILEGES on *.* to 'root'@'%' IDENTIFIED BY '123465' WITH GRANT OPTION;
	FLUSH PRIVILEGES
	
	SELECT
	CONCAT( 'ALTER TABLE ', TABLE_NAME, ' CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;' ) 
	FROM
	information_schema.`TABLES` 
	WHERE
	TABLE_SCHEMA = 'repast';
	
	spring-core-5.3.13.jar	需要这个jar
	spring-jcl-5.3.13.jar	需要这个jar
*/

public class Mariadb_Init{
	
	public DB db;
	
	public void init() throws Exception {
		
		String jarPath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		try {
			jarPath = java.net.URLDecoder.decode(jarPath, "UTF-8"); //解决路经中存在的空格问题，如：program%20files%20
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		final String zipPath = new File(jarPath).getParent() + File.separator + "dblocal.zip";
		final File dbfile = new File(zipPath);
		if (dbfile.exists() == false) {
			JOptionPane.showMessageDialog(null, "用于数据库目录恢复的初始化压缩文件没有找到：" + zipPath);
			return;
		}
		
		String dbdir = getzipdir(zipPath, dbfile.getParent());
		if(new File(dbdir).exists()==false) {
			dbdir = unzip(zipPath, dbfile.getParent()); //没有数据库目录,解压zip得到数据库目录
		}
		
		final DBConfiguration dbConfiguration = DBConfigurationBuilder.newBuilder().setPort(3306).setDataDir(dbdir)
				// .addArgument("--basedir=" + baseDir.getAbsolutePath(),false).setWorkingDirectory(baseDir);
				// .addArgument("--datadir=" + dataDir.getAbsolutePath(), false);
				.addArg("--user=root")
				.addArg("--skip-grant-tables=off")	//实际默认是on, 参考：https://mariadb.com/docs/server/ref/mdb/system-variables/skip_grant_tables/
				.addArg("--skip-name-resolve") 		//当创建授权表时，用IP地址而不是host名，如'log'@'localhost'登陆时会变成'log'@'127.0.0.1'
				//.addArg("--port=3306")
				.addArg("--character-set-server=utf8") //确保支持中文,是否生效检查语句：show VARIABLES LIKE '%char%'
				.addArg("--character-set-client=utf8") //数据库使用了utf8mb4编码,不需要改,因为对于java的utf8来说是全兼容的
				.build();
		
		db = DB.newEmbeddedDB(dbConfiguration);
		System.out.println("程序运行目录 BaseDir:  " + db.getConfiguration().getBaseDir());
		System.out.println("数据库目录 DataDir:  " + db.getConfiguration().getDataDir());
		
		// 系统关闭时执行
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			try {
				if(db!=null) db.stop();
			} catch (ManagedProcessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}));
	}
	
	//用于获取压缩文件中的第一个目录,这样做的目的是使压缩文件目录可以自定义名称
	private String getzipdir(String zipFilePath, String destDirectory) throws IOException {
        final File destDir = new File(destDirectory);
        if (!destDir.exists()) destDir.mkdirs();
        final ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
        final ZipEntry entry = zipIn.getNextEntry();
        String rootdir = "";
        if(entry != null) rootdir=destDirectory + File.separator + entry.getName();
        zipIn.close();
        return rootdir;
    }
	
	private String unzip(String zipFilePath, String destDirectory) throws IOException {
        final File destDir = new File(destDirectory);
        if (!destDir.exists()) destDir.mkdirs();
        final ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
        ZipEntry entry = zipIn.getNextEntry();
        String rootdir = "";
        while (entry != null) {
            final String filePath = destDirectory + File.separator + entry.getName();
            if(rootdir.isEmpty()) {
            	rootdir = filePath; //第一个就是根目录,先对旧目录备份
            	final File tem = new File(filePath);
                final SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
            	if(tem.exists()) tem.renameTo(new File(tem.getParent()+File.separator+"db_backup_"+formatter.format(new Date())));
            }
            if (!entry.isDirectory()) {
                extractFile(zipIn, filePath);
            } else {
                final File dir = new File(filePath);
                dir.mkdirs();
            }
            zipIn.closeEntry();
            entry = zipIn.getNextEntry();
        }
        zipIn.close();
        return rootdir;
    }
	
    private void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
        final BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
        final byte[] bytesIn = new byte[4096];
        int read;
        while ((read = zipIn.read(bytesIn)) != -1) {
            bos.write(bytesIn, 0, read);
        }
        bos.close();
    }
    
}
