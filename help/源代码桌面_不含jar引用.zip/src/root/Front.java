package root;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.KeyEventPostProcessor;
import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import java.util.ArrayList;
import javax.swing.*;
import bar.BarFrame;
import desk_ago.Querybill;
import desk_creat.Desk_Table;
import desk_creat.Desk_init;
import Menu.Menu;
import Privilege.PriFrame;
import print.PrintFrame;
import pub.ConfigFile;
import pub.Var;
import report.Report_frame;
import reserve.*;
import sidePanel.SouthPan;
import sidePanel.WestPan;
public class Front extends JFrame{
	
	private static final long serialVersionUID = 20850641545538L;
	public static Image logo ;
	public static Front front ;
	public static boolean N,W,S;
	
	public static void main(String arg[]) {
        new ConfigFile();	//初始化本地配置文件包括dll文件布置
        final String tem = ConfigFile.getProperty("RootPasswordReset");
        ConfigFile.setProperty("RootPasswordReset", false); //有效性为单次
        if(tem.equalsIgnoreCase("Y")) {
        	new Mariadb_ResetPassword(); //密码重置
        	System.exit(0);
        }
        new Logon(); //包括可选本地数据库的启动
    	new Front();
    	// 王银波 2015-04-04 武汉江夏区梁子湖度假村 完工 在此留迹
    	// 2023-12-01 进行升级完工
	}
	
	private final JPanel NorthCen = new JPanel(new FlowLayout(FlowLayout.LEFT,20,3));
	public final JPanel   NorthPanel = new JPanel(new BorderLayout());
	public final WestPan  WestPanel  = new WestPan();
	public final SouthPan SouthPanel = new SouthPan();
	public static boolean style,help=true;
	public static JButton selected;		//记录当前选择的区域
	
	private final JLabel welcome	= init_button("欢迎首页 Welcome_Page","wel");
	private final JLabel deskStat	= init_button("方块餐态图 Desk_view","stat1");
	private final JLabel deskTable	= init_button("表格餐态图 Table_view","stat2");
	private final JLabel historyBill= init_button("历史账单History_bill","his");
	private final JLabel reserve	= init_button("预定管理 Booking","booking");
	private final JLabel report		= init_button("财务报表 Fance_Report","finance");
	private final JLabel MenuManger	= init_button("菜品管理 Menu","menu");
	private final JLabel admin		= init_button("帐号管理 Account_Power ","admin");
	private final JLabel monitor	= init_button("实时监控 Monitor","mon");
	private final JLabel bar		= init_button("吧台管理 bar","bar");
	private final JLabel sys		= init_button("系统设置 System_Option","sys");
	private final JLabel print		= init_button("打印参数 Printer","print");
	private final JLabel hideshort	= init_button("隐藏 Hide = F6","hide1");
	
	public static final JDesktopPane inFrame = new JDesktopPane();
	
	public Front(){
		//全局快捷键,每按一次键，会激发两次到三次事件，用e.getID过滤掉不需要的
		KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
		manager.addKeyEventPostProcessor(new KeyEventPostProcessor() {
			public boolean postProcessKeyEvent(KeyEvent e) {
				if(e.getID()!=KeyEvent.KEY_PRESSED) return false;
				//这里的参数只允许使用可转换的 int 值或枚举常量
				switch(e.getKeyCode()){
					case KeyEvent.VK_F1: help();					break;
					case KeyEvent.VK_F2: myAction(welcome);			break;
					case KeyEvent.VK_F3: myAction(deskStat);		break;
					case KeyEvent.VK_F4: myAction(deskTable);		break;
					case KeyEvent.VK_F5: myAction(reserve);			break;
					case KeyEvent.VK_F6: myAction(hideshort);		break;
					case KeyEvent.VK_F7: WestPanel.hide.doClick();	break;
					case KeyEvent.VK_F8: SouthPanel.setSelectedIndex(SouthPanel.getComponentCount()-1);	break;
					default:			 break;
				}
				return true;
			}
		});

    	front = Front.this;
        inFrame.setOpaque(false);
        JPanel conPanel  = new JPanel(new BorderLayout());
        conPanel.setOpaque(false);	//必须透明，否则背景不显示
        
        NorthPanel.setOpaque(false);
        NorthCen.setOpaque(false);
        NorthPanel.add(new WHoliday(),BorderLayout.EAST);
        NorthPanel.add(NorthCen,BorderLayout.CENTER);
    	conPanel.add(NorthPanel,BorderLayout.NORTH);
    	conPanel.add(WestPanel,BorderLayout.WEST);
    	
    	JPanel tempCenter=new JPanel(new BorderLayout());
    	tempCenter.setOpaque(false);
    	tempCenter.add(inFrame, BorderLayout.CENTER);
    	tempCenter.add(SouthPanel, BorderLayout.SOUTH);
    	SouthPanel.setVisible(false);
    	conPanel.add(tempCenter,BorderLayout.CENTER);
    	
    	setTitle(" dmumu.com 大木木集团股份");
    	if(style) setUndecorated(true);				//没有边框
    	setMinimumSize(new Dimension(820,600));		//最小窗口大小
	    setExtendedState(JFrame.MAXIMIZED_BOTH);	//窗口最大
 	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 	    setContentPane(conPanel);
 	    setJMenuBar(new Frame_Menu());				//菜单
 	    setIconImage(logo);							//窗体左上角图标(自动缩小)，默认为一杯咖啡
	    
	    //正确启用UI线程的方法,到EDT线程中执行
	    final BgPan bg=new BgPan("pic/b.jpg","icon31"); //背景
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
		    	setVisible(true);
		    	bg.setSize(getSize());	//必须指定大小
		        getLayeredPane().add(bg, new Integer(Integer.MIN_VALUE));
		    }
		});
		new ini().execute();
	    
	    //JFrame中的层次分布及相对关系是:最底层是JRootPane,第二层是JlayerPane,最上层就是ContentPane,也正是我们常说的内容面板。
	    //所以一般我们拖放的控件就是在ContentPane层上。也就是说我们只需将背景图片放在JFrame的第二层是JlayerPane上,
	    //再把内容面板ContentPane设置为透明,则第二层JlayerPane上放置的图片即成为内容面板的背景了。
        
	    addWindowStateListener(new WindowStateListener() {
			public void windowStateChanged(WindowEvent e) {
				if(e.getNewState() == 1 || e.getNewState() == 7) {
                    //System.out.println("窗口最小化");
                }
				//最大化及取消最大化
				else if(e.getNewState() == 0) {
					setLocationRelativeTo(null);	//居中
                }
                else if(e.getNewState() == 6) {
                    //System.out.println("窗口最大化");
                }
			}
		});
	}
	
	public class ini extends SwingWorker<Component, Void> {
		protected Component doInBackground() throws Exception {
			if(style){
				return new Desk_init();
			}
			return new Welcome();
		}
		protected void done() {
		    try {
		    	inFrame.add(get());
		    	if(get() instanceof Desk_init){
		    		((JInternalFrame)inFrame.getComponent(0)).setMaximum(true); 
		    	}
		    }catch (Exception es) {es.printStackTrace();}
		}
	}
	
	private JLabel init_button(String tip,String pic){
		final JLabel b=new JLabel();
		b.setToolTipText(tip);
		Icon co=new ImageIcon(this.getClass().getClassLoader().getResource("shortico/"+pic+".png"));
		b.setIcon(co);
		b.setName(tip);
		b.setPreferredSize(new Dimension(38, 38));
		b.addMouseListener(new MouseAdapter() {
			public void mouseExited(MouseEvent arg0) {
				b.setBorder(null);
			}
			public void mouseEntered(MouseEvent arg0) {
				b.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));//立体感
			}
			public void mousePressed(MouseEvent arg0) {
				myAction(b);
			}
		});
		NorthCen.add(b);
		return b;
	}
	
	private void help(){
		if(help){	//help是为了防止多次重复按help键导致弹出多个重叠的消息对话框
			help=false;
			String helpstr = "select item,value,remark from general where name='help'" ;
			ArrayList<String[]> arr = Sql.getArrayToArrary(helpstr, this);
			String s="";
			for(String temp[] : arr){
				s=s+temp[1]+"、"+temp[0]+"："+temp[2]+"\n";
			}
			if(s.isEmpty()) s="没有从数据库表general中查找到帮助信息。";
			JOptionPane.showMessageDialog(null,s,"帮助 Help",2,Var.getIcon("米饭"));
			help=true;
		}
	}
	
	private void myAction(JLabel lab){
		if(lab==hideshort){
			getJMenuBar().setVisible(!NorthPanel.isVisible());
			NorthPanel.setVisible(!NorthPanel.isVisible());
			return ;
		}
		
		if(lab==welcome){
			inFrame.removeAll();
			inFrame.add(new Welcome());
			return ;
		}

		if(lab==deskStat){
			addFrame(new Desk_init());
		}
		else if(lab==historyBill){
			addFrame(new Querybill());
		}
		else if(lab==MenuManger){
			addFrame(new Menu());
		}
		else if(lab==report){
			addFrame(new Report_frame());
		}
		else if(lab==reserve){
			addFrame(new Booking());
		}
		else if(lab==bar){
			addFrame(new BarFrame());
		}
		else if(lab==admin){
			addFrame(new PriFrame());
		}
		else if(lab==print){
			addFrame(new PrintFrame());
		}
		else if(lab==sys){
			addFrame(new SysOption());
		}
		else if(lab==deskTable){
			addFrame(new Desk_Table());
		}
		else if(lab==monitor){
			addFrame(new Monitor());
		}
	}
	
	//单击事件本身在EDT线程中执行
	private void addFrame(Component p){
		inFrame.removeAll();
		inFrame.add(p);
		
		//进行最大化，这样做是为了能自适应inFrame的大小
	    try {
	    	((JInternalFrame)inFrame.getComponent(0)).setMaximum(true);
		}
	    catch (Exception es) {es.printStackTrace();}
	}
}


//后三个参数说明
//Object val=JOptionPane.showInputDialog(null,"输入年份与月份","输入",3,Var.getIcon("米饭"),new Object[]{"sdf","sdfa"},"sdfa");


//注意，当客户端程序运行时，修改了mysql数据库服务器的时间，则会导致客户端与数据库的连接被断开。
/*如下面的语句会出错	java.lang.ArrayIndexOutOfBoundsException: 0
String time[]=Sql.getString("select current_date();",getClass().getName());
int year=Integer.valueOf(time[0].substring(0, 4));	//得到年份
*/


//Box box=Box.createHorizontalBox();
//JButton btnA=new JButton("A");
//JButton btnB=new JButton("B");
//box.add(btnA);
//box.add(btnB);  
//f.add(box);  


/*参考资料
maxMemory()这个方法返回的是java虚拟机（这个进程）能构从操作系统那里挖到的最大的内存，以字节为单位，
如果在运行 java程序的时候，没有添加-Xmx参数，那么就是64兆，也就是说maxMemory()返回的大约是64*1024*1024字节，
这是java虚拟机默认情况下能从操作系统那里挖到的最大的内存。如果添加了-Xmx参数，将以这个参数后面的值为准，
例如java -cp ClassPath -Xmx512m ClassName，那么最大内存就是512*1024*0124字节。

totalMemory()这个方法返回的是java虚拟机现在已经从操作系统那里挖过来的内存大小，也就是java虚拟机这个进程当时所占用的所有内存。
如果在运行java的时候没有添加-Xms参数，那么，在java程序运行的过程的，内存总是慢慢的从操作系统那里挖的，基本上是用多少挖多少，
直挖到maxMemory()为止，所以totalMemory()是慢慢增大的。如果用了-Xms参数，程序在启动的时候就会无条件的从操作系统中挖-Xms后面定义的内存数，
然后在这些内存用的差不多的时候，再去挖。

freeMemory()是什么呢，刚才讲到如果在运行java的时候没有添加-Xms参数，那么，在java程序运行的过程的，
内存总是慢慢的从操作系统那里挖的，基本上是用多少挖多少，但是java虚拟机100％的情况下是会稍微多挖一点的，
这些挖过来而又没有用上的内存，实际上就是 freeMemory()，所以freeMemory()的值一般情况下都是很小的，
但是如果你在运行java程序的时候使用了-Xms，这个时候因为程序在启动的时候就会无条件的从操作系统中挖-Xms后面定义的内存数，
这个时候，挖过来的内存可能大部分没用上，所以这个时候freeMemory()可能会有些大。



关于超时如何解决：

最近有个需求, 当DB压力过大时获取Connction的时间过慢长时间不返回的话, 就不连接DB了, 研究了好久,DataSource里面的setLoginTimeOut 
根本没法用, 刚开始一直纠结在大google搜索"java get connection 超时"答案上, 但始终找不到答案, 偶然尝试了下"java 设置超时" 
问题就迎刃而解了. 

java早已经给我们提供了解决方案。jdk1.5自带的并发库中Future类就能满足这个需求。Future类中重要方法包括get()和cancel()。get()
获取数据对象，如果数据没有加载，就会阻塞直到取到数据，而 cancel()是取消数据加载。另外一个get(timeout)操作，表示如果在timeout时间内
没有取到就失败返回，而不再阻塞。 看来不能一直纠结在一条道上, 偶尔换个思路还是很有帮助的,  不多说了, 解决方案如下 

我的code: 
Java代码  收藏代码
public boolean checkDBStatus() {  
    boolean bdStatus = false;  
  
    final ExecutorService exec = Executors.newFixedThreadPool(1);  
    Callable<String> call = new Callable<String>() {  
        public String call() throws Exception {  
            DataSource dataSource = getJdbcTemplate().getDataSource();  
            Connection connection = dataSource.getConnection();  
            Statement statement = connection.createStatement();  
            statement.executeQuery("select * from citirisk_menu_node");  
            return "true";  
        }  
    };  
  
    try {  
        Future<String> future = exec.submit(call);  
        // set db connection timeout to 10 seconds  
        String obj = future.get(1000 * 10, TimeUnit.MILLISECONDS);   
        bdStatus = Boolean.parseBoolean(obj);  
        System.out.println("the return value from call is :" + obj);  
    } catch (TimeoutException ex) {  
        System.out.println("====================task time out===============");  
        ex.printStackTrace();  
        bdStatus = false;  
    } catch (Exception e) {  
        System.out.println("failed to handle.");  
        e.printStackTrace();  
        bdStatus = false;  
    }  
    // close thread pool  
    exec.shutdown();  
  
    return bdStatus;  
}  


在Java中，如果需要设定代码执行的最长时间，即超时，可以用Java线程池ExecutorService类配合Future接口来实现。 Future接口是Java标准API的
一部分，在java.util.concurrent包中。Future接口是Java线程Future模式的实现，可以来进行异步计算。 

Future模式可以这样来描述：我有一个任务，提交给了Future，Future替我完成这个任务。期间我自己可以去做任何想做的事情。一段时间之后，
我就便可以从Future那儿取出结果。就相当于下了一张订货单，一段时间后可以拿着提订单来提货，这期间可以干别的任何事情。
其中Future 接口就是订货单，真正处理订单的是Executor类，它根据Future接口的要求来生产产品。 

Future接口提供方法来检测任务是否被执行完，等待任务执行完获得结果，也可以设置任务执行的超时时间。
这个设置超时的方法就是实现Java程序执行超时的关键。 

Future接口是一个泛型接口，严格的格式应该是Future<V>，其中V代表了Future执行的任务返回值的类型。 Future接口的方法介绍如下： 

    boolean cancel (boolean mayInterruptIfRunning) 取消任务的执行。参数指定是否立即中断任务执行，或者等等任务结束 
    boolean isCancelled () 任务是否已经取消，任务正常完成前将其取消，则返回 true 
    boolean isDone () 任务是否已经完成。需要注意的是如果任务正常终止、异常或取消，都将返回true 
    V get () throws InterruptedException, ExecutionException  
          等待任务执行结束，然后获得V类型的结果。InterruptedException 线程被中断异常， ExecutionException任务执行异常，
         如果任务被取消，还会抛出CancellationException 
    V get (long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException 
          同上面的get功能一样，多了设置超时时间。参数timeout指定超时时间，uint指定时间的单位，在枚举类TimeUnit中有相关的定义。
          如果计算超时，将抛出TimeoutException 

Future的实现类有java.util.concurrent.FutureTask<V>即 javax.swing.SwingWorker<T,V>。
通常使用FutureTask来处理我们的任务。FutureTask类同时又实现了Runnable接口，所以可以直接提交给Executor执行。
使用FutureTask实现超时执行的代码如下： 

Java代码  收藏代码
ExecutorService executor = Executors.newSingleThreadExecutor();    
FutureTask<String> future =    
       new FutureTask<String>(new Callable<String>() {//使用Callable接口作为构造参数    
         public String call() {    
           //真正的任务在这里执行，这里的返回值类型为String，可以为任意类型    
       }});    
executor.execute(future);    
//在这里可以做别的任何事情    
try {    
    result = future.get(5000, TimeUnit.MILLISECONDS); 
    //取得结果，同时设置超时执行时间为5秒。同样可以用future.get()，不设置执行超时时间取得结果    
} catch (InterruptedException e) {    
    futureTask.cancel(true);    
} catch (ExecutionException e) {    
    futureTask.cancel(true);    
} catch (TimeoutException e) {    
    futureTask.cancel(true);    
} finally {    
    executor.shutdown();    
}    

//临时向用户主目录中写入缩放后的文件
2014-11-25在武汉梁子湖放弃下面的代码
Properties props=System.getProperties();
File smallimg = new File(props.getProperty("user.home")+"/smallimg.png");
ImageIO.write((BufferedImage)img,"png",smallimg);
		

不直接构造Future对象，也可以使用ExecutorService.submit方法来获得Future对象，submit方法即支持以 Callable接口类型，
也支持Runnable接口作为参数，具有很大的灵活性。使用示例如下： 
Java代码  收藏代码
ExecutorService executor = Executors.newSingleThreadExecutor();    
FutureTask<String> future =　executor.submit(    
   new Callable<String>() {//使用Callable接口作为构造参数    
       public String call() {    
      //真正的任务在这里执行，这里的返回值类型为String，可以为任意类型    
   }});    
//在这里可以做别的任何事情    
//同上面取得结果的代码    

//控制线程并发量
public class TestThread {
     * 使用线程池的方式是复用线程的（推荐）
     * 而不使用线程池的方式是每次都要创建线程
     * Executors.newCachedThreadPool()，该方法返回的线程池是没有线程上限的，可能会导致过多的内存占用
     * 建议使用Executors.newFixedThreadPool(n)
     * 
     * 有兴趣还可以看下定时线程池：SecheduledThreadPoolExecutor
     
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        int nThreads = 5;
        
        
         * Executors是ThreadPoolExecutor的工厂构造方法
         
        ExecutorService executor = Executors.newFixedThreadPool(nThreads);
        
        //submit有返回值，而execute没有返回值，有返回值方便Exception的处理
        Future res = executor.submit(new ConsumerThread());
        //executor.execute(new ConsumerThread());
        
        /**
         * shutdown调用后，不可以再submit新的task，已经submit的将继续执行
         * shutdownNow试图停止当前正执行的task，并返回尚未执行的task的list
         
        executor.shutdown();
        
        //配合shutdown使用，shutdown之后等待所有的已提交线程运行完，或者到超时。继续执行后续代码
        executor.awaitTermination(1, TimeUnit.DAYS);
        
        //打印执行结果，出错的话会抛出异常，如果是调用execute执行线程那异常会直接抛出，不好控制，submit提交线程，调用res.get()时才会抛出异常，方便控制异常
        System.out.println("future result:"+res.get());
    }
    
    static class ConsumerThread implements Runnable{

        @Override
        public void run() {
            for(int i=0;i<5;i++) {
                System.out.println(i);
            }
        }
    }
}

*/
