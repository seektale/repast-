package root;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
public class Monitor extends JInternalFrame{
	private static final long serialVersionUID = 734411224454457668L;
	private JTabbedPane tab=new JTabbedPane();
	public Monitor(){
		super("实时监控",true,true,true,true);

		tab.add("通用日志监控",new Mon("syslog"));
	    tab.add("◇点单监控",new Mon("dish"));
	    tab.add("◇商品日志监控",new Mon("dishlog"));
	    tab.add("打印监控",new Mon("print_job"));
	    tab.add("聊天记录",new Mon("chat"));
		
		setContentPane(tab);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	}
	
	class Mon extends JPanel implements ActionListener,Runnable{
		private static final long serialVersionUID = 145345347L;
		private JCheckBox ch=new JCheckBox("启动监控");
		private JButton clear = new JButton("清屏");
		private JSpinner hz=new JSpinner(new SpinnerNumberModel(5,1,60,1));
		private JLabel lab=new JLabel("");
		private int ind=0;		//记录表中的最大索引值
		private Thread th;
		
		private String TableName="";
		private String colName="";		//第一列一般是索引，存储索引列名
		
		private JTable t=Sql.getTable();
		JTable temp=new JTable();
		DefaultTableModel mod1=(DefaultTableModel)t.getModel();
		DefaultTableModel mod2=(DefaultTableModel)temp.getModel();
		private Mon(String TableName){
			this.TableName=TableName;
			setLayout(new BorderLayout());
			
			ArrayList<String> col = Sql.getcolname(TableName, getClass().getName());
			if(col.size()>0)	colName=col.get(0);
			
			JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
			ch.addActionListener(this);
			clear.addActionListener(this);
			((JSpinner.NumberEditor)hz.getEditor()).getTextField().setEditable(false);
		    
			nor.add(ch);
			nor.add(hz);
			nor.add(lab);
			nor.add(new JLabel("     "));
			nor.add(clear);

			add(nor,BorderLayout.NORTH);
			add(new JScrollPane(t),BorderLayout.CENTER);
		}
		
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==clear){
				while(t.getRowCount()>0){
					mod1.removeRow(0);
				}
				return;
			}
			
			if(ch.isSelected()){
				if((th==null)||th.getState().toString().equals("TERMINATED")){
					th=new Thread(this);
					th.start();
				}
			}
		}

		public void run() {
			//首次运行读取当前最大索引值
			if(ind==0){
				String s[]=Sql.getString("select max("+colName+") from "+TableName, this);
				ind=Integer.valueOf(s[0]);
				//初始读取最近三条记录
				Sql.getArrayToTable("select * from "+TableName+" where "+colName+">"+(ind-3), this, t);
				Sql.TableAtt(t, true, false);
			}
			
			do{
				Sql.getArrayToTable("select * from "+TableName+" where "+colName+">"+ind, this, temp);
				if(temp.getRowCount()>0){
					//索引记录增加
					ind=ind+temp.getRowCount();
					newdata();
				}
				
				try {
					for(int k=0;k<Integer.valueOf(hz.getValue()+"");k++){
						lab.setText("下次刷新计时："+k+" / "+Integer.valueOf(hz.getValue()+""));
						Thread.sleep(1000);
					}
				}catch(InterruptedException e) {}
				
			//isShowing()		可以保证当用户关闭当前内部窗口或点击了别的选项卡时能结束进程
			//isDisplayable()	可以保证当用户关闭当前内部窗口时能结束进程
			}
			while(ch.isSelected() && isShowing());
			System.out.println("对表:"+TableName+" 的监听进程结束。");
			ch.setSelected(false);
		}
		
		//加入新数据
		private void newdata(){
			try {
				SwingUtilities.invokeAndWait(new Runnable() {
					@SuppressWarnings("unchecked")
					public void run() {
						//追加新查询到的数据行
						for(Object v : mod2.getDataVector()){
							mod1.addRow((Vector<Object>)v);
						}
						
						//将窗口滚动到最下面
						//JViewport js=(JViewport)t.getParent();
						//js.setViewPosition(new Point(0, Integer.MAX_VALUE));
						t.scrollRectToVisible(new Rectangle(0, t.getHeight(), 20, 20)); 
						Sql.TableAtt(t, true, false);
					}
				});
			} 
			catch (InvocationTargetException e) {
				e.printStackTrace();
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

