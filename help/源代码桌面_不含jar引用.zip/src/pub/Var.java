package pub;
//下面是常用到的变量，为防止反复读写数据库，在这里存储变量
//缺点是如果对某一常量要生效，其它用户需要重新登陆
import java.awt.Color;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;
import javax.swing.Icon;
import root.Sql;
import sidePanel.SouthPan;
public class Var {
	private static String area[];

	//已开台,未开台,脏台,预定,维修,停用,挂起,已结账,表格前色彩,表格后色彩,表格选中色彩
	//菜品方块前景,菜品方块背影,鼠标悬停色彩,一般菜品背景色彩,退菜背景色彩,换桌菜品背景色彩,删除菜品背景色彩,
	//共有18种定义的颜色
	public final static HashMap<String, Color> myColor=new HashMap<String, Color>();
	//缓存一些图片
	private final static HashMap<String, Icon> myIcon=new HashMap<String, Icon>();
	
	public static int deskw=0;			//餐台方块宽
	public static int deskh=0;			//餐台方块高
	public static int desk_hgap=0;		//餐台水平间距
	public static int desk_vgap=0;		//餐台垂直间距
	public static String desk_font;		//餐台文字字体
	public static int desk_textsize=0;	//餐台文字大小

	public static int dishw=0;			//菜品方块宽
	public static int dishh=0;			//菜品方块高
	public static int dish_hgap=0;		//菜品水平间距
	public static int dish_vgap=0;		//菜品垂直间距
	public static String dish_font=null;//菜品文字字体
	public static int dish_textsize=0;	//菜品文字大小
	
	public static int TableHeight=0;	//表格高度
	public static String dishcol;		//菜品表格列表可显示列
	
	//下面变量重新登陆后生效，没有提供即时生效方法
	private static String backdish_reson[]=null;	//退菜原因
	private static String market[]=null;			//市场码
	private static String menu_class[]=null;		//菜品分类
	private static String ar_class[]=null;			//AR账号类别
	private static String line_class[]=null;		//取号类别
	private static String dish_remark[]=null;		//点菜时提供的快捷备注
	private static String dish_unit[]=null;			//点菜时提供的快捷单位
	
	//打印时记录billpage表存储在这里
	public final static HashMap<String, ArrayList<String[]>> hprint=new HashMap<String, ArrayList<String[]>>();
	
	//避免频繁的调用同一个模板，故将查询过的模板存储起来,但如果修改模板参数，则需要重新登陆
	public final static ArrayList<String[]> billview(String templet){
		if(hprint.get(templet) == null){
			//查找所有参数,注意排序与存储过程bill_view中的要一致
			String sql = "select area,font_size,font_style,left_far,up_far,color,row_far,row_count,logo from billview " +
						 "where templet='"+templet+"' and used='Y' order by ind";
			hprint.put(templet, Sql.getArrayToArrary(sql, "Var.billview()"));
		}
		return hprint.get(templet) ;
	}
	
	//餐区， 当餐区发生变化时、当前客户端立即生效，其它客户端需要重新登陆,如果要刷新需要两步：area=null;area();
	public static String[] area(){
		return area(false);
	}
	public static String[] area(boolean b){
		if((area==null)||b){
			area=Sql.getString("select distinct 区域 from desk order by 前辍 asc","Var.area");
		}
		return area;
	}
	public static Color getColor(String who){
		if(who==null){
			SouthPan.warn("Var.myColor 传入的变量为null,该值不合法,系统自动使用黑色代替 Postion: Var-->myColor",false);
			return new Color(0);
		}
		Color c=myColor.get(who);
		if(c==null)	return co(who);
		else		return c;
	}
	//通过执行sql得到一个颜色对象
	private static Color co(String who){
		String s[]=Sql.getString("select value from general where name='color' and item='"+who+"';", "Var-->co");
		if(s.length==0){
			SouthPan.warn("未能查找到目标为:"+who+" 背景色值，系统自动使用白色代替。Postion: Var-->co",false);
			return new Color(255,255,255);
		}
		else{
			try{
				int val=Integer.valueOf(s[0]);
				myColor.put(who, new Color(val));
				return new Color(val);
			}catch (Exception e){
				SouthPan.warn("对目标背景色字符串值："+s[0]+" 转为数字时发生异常，系统自动使用黑色代替。Postion: Var-->co",false);
				return new Color(0);
			}
		}
	}
	
	/*******************************************************************/
	//方块餐台属性调用以下四个方法
	public static int deskw(){
		if(deskw==0){
			deskw=getnum("select value from general where name='desk' and item='width';");
			if(deskw==0){
				SouthPan.warn("方块餐台宽度从数据库更新失败，将使用默认值140，Postion: Var-->deskw",false);
				deskw=140;
			}
		}	
		return deskw;
	}
	public static int deskh(){
		if(deskh==0){
			deskh=getnum("select value from general where name='desk' and item='height';");
			if(deskh==0){
				SouthPan.warn("方块餐台高度从数据库更新失败，将使用默认值80，Postion: Var-->deskh",false);
				deskh=80;
			}
		}	
		return deskh;
	}
	public static int deskhgap(){
		if(desk_hgap==0){
			desk_hgap=getnum("select value from general where name='desk' and item='hgap';");
			if(desk_hgap==0){
				SouthPan.warn("方块餐台水平间距从数据库更新失败，将使用默认值15，Postion: Var-->deskhgap",false);
				desk_hgap=15;
			}
		}	
		return desk_hgap;
	}
	public static int deskvgap(){
		if(desk_vgap==0){
			desk_vgap=getnum("select value from general where name='desk' and item='vgap';");
			if(desk_vgap==0){
				SouthPan.warn("方块餐台垂直间距从数据库更新失败，将使用默认值15，Postion: Var-->deskvgap",false);
				desk_vgap=15;
			}
		}	
		return desk_vgap;
	}
	public static String deskfont(){
		if(desk_font==null)	desk_font=getstr("select value from general where name='desk' and item='font';");
		return desk_font;
	}
	public static int desktextsize(){
		if(desk_textsize==0){
			desk_textsize=getnum("select value from general where name='desk' and item='textsize';");
			if(desk_textsize==0){
				SouthPan.warn("方块内文字大小更新后仍为0，将使用默认值20，Postion: Var-->desktextsize",false);
				desk_textsize=20;
			}
		}
		return desk_textsize;
	}
	/***********************************************************************************/
	//方块菜品属性调用以下六个方法
	public static int dishw(){
		if(dishw==0){
			dishw=getnum("select value from general where name='dish' and item='width';");
			if(dishw==0){
				SouthPan.warn("方块菜品宽度从数据库更新失败，将使用默认值400，Postion: Var-->dishw",false);
				dishw=400;
			}
		}	
		return dishw;
	}
	public static int dishh(){
		if(dishh==0){
			dishh=getnum("select value from general where name='dish' and item='height';");
			if(dishh==0){
				SouthPan.warn("方块菜品高度从数据库更新失败，将使用默认值80，Postion: Var-->dishh",false);
				dishh=80;
			}
		}	
		return dishh;
	}
	public static int dishhgap(){
		if(dish_hgap==0){
			dish_hgap=getnum("select value from general where name='dish' and item='hgap';");
			if(dish_hgap==0){
				SouthPan.warn("方块菜品水平间距从数据库更新失败，将使用默认值15，Postion: Var-->dishhgap",false);
				dish_hgap=15;
			}
		}	
		return dish_hgap;
	}
	public static int dishvgap(){
		if(dish_vgap==0){
			dish_vgap=getnum("select value from general where name='dish' and item='vgap';");
			if(dish_vgap==0){
				SouthPan.warn("方块菜品垂直间距从数据库更新失败，将使用默认值15，Postion: Var-->dishvgap",false);
				dish_vgap=15;
			}
		}	
		return dish_vgap;
	}
	public static String dishfont(){
		if(dish_font==null)	dish_font=getstr("select value from general where name='dish' and item='font';");
		return dish_font;
	}
	public static int dishtextsize(){
		if(dish_textsize==0){
			dish_textsize=getnum("select value from general where name='dish' and item='textsize';");
			if(dish_textsize==0){
				SouthPan.warn("方块内文字大小更新后仍为0，将使用默认值16，Postion: Var-->dishtextsize",false);
				dish_textsize=16;
			}
		}
		return dish_textsize;
	}
	/***********************************************************************************/
	public static int getTableHeight(){
		if(TableHeight==0)
			TableHeight=getnum("select value from general where name='system' and item='tableheight';");
		if(TableHeight<=0){
			SouthPan.warn("表格高度值:"+TableHeight+" 不实际，系统使用20来代替，Postion: Var-->getTableHeight",false);
			TableHeight=20;
		}
		return TableHeight;
	}
	public static int getTableHeight(boolean b){	//强行更新
		TableHeight=getnum("select value from general where name='system' and item='tableheight';");
		return TableHeight;
	}
	public static String getDishCol(){
		if(dishcol==null)	dishcol=getstr("select value from general where name='system' and item='dishcol';");
		return dishcol;
	}
	//通过执行sql得到一个数字
	private static int getnum(String sql){
		String s[]=Sql.getString(sql, "Var-->getnum");
		if(s.length==0){
			SouthPan.warn(sql+" 没有返回结果任何结果，将使用默认值0，Postion: Var-->getnum",false);
			return 0;
		}
		else{
			try{
				int k=Integer.valueOf(s[0]);
				return k;
			}catch (Exception e){
				SouthPan.warn(s[0]+" 转为数字时发生异常，系统自动使用0代替。Postion: Var-->getnum",false);
				return 0;
			}
		}
	}
	//通过执行sql得到一个字符串
	private static String getstr(String sql){
		String s[]=Sql.getString(sql, "Var-->getstr");
		if(s.length==0){
			SouthPan.warn(sql+" 没有返回结果任何结果，将使用默认值空字符串，Postion: Var-->getval",false);
			return "";
		}
		else return s[0];
	}
	
	public static String[] getbackdish_reson(){
		if(backdish_reson==null)	
			backdish_reson=Sql.getString("select value from general where name='退回商品原因'", "Var.getbackdish_reson");
		return backdish_reson;
	}
	public static String[] getMarket(){
		if(market==null)	
			market=Sql.getString("select value from general where name='市场码'", "Var.getMarket()");//市场码
		return market;
	}
	public static String[] getAR_class(){
		if(ar_class==null)	
			ar_class=Sql.getString("select value from general where name='ar'", "Var.getAR_class()");//AR账号类别
		return ar_class;
	}
	public static String[] getLine_class(){
		if(line_class==null)	
			line_class=Sql.getString("select value from general where name='lineup'", "Var.getLine_class()");
		return line_class;
	}
	public static String[] getMenu_class(){
		return getMenu_class(false);
	}
	public static String[] getMenu_class(boolean b){
		if((menu_class==null)||b){
			menu_class=Sql.getString("select distinct 分类 from menu;","Var.getMenu_class");	//商品大类
		}
		return menu_class;
	}
	public static String[] getDish_remark(){
		if(dish_remark==null)	
			dish_remark=Sql.getString("select value from general where name='商品备注';", "Var.getDish_remark");
		return dish_remark;
	}
	public static String[] getDish_unit(){
		if(dish_unit==null)	
			dish_unit=Sql.getString("select distinct 单位 from menu", "Var.getDish_unit");
		return dish_unit;
	}

	//该方法的作用是缓存图片，这样可以避免反复读取数据库，仅供系统图片读取时调用
	public static Icon getIcon(String name){
		Icon c=myIcon.get(name);
		if(c==null){
			c=Photo.readIcon(name);
			if(c!=null)	myIcon.put(name, c);
		}
		return c;
	}
	
	//pc信息
	public static Vector<String> getpc(){
		
    	final Vector<String> v=new Vector<String>();
    	final Map<String,String> map = System.getenv();  
        v.add("计算机用户名:"+map.get("USERNAME"));
        v.add("\n计算机名称:"+map.get("COMPUTERNAME"));
        v.add("\n计算机域名:"+map.get("USERDOMAIN"));
        
        Properties props=System.getProperties();
        v.add("\n\n操作系统名："+props.getProperty("os.name"));
        v.add("\n操作系统构架："+props.getProperty("os.arch"));
        v.add("\n操作系统版本："+props.getProperty("os.version"));
        v.add("\n文件分隔符："+props.getProperty("file.separator"));
        v.add("\n用户主目录："+props.getProperty("user.home"));
        try {
			v.add("\n用户当前工作目录："+java.net.URLDecoder.decode(props.getProperty("user.dir"), "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
        
        // System.getProperty("java.version")
        try {
			v.add("\n\nJDK或JRE目录："+java.net.URLDecoder.decode(props.getProperty("java.home"), "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
        v.add("\nJDK或JRE版本："+props.getProperty("java.version"));
        v.add("\nJDK或JRE字节位："+props.getProperty("os.arch"));
        
        return v;
    }
}
