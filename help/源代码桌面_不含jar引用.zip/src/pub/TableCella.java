package pub;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

//彩色表格
public class TableCella extends DefaultTableCellRenderer{
	private static final long serialVersionUID = 3887950977759767191L;
	private final DefaultTableCellRenderer DEFAULT_RENDERER = new DefaultTableCellRenderer();
	public Component getTableCellRendererComponent(JTable table, Object value,boolean isSelected, boolean hasFocus, int row, int column){
		Component renderer = DEFAULT_RENDERER.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		Color foreground=null, background=null;
		if (isSelected) {
			foreground = Color.DARK_GRAY;
			background = Var.getColor("表格选中色彩");
		} 
		else {
			if (row % 2 == 0) {
				foreground = Color.DARK_GRAY;
				background = Var.getColor("表格前色彩");
			} else {
				foreground = Color.DARK_GRAY;
				background = Var.getColor("表格后色彩");
			}
		}
		renderer.setForeground(foreground);
		renderer.setBackground(background);
		
		//其实renderer就是一个JLabel
		//((JLabel)renderer).setHorizontalAlignment(SwingConstants.RIGHT);
		
		return renderer;
	}
}
