package pub;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import javax.imageio.ImageIO;
import com.google.zxing.common.BitMatrix;
public class MatrixToImageWriter {
	private int BLACK = 0xFF000000;
	private int WHITE = 0xEEEEEEEE;	//使用近似白色是为了方便黑白打印
	//private int WHITE = Color.PINK.getRGB();
	public MatrixToImageWriter() {}
	public BufferedImage toBufferedImage(BitMatrix matrix, String text) {
		int width = matrix.getWidth();
		int height = matrix.getHeight();
		BufferedImage image = new BufferedImage(width, height,BufferedImage.TYPE_INT_RGB);
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				image.setRGB(x, y, matrix.get(x, y) ? BLACK : WHITE);
			}
		}
		
		//写入文字描述
		if(!text.isEmpty() && text.contains("#")){
			String val[] = text.split("#");
			Graphics g = image.getGraphics();
			g.setColor(Color.BLACK);
			g.drawString("编号: "+val[0], 26, 20);
	 		g.drawString(val[1], 26, 188);
		}

		return image;
	}
	
	//没用上
	public void writeToFile(BitMatrix matrix, String format, File file) throws IOException {
		BufferedImage image = toBufferedImage(matrix,"");
		if (!ImageIO.write(image, format, file)) {
			throw new IOException("Could not write an image of format "+ format + " to " + file);
		}
	}
	//没用上
	public void writeToStream(BitMatrix matrix, String format,OutputStream stream) throws IOException {
		BufferedImage image = toBufferedImage(matrix,"");
		if (!ImageIO.write(image, format, stream)) {
			throw new IOException("Could not write an image of format "+ format);
		}
	}
}