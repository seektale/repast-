package pub;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Calendar;
import java.util.HashMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/************************************
阴历及节日程序 2008 beta1
免费软件(Free Software) 你可以无限传播与反编译
该日历有三种外观样式,有从1900年至2049年间的所有阴历
个人爱好开发  作者:朱春 Email:npuxbd@163.com
Copyright @ 2008- All Rights Reserved
FileName:Simple_Calendar
************************************/
public class Mycal extends JPanel implements ActionListener {
	private static final long serialVersionUID = 314745763301600268L;
	private JLabel datas[][] = new JLabel[6][7];// 显示一个月的日期
	private JLabel label = null;
	private JPanel panel_Header, panel_Week, panel_Calendar;
	private Calendar calendar = null;
	private JComboBox<String> year_box = null;
	private JComboBox<String> month_box = null;
	private JButton isnow=new JButton("今天");
	private int today;
	private JLabel msg = new JLabel();
	public Mycal() {
		setLayout(new BorderLayout());
		setOpaque(false);
		
		calendar = Calendar.getInstance();
		today = calendar.get(Calendar.DAY_OF_MONTH);
		
		panel_Header = initializtion_Header();
		panel_Header.setOpaque(false);
		panel_Week = initializtion_Week();
		panel_Calendar = initializtion_Calendar();
		panel_Calendar.setOpaque(false);

		JPanel te=new JPanel();
		te.setLayout(null);
		te.setOpaque(false);
		te.add(panel_Week);
		panel_Week.setBounds(5, 5, 620, 30);
		te.add(panel_Calendar);
		panel_Calendar.setBounds(5, 35, 620, 300);

		initializtion_Data(calendar);
		
		add("Center",te);
		add("North",panel_Header);
	}

	private JPanel initializtion_Header() {	//显示表头的panel
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT,12,0));
		
		year_box = new JComboBox<String>();
		month_box = new JComboBox<String>();

		JLabel year_l = new JLabel("请您选择年份: ", JLabel.RIGHT);
		JLabel month_l = new JLabel("月份: ", JLabel.RIGHT);

		for (int i = 1900; i < 2050; i++)
			year_box.addItem("" + i);
		for (int j = 1; j <= 12; j++)
			month_box.addItem("" + j);
		
		year_box.setSelectedIndex(calendar.get(Calendar.YEAR) - 1900);
		month_box.setSelectedIndex(calendar.get(Calendar.MONTH));
		panel.add(year_l);
		panel.add(year_box);
		panel.add(month_l);
		panel.add(month_box);
		panel.add(isnow);
		panel.add(msg);
		Lunar lun=new Lunar(calendar);
		msg.setText(lun.cyclical()+"年 "+lun.animalsYear());

		year_box.addActionListener(this);
		month_box.addActionListener(this);
		isnow.addActionListener(this);
		return panel;
	}

	private JPanel initializtion_Week() {// 显示星期的panel
		JPanel panel = new JPanel();
		panel.setOpaque(false);
		panel.setLayout(new GridLayout(1, 7));
		String columnNames[] = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五","星期六" };
		JLabel label = null;
		for (int i = 0; i < 7; i++) {
			label = new JLabel(columnNames[i], JLabel.CENTER);
			if (i == 0 || i == 6)	label.setForeground(Color.RED);
			label.setBorder(new LineBorder(Color.BLUE));
			panel.add(label);
		}
		return panel;
	}

	private JPanel initializtion_Calendar() {// 显示日期的panel
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(6, 7));
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				label = new JLabel("", JLabel.CENTER);
				datas[i][j] = label;
				label.setBorder(new LineBorder(Color.BLUE));
				//if (j == 0 || j == 6)	label.setForeground(Color.RED);
				datas[i][j].addMouseListener(new List_MouseListener());
				panel.add(label);
			}
		}
		return panel;
	}

	public void clear_Data() {// 清空内容的
		for (int i = 0; i < 6; i++)
			for (int j = 0; j < 7; j++) {
				datas[i][j].setText("");
				if (j == 0 || j == 6)
					datas[i][j].setForeground(Color.RED);
				else
					datas[i][j].setForeground(null);
			}
	}

	public void initializtion_Data(Calendar calendar) {// 初始化函数
		/*
		 * 节日和纪念日 格式：起始年(yyyy)+月(mm)+日(dd)
		 * 
		 * 0000表示起始年不明
		 */
		HashMap<String, String> sFestival = new HashMap<String, String>();
		// String []sFestival_={
		sFestival.put("0101", "  元旦");
		sFestival.put("0214", "情人节");
		sFestival.put("0308", "妇女节");
		sFestival.put("0312", "植树节");
		sFestival.put("0401", "愚人节");
		sFestival.put("0501", "劳动节");
		sFestival.put("0504", "青年节");
		sFestival.put("0601", "儿童节");
		sFestival.put("0701", "建党节");
		sFestival.put("0801", "建军节");
		sFestival.put("0910", "教师节");
		sFestival.put("1001", "国庆节");
		sFestival.put("1031", "万圣节");
		sFestival.put("1112", "孙中山诞辰");
		sFestival.put("1225", "圣诞节");
		sFestival.put("1226", "毛泽东诞辰");
		// };
		// 某月第几个星期几
		// 起始年(4位)+月(2位)+第几个(1位)+星期几(1位)
		HashMap<String, String> wFestival = new HashMap<String, String>();
		// String []wFestival={
		wFestival.put("0520", "母亲节");
		wFestival.put("0630", "父亲节");
		wFestival.put("1144", "感恩节");
		// };
		// 农历 99表示月最后一天
		HashMap<String, String> lFestival = new HashMap<String, String>();
		// String []lFestival={
		lFestival.put("0101", "春 节");
		lFestival.put("0102", "大年初二");
		lFestival.put("0103", "大年初三");
		lFestival.put("0115", "元宵节");
		lFestival.put("0505", "端午节");
		lFestival.put("0707", "七 夕");
		lFestival.put("0815", "中秋节");
		lFestival.put("0909", "重阳节");
		lFestival.put("1208", "腊八节");
		lFestival.put("1299", "除 夕");
		// };

		// //////////////////////////////////////////////////
		this.calendar = calendar;
		today = calendar.get(Calendar.DAY_OF_MONTH);
		int month = calendar.get(Calendar.MONTH);
		int weekindexDay;
		int weekindexMonth;

		calendar.set(Calendar.DATE, 1);

		while (calendar.get(Calendar.MONTH) == month) {
			weekindexMonth = calendar.get(Calendar.WEEK_OF_MONTH) - 1;
			weekindexDay = calendar.get(Calendar.DAY_OF_WEEK) - 1;
			int day = calendar.get(Calendar.DAY_OF_MONTH);
			// /////////////////////////////////////////////
			String today_, month_;
			today_ = day < 10 ? "0" + day : "" + day;
			month_ = month < 10 ? "0" + (month + 1) : "" + (month + 1);
			Lunar lunar = new Lunar(calendar);
			String lunar_ = lunar.toString();
			// /////////////////////////////////////////
			if (null != sFestival.get(month_ + today_))
				lunar_ = "<font color=red>" + sFestival.get(month_ + today_);
			// /////
			String wFestival_ = month_ + (weekindexMonth) + (weekindexDay);

			if (null != wFestival.get(wFestival_)) {
				lunar_ = "<font color=red>" + wFestival.get(wFestival_);
				//System.out.println(wFestival_);
			}

			if (null != lFestival.get(lunar.numeric_md()))
				lunar_ = "<font color=red>" + lFestival.get(lunar.numeric_md());

			// 计算除夕
			Calendar temp_calendar = Calendar.getInstance();
			temp_calendar.set(calendar.get(Calendar.YEAR), month, day + 1);

			// temp_calendar.add(Calendar.DAY_OF_MONTH,1);
			Lunar temp_lunar = new Lunar(temp_calendar);
			String temp_str = temp_lunar.numeric_md();
			if (temp_str.equals("0101"))
				lunar_ = "<font color=red>" + lFestival.get("1299");
			// /计算除夕结束
			// ////////////////////////////////////////
			String day_str;
			if (day < 10)
				day_str = "<html><center><font size=4>" + today_;
			else
				day_str = "<html><center><font size=4>" + today_;
			
			//自己加上去的，用于将字体变小
			if(lunar_.startsWith("<font color=red>"))
				lunar_=lunar_.replace("<font color=red>","<font color=red size=3>");
			else
				lunar_="<font size=3>"+lunar_;
			
			day_str += "</font><br>" + lunar_;

			datas[weekindexMonth][weekindexDay].setFont(new Font("",Font.PLAIN,16));
			if (day == today){
				datas[weekindexMonth][weekindexDay].setForeground(Color.MAGENTA);
				datas[weekindexMonth][weekindexDay].setFont(new Font("",Font.BOLD,16));
			}
			datas[weekindexMonth][weekindexDay].setText(day_str);
			calendar.add(Calendar.DATE, 1);
		}
	}

	public void actionPerformed(ActionEvent e) {	//日期和年份的选择更新
		if(e.getSource()==isnow){
			calendar = Calendar.getInstance();
			year_box.removeActionListener(this);
			month_box.removeActionListener(this);
			year_box.setSelectedIndex(calendar.get(Calendar.YEAR) - 1900);
			month_box.setSelectedIndex(calendar.get(Calendar.MONTH));
			year_box.addActionListener(this);
			month_box.addActionListener(this);
		}
		else{
			int year  = Integer.parseInt(year_box. getSelectedItem().toString());
			int month = Integer.parseInt(month_box.getSelectedItem().toString()) - 1;
			
			calendar.set(year, month, 1);
			//注意，如果今天是1月30号，当改变月份为2月时，由于2月没有30号，所以日期会变为2号或者出错
			//取得当月最后一天
			int lastDate = calendar.getActualMaximum(Calendar.DATE);
			if(today<=lastDate){
				calendar.set(Calendar.DAY_OF_MONTH, today);	//还原
			}
			
			Lunar lun=new Lunar(calendar);
			msg.setText(lun.cyclical()+"年 "+lun.animalsYear());
		}
		
		clear_Data();
		initializtion_Data(calendar);
	}

	/*
	 * 内部类
	 * */
	class List_MouseListener implements MouseListener {// 鼠标移入时显示的信息
		JLabel labe = null;
		String weeks[] = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };

		public String constellation(Calendar cal) {
			String[][] con = { { "水瓶座", "0122", "0221" },
					{ "双鱼座", "0222", "0321" }, { "白羊座", "0322", "0420" },
					{ "金牛座", "0421", "0521" }, { "双子座", "0522", "0621" },
					{ "巨蟹座", "0621", "0721" }, { "狮子座", "0722", "0821" },
					{ "处女座", "0822", "0921" }, { "天秤座", "0922", "1021" },
					{ "天蝎座", "1022", "1121" }, { "射手座", "1122", "1221" },
					{ "摩羯座", "1222", "0121" } };
			int month = cal.get(Calendar.MONTH) + 1;
			int today = cal.get(Calendar.DAY_OF_MONTH);
			String month_str = month < 10 ? "0" + month : "" + month;
			String today_str = today < 10 ? "0" + today : "" + today;
			String str = month_str + today_str;
			for (int i = 0; i < con.length - 1; i++) {
				if (Integer.parseInt(str) >= Integer.parseInt(con[i][1])&& Integer.parseInt(str) <= Integer.parseInt(con[i][2]))
					return con[i][0];
			}
			if ((Integer.parseInt(str) >= Integer.parseInt(con[11][1]) && Integer.parseInt(str) < 1232)|| Integer.parseInt(str) <= Integer.parseInt(con[11][2]))
				return con[11][0];
			return "error!";
		}
		
		public void mouseClicked(MouseEvent e) {}
		public void mouseEntered(MouseEvent e) {// 鼠标进入到组件上时调用。
			labe = (JLabel) e.getSource();
			String lab = labe.getText();
			if (!lab.isEmpty()) {
				labe.setBackground(Color.red);
				String day = lab.substring(lab.indexOf("size=4>") + 7,
						lab.indexOf("</font>"));
				// String lun=lab.substring(lab.indexOf("<br>")+4);
				String message = "<html><body><center>公元 "
						+ year_box.getSelectedItem() + "年"
						+ month_box.getSelectedItem() + "月"
						+ Integer.parseInt(day) + "日";
				calendar.set(Integer.parseInt(year_box.getSelectedItem()
						.toString()), Integer.parseInt(month_box
						.getSelectedItem().toString()) - 1, Integer
						.parseInt(day));
				Lunar lunar = new Lunar(calendar);
				message += "<br><font color=red>"
						+ weeks[(calendar.get(Calendar.DAY_OF_WEEK) - 1)];
				message += "&nbsp;&nbsp;&nbsp;&nbsp;" + constellation(calendar)
						+ "</font><br>农历 ";
				message += lunar.get_month() + "月" + lunar.get_Big_Or_Small()
						+ "&nbsp;&nbsp;&nbsp;&nbsp;" + lunar.get_date() + "日";
				// message+=lunar.get_JQ();
				labe.setToolTipText(message);
				labe.setBackground(Color.pink);
				labe.setOpaque(true);
			}

		}
		public void mouseExited(MouseEvent e) {// 鼠标离开组件时调用。
			labe.setBackground(null);
			labe.setOpaque(false);
		}
		public void mousePressed(MouseEvent e) {}
		public void mouseReleased(MouseEvent e) {}
	}
}


/*以后研究
class SwingConsole {// 提供安全线程机制
	public static void run(final JFrame f, final int width, final int height) {
		SwingUtilities.invokeLater(new Runnable(){
			public void run() {
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f.setSize(width, height);
				f.setVisible(true);
			}
		});
	}
}
*/