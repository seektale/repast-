package pub;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Pattern;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableModel;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import root.Front;
import root.Sql;

//用于表格的导出
public class Popup_tab extends JPopupMenu implements ActionListener{
	private static final long serialVersionUID = -182596445400196L;
	private JTable t;
	private JMenuItem a = new JMenuItem("导出");
	private JMenuItem aa = new JMenuItem("导出(数字转文本)");
	private JMenuItem b = new JMenuItem("行高",Var.getIcon("菜单选择"));
	private JMenuItem c = new JMenuItem("色彩");
	private JMenuItem d = new JMenuItem("打印(建议先取消色彩)");
	private JMenuItem e = new JMenuItem("字体");
	private JMenuItem f = new JMenuItem("取消选中行");
	private JMenuItem g = new JMenuItem("展示当前单元格");
	private JMenuItem h = new JMenuItem("平均列宽");
	private JMenuItem i = new JMenuItem("最大列宽");
	public Popup_tab(JTable t){
		this.t=t;
		a.addActionListener(this);
		aa.addActionListener(this);
		b.addActionListener(this);
		c.addActionListener(this);
		d.addActionListener(this);
		e.addActionListener(this);
		f.addActionListener(this);
		g.addActionListener(this);
		h.addActionListener(this);
		i.addActionListener(this);
		
		b.setHorizontalTextPosition(SwingConstants.RIGHT);
		//快捷键
		//d.setAccelerator( KeyStroke.getKeyStroke('P', java.awt.Event.CTRL_MASK, false) );
		
		add(a);
		add(aa);
		addSeparator();
		add(g);
		add(h);
		add(i);
		addSeparator();
		add(b);
		add(c);
		add(e);
		addSeparator();
		add(d);
		add(f);
	}
	public JMenu getMenu(){
		JMenu m=new JMenu("其它");
		m.add(a);
		m.add(aa);
		m.addSeparator();
		m.add(g);
		m.add(h);
		m.add(i);
		m.addSeparator();
		m.add(b);
		m.add(c);
		m.add(e);
		m.addSeparator();
		m.add(d);
		m.add(f);
		return m;
	}
	public void actionPerformed(ActionEvent es) {
		if(es.getSource()==a){
			myxls(t, true) ;
		}
		if(es.getSource()==aa){
			myxls(t, false) ;
		}
		else if(es.getSource()==b){
			final JSpinner pin=new JSpinner(new SpinnerNumberModel(20,1,100,1));
			pin.setValue(t.getRowHeight());
			pin.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					t.setRowHeight(Integer.valueOf(pin.getValue().toString()));
				}
			});
			JOptionPane.showMessageDialog(Front.front, pin,"表格行高度",0,new ImageIcon());
		}
		else if(es.getSource()==c){
			if(c.getIcon()==null){
				c.setIcon(Var.getIcon("菜单选择"));
				t.setDefaultRenderer(Object.class, new TableCella());
				t.repaint();
			}
			else{
				c.setIcon(null);
				t.setDefaultRenderer(Object.class, new TableCell());
				t.repaint();
			}
		}
		else if(es.getSource()==d){
			try {
                t.print();
			} catch (java.awt.print.PrinterException er) {
				er.printStackTrace();
			}
		}
		else if(es.getSource()==f){
			//取消对行选中状态
			t.removeRowSelectionInterval(0, t.getRowCount()-1); 
		}
		else if(es.getSource()==g){
			int m = t.getSelectedRow();
			int n = t.getSelectedColumn();
			if(m<0 || n<0) return ;
			JOptionPane.showMessageDialog(Front.front, t.getValueAt(m, n).toString(),"当前选中单元格内容明细",1,new ImageIcon());
		}
		else if(es.getSource()==h){
			Sql.TableAtt(t, false, false);
		}
		else if(es.getSource()==i){
			Sql.TableAtt(t, true, false);
		}
		else if(es.getSource()==e){
			JPanel pan=new JPanel();
			pan.setLayout(new BoxLayout(pan, BoxLayout.PAGE_AXIS));	//一行一行的布局
			final JSpinner pin=new JSpinner(new SpinnerNumberModel(20,1,100,1));
			GraphicsEnvironment g = GraphicsEnvironment.getLocalGraphicsEnvironment();
			String fontName[] = g.getAvailableFontFamilyNames();
			final JComboBox<String> ch=new JComboBox<String>(fontName);
			final JCheckBox box1=new JCheckBox("粗体");
			final JCheckBox box2=new JCheckBox("斜体");
			
			//初始化参数
			Font font=t.getFont();
			pin.setValue(font.getSize());
			ch.setSelectedItem(font.getFamily());
			
			pin.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					Font font=t.getFont();
					//System.out.println(font.getFamily());
					//System.out.println(font.getFontName());
					t.setFont(new Font(font.getFontName(), font.getStyle(), Integer.valueOf(pin.getValue().toString())));
				}
			});
			
			box1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Font font=t.getFont();
					if(box1.isSelected()){
						t.setFont(new Font(font.getFontName(),Font.BOLD, font.getSize()));
					}
					else{
						t.setFont(new Font(font.getFontName(),Font.PLAIN, font.getSize()));
					}
				}
			});
			
			box2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Font font=t.getFont();
					if(box2.isSelected()){
						t.setFont(new Font(font.getFontName(),Font.ITALIC, font.getSize()));
					}
					else{
						t.setFont(new Font(font.getFontName(),Font.PLAIN, font.getSize()));
					}
				}
			});
			
			ch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Font font=t.getFont();
					t.setFont(new Font(ch.getSelectedItem().toString(),font.getStyle(), font.getSize()));
				}
			});
		    
			JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT,8,1));
		    temp.add(new JLabel("字符大小："));
		    temp.add(pin);
		    pan.add(temp);
		    pan.add(Box.createVerticalStrut((10)));
		    
		    temp=new JPanel(new FlowLayout(FlowLayout.LEFT,8,1));
		    temp.add(new JLabel("字体样式："));
		    temp.add(ch);
		    pan.add(temp);
		    pan.add(Box.createVerticalStrut((12)));
		    
		    temp=new JPanel(new FlowLayout(FlowLayout.LEFT,8,1));
		    temp.add(new JLabel("字体风格："));
		    temp.add(box1);
		    temp.add(box2);
		    pan.add(temp);
		    
		    pan.add(new JSeparator());	//分割线
		    
			JOptionPane.showMessageDialog(Front.front, pan,"",0,new ImageIcon());
		}
	}
	
	//将表格导出为xls文件，需要引入poi-3.11.jar文件
	public static void myxls(JTable t, boolean tag) {
		//默认选择当前用户桌面
		SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");
    	Properties props=System.getProperties();
    	String sel=props.getProperty("user.home")+"\\desktop\\table"+sd.format(new Date())+".xls";
    	
		//选择目录  
		JFileChooser chooser = new JFileChooser();  
		chooser.setSelectedFile(new File(sel));
		int result = chooser.showSaveDialog(null);
		
		//导出到excel
		if (result != JFileChooser.APPROVE_OPTION) {
			return ;
		}
		String filePath = chooser.getSelectedFile().getPath();
		
		//第一步，创建一个webbook，对应一个Excel文件
		HSSFWorkbook wb = new HSSFWorkbook();
		//第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
		HSSFSheet sheet = wb.createSheet("smosu_xls_one");
		//第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制short
		HSSFRow row = sheet.createRow((int)0);
		//第四步，创建单元格，并设置值表头  设置表头居中
		HSSFCellStyle style = wb.createCellStyle();
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER); //创建一个居中格式

		//表列名
		TableModel model = t.getModel();
		DefaultTableColumnModel dcm = (DefaultTableColumnModel)t.getColumnModel(); // 获取列模型
		for (int i = 0; i < model.getColumnCount(); i++) {
			sheet.setColumnWidth(i, dcm.getColumn(i).getWidth()*38);	//百度说是*256,但这个数太大
			HSSFCell cell = row.createCell(i);
			cell.setCellValue(model.getColumnName(i)); 
			cell.setCellStyle(style);
		}
		
		//第五步，写入实体数据 实际应用中这些数据从数据库得到，
		for(int m=0; m<t.getRowCount(); m++){
			row = sheet.createRow(m+1);
			for(int n=0; n<t.getColumnCount(); n++){
				//第四步，创建单元格，并设置值
				HSSFCell cell = row.createCell(n);
				String v = t.getValueAt(m, n).toString() ;
				cell.setCellValue(v);
				
				if(tag && isnum(v)){
					cell.setCellValue(Double.valueOf(v));
				}
				
				//cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC); //数字型
				//cell.setCellValue(12.22);
			}
		}
		
		//第六步，将文件存到指定位置
		try {
			FileOutputStream fout = new FileOutputStream(filePath);
			wb.write(fout);
			fout.close();
			JOptionPane.showMessageDialog(Front.front, "恭喜，表格导出成功");
		}
		catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(Front.front, "表格导出失败，无法保存到指定目录\n"+e.getMessage());
		}
	}
	
	/*
	  * 判断是否为整数 
	  * @param str 传入的字符串 
	  * @return 是整数返回true,否则返回false 
	*/
	public static boolean isnum(String str) {
		if(str.isEmpty()) return false;
	    Pattern pattern = Pattern.compile("^(-?\\d+)(\\.\\d+)?$") ;
	    return pattern.matcher(str).matches();  
	}
	
}


