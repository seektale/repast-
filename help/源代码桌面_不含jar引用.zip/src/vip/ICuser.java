package vip;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import log.AdvSelect;
import root.Front;
import root.Sql;
public class ICuser extends JPanel implements ActionListener{
	private static final long serialVersionUID = -3434232323889928203L;
	private JButton sel = new JButton("查询在用IC");
	private JButton adv=new JButton("高级查询");
	private JButton lost = new JButton("挂失");
	private JButton lost_cancel = new JButton("撤消挂失");
	private JTextField text = new JTextField("",15);
	private JTable west = Sql.getTable();
	public ICuser(){
		setLayout(new BorderLayout());
		JPanel fuc = new JPanel(new FlowLayout(FlowLayout.LEFT));
		fuc.setBackground(Color.LIGHT_GRAY);
		fuc.add(sel);
		fuc.add(adv);
		fuc.add(new JLabel(" ○○ "));
		fuc.add(lost);
		fuc.add(lost_cancel);
		fuc.add(new JLabel("   模糊查询："));
		fuc.add(text);
		
		sel.addActionListener(this);
		lost.addActionListener(this);
		lost_cancel.addActionListener(this);
		
		adv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AdvSelect("cardlist", west);
			}
		});
		
		text.getDocument().addDocumentListener(new DocumentListener() {
			public void removeUpdate(DocumentEvent e) {
				insertUpdate(e);
			}
			public void insertUpdate(DocumentEvent e) {
				String s = text.getText().trim() ;
				s = s.replace("'", "");
				if(s.trim().isEmpty()) return ;
				
				s = "ind like '%"+s+"%' or cardid like '%"+s+"%' or cardno like '%"+s+"%' or guest like '%"+s+"%' or phone like '%"+s+"%'";
				Sql.getArrayToTable("select * from cardlist where "+s+" limit 0,300", ICuser.this, west);
				Sql.TableAtt(west, true, false);
			}
			public void changedUpdate(DocumentEvent e) {}
		});
		
		add(fuc, BorderLayout.NORTH);
		add(new JScrollPane(west), BorderLayout.CENTER);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==sel){
			Sql.getArrayToTable("select * from cardlist limit 0,300", this, west);
			Sql.TableAtt(west, true, false);
			
			return ;
		}
		
		int row = west.getSelectedRow() ;
		if(row<0){
			JOptionPane.showMessageDialog(Front.front, "没有选择表格中的数据行", "消息", 2);
			return ;
		}
		ArrayList<String> v=new ArrayList<String>();
		v.add(west.getValueAt(row, 1).toString());
		if(e.getSource()==lost){
			v.add("Y");
			Sql.mysqlprocedure("card_lost", v);
			return ;
		}
		if(e.getSource()==lost_cancel){
			v.add("N");
			Sql.mysqlprocedure("card_lost", v);
			return ;
		}
	}
}
