package vip;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import pub.ConfigFile;
import pub.Photo;
import root.Front;
import root.Sql;
public class ICissue extends JPanel implements ActionListener{
	private static final long serialVersionUID = 4573835253340333399L;
	private JTextField cardval[] = new JTextField[3];
	private JTextField cv[] = new JTextField[14];
	private JButton go = new JButton("启用/发行 F");
	private JButton a = new JButton("查询 S");
	private JButton b = new JButton("设备复位");
	private JButton c = new JButton("退卡 B");
	private JButton d = new JButton("设置密码");
	private JButton e = new JButton("保存姓名/电话");
	private JButton log = new JButton("卡片日志");
	
	private JButton charge = new JButton("充值 M");
	private JButton deposit = new JButton("押金(默认)");
	private JButton deposit_qu = new JButton("输入押金");
	private JButton deposit_cancel = new JButton("取消押金");
	
	private JButton lost = new JButton("挂失");
	private JButton lost_cancel = new JButton("撤消挂失");
	
	private JCheckBox auto = new JCheckBox("自动打印充值小票");
	private String printSite[] = Sql.getString("select 站点 from print_config;", this);
	private JComboBox<String> place=new JComboBox<String>(printSite);

	private JTable cardlog = Sql.getTable();
	private JLabel cardclass = new JLabel("卡类型：", JLabel.CENTER);
	private JNativeSub mwrf = new JNativeSub();
	public ICissue(){
		setLayout(new BorderLayout());
		
		JPanel left = new JPanel(null);
		left.add(sel());
		left.add(seldb_init());
		left.add(but());
		left.add(ch());
		left.add(cardclass);
		left.add(oth());
		cardclass.setBounds(260, 410, 300, 50);
		cardclass.setOpaque(true);
		cardclass.setFont(new Font("楷体", Font.BOLD, 26));
		cardclass.setBackground(Color.LIGHT_GRAY);
		cardclass.setForeground(Color.BLUE);
		cardclass.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));//立体感
		
		go.addActionListener(this);
		a.addActionListener(this);
		b.addActionListener(this);
		c.addActionListener(this);
		d.addActionListener(this);
		e.addActionListener(this);
		log.addActionListener(this);
		charge.addActionListener(this);
		deposit.addActionListener(this);
		deposit_qu.addActionListener(this);
		deposit_cancel.addActionListener(this);
		lost.addActionListener(this);
		lost_cancel.addActionListener(this);
		deposit.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(e.getButton()!=3) return ;
				String val = JOptionPane.showInputDialog(Front.front, "请输入 快捷默认 金额：");
				if(val==null || val.isEmpty()) return ;
				try{
					Double.valueOf(val);
				}catch (Exception err) {
					JOptionPane.showMessageDialog(Front.front, "输入的金额必须为数字，请检查...", "错误", 0);
					return ;
				}
				ConfigFile.setProperty("default_deposit", val);
			}
		});
		
		JLabel tip = new JLabel("   IC卡类型为M1(Mifare_l)卡,读写设备厂家为<明华>,测试型号:URF-R330,亦可使用兼容设备。");
		tip.setFont(new Font("正楷", Font.BOLD, 13));
		
		JPanel cen = new JPanel(new GridLayout(1,2));
		cen.add(left);
		cen.add(new JScrollPane(cardlog));
		add(cen, BorderLayout.CENTER);
		
		JPanel soupan = new JPanel(new FlowLayout(FlowLayout.LEFT));
		soupan.setBackground(Color.LIGHT_GRAY);
		soupan.add(auto);
		soupan.add(place);
		soupan.add(tip);
		auto.addActionListener(this);
		String temp=ConfigFile.getProperty("AutoPrintCharge");
		if(temp.equals("Y"))	auto.setSelected(true);
		else place.setEnabled(false);
		place.setSelectedItem(ConfigFile.getProperty("CardChargePrintSite"));
		place.addItem("COM1");
		place.addItem("COM2");
		place.addActionListener(this);
		add(soupan, BorderLayout.SOUTH);
	}
	
	private JPanel sel(){
		JPanel pan = new JPanel(new BorderLayout());
		pan.setBounds(300, 12, 240, 120);
		pan.setBorder(Sql.getBorder(2, "IC卡信息"));
		JPanel west = new JPanel(new GridLayout(3, 1));
		
		west.add(new JLabel("卡面编号："));
		west.add(new JLabel("卡密码MD5："));
		west.add(new JLabel("总资产："));
		
		JPanel cen = new JPanel(new GridLayout(3, 1));
		for(int flag=0; flag<3; flag++){
			cardval[flag] = new JTextField();
			cardval[flag].setEditable(false);
			cardval[flag].setBackground(Color.LIGHT_GRAY);
			if(flag == 2){
				cardval[flag].setFont(new Font(null, Font.BOLD, 15));
			}
			cen.add(cardval[flag]);
		}
		
		pan.add(west, BorderLayout.WEST);
		pan.add(cen, BorderLayout.CENTER);
		return pan;
	}
	private JPanel seldb_init(){
		JPanel pan = new JPanel(new BorderLayout());
		pan.setBounds(12, 12, 240, 450);
		pan.setBorder(Sql.getBorder(2, "同步的数据库信息"));
		JPanel west = new JPanel(new GridLayout(14, 1));
		west.add(new JLabel("流水号："));
		west.add(new JLabel("IC卡内编码："));
		west.add(new JLabel("IC卡外编号："));
		
		west.add(new JLabel("发行时间:"));
		west.add(new JLabel("发行工号:"));
		west.add(new JLabel("发行站点:"));
		
		west.add(new JLabel("持卡人姓名:"));
		west.add(new JLabel("性别:"));
		west.add(new JLabel("联系电话："));
		
		west.add(new JLabel("可用余额："));
		west.add(new JLabel("钱包一："));
		west.add(new JLabel("钱包二："));
		
		west.add(new JLabel("押金/冻结："));
		west.add(new JLabel("挂失状态："));
		
		JPanel cen = new JPanel(new GridLayout(14, 1));
		for(int flag=0; flag<cv.length; flag++){
			cv[flag] = new JTextField();
			cv[flag].setEditable(false);
			cv[flag].setBackground(Color.LIGHT_GRAY);
			if(flag == 3 || flag == 4 || flag == 5){
				cv[flag].setBackground(Color.PINK);
			}
			if(flag == 6 || flag == 7 || flag == 8){
				cv[flag].setEditable(true);
				cv[flag].setBackground(null);
			}
			if(flag > 8){
				cv[flag].setFont(new Font(null, Font.BOLD, 15));
			}
			if(flag == 12){
				cv[flag].setForeground(Color.RED);
			}
			cen.add(cv[flag]);
		}
		cv[7].addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(e.getButton()!=3) return ;
				if(cv[7].getText().isEmpty() || cv[7].getText().equals("女")){
					cv[7].setText("男");
					return ;
				}	
				if(cv[7].getText().equals("男")){
					cv[7].setText("女");
					return ;
				}
			}
		});
		
		pan.add(west, BorderLayout.WEST);
		pan.add(cen, BorderLayout.CENTER);
		return pan;
	}
	private JPanel but(){
		JPanel pan = new JPanel(new GridLayout(4,1));
		pan.setBounds(430, 230, 120, 160);
		pan.add(d);
		pan.add(e);
		pan.add(lost);
		pan.add(lost_cancel);
		return pan ;
	}
	private JPanel oth(){
		JPanel pan = new JPanel(new GridLayout(1,5));
		pan.setBounds(10, 480, 560, 40);
		pan.add(deposit);
		pan.add(deposit_qu);
		pan.add(deposit_cancel);
		pan.add(b);
		pan.add(log);
		return pan ;
	}
	private JPanel ch(){
		JPanel pan = new JPanel(new GridLayout(4,1));
		pan.setBounds(300, 150, 120, 160);
		pan.add(go);
		pan.add(a);
		pan.add(charge);
		pan.add(c);
		charge.setForeground(Color.BLUE);
		
		go.setMnemonic(KeyEvent.VK_F);
		a.setMnemonic(KeyEvent.VK_S);
		charge.setMnemonic(KeyEvent.VK_M);
		c.setMnemonic(KeyEvent.VK_B);
		
		return pan ;
	}

	@Override
	public void actionPerformed(ActionEvent ev) {
		// TODO Auto-generated method stub
		if(ev.getSource()==auto){
			ConfigFile.setProperty("AutoPrintCharge", auto.isSelected());
			place.setEnabled(auto.isSelected());
			return ;
		}
		
		if(ev.getSource()==place){
			ConfigFile.setProperty("CardChargePrintSite", place.getSelectedItem().toString());
			return ;
		}
		
		if(ev.getSource() == go){
			// 检查卡片合法性, 设备是否准备好
			boolean res = mwrf.isReady(true) ;
			if(res==false) return ;
			
			// 记录到数据库中
			ArrayList<String> v=new ArrayList<String>();
			v.add(mwrf.snr);
			v.add(mwrf.cardno);
			res = Sql.mysqlprocedure("card_issue", v);
			if(res == false) return ;
			
			if(mwrf.giveCard()){
				selectCard();
			}
			
			return ;
		}
		
		if(ev.getSource() == a){
			selectCard();
			return ;
		}
		
		if(ev.getSource() == charge){
			
			ArrayList<String> arr = mwrf.getMyInfo();
			if(arr==null || arr.size()!=3) return ;
			
			String val = JOptionPane.showInputDialog(Front.front,"充值金额 (正数充值,负数扣款)：");
			if(val==null || val.trim().isEmpty()) return ;
			
			try{
				Double.valueOf(val.trim());
			}
			catch (Exception err) {
				JOptionPane.showMessageDialog(Front.front, "必须输入一个数字", "警告", 0);
				return ;
			}
			
			// 检查卡片合法性, 设备是否准备好
			boolean res = mwrf.isReady(false) ;
			if(res==false) return ;
			
			// 开始充值操作
			ArrayList<String> v=new ArrayList<String>();
			v.add(mwrf.snr);
			v.add(val.trim());
			res = Sql.mysqlprocedure("card_charge", v);
			
			// 开始同步到卡片
			if(res){
				mwrf.CardCharge(Double.valueOf(val.trim())); 
				selectCard();
				if(auto.isSelected()) print("-1");   //打印小票
			}
			
			return ;
		}
		
		if(ev.getSource() == c){
			int k=JOptionPane.showConfirmDialog(Front.front, "确定退卡？","不可逆操作",0);
			if(k!=0) return ;
			
			// 检查卡片合法性, 设备是否准备好
			boolean res = mwrf.isReady(false) ;
			if(res==false) return ;
			
			res = Sql.mysqlprocedure("card_back", mwrf.snr);
			if(res==false) return ;
			
			res = mwrf.giveCardData(null,"","");
			if(res) selectCard();
			return ;
		}
		
		if(ev.getSource() == d){
			new ICPassword();
			selectCard();
			return ;
		}
		if(ev.getSource() == e){
			// 检查卡片合法性, 设备是否准备好, 这样做是为了保证有卡片的情况下才能修改信息
			boolean res = mwrf.isReady(false) ;
			if(res==false) return ;
			
			// 保存信息
			ArrayList<String> v=new ArrayList<String>();
			v.add(mwrf.snr);
			v.add(cv[6].getText());
			v.add(cv[7].getText());
			v.add(cv[8].getText());
			Sql.mysqlprocedure("card_info", v);
			
			return ;
		}
		if(ev.getSource() == log){
			String sql = "select * from cardlog where issueid in (select ind from cardlist where cardid='"+mwrf.snr+"');" ;
			Sql.getArrayToTable(sql, this, cardlog);
			Sql.TableAtt(cardlog, true, false);
			return ;
		}
		if(ev.getSource() == b){
			mwrf.devReset();
			return ;
		}
		if(ev.getSource() == deposit){
			String val = ConfigFile.getProperty("default_deposit");
			if(val.isEmpty()) val="10";
			depositexe(val);
			return ;
		}
		if(ev.getSource() == deposit_qu){
			String val = JOptionPane.showInputDialog(Front.front,"请输入金额：");
			if(val==null || val.isEmpty()) return ;
			
			try{
				Double.valueOf(val);
			}catch (Exception err) {
				JOptionPane.showMessageDialog(Front.front, "输入的金额必须为数字，请检查...", "错误", 0);
				return ;
			}
			
			depositexe(val);
			return ;
		}
		if(ev.getSource() == deposit_cancel){
			depositexe("0");
			return ;
		}
		if(ev.getSource() == lost){
			// 检查卡片合法性, 设备是否准备好
			boolean res = mwrf.isReady(false) ;
			if(res==false) return ;
			
			ArrayList<String> v=new ArrayList<String>();
			v.add(mwrf.snr);
			v.add("Y");
			Sql.mysqlprocedure("card_lost", v);
			selectCard();
			return ;
		}
		if(ev.getSource() == lost_cancel){
			// 检查卡片合法性, 设备是否准备好
			boolean res = mwrf.isReady(false) ;
			if(res==false) return ;
			
			ArrayList<String> v=new ArrayList<String>();
			v.add(mwrf.snr);
			v.add("N");
			Sql.mysqlprocedure("card_lost", v);
			selectCard();
			return ;
		}
	}
	private void depositexe(String val){
		// 检查卡片合法性, 设备是否准备好, 这样做是为了保证有卡片的情况下才能操作
		boolean res = mwrf.isReady(false) ;
		if(res==false) return ;
		
		// 保存信息
		ArrayList<String> v=new ArrayList<String>();
		v.add(mwrf.snr);
		v.add(val);
		Sql.mysqlprocedure("card_deposit", v);
		selectCard();
	}
	
	// 使用线程的方式可以看到信息刷新时闪一下的效果
	private void selectCard(){
		Thread th = new Thread(new Runnable() {
			public void run() {
				cardclass.setText("");
				for(JTextField temp : cardval){
					temp.setText("");
				}
				for(JTextField temp : cv){
					temp.setText("");
				}
				
				ArrayList<String> arr = mwrf.getMyInfo();
				if(arr==null || arr.size()!=3) return ;
				
				int flag = 0 ;
				for(String s : arr){
					cardval[flag].setText(s);
					flag++ ;
				}
				
				cardclass.setText("使用中:"+mwrf.snr);
				cardclass.setForeground(Color.blue);
				if(cardval[2].getText().trim().isEmpty()){
					cardclass.setText("空白卡:"+mwrf.snr);
					cardclass.setForeground(Color.white);
					return ;
				}
				
				if(cardval[2].getText().trim().startsWith("-")){
					cardval[2].setBackground(Color.ORANGE);
				}
				else{
					cardval[2].setBackground(Color.LIGHT_GRAY);
				}
				
				seldb(mwrf.snr);
			}
		});
		th.start();
	}
	
	private void seldb(String ma){
		String sql = "select * from cardlist where cardid='"+ma+"'" ;
		ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
		if(arr.size()==0) return ;

		for(int flag=0; flag<cv.length; flag++){
			cv[flag].setText(arr.get(0)[flag]);
		}
	}
	
	public void print(String ind){
		if(place.getSelectedItem()==null){
			JOptionPane.showMessageDialog(Front.front,"未配置热敏打印机站点，无法完成打印。","注意 Error",0);
			return ;
		}
		
		byte b[] = Photo.getcharge(ind);
		if(b==null) return ;
		
		String com = place.getSelectedItem().toString();
		if(com.toUpperCase().startsWith("COM")){
			try {
				Photo.Printcom(b, com);
			}
			catch (Exception err) {
				JOptionPane.showMessageDialog(Front.front, err.getMessage(), "错误", 0);
				err.printStackTrace();
			}
			return ;
		}
		Photo.printbin(b, place.getSelectedItem().toString(), true);
	}
}
