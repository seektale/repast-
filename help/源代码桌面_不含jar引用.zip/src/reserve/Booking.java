package reserve;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JInternalFrame;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import root.Front;
import root.Sql;
public class Booking extends JInternalFrame{
	private static final long serialVersionUID = 734411224457668L;
	private final JTabbedPane tab=new JTabbedPane();
	public Booking(){
		super("预定",true,true,true,true);
		
		final HashMap<Integer, String> week=new HashMap<Integer, String>();
		week.put(1, "星期天");
		week.put(2, "星期一");
		week.put(3, "星期二");
		week.put(4, "星期三");
		week.put(5, "星期四");
		week.put(6, "星期五");
		week.put(7, "星期六");
		
		//传值过去则只运行一次，以免频繁读取数据库
		ArrayList<String[]> desk=Sql.getArrayToArrary("select 区域,台号,别名 from desk ORDER BY 前辍,台号", this);
		tab.add("预定管理",new Booking1(week));
		tab.add("分布图",new Booking2(desk, week));
	    tab.add("时间轴",new Booking3(desk, week));
	    tab.add("操作日志",new BLog());
		
	    tab.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				final int ind = tab.getSelectedIndex();
				if(ind==1) ((Booking2)tab.getSelectedComponent()).refresh();
				if(ind==2) ((Booking3)tab.getSelectedComponent()).refresh(false);
			}
		});
	    
		setContentPane(tab);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	}
}