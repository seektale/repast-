package reserve;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import pub.DateUI;
import pub.Lunar;
import pub.Popup_tab;
import pub.Var;
import root.Front;
import root.Sql;
//import sun.swing.table.DefaultTableCellHeaderRenderer;
public class Booking3 extends JPanel implements ActionListener,MouseMotionListener{
	private static final long serialVersionUID = 7320447810896457668L;
	private int slip=0;
	private final JButton up=new JButton("＜");
	private final JButton down=new JButton("＞");
	private final JButton mydate=new JButton("指定首列日期");
	private final HashMap<String, String> tip=new HashMap<String, String>();
	private final ButtonGroup group = new ButtonGroup();
	private JTable t;
	private final JLabel msg = new JLabel();
	private ArrayList<String[]> deskinfo;
	private HashMap<Integer, String> week;
	public Booking3(ArrayList<String[]> deskinfo, HashMap<Integer, String> week){
		this.deskinfo = deskinfo;
		this.week=week;
		setLayout(new BorderLayout());
		up.addActionListener(this);
		down.addActionListener(this);
		mydate.addActionListener(this);
	    add(head(),BorderLayout.NORTH);
	    init();
	}
	
	private void init(){
		 //不可编辑
	    t=new JTable(new DefaultTableModel(0,0){
    		private static final long serialVersionUID = 354854820819L;
	        public boolean isCellEditable(int row, int column) {
	        	return false;
	        }
		});
	    
	    // 设置table表头居中
	    //DefaultTableCellHeaderRenderer thr = new DefaultTableCellHeaderRenderer();
	    final DefaultTableCellRenderer thr = new DefaultTableCellRenderer();
	    thr.setHorizontalAlignment(JLabel.CENTER);
	    t.getTableHeader().setDefaultRenderer(thr);
	    
	    // 设置table内容居中
	    final DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
	    tcr.setHorizontalAlignment(JLabel.CENTER);
	    t.setDefaultRenderer(Object.class, tcr);
	    
	    // 设置不能重新排序各列
        t.getTableHeader().setReorderingAllowed(false);
        t.setSelectionBackground(Color.pink);
	    t.setShowGrid(true);
	    
	    // 监听鼠标移动，同步显示tip
        t.addMouseMotionListener(this);
        t.setComponentPopupMenu(new Popup_tab(t));
        
        add(new JScrollPane(t),BorderLayout.CENTER);
	}
	
	private JPanel head(){
		final JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT));
		for(String temp :Var.area()){
			//使用单选而不使用复选组件，是因为复选过多时，占用内存太大，导致程序体验极不佳
			JRadioButton c=new JRadioButton(temp);
			c.setActionCommand(temp);
			group.add(c);
			c.addActionListener(this);
			p.add(c);
		}
		
		p.add(up);p.add(down);
		p.add(mydate);
		p.add(msg);
		msg.setForeground(Color.BLUE);
		p.add(new JLabel("  "));	//仅仅为了分割开一点
		String s="［<font color=red>●</font>早餐,<font color=green>●</font>中餐,<font color=blue>●</font>晚餐,<font color=black>●</font>夜宵和其它］";
		p.add(new JLabel("<html><body>"+s+"</font></body></html>"));
		
		return p;
	}
	private String getpan(ArrayList<String> v,int x){
		String temp="";
		boolean flag=true;
		for(String val : v){
			if(val.equals("早餐")){
				temp=temp+"<font color=red>●</font>";
				v.remove(val);
				flag=false; break;
			}
		}
		if(flag)	temp=temp+"○";
		
		flag=true;
		for(String val : v){
			if(val.equals("中餐")){
				temp=temp+"<font color=green>●</font>";
				v.remove(val);
				flag=false; break;
			}
		}
		if(flag)	temp=temp+"○";
		
		flag=true;
		for(String val : v){
			if(val.equals("晚餐")){
				temp=temp+"<font color=blue>●</font>";
				v.remove(val);
				flag=false; break;
			}
		}
		if(flag)	temp=temp+"○";
		
		//夜宵和其它
		temp = v.size()>0 ? temp+"<font color=black>●</font>" : temp+"○" ;
		
		//历史风格
		if((slip<0)&&(x<Math.abs(slip)+1)){
			temp=temp.replace("○", "□");
			temp=temp.replace("●", "■");
		}
		
		//当天风格
		if((slip<=0)&&(x==Math.abs(slip)+1)){
			temp=temp.replace("○", "◇");
			temp=temp.replace("●", "◆");
		}

		return "<html><body>"+temp+"</body></html>";
	}
	public void actionPerformed(ActionEvent e){
		//没有选择区域时不作响应
		if(group.getSelection()==null) return ;
		
		if(e.getSource()==up)	slip--;
		else if(e.getSource()==down)	slip++;
		else if(e.getSource()==mydate){
			DateUI du = new DateUI();
			if(du.toString().isEmpty()) return ;
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			try {
				Date date = df.parse(du.toString());
				Date now = new Date();
				long k = (date.getTime()-now.getTime())/1000/3600/24;
				slip=(int)k;
			} catch (ParseException e1) {
				JOptionPane.showMessageDialog(Front.front, "日期格式转换失败");
				return  ;
			} 
		}
		
		//时间描述
		final Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)+slip);
		final Lunar l=new Lunar(cal);	//农历
		int k = cal.get(Calendar.DAY_OF_WEEK);
		final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		msg.setText("首列日期："+df.format(cal.getTime())+"  农历："+l.toString()+"  "+week.get(k));
		
		refresh(true);
	}
	
	public void refresh(boolean boo){
		tip.clear();  //复位
		final ArrayList<String> col=new ArrayList<String>();
	   
   	    //第一行标题数据
	    col.add("台号 / 别名");
	    
	    //注意，月份是从0到11，年和日期不是从0开始
	    Calendar cal = Calendar.getInstance();
	    cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)-1+slip);	//先往后退一天
	    for(int m=0;m<10;m++){
	    	//第次循环日期往前移一天
	    	cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)+1);
	    	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	    	col.add(df.format(cal.getTime()));
	    }
	    
	    //第二行开使的表格数据，首先找出这个时间段的所有预定数据
	    final String booksql="select 区域,台号,抵达日期,时段,宾客单位,宾客姓氏,电话,时段,人数,标准,定金,备注 from booking " +
	    			   "where to_days(抵达日期)-to_days(now())>='"+slip+"' and to_days(抵达日期)-to_days(now())<='"+10+slip+"';";
	    
	    final ArrayList<String[]> book = Sql.getArrayToArrary(booksql, this);
	    final ArrayList<String[]> val=new ArrayList<String[]>();
	    
	    for(String temp[] : deskinfo){
	    	
	    	if(boo) {
	    		 final String Radioval = group.getSelection().getActionCommand();
	    		 if(!temp[0].equals(Radioval)) continue ;
	    	}
	    	
	    	final ArrayList<String> sub=new ArrayList<String>();
	    	//第一列
   	    	String num=temp[1];
   	    	if(num.length()==1) num="0"+num;
	   	    sub.add(num+"   "+temp[2]);
	   	    
	   	    //第二列开始
	   	    cal = Calendar.getInstance();		//初始化
	   	    cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)-1+slip);
	   	    for(int n=0;n<10;n++){	//显示窗口为10天的预定信息
	   	    	cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)+1);
				
			    String b1=cal.get(Calendar.YEAR)+"";
			    String b2=cal.get(Calendar.MONTH)+1+"";
			    if(b2.length()==1) b2="0"+b2;
			    String b3=cal.get(Calendar.DAY_OF_MONTH)+"";
			    if(b3.length()==1) b3="0"+b3;
			    String arrtime=b1+"-"+b2+"-"+b3;
			    
			    String dep2=temp[0];
			    String ind2=temp[1];
			    ArrayList<String> v=new ArrayList<String>();
			    String msg="";
			    for(int k=0;k<book.size();k++){
			    	String dep1 = book.get(k)[0];
			    	String ind1 = book.get(k)[1];
			    	String time = book.get(k)[2];
			    	if(dep1.equals(dep2)&&ind1.equals(ind2)&&time.equals(arrtime)){
			    		//存在预定信息就放入向量，可能有多个预定信息
			    		v.add(book.get(k)[3]);
			    		//鼠标移到上有预定的目标上时，显示的tip信息
			    		msg=msg+"<font color=red>单位："+book.get(k)[4]+"</font><br>" +
			    				"姓名："+book.get(k)[5]+"<br> 电话："+book.get(k)[6]+"<br>" +
			    				"餐别："+book.get(k)[7]+"<br>人数："+book.get(k)[8]+"<br>标准："+book.get(k)[9]+"<br>" +
			    				"定金："+book.get(k)[10]+"<br>备注："+book.get(k)[11]+"<br><br>";
			    	}
			    }
			    
			    if(v.size()>0){
			    	tip.put(val.size()+"#"+sub.size(), msg);
			    }
			   	sub.add(getpan(v,sub.size()));
		    }
	   	    final String subarr[] = new String[sub.size()];
	   	    val.add(sub.toArray(subarr));
   	    }
   	    
	    if(val.size()>0){
	    	final String ss[][]=new String[val.size()][val.get(0).length];
	    	for(int m=0;m<val.size();m++){
	    		ss[m]=val.get(m);
	    	}
	    	//更新数据
			final DefaultTableModel mod=(DefaultTableModel)t.getModel();
			mod.setDataVector(ss,col.toArray());
	    }
		
		//第一列不要居中
	    final DefaultTableCellRenderer render = new DefaultTableCellRenderer();
	    render.setHorizontalAlignment(SwingConstants.LEFT);
	    if(t.getColumnCount()>0) t.getColumn(t.getColumnName(0)).setCellRenderer(render);
	}

	public void mouseDragged(MouseEvent arg0) {}
	public void mouseMoved(MouseEvent e) {
		if(group.getSelection()==null) return ;
		
		final Point point = e.getPoint();
        int x = t.rowAtPoint(point);
        int y = t.columnAtPoint(point);

        final String msg=tip.get(x+"#"+y);
        if(msg==null){
        	t.setToolTipText(null);
        }
        else{
        	t.setToolTipText("<html><body>"+msg+"</body></html>");
        }
	}
}
