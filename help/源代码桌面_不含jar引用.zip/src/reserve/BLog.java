package reserve;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import pub.DateUI;
import root.Sql;
public class BLog extends JPanel{
	private static final long serialVersionUID = -4593851044789735752L;
	private JTable t=Sql.getTable();
	private JButton button = new JButton("日期选择");
	private JButton last = new JButton("最近100条记录");
	public BLog(){
		setLayout(new BorderLayout());
		
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DateUI du = new DateUI();
				if(du.toString().isEmpty()) return ;
				String sql="select * from syslog where action like '%预定%' and date(time)=date('"+du.toString()+"') ";
				Sql.getArrayToTable(sql, BLog.this, t);
				Sql.TableAtt(t, true, false);
			}
		});
		
		last.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//只有倒序才能查询最近的记录
				String sql="select * from syslog where action like '%预定%' order by ind desc limit 0,100 ";
				Sql.getArrayToTable(sql, BLog.this, t);
				Sql.TableAtt(t, true, false);
			}
		});
		
		t.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);	//恢复多选功能
		
		String sql="select * from syslog where action like '%预定%' order by ind desc limit 0,100 ";
		Sql.getArrayToTable(sql, this, t);
		Sql.TableAtt(t, true, false);
		
		JPanel nor = new JPanel(new FlowLayout(FlowLayout.LEFT));
		nor.add(button);
		nor.add(last);
		nor.add(new JLabel("  单击列标题 系统根据该列 自动分类排序"));
		
		add(nor, BorderLayout.NORTH);
		add(new JScrollPane(t), BorderLayout.CENTER);
	}
}
