package desk_creat;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.SwingWorker;
import root.Sql;
public class Desk_Table_EDT extends SwingWorker<List<tableLab>, tableLab> {
	private Desk_Table dt;
	public Desk_Table_EDT(Desk_Table dt){
	    this.dt=dt;
	}
	
	protected List<tableLab> doInBackground() throws Exception {
		
		List<tableLab> list = new ArrayList<tableLab>();
		
		//第二行开使的表格数据
	    String sql="select 区域,台号,状态,别名 from desk ORDER BY 前辍,台号";
	    ArrayList<String[]> deskarr = Sql.getArrayToArrary(sql, this);
	    //以键值对的形式保存第个卡台的信息
	    HashMap<String, String[]> hm = new HashMap<String, String[]>();
	    for(String temp[] : deskarr){
	    	hm.put(temp[0]+temp[1], temp);
	    }
	    
	    sql="SELECT '已开台',区域,台号,选择时段,COUNT(*) from deskgo WHERE 开台时间 in (select 操作时间 from desk where 状态='已开台') and isnull(结账时间) GROUP BY 区域,台号";
	    sql=sql+" UNION ALL ";
	    sql=sql+"SELECT '挂起',区域,台号,'',COUNT(*) from deskgo WHERE 开台时间 not in (select 操作时间 from desk) and isnull(结账时间) GROUP BY 区域,台号";
	    sql=sql+" UNION ALL ";
	    sql=sql+"SELECT '已结账',区域,台号,'',COUNT(*) from deskgo WHERE not isnull(结账时间) GROUP BY 区域,台号";
	    ArrayList<String[]> infoarr = Sql.getArrayToArrary(sql, this);
	    
	    for(tableLab A[] : dt.lab){
	    	for(tableLab B : A){
	    		Thread.sleep(1);	//产生过渡效果，UI交互更美观
	    		
		    	String temp[]=hm.get(B.dep+B.ind);	//找出卡台信息
		    	if(temp==null) continue ;
		    	
				String s="<font color=yellow>■</font>";
				if(temp[2].equals("空台")){
					s="<font color=white>■</font>";
				}
				else if(temp[2].equals("已开台")){
					s="<font color=blue>■</font>";
				}
				else if(temp[2].equals("脏台")){
					s="<font color=red>■</font>";
				}
				s=s+inforun(infoarr, B);
				
				if(temp[1].length()==1) temp[1]="0"+temp[1];
				B.text = "<html><body>"+temp[1]+" "+s+"</body></html>" ;
				
				//为防止重复注册多次监听，需要先判断是否已注册监听
				if(B.getMouseListeners().length==0){
					B.addMouseListener(dt);
				}
				if(!temp[3].isEmpty()) B.setToolTipText("别名："+temp[3]);
				
				publish(B);
				list.add(B);
		    }
	    }
	    
	    return list;
	}
	
	protected void process(List<tableLab> val){
		if(isCancelled()) return ;
		for(tableLab temp : val){
			if(dt.liti.isSelected()) temp.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));//立体感
			else	temp.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
			temp.setOpaque(true);
			temp.setText(temp.text);
		}
	}
	
	private String inforun(ArrayList<String[]> info, tableLab lab){
		String a = "<font color=gray>○○○○</font>";
		String b = "<font color=gray>△0</font>";
		String c = "<font color=gray>￥0</font>";
		for(String temp[] : info){
			if(!temp[1].equals(lab.dep) || !temp[2].equals(lab.ind)) continue ;
			
			if(temp[0].equals("已开台")){
				int count=Integer.valueOf(dt.ch2.getText().replace("已开台 ", ""));
				dt.ch2.setText("已开台 "+(count+1));
				String flag=temp[3];
				if(flag.equals("早餐")){
					a="<font color=red>●○○○</font>";
				}
				else if(flag.equals("中餐")){
					a="<font color=green>○●○○</font>";
				}
				else if(flag.equals("晚餐")){
					a="<font color=blue>○○●○</font>";
				}
				else{
					a="<font color=black>○○○●</font>";
				}
			}
			else if(temp[0].equals("挂起")){
				b="<font color=blue>▲</font>"+temp[4];
				//计数
				int count=Integer.valueOf(dt.ch3.getText().replace("挂起 ", ""));
				dt.ch3.setText("挂起 "+(count+Integer.valueOf(temp[4])));
			}
			else if(temp[0].equals("已结账")){
				c="<font color=blue><strong>￥</strong></font>"+temp[4];
				//计数
				int count=Integer.valueOf(dt.ch4.getText().replace("已结账 ", ""));
				dt.ch4.setText("已结账 "+(count+Integer.valueOf(temp[4])));
			}
		}

		String gray = "<font color=gray>＿</font>";
		if(dt.tar.isSelected()){
			if(dt.ch1.isSelected()&&(a.contains("○○○○")))	return gray + a ;
			if(dt.ch2.isSelected()&&(!a.contains("○○○○")))	return gray + a ;
			if(dt.ch3.isSelected()&&(!b.contains("△0")))	return gray + a ;
			if(dt.ch4.isSelected()&&(!c.contains("￥0")))	return gray + a ;
			return "<font color=gray>＿＿＿＿＿</font>";
		}
		
		if(dt.ch1.isSelected()&&(a.contains("○○○○")))		return gray+a+gray+b+gray+c;
		if(dt.ch2.isSelected()&&(!a.contains("○○○○")))		return gray+a+gray+b+gray+c;
		if(dt.ch3.isSelected()&&(!b.contains("△0")))		return gray+a+gray+b+gray+c;
		if(dt.ch4.isSelected()&&(!c.contains("￥0")))		return gray+a+gray+b+gray+c;
		return "<font color=gray>＿＿＿＿＿＿＿＿＿＿.</font>";
	}
}
