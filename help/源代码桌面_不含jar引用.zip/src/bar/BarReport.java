package bar;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import root.Sql;
public class BarReport extends JPanel implements ActionListener{
	private static final long serialVersionUID = -5671013107914868347L;
	private JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JTable t=Sql.getTable();
	private HashMap<String, String> val=new HashMap<String, String>();
	BarReport(){
		setOpaque(false);
	    setLayout(new BorderLayout());
	    
	    String sql="select value,remark from general where name='report' and item='吧台报表' and value not like '%已班结%' ";
	    ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
	    
	    for(String f[] : arr){
	    	getButton(f[0]);
	    	val.put(f[0], f[1]);
	    }
	    
	    JButton node = new JButton("班结吧台商品");
	    node.setForeground(Color.BLUE);
	    node.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Sql.mysqlprocedure("node_bar");
			}
		});
	    nor.add(node);
	    
	    nor.add(new JLabel("  [ 库存值为:-1 代表未启用该商品的库存功能 ]"));
	    add(nor,BorderLayout.NORTH);
	    add(new JScrollPane(t),BorderLayout.CENTER);
	}
	
	private JButton getButton(String s){
		JButton b=new JButton(s);
		b.addActionListener(this);
		nor.add(b);
		return b;
	}
	
	public void actionPerformed(ActionEvent e) {
		String cmd=e.getActionCommand();
		cmd=val.get(cmd);
		Sql.getArrayToTable(cmd, this, t);
		Sql.TableAtt(t, true, false);
	}
}
