package bar;
import java.awt.Component;
import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import pub.Var;
import root.Front;
import root.Sql;
public class BarFrame extends JInternalFrame{
	private static final long serialVersionUID = 2664755651140502L;
	private JTabbedPane tp=new JTabbedPane();
	public String cla;
	public BarFrame(){
		super("吧台管理",true,true,true,true);
		setContentPane(tp);
	    setResizable(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
	    cla=initClass();	//初始化
	    
		tp.addTab("吧台商品明细", new BarGoods(this));
		tp.addTab("吧台售出/退回 查询", new BarLog(cla));
		tp.addTab("卡台售出/退回 查询", new BarLogme(cla));
		tp.addTab("入库/出库 查询", new BarInout(cla));
		tp.addTab("吧台报表/班结", new BarReport());
		
		setVisible(true);
	}
	
	private String initClass(){
		//把吧台商品类别存放在里面
		String me="select value from general where name='system' and item='barmenu';";
		String barmenu[]=Sql.getString(me, this);
		if(barmenu.length>0){
			String temp=barmenu[0];
			int len=temp.length();
			if(len>2){
				// 列：[酒水, 零食, 香烟, 辅助]
				temp=temp.substring(1, len-1);
				return temp+", ";
			}
		}
		return "";
	}
	
	//重新定义吧台商品类别
	public void part(){
		String s[]=Var.getMenu_class(true);
		JPanel pan=new JPanel(new GridLayout(s.length/10+1, 8));
		for(String me : s){
			JCheckBox ch=new JCheckBox(me);
			if(cla.contains(me+",") || cla.contains(me+"]")) ch.setSelected(true);
			pan.add(ch);
		}
		
		int m=JOptionPane.showConfirmDialog(Front.front, pan,"选择隶属于吧台的商品类别",2,1,new ImageIcon());
		if(m==0){
			ArrayList<String> arr=new ArrayList<String>();
			for(Component temp : pan.getComponents()){
				JCheckBox ch = (JCheckBox)temp;
				if(ch.isSelected()) arr.add(ch.getText());
			}
			
			if(arr.size()==0) Sql.mysqlprocedure("bar_menu","");
			else Sql.mysqlprocedure("bar_menu",arr.toString());
			
			cla=initClass(); //同步
		}
	}
}
