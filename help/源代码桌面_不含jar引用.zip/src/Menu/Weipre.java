package Menu;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import pub.MatrixToImageWriter;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

import root.Front;
public class Weipre extends JDialog implements ActionListener{
	private static final long serialVersionUID = 47676624736652L;
	private BufferedImage buff ;
	private String val ;
	private JButton ok = new JButton("导出到桌面 Export_To_Desktop");
	public Weipre(String val){
		super(Front.front,val,true);
		this.val=val;
		buff = getimg();
		ok.addActionListener(this);
		
		JPanel con = new JPanel(new BorderLayout());
		con.add(new mywei(),BorderLayout.CENTER);
		con.add(ok,BorderLayout.SOUTH);
		
		setContentPane(con);
		setSize(new Dimension(236, 270));
		setLocationRelativeTo(Front.inFrame);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Front.logo);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		//注意替换文件分隔符有两种文件分隔符
		val = val.replace("\\", "@");
		val = val.replace("/", "@");
		
		Properties props = System.getProperties();
		String sel = props.getProperty("user.home") + "\\desktop\\"+val+".jpg";
		//File outputFile = new File("E:" + File.separator + "new.jpg");
		try {
			ImageIO.write(buff, "jpg", new File(sel));
			JOptionPane.showMessageDialog(null, "二维码导出到桌面成功");
		} catch (IOException e1) {
			e1.printStackTrace();
			JOptionPane.showMessageDialog(null, "二维码导出失败");
		}
	}
	
	private BufferedImage getimg(){
		Hashtable<EncodeHintType, String> hints = new Hashtable<EncodeHintType, String>();
		hints.put(EncodeHintType.CHARACTER_SET, "utf-8");	// 内容所使用编码
		try{
			BitMatrix bitMatrix = new MultiFormatWriter().encode(val, BarcodeFormat.QR_CODE, 200, 200, hints);
			MatrixToImageWriter ww = new MatrixToImageWriter();
			return ww.toBufferedImage(bitMatrix,val) ;
		}catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "二维码生成失败\n"+e.getMessage());
		}
		return null;
	}
	
	class mywei extends JPanel {
		private static final long serialVersionUID = 423423647586652L;
		public void paint(Graphics g) {
			g.drawImage(buff,0,0,this.getWidth(),this.getHeight(),this);
		    super.paintChildren(g);
		}
	}
}

