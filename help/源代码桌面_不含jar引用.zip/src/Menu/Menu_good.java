package Menu;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import pub.ModifiedFlowlayout;
import pub.Var;
import root.Front;
import root.Sql;
public class Menu_good extends JSplitPane implements ActionListener{
	private static final long serialVersionUID = -6411629019479635720L;
	private JTable up = Sql.getTable() ,down = Sql.getTable();
	private JButton add	=new JButton("添加套餐");
	private JButton del	=new JButton("删除套餐");
	private JButton refresh	=new JButton("刷新");
	
	private JButton adds =new JButton("添加商品");
	private JButton dels =new JButton("删除商品");
	Menu_good(){
		setOneTouchExpandable(true);
		setOrientation(JSplitPane.VERTICAL_SPLIT);
	    setDividerSize(6);
	    setOpaque(false);
		
		//套餐列表
		JPanel temp=new JPanel(new BorderLayout());
	    JPanel nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
	    nor.add(add);
	    nor.add(del);
	    nor.add(refresh);
	    add.addActionListener(this);
	    del.addActionListener(this);
	    refresh.addActionListener(this);
   	    temp.add(nor,BorderLayout.NORTH);
   	    
   	    refresh.doClick();		//初始化up表
   	    up.addMouseListener(new MouseAdapter() {
   	    	public void mousePressed(MouseEvent e) {
   	    		if(e.getClickCount()==1){
   	    			refreshdown();
   	    		}
   	    		else if(e.getClickCount()==2){
   	    			adds.doClick();
   	    		}
   	    	}
		});
   	    temp.add(new JScrollPane(up),BorderLayout.CENTER);
   	    setLeftComponent(temp);
   	    
   	    //套餐明细
   	    temp=new JPanel(new BorderLayout());
   	    nor=new JPanel(new FlowLayout(FlowLayout.LEFT));
   	    nor.add(adds);
	    nor.add(dels);
	    adds.addActionListener(this);
	    dels.addActionListener(this);
	    temp.add(nor,BorderLayout.NORTH);
	    
   	    temp.add(new JScrollPane(down),BorderLayout.CENTER);
		setRightComponent(temp);
		
		setSize(Front.inFrame.getSize());
		setDividerLocation(0.5d);
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==add){
			new MenuDialog(true);
			refresh.doClick();
		}
		else if(e.getSource()==adds){
			int k=up.getSelectedRow();
			if(k>=0){
				JOptionPane.showMessageDialog(Front.front,new Pan(),"套餐明细添加",2,new ImageIcon());
			}
			else{
				JOptionPane.showMessageDialog(Front.front,"没有在套餐表格中选择目标套餐","注意",2,new ImageIcon());
			}
		}
		else if(e.getSource()==del){
			int k=up.getSelectedRow();
			if(k==-1){
				JOptionPane.showMessageDialog(Front.front,"没有在套餐表格中选择要删除的行？");
				return ;
			}
			
			int action=JOptionPane.showConfirmDialog(Front.front,"确定要删除当前套餐:"+Sql.getval(up, "商品名", k),"消息",2,1,new ImageIcon());
			if(action==0){
				Sql.mysqlprocedure("menu_del",Sql.getval(up, "编号", k));
				refresh.doClick();
			}
		}
		else if(e.getSource()==dels){
			if((up.getSelectedRow()==-1) || (down.getSelectedRow()==-1)){
				JOptionPane.showMessageDialog(Front.front,"没有在下表 <套餐子商品明细表> 或上表 <套餐列表> 中选择要删除的行？");
				return ;
			}
			
			int row1=up.getSelectedRow();
			ArrayList<String> v=new ArrayList<String>();
			v.add(Sql.getval(up, "编号", row1));		//商品编号
			v.add(indstr());	//商品编号组成的字符串
			//提交菜品
			boolean boo=Sql.mysqlprocedure("menu_linkdel",v);
			if(boo) refreshdown();
		}
		else if(e.getSource()==refresh){
			Sql.getArrayToTable("select * from menu where 分类='套餐';", this, up);
			Sql.TableAtt(up, false, true);
			//清空down表
			DefaultTableModel mo=(DefaultTableModel)down.getModel();
			while(down.getRowCount()>0){
				mo.removeRow(0);
			}
		}
	}
	
	//根据索引找出套餐绑定的商品
	private void refreshdown(){
	 	String ind=Sql.getval(up, "编号", up.getSelectedRow());
		String temp[]=Sql.getString("select 备注 from menu where 编号="+ind, this);
		if(temp.length>0){
			Sql.getArrayToTable("select * from menu where '"+temp[0]+"' like concat('%',编号,'%')",this,down);
			Sql.TableAtt(down, true, false);
		}
		else{
			DefaultTableModel model = (DefaultTableModel)down.getModel();
			while(down.getRowCount()>0){
				model.removeRow(0);
			}
		}
	}
	
	//down表，即套餐明细表中所有子商品的索引组成字符串,仅供删除子商品使用
	private String indstr(){
		String s="";
		int row=down.getSelectedRow();
		for(int k=0;k<down.getRowCount();k++){
			if(k==row)	continue;
			s=s+down.getValueAt(k, 0).toString()+",";
		}
		return s ;
	}

	//内部类
	class Pan extends JSplitPane implements ActionListener,DocumentListener{
		private static final long serialVersionUID = -8086828318439759983L;
		private JPanel right =new JPanel(new BorderLayout());	//右边的卡片布局面板
		private JTable t = Sql.getTable();
		private JTextField sel = new JTextField(20);
		public Pan(){
			setPreferredSize(new Dimension(800, 500));
			
			//左边的菜品分类栏
			JPanel left=new JPanel(new ModifiedFlowlayout(FlowLayout.LEFT));		//左边的菜单面板
			for(String temp : Var.getMenu_class()){
				if(temp.equals("套餐")) continue;
				JButton b=new JButton(temp);
				b.addActionListener(this);
				b.setPreferredSize(new Dimension(110,36));
				b.setToolTipText(temp);
				left.add(b);
			}
			t.addMouseListener(new MouseAdapter() {
				public void mouseClicked(MouseEvent e){
					if (e.getClickCount() == 2){	//处理双击事件
						sub();
			        }
				}
			});
			
			JPanel sou1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			sou1.add(new JLabel("输入 [商品名,商品编号 或 商品助记符] 查询："));
			sou1.add(sel);
			JPanel sou2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			sou2.add(new JLabel("双击目标添加对应子商品, 套餐中子商品不可以又是套餐、系统已过滤掉, 查询最多返回前300行"));
			sel.getDocument().addDocumentListener(this);
			JPanel sou = new JPanel(new GridLayout(2, 1, 0, 0));
			sou.add(sou1);
			sou.add(sou2);
			
			right.add("Center",new JScrollPane(t));
			right.add("South",sou);

			JScrollPane lefts=new JScrollPane(left);
			lefts.getVerticalScrollBar().setUnitIncrement(18);	//滚动量
			setLeftComponent(lefts);
			setRightComponent(right);
			setOrientation(JSplitPane.HORIZONTAL_SPLIT);
			setSize(Front.inFrame.getSize());
			setDividerSize(7);
			setDividerLocation(0.12d);
			setOneTouchExpandable(true);
		}
		public void actionPerformed(ActionEvent e){
			String s=e.getActionCommand();
			s = "select 编号,分类,商品名,价格,单位,助记符,备注 from menu where 分类='"+s+"'" ;
			Sql.getArrayToTable(s, this, t);
			Sql.TableAtt(t, true, false);
		}
		
		private void sub(){
			int row1=up.getSelectedRow();
			int row2=t.getSelectedRow();
			
			String desind = Sql.getval(t, "编号", row2) ;
			for(int k=0;k<down.getRowCount();k++){
				String chind = down.getValueAt(k, 0).toString();
				if(chind.equals(desind)) {
					JOptionPane.showMessageDialog(Front.front, "目标商品已存在于当前套餐中。");
					return ;
				}
			}
			
			ArrayList<String> v=new ArrayList<String>();
			v.add(Sql.getval(up, "编号", row1));	//商品编号
			v.add(indstrall(desind));	//商品编号组成的字符串
			//提交菜品
			Sql.mysqlprocedure("menu_linkadd",v);
			refreshdown();	//刷新套餐明细表，即down表
		}
		
		//down表，即套餐明细表中所有子商品的索引组成字符串
		private String indstrall(String newind){
			String s="";
			for(int k=0;k<down.getRowCount();k++){
				s=s+down.getValueAt(k, 0).toString()+",";
			}
			return s+newind ;
		}
		
		public void changedUpdate(DocumentEvent e) {}
		public void insertUpdate(DocumentEvent e) {
			String s = sel.getText();
			if(s.isEmpty()) return ;
			String sql="select 编号,分类,商品名,价格,单位,助记符,备注 from menu " +
					"where 分类<>'套餐' and (编号 like '%"+s+"' or 商品名 like '%"+s+"%' or 助记符 like '%"+s+"%') limit 0,300" ;
			Sql.getArrayToTable(sql, this, t);
			Sql.TableAtt(t, true, false);
		}
		public void removeUpdate(DocumentEvent e) {
			insertUpdate(e);
		}
	}
}
