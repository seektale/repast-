package bill;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import root.Front;
import root.Sql;
public class Interface_Design extends JInternalFrame implements ActionListener{
	private static final long serialVersionUID = 2955920470363246923L;
    private final JPanel Pan=new JPanel(new BorderLayout());
    private final JPanel up=new JPanel(new BorderLayout());
    private final JComboBox<String> dbase=new JComboBox<String>(new String[]{"Sybase"});
    private final JTextField a=new JTextField();
    private final JTextField b=new JTextField();
    private final JTextField c=new JTextField();
    private final JTextField d=new JTextField();
    private final JTextField e=new JTextField();
    private final JTextField f=new JTextField();
    private final JTextField sqlval[] = new JTextField[6];
    private final JTable t[] = new JTable[6];
    private final JTabbedPane tab = new JTabbedPane();
    private final JButton save=new JButton("保存参数");
    private final JButton test=new JButton("测试连接(测试前请先保存)");
    public Interface_Design(){
		super("接口设计(目前主要对西软[Sybase]系统进行对接)",true,true,true,true);
		setContentPane(Pan);
	    setResizable(true);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    Pan.add(up,BorderLayout.NORTH);
	    
	    for(int x=0; x<6; x++){
	    	t[x] = Sql.getTable();
	    	tab.addTab("sql - "+x, new JScrollPane(t[x]));
	    }
	    Pan.add(tab,BorderLayout.CENTER);
	    
	    JPanel grid=new JPanel(new BorderLayout());
	    grid.setBorder(BorderFactory.createTitledBorder(""));
	    JPanel gridw=new JPanel(new GridLayout(7,1,6,3)); 
	    gridw.add(new JLabel("接口数据库产品类型："));
	    gridw.add(new JLabel("数据库名称："));
	    gridw.add(new JLabel("函数："));
	    gridw.add(new JLabel("地址 IP Address："));
	    gridw.add(new JLabel("端口 Port："));
	    gridw.add(new JLabel("连接帐号 Acount："));
	    gridw.add(new JLabel("连接密码 Password："));
	    JPanel gridc=new JPanel(new GridLayout(7,1,6,3));
	    gridc.add(dbase);
	    gridc.add(a);
	    gridc.add(b);
	    gridc.add(c);
	    gridc.add(d);
	    gridc.add(e);
	    gridc.add(f);
	    grid.add("West",gridw);
	    grid.add("Center",gridc);
	    up.add(grid,BorderLayout.WEST);
	    
	    grid=new JPanel(new BorderLayout());
	    grid.setBorder(BorderFactory.createTitledBorder(""));
	    gridw=new JPanel(new GridLayout(6,1,6,3)); 
	    gridw.add(new JLabel("SQLA："));
	    gridw.add(new JLabel("SQLB："));
	    gridw.add(new JLabel("SQLC："));
	    gridw.add(new JLabel("SQLD："));
	    gridw.add(new JLabel("SQLE："));
	    gridw.add(new JLabel("SQLF："));
	    gridc=new JPanel(new GridLayout(6,1,6,3));
	    for(int x=0; x<6; x++){
	    	sqlval[x] = new JTextField();
	    	gridc.add(sqlval[x]);
	    }
	    grid.add(gridw,BorderLayout.WEST);
	    grid.add(gridc,BorderLayout.CENTER);
	    up.add(grid,BorderLayout.CENTER);
	    
	    JPanel lefts=new JPanel(new FlowLayout(FlowLayout.LEFT,10,2));
	    test.addActionListener(this);
	    save.addActionListener(this);
	    lefts.add(save);
	    lefts.add(test);
	    grid.add(lefts,BorderLayout.SOUTH);
	    
	    init();
    }
	public void actionPerformed(ActionEvent ea) {
		if(ea.getSource()==test){
			new Sybase(t);
			up.updateUI();
		}
		if(ea.getSource()==save){
			final ArrayList<String> v=new ArrayList<String>();
			v.add(dbase.getSelectedItem()+"");
			v.add(a.getText());
			v.add(b.getText());
			v.add(c.getText());
			v.add(d.getText());
			v.add(e.getText());
			v.add(f.getText());
			
			for(int x=0; x<6; x++){
		    	v.add(sqlval[x].getText());
		    }
			
			Sql.mysqlprocedure("interface_var",v);
			init();
		}
	}
	private void init(){		 //初始化参数
		final String sql = "select item,value,remark from general where name='interface' ";
		final ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
		final HashMap<String, String> me=new HashMap<String, String>();
		for(String temp[] : arr){
			me.put(temp[0], temp[1]);
			if(temp[0].equals("sqla")) tab.setTitleAt(0, temp[2]);
			if(temp[0].equals("sqlb")) tab.setTitleAt(1, temp[2]);
			if(temp[0].equals("sqlc")) tab.setTitleAt(2, temp[2]);
			if(temp[0].equals("sqld")) tab.setTitleAt(3, temp[2]);
			if(temp[0].equals("sqle")) tab.setTitleAt(4, temp[2]);
			if(temp[0].equals("sqlf")) tab.setTitleAt(5, temp[2]);
		}
		
	    dbase.setSelectedItem(me.get("db_style"));
	    a.setText(me.get("db_name"));
	    b.setText(me.get("function"));
	    c.setText(me.get("ip"));
	    d.setText(me.get("port"));
	    e.setText(me.get("account"));
	    f.setText(me.get("password"));
	    
	    sqlval[0].setText(me.get("sqla"));
	    sqlval[1].setText(me.get("sqlb"));
	    sqlval[2].setText(me.get("sqlc"));
	    sqlval[3].setText(me.get("sqld"));
	    sqlval[4].setText(me.get("sqle"));
	    sqlval[5].setText(me.get("sqlf"));
	    
	    for(int x=0; x<6; x++){
	    	t[x].setName(sqlval[x].getText());
	    }
	    
	}
}

