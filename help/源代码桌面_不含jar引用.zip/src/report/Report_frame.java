package report;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import log.AdvSelect;
import pub.DateUI;
import root.Front;
import root.Sql;
public class Report_frame extends JInternalFrame implements ActionListener{
	private static final long serialVersionUID = 4223236164786894393L;
	private JPanel norA = new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JPanel norB = new JPanel(new FlowLayout(FlowLayout.LEFT));
	private JTextField from = new JTextField(8);
	private JTextField to   = new JTextField(8);
	private JTextField who  = new JTextField(10);
	public  JTable t = Sql.getTable();
	private Report_tree tree=new Report_tree(t);
	private JButton sel = new JButton("查询");
	private JButton advsel = new JButton("高级查询(主要用于数据分析)");
	private JButton groupbill = new JButton("账单数量及人数统计");
	private JButton groupbillcash = new JButton("账单结算分组");
	private JButton groupdish = new JButton("商品收入分组");
	private JLabel tip = new JLabel("   以 [#] 号结束的报表将在 收银快捷报表 中体现");
	public Report_frame(){
		super("财务报表",true,true,true,true);
		JPanel Pan=new JPanel(new BorderLayout());
		setContentPane(Pan);
	    setVisible(true);
	    setSize(Front.inFrame.getSize());
	    
	    tree.setComponentPopupMenu(getMenu());
	    nor();
	    norB.add(advsel);
	    norB.add(groupbill);
	    norB.add(new JLabel("   ※  结算收入分组高级查询==>"));
	    norB.add(groupbillcash);
	    norB.add(groupdish);
	    JPanel nor = new JPanel(new GridLayout(2, 1, 0, 0));
	    nor.add(norA);
	    nor.add(norB);
	    Pan.add(nor,BorderLayout.NORTH);
		Pan.add(new JScrollPane(tree),BorderLayout.WEST);
		Pan.add(new JScrollPane(t),BorderLayout.CENTER);
		Pan.setOpaque(false);
	}
	private void nor(){
		from.setBackground(Color.YELLOW);
		to.setBackground(Color.YELLOW);
		sel.setForeground(Color.BLUE);
		sel.addActionListener(this);
		advsel.addActionListener(this);
		groupbill.addActionListener(this);
		groupbillcash.addActionListener(this);
		groupdish.addActionListener(this);
		from.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent arg0) {
				DateUI d = new DateUI();
				if(d.toString().isEmpty()) return ;
				from.setText(d.toString());
			}
		});
		to.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent arg0) {
				DateUI d = new DateUI();
				if(d.toString().isEmpty()) return ;
				to.setText(d.toString());
			}
		});
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		from.setText(df.format(new Date()));
		to.setText(df.format(new Date()));
		
		norA.add(new JLabel("从："));
		norA.add(from);
		norA.add(new JLabel("到："));
		norA.add(to);
		norA.add(new JLabel(" ※ "));

		norA.add(new JLabel("   "));
		norA.add(new JLabel("参数(工号/商品名等)："));
		norA.add(who);
		
		norA.add(new JLabel("   "));
		norA.add(sel);
		norA.add(tip);
	}
	//右键菜单
	private JPopupMenu getMenu(){
		JPopupMenu pop=new JPopupMenu();
		add("编辑报表定义",true,pop);
		add("新增报表",false,pop);
		add("重命名报表",false,pop);
		add("变更报表所属节点",true,pop);
		add("删除报表",false,pop);
		return pop;
	}
	private void add(String name,boolean b,JPopupMenu pop){
		JMenuItem m = new JMenuItem(name);
		m.addActionListener(this);
		pop.add(m);
		if(b)	pop.addSeparator();
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==sel){
			select();
			return ;
		}
		if(e.getSource()==groupbill){
			new Groupbilljust(t);
			return ;
		}
		if(e.getSource()==groupbillcash){
			new Groupbill(t);
			return ;
		}
		if(e.getSource()==groupdish){
			new Groupdish(t);
			return ;
		}
		if(e.getSource()==advsel){
			tablesel ts = new tablesel();
			ts.show(advsel, 1, advsel.getHeight());
			return ;
		}
		
		if(e.getActionCommand().equals("编辑报表定义")){
			sub();
		}
		else if(e.getActionCommand().equals("删除报表")){
			int k=JOptionPane.showConfirmDialog(Front.front,"确定删除当前节点："+tree.selected()+" ?","Baicos",0);
			if(k==0){
				ArrayList<String> v=new ArrayList<String>();
				v.add(tree.selected());
				Sql.mysqlprocedure("report_del",v);
				tree.refresh();
			}
		}
		//剩下的三种情况为：新增报表,重命名报表,变更报表所属节点
		else{
			new Dia_edit(e.getActionCommand());
		}
	}
	
	private void select(){
		if(!tree.leaf()){
			JOptionPane.showMessageDialog(Front.front, "请先选择子节点", "注意", 2);
			return ;
		}
		
		String dep=tree.selected();
		String s[]=Sql.getString("select remark from general where name='report' and value='"+dep+"';", this);
		if(s.length>1){
			String err = "报表节点："+dep+" 共有"+s.length+"个,请先在数据库general表中对报表名进行修正。" ;
			JOptionPane.showMessageDialog(Front.front, err, "错误", 0);
			return ;
		}
		if(s.length==0){
			JOptionPane.showMessageDialog(Front.front, "报表节点："+dep+" 不存在。", "消息", 2);
			return ;
		}
		
		if(s[0].isEmpty()){
			JOptionPane.showMessageDialog(Front.front, "报表节点："+dep+" 未定义。", "消息", 2);
			return ;
		}
		while(t.getRowCount()>0) ((DefaultTableModel)t.getModel()).removeRow(0);
		((DefaultTableModel)t.getModel()).setColumnIdentifiers(new String[]{});
		
		//读取第一行数据
		int k=s[0].indexOf("\n");
		String val = "" ;
		if(k>0){
			val = s[0].substring(0,k);
		}
		
		if(val.startsWith("#")){
			//@StartTime,@EndTime 代表你在打开报表之前可能要先确定开始时间和结束时间
			if(val.contains("@StartTime") && val.contains("@EndTime")){
				if(from.getText().isEmpty() || to.getText().isEmpty()){
					JOptionPane.showMessageDialog(Front.front, "需要指定 [开始日期] 与 [结止日期]", "消息", 2);
					return ;
				}
				s[0] = s[0].replace("@StartTime", from.getText());
				s[0] = s[0].replace("@EndTime", to.getText());
			}
			//指定日期
			if(val.contains("@DayTime")){
				if(from.getText().isEmpty()){
					JOptionPane.showMessageDialog(Front.front, "需要指定 一个日期 (即开始日期)", "消息", 2);
					return ;
				}
				s[0] = s[0].replace("@DayTime", from.getText());
			}
			//输入参数
			if(val.contains("@String")){
				if(who.getText().isEmpty()){
					JOptionPane.showMessageDialog(Front.front, "需要指定  [ 参数 ]", "消息", 2);
					return ;
				}
				s[0] = s[0].replace("@String", who.getText());
			}
		}
		
		Sql.getArrayToTable(s[0], this, t);
		Sql.TableAtt(t, true, false);
		tip.setText("当前查询结果共："+t.getRowCount()+" 条");
	}
	
	//对话框，用于修改报表的定义
	private void sub(){
		String val=tree.selected();
		final JLabel msg=new JLabel("字符提示");
		final JTextArea text=new JTextArea("");
		
		String s[]=Sql.getString("select remark from general where name='report' and value='"+val+"'", this);
		if(s.length==1)	text.setText(s[0]);
		else msg.setText("报表节点："+val+" 可能不存在,找不到sql语句。");
		
		text.setLineWrap(true);
		text.setWrapStyleWord(true);
		//只能保证宽，但高随文字多少自动调整
		text.setSize(new Dimension(800,200));
		//不要使用 text.setPreferredSize(new Dimension(500,120));
		text.getDocument().addDocumentListener(new DocumentListener() {
			public void removeUpdate(DocumentEvent e) {
				insertUpdate(e);
			}
			public void insertUpdate(DocumentEvent e) {
				int k=text.getText().length();
				if(k<1024){
					msg.setForeground(Color.BLUE);
					msg.setText("当前已输入字符数："+k+" <1024");
				}
				else{
					msg.setForeground(Color.RED);
					msg.setText("当前已输入字符数："+k+" >1024");
				}
			}
			public void changedUpdate(DocumentEvent arg0) {}
		});
		
		JPanel p=new JPanel(new BorderLayout());
		p.add(new JScrollPane(text),BorderLayout.CENTER);
		p.add(msg,BorderLayout.SOUTH);
		
		int action=JOptionPane.showConfirmDialog(Front.front, p, "当前对象："+val, 2, 1, new ImageIcon());
		if(action==0){
			ArrayList<String> v=new ArrayList<String>();
			v.add(val);
			v.add(text.getText());
			Sql.mysqlprocedure("report_save",v);
		}
	}
		
	/*
	 * 内部类,用于新增报表和移动报表节点位置
	 * */
	class Dia_edit extends JDialog implements ActionListener{
		private static final long serialVersionUID = 146546465L;
		private JComboBox<String> com;
		private JTextField text_val=new JTextField();
		
		private JButton add=new JButton("新增");
		private JButton rename=new JButton("重命名");
		private JButton cha=new JButton("变更");
		private JButton clo=new JButton("返回");
		
		private String val=tree.selected();
		private Dia_edit(String action){
			super(new JFrame(),true);
			setTitle(action);
			setSize(360, 140);
			setLayout(new BorderLayout());
			setResizable(false);
			setLocationRelativeTo(null);	//初始位置在屏幕正中间
			
			add.setEnabled(false);
			rename.setEnabled(false);
			cha.setEnabled(false);
			
			JPanel cen=new JPanel(new GridLayout(2, 2, 5, 6));
			cen.add(new JLabel(" 支节点："));
			cen.add(new JLabel(" 报表名："));
			String s[]=Sql.getString("select distinct item from general where name='report'", this);
			com=new JComboBox<String>(s);
			cen.add(com);
			cen.add(text_val);
			add(cen,BorderLayout.CENTER);
			
			JPanel sou=new JPanel(new FlowLayout(FlowLayout.RIGHT));
			sou.add(add);
			sou.add(rename);
			sou.add(cha);
			sou.add(clo);
			add.addActionListener(this);
			rename.addActionListener(this);
			cha.addActionListener(this);
			clo.addActionListener(this);
			add(sou,BorderLayout.SOUTH);
			
			if(action.startsWith("变更")){
				text_val.setEditable(false);
				text_val.setBackground(Color.LIGHT_GRAY);
				text_val.setText(val);
				cha.setEnabled(true);
			}
			else if(action.startsWith("重命名")){
				com.setEnabled(false);
				text_val.setText(val);
				rename.setEnabled(true);
			}
			else{
				add.setEnabled(true);
			}
			setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			boolean b=false;
			//添加报表
			if(e.getSource()==add){
				ArrayList<String> v=new ArrayList<String>();
				v.add(com.getSelectedItem()+"");
				v.add(text_val.getText());
				b=Sql.mysqlprocedure("report_add",v);
			}
			//重命名
			else if(e.getSource()==rename){
				ArrayList<String> v=new ArrayList<String>();
				v.add(val);
				v.add(text_val.getText());
				b=Sql.mysqlprocedure("report_rename",v);
			}
			//变更节点
			else if(e.getSource()==cha){
				ArrayList<String> v=new ArrayList<String>();
				v.add(com.getSelectedItem()+"");
				v.add(text_val.getText());
				b=Sql.mysqlprocedure("report_cha",v);
			}
			else if(e.getSource()==clo){
				dispose();
			}
			if(b)	tree.refresh();
		}
	}
	
	
	/*
	 * 内部类,用于表格选择
	 * */
	class tablesel extends JPopupMenu implements ActionListener{
		private static final long serialVersionUID = -182592350034196L;
		public tablesel(){
			String sql = "select tables.`TABLE_NAME`, tables.`TABLE_COMMENT` from information_schema.tables " +
			 			 "where (tables.`TABLE_SCHEMA` = 'repast') #查看所有表格信息";
			
			ArrayList<String[]> arr = Sql.getArrayToArrary(sql, this);
			for(String temp[] : arr){
				String val="<tr><th align=left width=80>"+temp[0]+"</th><th>"+temp[1]+"</th></tr>";
				JMenuItem c = new JMenuItem("<html><body><table border=none>"+val+"</table></body></html>");
				c.setPreferredSize(new Dimension(260, 18));
				c.setActionCommand(temp[0]);
				c.addActionListener(this);
				add(c);
			}
		}
		public void actionPerformed(ActionEvent e) {
			new AdvSelect(e.getActionCommand(),t);
		}
	}
}

