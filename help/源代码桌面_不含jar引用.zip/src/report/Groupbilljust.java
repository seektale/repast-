package report;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import pub.DateUI;
import root.Front;
import root.Sql;
public class Groupbilljust extends JDialog implements ActionListener,MouseListener{
	private static final long serialVersionUID = 2323602568904711269L;
	private JPanel con = new JPanel(new BorderLayout(3,3));
	private JTextField from = new JTextField(8);
	private JTextField to   = new JTextField(8);
	private JRadioButton day = new JRadioButton("按天");
	private JRadioButton week = new JRadioButton("按周");
	private JRadioButton month = new JRadioButton("按月");
	private JRadioButton year = new JRadioButton("按年");
	private JTextArea sqltip = new JTextArea(3,6);
	private JButton ok = new JButton("查询");
	private JButton exit = new JButton("退出");
	private ArrayList<JLabel> sequence = new ArrayList<JLabel>();	//分组顺序提示标签
	private ArrayList<JLabel> parameter = new ArrayList<JLabel>();	//选择的参数
	private ArrayList<String> group = new ArrayList<String>();		//选择的组(名字为易懂的列名)
	private ArrayList<String> groupcol = new ArrayList<String>();	//选择的组(名字为数据库列名)
	private JTable t;
	public Groupbilljust(JTable t){
		super(Front.front, true);
		this.t=t;
		JPanel nor = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JPanel left = new JPanel(new GridLayout(10, 1, 2, 2));
		JPanel cen = new JPanel(new GridLayout(10, 1, 2, 2));
		JPanel right = new JPanel(new GridLayout(10, 1, 2, 2));
		JPanel sou = new JPanel(new BorderLayout());
		sou.add(new JScrollPane(sqltip),BorderLayout.CENTER);
		JPanel radio = new JPanel(new FlowLayout(FlowLayout.LEFT));
		radio.add(new JLabel("时间段分组选择:"));
		radio.add(day);
		radio.add(week);
		radio.add(month);
		radio.add(year);
		sou.add(radio,BorderLayout.NORTH);
		JPanel soubut = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		soubut.add(ok);
		soubut.add(exit);
		sou.add(soubut,BorderLayout.SOUTH);
		ok.addActionListener(this);
		exit.addActionListener(this);
		sqltip.setBackground(Color.LIGHT_GRAY);
		sqltip.setEditable(false);
		sqltip.setWrapStyleWord(true);
		sqltip.setLineWrap(true);
		sqltip.setText("# 如需输入空字符串,可使用空格代替");
		
		nor.add(new JLabel("开始日期:"));
		nor.add(from);
		nor.add(new JLabel("结束日期:"));
		nor.add(to);
		day.setSelected(true);
		from.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent arg0) {
				DateUI d = new DateUI();
				if(d.toString().isEmpty()) return ;
				from.setText(d.toString());
			}
		});
		to.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent arg0) {
				DateUI d = new DateUI();
				if(d.toString().isEmpty()) return ;
				to.setText(d.toString());
			}
		});
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		from.setText(df.format(new Date()));
		to.setText(df.format(new Date()));
		ButtonGroup  radioGroup	= new ButtonGroup(); //单选组
	    radioGroup.add(day);
	    radioGroup.add(week);
	    radioGroup.add(month);
	    radioGroup.add(year);
		
		JLabel tip = new JLabel(" 分组顺序 ",JLabel.CENTER);
		tip.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));
		right.add(tip);
		
		tip = new JLabel("亦可指定某一个参数(AND关系)",JLabel.CENTER);
		tip.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));
		cen.add(tip);
		
		tip = new JLabel(" 选择分组顺序 ");
		tip.setBorder(BorderFactory.createBevelBorder(1, Color.gray, Color.white));
		left.add(tip);
		ArrayList<String[]> val = new ArrayList<String[]>();
		val.add(new String[]{"收银工号", "结账工号"});
		val.add(new String[]{"卡台区域", "区域"});
		val.add(new String[]{"卡台编号", "台号"});
		val.add(new String[]{"卡台别名", "别名"});
		val.add(new String[]{"宾客单位", "宾客单位"});
		val.add(new String[]{"主宾姓氏", "主宾姓氏"});
		val.add(new String[]{"开市时段", "选择时段"});
		val.add(new String[]{"销售员", "销售人员"});
		val.add(new String[]{"市场来源", "市场来源"});
		for(String temp[] : val){
			JCheckBox ch = new JCheckBox(temp[0]);
			ch.addActionListener(this);
			ch.setName(temp[1]);
			left.add(ch);
			
			JLabel lab = new JLabel("",JLabel.RIGHT);
			sequence.add(lab);
			right.add(lab);
			
			lab = new JLabel("",JLabel.CENTER);
			lab.setBackground(Color.ORANGE);
			lab.setOpaque(true);
			lab.setName(temp[1]);
			lab.addMouseListener(this);
			parameter.add(lab);
			cen.add(lab);
		}
		
		con.add(nor,BorderLayout.NORTH);
		con.add(left,BorderLayout.WEST);
		con.add(cen,BorderLayout.CENTER);
		con.add(right,BorderLayout.EAST);
		con.add(sou,BorderLayout.SOUTH);
		con.setBorder(BorderFactory.createTitledBorder(""));
		
		setContentPane(con);
		setTitle("账单数量及人数统计");
		setSize(380, 480);
		setLocationRelativeTo(Front.inFrame);  // 相对谁居中
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Front.logo);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == ok){
			if(timeCheck()) return ;
			String group = "";
			String select = "";
			String selectnull = "";
			String where = " where 结账时间>='"+from.getText()+"' and 结账时间<'"+to.getText()+"' ";
			if(day.isSelected()){
				group = "group by 日期 ";
				select = "SELECT date(`结账时间`) AS 日期,count(*) as 账单数量,sum(宾客人数) as 人数 ";
			}
			if(week.isSelected()){
				group = "group by 星期 ";
				select = "SELECT date_format(结账时间,'%x年-第%v周') AS 星期,count(*) as 账单数量,sum(宾客人数) as 人数 ";
			}
			if(month.isSelected()){
				group = "group by 月份 ";
				select = "SELECT date_format(结账时间,'%Y-%m') as 月份,count(*) as 账单数量,sum(宾客人数) as 人数 ";
			}
			if(year.isSelected()){
				group = "group by 年份 ";
				select = "SELECT year(结账时间) as 年份,count(*) as 账单数量,sum(宾客人数) as 人数 ";
			}
			selectnull = "SELECT '统计：',count(*) as 账单数量,sum(宾客人数) ";
			
			
			//分组group
			for(String temp : groupcol){
				group = group + "," + temp ;
			}
			//要查询的列select
			String getcol[] = getcol();
			for(String temp : getcol){
				select = select + "," + temp ;
				selectnull = selectnull + ",''" ;
			}
			//查询条件where
			for(JLabel lab : parameter){
				if(lab.getText().isEmpty())	continue ;
				where = where + "and " + lab.getName() + "='"+lab.getText()+"' ";
			}
			
			String sql =select+" from hqdeskgo "+where+group +" union "+ selectnull+" from hqdeskgo "+where;
			sqltip.setText(sql);
			Sql.getArrayToTable(sql, this, t);
			Sql.TableAtt(t, true, true);
			return ;
		}
		if(e.getSource() == exit){
			dispose();
			return ;
		}
		if(e.getSource() instanceof JCheckBox){
			JCheckBox ch = (JCheckBox)e.getSource();
			if(ch.isSelected()){
				group.add(ch.getText());
				groupcol.add(ch.getName());
				showsequence();
			}
			else{
				group.remove(ch.getText());
				groupcol.remove(ch.getName());
				showsequence();
			}
		}
	}
	
	private boolean timeCheck(){
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		try{
		    Date mm = df.parse(from.getText());
		    Date nn = df.parse(to.getText());
		    long k = mm.getTime() - nn.getTime();
		    if(k>0){
		    	JOptionPane.showMessageDialog(this, "开始时间不能大于结束时间", "时间段选择错误", 0);
		    	return true ;
		    }
		}
		catch (Exception e){
			JOptionPane.showMessageDialog(this, e.getMessage(), "时间段值<格式>不正确", 0);
			return true ;
		}
		return false ;
	}
	
	private void showsequence(){
		for(JLabel temp : sequence){
			temp.setText("");
		}
		for(int k=0; k<group.size(); k++){
			sequence.get(k).setText(group.get(k));
		}
	}
	
	private String[] getcol(){
		HashSet<String> hs = new HashSet<String>();
		for(String temp : groupcol){
			hs.add(temp);
		}
		for(JLabel lab : parameter){
			if(lab.getText().isEmpty())	continue ;
			hs.add(lab.getName());
		}
		String val[] = new String[hs.size()];
		hs.toArray(val);
		return val;
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		JLabel lab = (JLabel)e.getSource();
		if(e.getButton() == MouseEvent.BUTTON3){
			lab.setText("");
			return ;
		}
		
		String sql = lab.getName();
		
		if(sql.equals("宾客单位")){
			String val=JOptionPane.showInputDialog(this, "请输入<宾客单位>名称：");
			if(val==null) return ;
			lab.setText(val);
			return ;
		}
		if(sql.equals("主宾姓氏")){
			String val=JOptionPane.showInputDialog(this, "请输入<主宾姓氏>：");
			if(val==null) return ;
			lab.setText(val);
			return ;
		}
		
		if(sql.equals("台号")){
			sql = " select DISTINCT "+sql+" from hqdeskgo order by 台号 ";
		}
		else{
			sql = " select DISTINCT "+sql+" from hqdeskgo ";
		}
		
		String res[] = Sql.getString(sql, this);
		JPanel pan = new JPanel(new GridLayout(res.length/10+1, 10));
		if(res.length<10) pan.setLayout(new FlowLayout());
		else if(res.length%10==0) pan.setLayout(new GridLayout(res.length/10, 10));
		
		ButtonGroup  rg	= new ButtonGroup();
		for(String temp : res){
			if(temp.isEmpty()) continue;
			JRadioButton rad = new JRadioButton(temp);
			rad.setActionCommand(temp);
			rg.add(rad);
			pan.add(rad);
		}
		int k = JOptionPane.showConfirmDialog(this, pan, "请选择一个对象", 0, 1);
		if(k==0 && rg.getSelection()!=null){
			String cmd = rg.getSelection().getActionCommand();
			lab.setText(cmd);
		}
	}
}


