package desk_ago;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import root.Sql;
public class Desk_oldstart extends JPanel{
	private static final long serialVersionUID = 84114463252656566L;
	private JTextField m[]=new JTextField[9];
	private JTextArea re=new JTextArea(3,30); 		//开台备注
	private JLabel kai=new JLabel();				//提示信息
	private JLabel who=new JLabel();				//提示信息
	private String mealnum;
	public Desk_oldstart(String mealnum,String area,String index,String alias){
		this.mealnum=mealnum;
		for(int k=0;k<m.length;k++){
			m[k]=new JTextField();
			m[k].setEditable(false);
			m[k].setBackground(Color.lightGray);
		}
		BoxLayout layout=new BoxLayout(this, BoxLayout.Y_AXIS); //垂直布局
		setLayout(layout);

	    JPanel p=new JPanel(new GridLayout(6,1,0,8));	//左边根面板
	    
	    JLabel des = new JLabel("",JLabel.CENTER);
	    des.setFont(new Font("",Font.BOLD,16));
	    des.setForeground(Color.BLUE);
	    des.setText(area+" "+index+"号 "+alias);
	    p.add(des);
	    
	    JPanel temp=new JPanel(new BorderLayout());
		temp.add("West",new JLabel("顾客单位："));
		temp.add("Center",m[0]);
	    p.add(temp);
	    
	    p.add(getPan("主宾姓氏：","发票编码：",m[1],m[2]));
	    p.add(getPan("宾客人数：","选择时段：",m[3],m[4]));
	    p.add(getPan("销售人员：","VIP 客户 ：",m[5],m[6]));
	    p.add(getPan("市场来源：","联系电话：",m[7],m[8]));
	    add(p);
	    
		re.setLineWrap(true);         //自动换行
		re.setEnabled(false);
		add(Box.createVerticalStrut((18)));
		add(new JScrollPane(re));
		
	    add(Box.createVerticalStrut((18)));
		add(new JSeparator());
	    
		JPanel deskmsg=new JPanel(new FlowLayout(FlowLayout.LEFT));
		who.setForeground(Color.blue);
		who.setFont(new Font("粗体", Font.PLAIN, 18));
		deskmsg.add(who);
		add(deskmsg);

		deskmsg=new JPanel(new FlowLayout(FlowLayout.LEFT));
		kai.setForeground(Color.blue);
		kai.setFont(new Font("粗体", Font.PLAIN, 18));
		deskmsg.add(kai);
		add(deskmsg);
		
		refresh();
	}
	private JPanel getPan(String a,String b,JTextField x,JTextField y){
		JPanel gr=new JPanel(new GridLayout(1,2,5,2));
	    JPanel temp=new JPanel(new BorderLayout());
	    temp.add("West",new JLabel(a));
	    temp.add("Center",x);
	    gr.add(temp);
	    temp=new JPanel(new BorderLayout());
	    temp.add("West",new JLabel(b));
	    temp.add("Center",y);
	    gr.add(temp);
	    return gr;
	}

	//进行初始化
	public void refresh() {
		
		String sql="宾客单位,主宾姓氏,发票编码,宾客人数,选择时段,销售人员,VIP客户,市场来源,联系电话,备注,锁台,开台工号,开台时间,结账工号,结账时间";
		sql="select "+sql+" from hqdeskgo where 台次="+mealnum;
		String s[]=Sql.getString(sql, this);
		
    	if(s.length>0){
    		for(int k=0;k<m.length;k++){
    			m[k].setText(s[k]);
    		}
    		re.setText(s[9]);
    		kai.setText("<html><p>开："+s[11]+" "+s[12]+"</p><span>结："+s[13]+" "+s[14]+"</span></html>");
    		who.setText("编号 ==> "+mealnum);
		}
	}
}

