package desk_ago;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.PropertyVetoException;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import log.Select;
import root.Front;
import root.Sql;
public class Querybill extends JInternalFrame implements MouseListener,ActionListener{
	private static final long serialVersionUID = 628339174877004718L;
	private Select cho=new Select("select 台次,开台时间,开台工号,结账时间,结账工号,区域,台号,别名,选择时段 from hqdeskgo;");
	private JPanel Pan=new JPanel(new BorderLayout());
	public Querybill(){
		super("已班结历史账单查询",true,true,true,true);
		setContentPane(Pan);
	    setResizable(true);
	    setVisible(true);
	    setOpaque(false);
	    setSize(Front.inFrame.getSize());
	    
		Pan.add("North",cho);
		
		cho.t.addMouseListener(this);
		Pan.add("Center",new JScrollPane(cho.t));
		setOpaque(false);
		
		JButton b=new JButton("组合查询");
		cho.downpan.add(b);
		b.addActionListener(this);
		
		if(cho.downpan.timecol.getItemCount()==2){
			cho.downpan.timecol.setSelectedIndex(1);
		}
	}
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		if (e.getClickCount() == 2){	//处理双击事件
			int row=cho.t.getSelectedRow();
			String mealnum=Sql.getval(cho.t, "台次", row); //得到台次
			
			Desk_Frame temp=new Desk_Frame(mealnum);
			Front.inFrame.add(temp);
			
			//最大化
			try {
				temp.setMaximum(true);
			} catch (PropertyVetoException e1) {
				e1.printStackTrace();
			}
        }
	}
	public void mouseReleased(MouseEvent e) {}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		new Query_group(cho.t);
	}
}

