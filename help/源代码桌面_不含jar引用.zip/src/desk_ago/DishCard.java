package desk_ago;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import pub.ModifiedFlowlayout;
import pub.Var;
import root.Sql;
//已点菜品的卡片模型
class DishCard extends JPanel implements MouseListener{
	private static final long serialVersionUID = 3670002798090355435L;
	private JTable cookup;
	private JTable cookdown;
	public DishCard(Dish dish){
		cookup=dish.cookup;
		cookdown=dish.cookdown;
		setLayout(new ModifiedFlowlayout(FlowLayout.LEFT,Var.dishhgap(),Var.dishvgap()));
	}
	
	//下面的功能是能自动适应宽度
	private int reSize(){
		JScrollPane js=(JScrollPane)getParent().getParent();
		
		//布局时Var.dishhgap()，这里要先减去一个,还要减去滚动条约18
		int width=js.getWidth()-Var.dishhgap()-18;	
		if(width<=0) return 0;
		
		//除以方块的 宽度加间隙，即Var.dishw()+Var.dishhgap()
		int num=width / (Var.dishw()+Var.dishhgap());
		if(num==0) num=1;
		return width /num - Var.dishhgap() ;
	}
	
	//向面板中加入卡片菜品
	public void refresh(){
		removeAll();
		int width=reSize();	//写在开头，以勉反复运算
		for(int k=0;k<cookup.getRowCount();k++){
			//传入的值为商品的主键索引
			Pan p=new Pan(Integer.valueOf(getval("索引",k)),width);
			
			String cla=getval("属性",k);
			String te=getval("商品名",k);
			if(cla.isEmpty()){
				te=" "+te;
			}
			else{
				te="<html><body><font color=red>"+"["+cla+"]</font> "+te+"</body></html>";
			}
			p.add(getLabel(te));
			
			String pr=getval("实价",k);
			if(pr.endsWith(".00"))	pr=pr.replace(".00", "");
			String num=getval("数量",k);
			if(num.endsWith(".00"))	num=num.replace(".00", "");
			te=pr+" ￥"+"  ×"+num+getval("单位",k);
			if(!getval("折扣",k).equals("1")){
				te=te+"  ×"+getval("折扣",k);
			}
			p.add(getLabel(te));

			te=getval("点单员",k);
			if(getval("点单时间",k).length()>11)	te=te+" "+getval("点单时间",k).substring(11,19);
			p.add(getLabel(" "+te));
			
			JPanel temp=new JPanel(new FlowLayout(FlowLayout.LEFT));
			temp.add(getLabel("出单"));
			JCheckBox pri=new JCheckBox();
			pri.setEnabled(false);
			temp.add(pri);
			if(getval("出单",k).equals("0") || getval("出单",k).equals("-1")){
				pri.setSelected(false);
			}
			else{
				pri.setSelected(true);
			}
			temp.add(getLabel(getval("备注",k)));
			temp.setOpaque(false);
			p.add(temp);

			p.addMouseListener(this);
			add(p);
		}
		//起到刷新UI的界面，如果不这么做，窗口不会被刷新
		setVisible(false);
		setVisible(true);
	}
	private String getval(String col,int row){
		return Sql.getval(cookup, col, row);
	}
	private JLabel getLabel(String str){
		JLabel name=new JLabel(str);
		name.setFont(new Font(Var.dishfont(),Font.PLAIN,Var.dishtextsize()));
		name.setForeground(Var.getColor("商品显示前景"));
		return name;
	}
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent e) {
		Pan temp=(Pan)e.getSource();
		temp.setBorder(Sql.getBorder(1, ""));
	}
	public void mouseExited(MouseEvent e) {
		Pan temp=(Pan)e.getSource();
		temp.setBorder(Sql.getBorder(2, ""));
	}
	public void mousePressed(MouseEvent e) {
		int dishind=((Pan)e.getSource()).ind;
		if (e.getClickCount() == 1){
			Sql.getArrayToTable("select * from hqdishlog where 商品索引="+dishind, this, cookdown);
			Sql.TableAtt(cookdown, true, false);
        }
	}
	public void mouseReleased(MouseEvent e) {}
	
	//自定义商品描述面板
	class Pan extends JPanel{
		private static final long serialVersionUID = -158130390052855788L;
		public int ind;
		Pan(int ind, int width){
			this.ind=ind;
			
			setPreferredSize(new Dimension(Var.dishw(),Var.dishh()));
			if(width>0){
				setPreferredSize(new Dimension(width,Var.dishh()));
			}
			setLayout(new GridLayout(2, 2, 2, 0));
			
			setBackground(Var.getColor("商品显示背景"));
			setBorder(Sql.getBorder(2, ""));
		}
	}
}
